export {};
//# sourceMappingURL=hookFileService.test.d.ts.map