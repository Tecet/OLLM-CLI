/**
 * Integration Tests for Mode Transition Animator
 *
 * Tests the integration between PromptModeManager and ModeTransitionAnimator,
 * ensuring animations are properly triggered and managed during mode transitions.
 */
export {};
//# sourceMappingURL=ModeTransitionAnimator.integration.test.d.ts.map