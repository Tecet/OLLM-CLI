/**
 * Unit tests for compatibility matrix infrastructure
 *
 * Tests the compatibility test runner, result data structures,
 * and markdown documentation generator.
 */
export {};
//# sourceMappingURL=compatibilityMatrix.test.d.ts.map