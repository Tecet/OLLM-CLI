/**
 * Integration tests for model compatibility
 *
 * Tests representative models (general-purpose, code-specialized, small/fast)
 * for basic chat, streaming, tool calling, and context handling capabilities.
 *
 * These tests require a running LLM server and will skip gracefully if unavailable.
 */
export {};
//# sourceMappingURL=modelCompatibility.integration.test.d.ts.map