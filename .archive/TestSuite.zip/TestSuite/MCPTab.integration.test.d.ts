/**
 * Integration tests for MCPTab component
 *
 * Tests full user flows including:
 * - Server enable/disable with keyboard navigation
 * - Configuration persistence
 * - Server lifecycle management
 * - UI updates and state synchronization
 *
 * Validates: Requirements 2.1-2.7
 */
export {};
//# sourceMappingURL=MCPTab.integration.test.d.ts.map