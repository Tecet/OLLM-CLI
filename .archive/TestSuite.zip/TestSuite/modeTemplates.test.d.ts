/**
 * Tests for Mode Templates
 *
 * Tests that all mode templates are properly defined and contain expected content.
 */
export {};
//# sourceMappingURL=modeTemplates.test.d.ts.map