import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render } from 'ink-testing-library';
import { Text } from 'ink';
import { Dialog } from '../Dialog.js';
import { UIProvider } from '../../../../features/context/UIContext.js';
import { defaultDarkTheme } from '../../../../config/styles.js';
describe('Dialog', () => {
    const mockOnClose = vi.fn();
    beforeEach(() => {
        mockOnClose.mockClear();
    });
    describe('Rendering', () => {
        it('should render with title and content', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Dialog content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Test Dialog');
            expect(output).toContain('Dialog content');
        });
        it('should render with bold title', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Bold Title", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Bold Title');
        });
        it('should render children content', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsxs(Dialog, { title: "Title", onClose: mockOnClose, children: [_jsx(Text, { children: "First line" }), _jsx(Text, { children: "Second line" })] }) }));
            const output = lastFrame();
            expect(output).toContain('First line');
            expect(output).toContain('Second line');
        });
    });
    describe('Esc Key Handling', () => {
        it('should call onClose when Esc is pressed', async () => {
            const { stdin } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            // Simulate Esc key press
            stdin.write('\x1B'); // ESC character
            // Dialog defers close to the next tick so wait a macrotask
            await new Promise((r) => setTimeout(r, 0));
            expect(mockOnClose).toHaveBeenCalledTimes(1);
        });
        it('should not call onClose for other keys', () => {
            const { stdin } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            // Simulate other key presses
            stdin.write('a');
            stdin.write('b');
            stdin.write('\r'); // Enter
            expect(mockOnClose).not.toHaveBeenCalled();
        });
    });
    describe('Styling', () => {
        it('should use default width of 60', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            // Dialog should render (width is applied via Ink's Box component)
            const output = lastFrame();
            expect(output).toBeTruthy();
        });
        it('should accept custom width', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, width: 80, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toBeTruthy();
        });
        it('should use theme border color by default', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toBeTruthy();
        });
        it('should accept custom border color', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, borderColor: "red", children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toBeTruthy();
        });
        it('should use yellow title color by default', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Test Dialog');
        });
        it('should accept custom title color', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, titleColor: "cyan", children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Test Dialog');
        });
    });
    describe('Layout', () => {
        it('should have rounded border style', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            // Rounded borders use specific characters
            expect(output).toBeTruthy();
        });
        it('should have padding', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toBeTruthy();
        });
        it('should have margin between title and content', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Title", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Title');
            expect(output).toContain('Content');
        });
    });
    describe('Integration', () => {
        it('should work with complex content', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsxs(Dialog, { title: "Complex Dialog", onClose: mockOnClose, children: [_jsx(Text, { children: "Line 1" }), _jsx(Text, { color: "green", children: "Line 2" }), _jsx(Text, { bold: true, children: "Line 3" })] }) }));
            const output = lastFrame();
            expect(output).toContain('Complex Dialog');
            expect(output).toContain('Line 1');
            expect(output).toContain('Line 2');
            expect(output).toContain('Line 3');
        });
        it('should handle multiple Dialog instances', () => {
            const mockOnClose2 = vi.fn();
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsxs(_Fragment, { children: [_jsx(Dialog, { title: "Dialog 1", onClose: mockOnClose, children: _jsx(Text, { children: "Content 1" }) }), _jsx(Dialog, { title: "Dialog 2", onClose: mockOnClose2, children: _jsx(Text, { children: "Content 2" }) })] }) }));
            const output = lastFrame();
            expect(output).toContain('Dialog 1');
            expect(output).toContain('Dialog 2');
        });
    });
    describe('Accessibility', () => {
        it('should provide clear visual hierarchy', () => {
            const { lastFrame } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Accessible Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Main content" }) }) }));
            const output = lastFrame();
            expect(output).toContain('Accessible Dialog');
            expect(output).toContain('Main content');
        });
        it('should be keyboard navigable (Esc to close)', async () => {
            const { stdin } = render(_jsx(UIProvider, { initialTheme: defaultDarkTheme, children: _jsx(Dialog, { title: "Test Dialog", onClose: mockOnClose, children: _jsx(Text, { children: "Content" }) }) }));
            stdin.write('\x1B');
            await new Promise((r) => setTimeout(r, 0));
            expect(mockOnClose).toHaveBeenCalled();
        });
    });
});
//# sourceMappingURL=Dialog.test.js.map