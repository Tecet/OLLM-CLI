/**
 * Property-Based Tests for MCPTab Component
 *
 * Tests correctness properties using fast-check for:
 * - Configuration persistence (no data loss on save/load cycle)
 * - JSON validity after write
 * - Configuration integrity across restarts
 *
 * Validates: Requirements 2.3, 5.6, NFR-11, NFR-12
 */
export {};
//# sourceMappingURL=MCPTab.property.test.d.ts.map