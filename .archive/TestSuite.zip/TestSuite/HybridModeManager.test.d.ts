/**
 * Tests for HybridModeManager
 */
export {};
//# sourceMappingURL=HybridModeManager.test.d.ts.map