/**
 * Tests for HooksTab component
 */
export {};
//# sourceMappingURL=HooksTab.test.d.ts.map