import { jsx as _jsx } from "react/jsx-runtime";
import { render } from 'ink-testing-library';
import { describe, it, expect, vi } from 'vitest';
import { HookItem } from '../HookItem.js';
// Mock theme
const mockTheme = {
    name: 'default',
    bg: {
        primary: 'black',
        secondary: 'gray',
        tertiary: 'dim',
    },
    text: {
        primary: 'white',
        secondary: 'gray',
        accent: 'yellow',
    },
    role: {
        user: 'blue',
        assistant: 'green',
        system: 'gray',
        tool: 'magenta',
    },
    status: {
        success: 'green',
        error: 'red',
        warning: 'yellow',
        info: 'blue',
    },
    border: {
        primary: 'gray',
        secondary: 'dim',
        active: 'yellow',
    },
    diff: {
        added: 'green',
        removed: 'red',
    },
};
// Mock hook
const mockHook = {
    id: 'test-hook',
    name: 'Test Hook',
    command: 'echo',
    args: ['test'],
    source: 'user',
};
describe('HookItem', () => {
    it('should render hook name', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should show enabled indicator (●) when hook is enabled', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('●');
    });
    it('should show disabled indicator (○) when hook is disabled', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: false, hasFocus: false, isEnabled: false, theme: mockTheme }));
        expect(lastFrame()).toContain('○');
    });
    it('should apply focus styling when selected and has focus', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: true, hasFocus: true, isEnabled: true, theme: mockTheme }));
        // When selected and focused, text should be bold and yellow
        // We can't directly test styling, but we can verify the component renders
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should not apply focus styling when selected but no focus', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: true, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should not apply focus styling when has focus but not selected', () => {
        const { lastFrame } = render(_jsx(HookItem, { hook: mockHook, isSelected: false, hasFocus: true, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should call onSelect when provided', () => {
        const onSelect = vi.fn();
        render(_jsx(HookItem, { hook: mockHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme, onSelect: onSelect }));
        // Note: Ink doesn't support click events in testing, so we just verify
        // the component renders without errors when onSelect is provided
        expect(onSelect).not.toHaveBeenCalled();
    });
    it('should render with extension name if provided', () => {
        const hookWithExtension = {
            ...mockHook,
            extensionName: 'my-extension',
        };
        const { lastFrame } = render(_jsx(HookItem, { hook: hookWithExtension, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should render builtin hooks', () => {
        const builtinHook = {
            ...mockHook,
            source: 'builtin',
        };
        const { lastFrame } = render(_jsx(HookItem, { hook: builtinHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should render extension hooks', () => {
        const extensionHook = {
            ...mockHook,
            source: 'extension',
            extensionName: 'test-extension',
        };
        const { lastFrame } = render(_jsx(HookItem, { hook: extensionHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook');
    });
    it('should handle hooks with no args', () => {
        const hookNoArgs = {
            id: 'test-hook-no-args',
            name: 'Test Hook No Args',
            command: 'echo',
            source: 'user',
        };
        const { lastFrame } = render(_jsx(HookItem, { hook: hookNoArgs, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('Test Hook No Args');
    });
    it('should handle long hook names', () => {
        const longNameHook = {
            ...mockHook,
            name: 'This is a very long hook name that might need to be truncated or wrapped',
        };
        const { lastFrame } = render(_jsx(HookItem, { hook: longNameHook, isSelected: false, hasFocus: false, isEnabled: true, theme: mockTheme }));
        expect(lastFrame()).toContain('This is a very long hook name');
    });
});
//# sourceMappingURL=HookItem.test.js.map