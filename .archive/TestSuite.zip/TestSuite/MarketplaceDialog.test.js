import { jsx as _jsx } from "react/jsx-runtime";
import { describe, it, expect, vi, beforeEach } from 'vitest';
// Mock ServiceContext so MCPProvider can call `useServices()` during tests
vi.mock('../../../../features/context/ServiceContext.js', () => ({
    useServices: () => ({
        container: {
            getToolRegistry: () => ({
                register: () => { },
                unregister: () => { },
            }),
        },
    }),
}));
import { render } from 'ink-testing-library';
import { MarketplaceDialog } from '../MarketplaceDialog.js';
import * as MCPContextModule from '../../../contexts/MCPContext.js';
import { UIProvider } from '../../../../features/context/UIContext.js';
// Mock servers for testing
const mockServers = [
    {
        id: 'filesystem',
        name: 'filesystem',
        description: 'Secure file system operations',
        rating: 5,
        installCount: 10000,
        requiresOAuth: false,
        requirements: ['Node.js 18+'],
        command: 'npx',
        args: ['-y', '@modelcontextprotocol/server-filesystem'],
        category: 'File System',
        author: 'Anthropic',
    },
    {
        id: 'github',
        name: 'github',
        description: 'GitHub API integration',
        rating: 4.8,
        installCount: 8500,
        requiresOAuth: true,
        requirements: ['Node.js 18+', 'GitHub Personal Access Token'],
        command: 'npx',
        args: ['-y', '@modelcontextprotocol/server-github'],
        env: { GITHUB_PERSONAL_ACCESS_TOKEN: '' },
        category: 'Development',
        author: 'Anthropic',
    },
    {
        id: 'postgres',
        name: 'postgres',
        description: 'PostgreSQL database integration',
        rating: 4.7,
        installCount: 7200,
        requiresOAuth: false,
        requirements: ['Node.js 18+', 'PostgreSQL connection string'],
        command: 'npx',
        args: ['-y', '@modelcontextprotocol/server-postgres'],
        env: { POSTGRES_CONNECTION_STRING: '' },
        category: 'Database',
        author: 'Anthropic',
    },
];
// Mock MCP context (shape matches MCPContextValue)
const mockMCPContext = {
    state: {
        servers: new Map(),
        config: { mcpServers: {} },
        marketplace: mockServers,
        isLoading: false,
        error: null,
        operationsInProgress: new Map(),
    },
    toggleServer: vi.fn(),
    restartServer: vi.fn(),
    installServer: vi.fn(),
    uninstallServer: vi.fn(),
    configureServer: vi.fn(),
    configureOAuth: vi.fn(),
    refreshOAuthToken: vi.fn(),
    revokeOAuthAccess: vi.fn(),
    getServerHealth: vi.fn(),
    getServerLogs: vi.fn(),
    getServerTools: vi.fn(),
    setToolAutoApprove: vi.fn(),
    searchMarketplace: vi.fn().mockResolvedValue(mockServers),
    refreshMarketplace: vi.fn(),
    refreshServers: vi.fn(),
    toolRouter: {},
};
// Mock UI context
const mockUIContext = {
    state: {
        theme: {
            text: { primary: 'white', secondary: 'gray' },
            border: { active: 'cyan', inactive: 'gray' },
            status: { success: 'green', error: 'red', warning: 'yellow', info: 'cyan' },
        },
    },
    dispatch: vi.fn(),
};
/**
 * Render MarketplaceDialog with mocked contexts
 */
function renderMarketplaceDialog(props) {
    return render(_jsx(UIProvider, { value: mockUIContext, children: _jsx(MarketplaceDialog, { ...props }) }));
}
describe('MarketplaceDialog', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        // Ensure useMCP returns our mocked context
        vi.spyOn(MCPContextModule, 'useMCP').mockReturnValue(mockMCPContext);
    });
    describe('Rendering', () => {
        it('should render dialog with title', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('MCP Marketplace');
        });
        it('should render search box', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('Search:');
            expect(lastFrame()).toContain('Type to search or press / to focus');
        });
        it('should render all marketplace servers', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('filesystem');
            expect(lastFrame()).toContain('github');
            expect(lastFrame()).toContain('postgres');
        });
        it('should display server count', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('3 servers found');
        });
        // Use mocked `useMCP` variants (below) to keep hook ordering consistent in tests.
        it('should show OAuth indicator for servers requiring OAuth', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            const frame = lastFrame();
            // GitHub requires OAuth
            expect(frame).toContain('🔐 OAuth');
        });
        it('should display server ratings as stars', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            const frame = lastFrame();
            // filesystem has 5 stars
            expect(frame).toContain('★★★★★');
            // github has 4.8 stars (4 full + half)
            expect(frame).toContain('★★★★½');
        });
        it('should display formatted install counts', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            const frame = lastFrame();
            expect(frame).toContain('10.0K installs');
            expect(frame).toContain('8.5K installs');
            expect(frame).toContain('7.2K installs');
        });
        it('should display server categories', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            const frame = lastFrame();
            expect(frame).toContain('File System');
            expect(frame).toContain('Development');
            expect(frame).toContain('Database');
        });
        it('should show navigation help text', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('↑↓: Navigate');
            expect(lastFrame()).toContain('Enter: Install');
            expect(lastFrame()).toContain('/: Search');
            expect(lastFrame()).toContain('Esc: Close');
        });
        it('should show tip in footer', () => {
            const onClose = vi.fn();
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('💡 Tip:');
        });
    });
    describe('Search Functionality', () => {
        it('should filter servers by name', async () => {
            const onClose = vi.fn();
            mockMCPContext.searchMarketplace.mockResolvedValue([mockServers[1]]); // github only
            const { stdin } = renderMarketplaceDialog({ onClose });
            // Focus search with /
            stdin.write('/');
            await new Promise(resolve => setTimeout(resolve, 100));
            // Type search query
            stdin.write('github');
            await new Promise(resolve => setTimeout(resolve, 100));
            expect(mockMCPContext.searchMarketplace).toHaveBeenCalledWith('github');
        });
        it('should filter servers by description', async () => {
            const onClose = vi.fn();
            mockMCPContext.searchMarketplace.mockResolvedValue([mockServers[2]]); // postgres only
            const { stdin } = renderMarketplaceDialog({ onClose });
            stdin.write('/');
            await new Promise(resolve => setTimeout(resolve, 100));
            stdin.write('database');
            await new Promise(resolve => setTimeout(resolve, 100));
            expect(mockMCPContext.searchMarketplace).toHaveBeenCalledWith('database');
        });
        it('should handle empty marketplace', () => {
            const onClose = vi.fn();
            const emptyContext = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: [] },
                searchMarketplace: vi.fn().mockResolvedValue([]),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValueOnce(emptyContext);
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('0 servers found');
        });
        it('should handle servers without categories', () => {
            const onClose = vi.fn();
            const serversWithoutCategory = [
                { ...mockServers[0], category: undefined },
            ];
            const contextWithoutCategory = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serversWithoutCategory },
                searchMarketplace: vi.fn().mockResolvedValue(serversWithoutCategory),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValueOnce(contextWithoutCategory);
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            // Should render without errors
            expect(lastFrame()).toContain('filesystem');
        });
        it('should handle very large install counts', () => {
            const onClose = vi.fn();
            const serverWithLargeCount = [
                { ...mockServers[0], installCount: 1500000 },
            ];
            const contextWithLargeCount = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serverWithLargeCount },
                searchMarketplace: vi.fn().mockResolvedValue(serverWithLargeCount),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValueOnce(contextWithLargeCount);
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('1.5M installs');
        });
        it('should handle ratings with half stars', () => {
            const onClose = vi.fn();
            const serverWithHalfStar = [
                { ...mockServers[0], rating: 3.7 },
            ];
            const contextWithHalfStar = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serverWithHalfStar },
                searchMarketplace: vi.fn().mockResolvedValue(serverWithHalfStar),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValueOnce(contextWithHalfStar);
            const { lastFrame } = renderMarketplaceDialog({ onClose });
            expect(lastFrame()).toContain('★★★½');
        });
        it('should close when Esc pressed', async () => {
            const onClose = vi.fn();
            const { stdin } = renderMarketplaceDialog({ onClose });
            stdin.write('\x1b'); // Esc
            await new Promise(resolve => setTimeout(resolve, 100));
            expect(onClose).toHaveBeenCalled();
        });
        it('should not close when Esc pressed in search mode', async () => {
            const onClose = vi.fn();
            const { stdin } = renderMarketplaceDialog({ onClose });
            // Enter search mode
            stdin.write('/');
            await new Promise(resolve => setTimeout(resolve, 100));
            // Press Esc (should exit search, not close dialog)
            stdin.write('\x1b');
            await new Promise(resolve => setTimeout(resolve, 100));
            expect(onClose).not.toHaveBeenCalled();
        });
    });
    describe('Loading and Error States', () => {
        it('should show loading state', async () => {
            const onClose = vi.fn();
            mockMCPContext.searchMarketplace.mockImplementation(() => new Promise(resolve => setTimeout(() => resolve(mockServers), 1000)));
            const { lastFrame, stdin } = renderMarketplaceDialog({ onClose });
            stdin.write('/');
            await new Promise(resolve => setTimeout(resolve, 100));
            stdin.write('test');
            await new Promise(resolve => setTimeout(resolve, 100));
            const frame = lastFrame();
            expect(frame).toMatch(/Loading servers/);
        });
        it('should show error state on search failure', async () => {
            const onClose = vi.fn();
            mockMCPContext.searchMarketplace.mockRejectedValue(new Error('Network error'));
            const { lastFrame, stdin } = renderMarketplaceDialog({ onClose });
            stdin.write('/');
            await new Promise(resolve => setTimeout(resolve, 100));
            stdin.write('test');
            await new Promise(resolve => setTimeout(resolve, 200));
            const frame = lastFrame();
            expect(frame).toContain('✗ Network error');
        });
    });
    describe('Edge Cases', () => {
        // removed MCPProvider-wrapped variant; using `useMCP` spy variant below
        it('should handle empty marketplace', () => {
            const onClose = vi.fn();
            const emptyContext = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: [] },
                searchMarketplace: vi.fn().mockResolvedValue([]),
            };
            // Ensure useMCP returns the empty context for this test
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValue(emptyContext);
            const { lastFrame } = render(_jsx(UIProvider, { value: mockUIContext, children: _jsx(MarketplaceDialog, { onClose: onClose }) }));
            expect(lastFrame()).toContain('0 servers found');
        });
        // removed MCPProvider-wrapped variant; using `useMCP` spy variant below
        it('should handle servers without categories', () => {
            const onClose = vi.fn();
            const serversWithoutCategory = [
                { ...mockServers[0], category: undefined },
            ];
            const contextWithoutCategory = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serversWithoutCategory },
                searchMarketplace: vi.fn().mockResolvedValue(serversWithoutCategory),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValue(contextWithoutCategory);
            const { lastFrame } = render(_jsx(UIProvider, { value: mockUIContext, children: _jsx(MarketplaceDialog, { onClose: onClose }) }));
            // Should render without errors
            expect(lastFrame()).toContain('filesystem');
        });
        // removed MCPProvider-wrapped variant; using `useMCP` spy variant below
        it('should handle very large install counts', () => {
            const onClose = vi.fn();
            const serverWithLargeCount = [
                { ...mockServers[0], installCount: 1500000 },
            ];
            const contextWithLargeCount = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serverWithLargeCount },
                searchMarketplace: vi.fn().mockResolvedValue(serverWithLargeCount),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValue(contextWithLargeCount);
            const { lastFrame } = render(_jsx(UIProvider, { value: mockUIContext, children: _jsx(MarketplaceDialog, { onClose: onClose }) }));
            expect(lastFrame()).toContain('1.5M installs');
        });
        // removed MCPProvider-wrapped variant; using `useMCP` spy variant below
        it('should handle ratings with half stars', () => {
            const onClose = vi.fn();
            const serverWithHalfStar = [
                { ...mockServers[0], rating: 3.7 },
            ];
            const contextWithHalfStar = {
                ...mockMCPContext,
                state: { ...mockMCPContext.state, marketplace: serverWithHalfStar },
                searchMarketplace: vi.fn().mockResolvedValue(serverWithHalfStar),
            };
            vi.spyOn(MCPContextModule, 'useMCP').mockReturnValue(contextWithHalfStar);
            const { lastFrame } = render(_jsx(UIProvider, { value: mockUIContext, children: _jsx(MarketplaceDialog, { onClose: onClose }) }));
            expect(lastFrame()).toContain('★★★½');
        });
    });
});
//# sourceMappingURL=MarketplaceDialog.test.js.map