/**
 * LoadingSpinner Component Tests
 *
 * Tests for the LoadingSpinner component that displays animated loading states.
 */
export {};
//# sourceMappingURL=LoadingSpinner.test.d.ts.map