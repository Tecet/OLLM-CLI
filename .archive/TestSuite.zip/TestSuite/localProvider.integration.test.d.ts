export {};
//# sourceMappingURL=localProvider.integration.test.d.ts.map