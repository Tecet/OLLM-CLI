/**
 * Tests for Mode Transition Animator
 *
 * Tests animation creation, state management, message generation,
 * and lifecycle management for mode transitions.
 */
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { ModeTransitionAnimator } from '../ModeTransitionAnimator.js';
import { MODE_METADATA } from '../templates/modes/index.js';
describe('ModeTransitionAnimator', () => {
    let animator;
    beforeEach(() => {
        animator = new ModeTransitionAnimator();
    });
    describe('Animation Creation', () => {
        it('should create animation for mode transition', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            expect(animation).toBeDefined();
            expect(animation.id).toMatch(/^anim-\d+$/);
            expect(animation.transition).toBe(transition);
            expect(animation.state).toBe('pending');
            expect(animation.loadingMessage).toBeTruthy();
            expect(animation.completionMessage).toBeTruthy();
            expect(animation.icon).toBe(MODE_METADATA.developer.icon);
            expect(animation.duration).toBeGreaterThan(0);
        });
        it('should generate unique IDs for each animation', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const anim1 = animator.createAnimation(transition);
            const anim2 = animator.createAnimation(transition);
            expect(anim1.id).not.toBe(anim2.id);
        });
        it('should use correct icon for each mode', () => {
            const modes = [
                { mode: 'assistant', icon: MODE_METADATA.assistant.icon },
                { mode: 'planning', icon: MODE_METADATA.planning.icon },
                { mode: 'developer', icon: MODE_METADATA.developer.icon },
                { mode: 'debugger', icon: MODE_METADATA.debugger.icon },
                { mode: 'reviewer', icon: MODE_METADATA.reviewer.icon },
            ];
            modes.forEach(({ mode, icon }) => {
                const transition = {
                    from: 'assistant',
                    to: mode,
                    timestamp: new Date(),
                    trigger: 'manual',
                    confidence: 0.8
                };
                const animation = animator.createAnimation(transition);
                expect(animation.icon).toBe(icon);
            });
        });
    });
    describe('Animation State Management', () => {
        it('should start animation', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            expect(animation.state).toBe('pending');
            animator.startAnimation(animation.id);
            const updated = animator.getAnimation(animation.id);
            expect(updated?.state).toBe('active');
            expect(updated?.startTime).toBeDefined();
        });
        it('should complete animation', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            animator.startAnimation(animation.id);
            animator.completeAnimation(animation.id);
            const updated = animator.getAnimation(animation.id);
            expect(updated?.state).toBe('complete');
            expect(updated?.endTime).toBeDefined();
        });
        it('should handle non-existent animation gracefully', () => {
            expect(() => animator.startAnimation('non-existent')).not.toThrow();
            expect(() => animator.completeAnimation('non-existent')).not.toThrow();
        });
        it('should auto-cleanup completed animations', () => {
            vi.useFakeTimers();
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            animator.completeAnimation(animation.id);
            expect(animator.getAnimation(animation.id)).toBeDefined();
            vi.advanceTimersByTime(2000);
            expect(animator.getAnimation(animation.id)).toBeUndefined();
            vi.useRealTimers();
        });
    });
    describe('Message Generation', () => {
        it('should generate loading message for explicit trigger', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'explicit',
                confidence: 1.0
            };
            const animation = animator.createAnimation(transition);
            expect(animation.loadingMessage).toContain(MODE_METADATA.developer.icon);
            expect(animation.loadingMessage).toContain('Activating development tools');
        });
        it('should generate loading message for manual trigger', () => {
            const transition = {
                from: 'assistant',
                to: 'debugger',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            expect(animation.loadingMessage).toContain('Switching to Debugger mode');
        });
        it('should generate loading message for auto trigger', () => {
            const transition = {
                from: 'developer',
                to: 'debugger',
                timestamp: new Date(),
                trigger: 'auto',
                confidence: 0.85
            };
            const animation = animator.createAnimation(transition);
            expect(animation.loadingMessage).toContain('Auto-switching to Debugger mode');
        });
        it('should generate completion message', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const animation = animator.createAnimation(transition);
            expect(animation.completionMessage).toContain('✓');
            expect(animation.completionMessage).toContain('Development mode ready');
        });
        it('should generate contextual messages for specific transitions', () => {
            const transitions = [
                {
                    from: 'developer',
                    to: 'debugger',
                    expected: `${MODE_METADATA.debugger.icon} Error detected`
                },
                {
                    from: 'debugger',
                    to: 'developer',
                    expected: '✓ Bug analysis complete'
                },
                {
                    from: 'assistant',
                    to: 'planning',
                    expected: `${MODE_METADATA.planning.icon} Switching to planning mode`
                }
            ];
            transitions.forEach(({ from, to, expected }) => {
                const transition = {
                    from,
                    to,
                    timestamp: new Date(),
                    trigger: 'auto',
                    confidence: 0.85
                };
                const message = animator.generateContextualMessage(transition);
                expect(message).toContain(expected);
            });
        });
    });
    describe('Active Animations', () => {
        it('should track active animations', () => {
            const transition1 = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            const transition2 = {
                from: 'developer',
                to: 'debugger',
                timestamp: new Date(),
                trigger: 'auto',
                confidence: 0.85
            };
            animator.createAnimation(transition1);
            animator.createAnimation(transition2);
            const active = animator.getActiveAnimations();
            expect(active).toHaveLength(2);
        });
        it('should clear all animations', () => {
            const transition = {
                from: 'assistant',
                to: 'developer',
                timestamp: new Date(),
                trigger: 'manual',
                confidence: 0.8
            };
            animator.createAnimation(transition);
            animator.createAnimation(transition);
            expect(animator.getActiveAnimations()).toHaveLength(2);
            animator.clearAnimations();
            expect(animator.getActiveAnimations()).toHaveLength(0);
        });
    });
    describe('Animation Duration', () => {
        it('should use mode-specific durations', () => {
            const modes = [
                { mode: 'assistant', duration: 500 },
                { mode: 'planning', duration: 600 },
                { mode: 'developer', duration: 500 },
                { mode: 'debugger', duration: 700 },
                { mode: 'reviewer', duration: 600 }
            ];
            modes.forEach(({ mode, duration }) => {
                const transition = {
                    from: 'assistant',
                    to: mode,
                    timestamp: new Date(),
                    trigger: 'manual',
                    confidence: 0.8
                };
                const animation = animator.createAnimation(transition);
                expect(animation.duration).toBe(duration);
            });
        });
    });
});
//# sourceMappingURL=ModeTransitionAnimator.test.js.map