/**
 * Tests for MCPTab component
 *
 * Validates: Requirements 1.1-1.6, 12.1-12.15
 */
export {};
//# sourceMappingURL=MCPTab.test.d.ts.map