/**
 * ServerToolsViewer - Component Tests
 *
 * Tests for the ServerToolsViewer dialog component that manages
 * tool auto-approval settings for MCP servers.
 */
export {};
//# sourceMappingURL=ServerToolsViewer.test.d.ts.map