import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// Minimal test to isolate React 19 + Ink 6 issues
import { describe, it, expect } from 'vitest';
import { render } from 'ink-testing-library';
import { Box, Text } from 'ink';
describe('Minimal Ink Tests', () => {
    it('renders simple Text', () => {
        const { lastFrame } = render(_jsx(Text, { children: "Hello" }));
        expect(lastFrame()).toContain('Hello');
    });
    it('renders simple Box with Text', () => {
        const { lastFrame } = render(_jsx(Box, { children: _jsx(Text, { children: "Hello" }) }));
        expect(lastFrame()).toContain('Hello');
    });
    it('renders Box with flexDirection row and gap', () => {
        const { lastFrame } = render(_jsxs(Box, { flexDirection: "row", gap: 2, children: [_jsx(Text, { children: "A" }), _jsx(Text, { children: "B" })] }));
        expect(lastFrame()).toContain('A');
        expect(lastFrame()).toContain('B');
    });
    it('renders nested Box components', () => {
        const { lastFrame } = render(_jsx(Box, { flexDirection: "column", children: _jsxs(Box, { flexDirection: "row", children: [_jsx(Text, { children: "Left" }), _jsx(Text, { children: "Right" })] }) }));
        expect(lastFrame()).toContain('Left');
        expect(lastFrame()).toContain('Right');
    });
    it('renders conditional children', () => {
        const showExtra = true;
        const { lastFrame } = render(_jsxs(Box, { flexDirection: "column", children: [_jsx(Text, { children: "Always" }), showExtra && _jsx(Text, { children: "Extra" })] }));
        expect(lastFrame()).toContain('Always');
        expect(lastFrame()).toContain('Extra');
    });
    it('renders Text with children expression', () => {
        const value = 42;
        const { lastFrame } = render(_jsxs(Text, { children: ["Value: ", value] }));
        expect(lastFrame()).toContain('Value: 42');
    });
    it('renders borderStyle', () => {
        const { lastFrame } = render(_jsx(Box, { borderStyle: "single", borderColor: "#555", children: _jsx(Text, { children: "Inside" }) }));
        expect(lastFrame()).toContain('Inside');
    });
    it('renders multiple conditionals in row', () => {
        const a = true;
        const b = false;
        const { lastFrame } = render(_jsxs(Box, { flexDirection: "row", children: [_jsx(Text, { children: "Base" }), a && _jsx(Text, { children: " AAA" }), b && _jsx(Text, { children: " BBB" })] }));
        expect(lastFrame()).toContain('Base');
        expect(lastFrame()).toContain('AAA');
        expect(lastFrame()).not.toContain('BBB');
    });
});
//# sourceMappingURL=minimal-ink.test.js.map