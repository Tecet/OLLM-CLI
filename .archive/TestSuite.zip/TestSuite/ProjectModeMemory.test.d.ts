/**
 * Tests for ProjectModeMemory
 */
export {};
//# sourceMappingURL=ProjectModeMemory.test.d.ts.map