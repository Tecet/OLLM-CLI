/**
 * Tests for Mode Transition Suggester
 *
 * Tests suggestion logic, confidence scoring, auto-switch behavior,
 * and preference management for the Dynamic Prompt System.
 */
export {};
//# sourceMappingURL=ModeTransitionSuggester.test.d.ts.map