export {};
//# sourceMappingURL=memoryGuard.enforce-compress-signature.test.d.ts.map