/**
 * Unit tests for SnapshotManager
 */
export {};
//# sourceMappingURL=SnapshotManager.test.d.ts.map