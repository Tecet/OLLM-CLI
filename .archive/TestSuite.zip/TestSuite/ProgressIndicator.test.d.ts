/**
 * ProgressIndicator Component Tests
 *
 * Tests for the ProgressIndicator component that displays operation progress.
 */
export {};
//# sourceMappingURL=ProgressIndicator.test.d.ts.map