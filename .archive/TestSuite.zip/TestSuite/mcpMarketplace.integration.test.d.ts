/**
 * Integration Tests for MCP Marketplace Service
 *
 * These tests verify real connectivity and behavior without mocks.
 * They test the actual fallback logic and local registry functionality.
 */
export {};
//# sourceMappingURL=mcpMarketplace.integration.test.d.ts.map