/**
 * Tests for ModeConfidenceDisplay component
 */
export {};
//# sourceMappingURL=ModeConfidenceDisplay.test.d.ts.map