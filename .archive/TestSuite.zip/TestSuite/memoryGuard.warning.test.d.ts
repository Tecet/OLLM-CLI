export {};
//# sourceMappingURL=memoryGuard.warning.test.d.ts.map