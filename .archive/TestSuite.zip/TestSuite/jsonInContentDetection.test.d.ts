/**
 * Tests for JSON-in-content tool call detection (healer logic)
 * Verifies that the heuristic correctly identifies tool calls while avoiding false positives
 */
export {};
//# sourceMappingURL=jsonInContentDetection.test.d.ts.map