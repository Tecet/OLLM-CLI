/**
 * Tests for Mode System Simplification Changes
 *
 * Tests the recent improvements:
 * 1. Reduced hysteresis (30s → 15s)
 * 2. Optional metrics (default disabled)
 */
export {};
//# sourceMappingURL=mode-system-simplification.test.d.ts.map