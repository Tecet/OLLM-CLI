export {};
//# sourceMappingURL=HookItem.test.d.ts.map