/**
 * MarketplacePreview Component Tests
 *
 * Tests the MarketplacePreview component functionality including:
 * - Rendering top 3 servers
 * - Displaying server details (name, description, rating, install count)
 * - OAuth requirement indicators
 * - Marketplace hint message
 * - Empty state handling
 */
export {};
//# sourceMappingURL=MarketplacePreview.test.d.ts.map