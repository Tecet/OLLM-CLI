/**
 * Unit tests for test fixtures.
 * Tests fixture creation functions, helper functions, and assertion utilities.
 */
export {};
//# sourceMappingURL=fixtures.test.d.ts.map