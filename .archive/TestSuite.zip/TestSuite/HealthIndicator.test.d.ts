export {};
//# sourceMappingURL=HealthIndicator.test.d.ts.map