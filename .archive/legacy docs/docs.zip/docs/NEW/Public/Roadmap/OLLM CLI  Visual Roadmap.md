
> **Note:** This is a visual representation of the OLLM CLI development roadmap. All stages marked as "Planned" are future development and not yet implemented.



## Quick Links

- **[Roadmap Overview](roadmap.md)** - Main entry point
- **[Future Development](future-development.md)** - Detailed roadmap with specifications
- **[Future Features](future-features.md)** - Quick reference guide
- **[Contributing](future-development.md#contributing)** - How to contribute
- **[Feedback](future-development.md#feedback)** - Share your thoughts


## Feature Availability Timeline

```
┌──────────────────────────────────────────────────────────────────────┐
│                      Estimated Feature Timeline                       │
│                    (Subject to change based on                        │
│                   community feedback and resources)                   │
└──────────────────────────────────────────────────────────────────────┘

Q1 2026  │ ████████████ v0.1.0: Alpha Release        
Q2 2026  │ ░░░░░░░░░░░░ v0.4.0: Code Editor 
         │ ░░░░░░░░░░░░ v0.5.0: Kraken Integration (Planned)
         │
Q2 2026  │ ░░░░░░░░░░░░ v0.6.0: Intelligence Layer (Planned)
         │ ░░░░░░░░░░░░ v0.7.0: Dev Productivity (Planned)
         │
Q3 2026  │ ░░░░░░░░░░░░ v0.8.0: Cross-Platform Support
         │ ░░░░░░░░░░░░ v0.9.0: Multi-Provider Support  
         │ ░░░░░░░░░░░░ v1.0.0: Beta Release  

Legend:
████ Completed/In Progress
░░░░ Planned (Timeline TBD)
```


## Development Timeline

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         OLLM CLI Development Roadmap                     │
└─────────────────────────────────────────────────────────────────────────┘

COMPLETED / IN PROGRESS
═══════════════════════════════════════════════════════════════════════════

Stage 1-8: Core Features                                    [████████████] 95%
├─ Interactive TUI (React + Ink)                           ✅ Complete
├─ Non-Interactive Mode                                    ✅ Complete
├─ Tool System (File, Shell, Web)                          ✅ Complete
├─ Policy Engine (ASK/AUTO/YOLO)                           ✅ Complete
├─ Context Management + VRAM Monitoring                    ✅ Complete
├─ Session Recording & Compression                         ✅ Complete
├─ Hook System                                             ✅ Complete
├─ MCP Integration pre-Alfa                                ✅ Complete
└─ Testing Infrastructure                                  🔄 In Progress

Stage 9: Documentation & Release                           [████████████] 90%
├─ README.md                                               ✅ Complete
├─ Configuration Reference                                 ✅ Complete
├─ Troubleshooting Guide                                   ✅ Complete
├─ Roadmap Documentation                                   ✅ Complete
├─ Package Configuration                                   ✅ Complete
├─ Debuging                                                ✅ Complete
└─ Release Process v0.1.0 alfa                             🔄 In Progress


PLANNED FUTURE DEVELOPMENT
═══════════════════════════════════════════════════════════════════════════

v0.2.0: File Explorer                                    [█████████   ] 80%
Priority: HIGH
├─ Workspace Management                                    ✅ Complete
├─ File Tree Navigation                                    ✅ Complete
├─ Focus System                                            ✅ Complete
├─ Syntax Viewer                                           ✅ Complete
├─ Implement batch operations                              🔄 In Progress
└─ File Operations                                         🔄 In Progress

v0.2.1: File Upload System                               [            ] 0%
Priority: MEDIUM
├─ Multiple Upload Methods                                 📋 Planned
├─ Session-Scoped Storage                                  📋 Planned
├─ File Deduplication                                      📋 Planned
├─ Image Processing                                        📋 Planned
└─ Storage Management                                      📋 Planned

v0.3.0: MCP Integration                                  [██████████  ] 90%
Priority: HIGH
├─ Data Layer                                              ✅ Complete
├─ UI Components                                           ✅ Complete
├─ Marketplace / MCP Repository                            ✅ Complete
├─ Dialogs                                                 ✅ Complete
├─ FocusContext Transfer                                   🔄 In Progress
└─ Integration & Testing                                   🔄 In Progress

v0.4.0: Code Editor                                      [            ] 0%
Priority: HIGH
├─ Foundation                                              📋 Planned
├─ UI Components                                           📋 Planned
├─ Input Handling                                          📋 Planned
├─ Enhanced Editing                                        📋 Planned
├─ Syntax Color Themes                                     📋 Planned
└─ Integration & Testing                                   📋 Planned

v0.5.0: Kraken Integration                               [            ] 0%
Priority: HIGH
├─ CLI Bridge Execution                                    📋 Planned
├─ API Provider Integration                                📋 Planned
├─ Provider Discovery & Health Checks                      📋 Planned
├─ Auto-Escalation                                         📋 Planned
├─ Context Transfer                                        📋 Planned
└─ Cost Tracking & Budget Enforcement                      📋 Planned

v0.6.0: Intelligence Layer RAG                           [            ] 0%
Priority: MEDIUM
├─ Semantic Codebase Search (RAG)                          📋 Planned
├─ Structured JSON Output                                  📋 Planned
├─ Code Execution Sandbox                                  📋 Planned
├─ Vision & Image Analysis                                 📋 Planned
├─ Developer Productivity Tools                            📋 Planned
└─ Cost Tracking                                           📋 Planned

v0.7.0: Developer Productivity Tools                     [            ] 0%
Priority: MEDIUM
├─ Git Integration Tool                                    📋 Planned
├─ @-Mention Syntax                                        📋 Planned
├─ Context Loader                                          📋 Planned
├─ Diff Review Mode                                        📋 Planned
├─ Auto-Commit                                             📋 Planned
└─ Git Status in System Prompt                             📋 Planned

v0.8.0: Cross-Platform Support                           [            ] 0%
Priority: MEDIUM
├─ Platform Detection                                      📋 Planned
├─ Configuration Path Resolution                           📋 Planned
├─ Terminal Capability Detection                           📋 Planned
├─ Cross-Platform GPU Monitoring                           📋 Planned
└─ Path Normalization                                      📋 Planned

v0.9.0: Multi-Provider Support                           [            ] 0%
Priority: MEDIUM
├─ vLLM Provider                                           📋 Planned
├─ OpenAI-Compatible Provider                              📋 Planned
├─ SSE Stream Parsing                                      📋 Planned
├─ Provider Registry & Aliases                             📋 Planned
└─ Guided Decoding Support                                 📋 Planned

```

## Feature Categories

```
┌──────────────────────────────────────────────────────────────────────┐
│                        Features by Category                           │
└──────────────────────────────────────────────────────────────────────┘

🎨 USER INTERFACE
├─ Interactive TUI                                         ✅ Complete
├─ Non-Interactive Mode                                    ✅ Complete
├─ Status Bar & Indicators                                 ✅ Complete
└─ Diff Review UI                                          📋 Planned v0.7.0

🔧 CORE FUNCTIONALITY
├─ Tool System                                             ✅ Complete
├─ Policy Engine                                           ✅ Complete
├─ Hook System                                             ✅ Complete
├─ MCP Integration                                         🔄 In Progress
└─ Git Integration                                         📋 Planned v0.7.0

🧠 INTELLIGENCE
├─ Context Management                                      🔄 In Progress
├─ VRAM Monitoring                                         ✅ Complete
├─ Session Compression                                     🔄 In Progress
├─ Semantic Search                                         📋 Planned v0.6.0
├─ Structured Output                                       📋 Planned v0.6.0
└─ Code Execution                                          📋 Planned v0.6.0

🔌 PROVIDERS
├─ Ollama (Local)                                          ✅ Complete
├─ External LLMs (Kraken)                                  📋 Planned v0.5.0
├─ vLLM                                                    📋 Planned v0.5.0
└─ OpenAI-Compatible                                       📋 Planned v0.5.0

📁 FILE HANDLING
├─ File Read/Write Tools                                   ✅ Complete
├─ @-Mention Context Loading                               📋 Planned v0.7.0
└─ File Upload System                                      📋 Planned v0.2.1

🖥️ PLATFORM
├─ Basic Cross-Platform                                    🔄 In Progress
└─ Enhanced Cross-Platform                                 📋 Planned v0.8.0

🔍 VISION & MEDIA
├─ Image Analysis                                          📋 Planned v0.2.1
└─ Screenshot Capture                                      📋 Planned v0.2.1

💰 COST & TRACKING
├─ Basic Token Counting                                    ✅ Complete
├─ Cost Tracking                                           📋 Planned v0.6.0
└─ Budget Enforcement                                      📋 Planned v0.6.0
```

## Implementation Status Legend

```
✅ Complete       - Feature is implemented and tested
🔄 In Progress    - Feature is currently being developed
📋 Planned        - Feature is planned for future development
⏸️ On Hold        - Feature development is paused
❌ Cancelled      - Feature will not be implemented
```

## Feature Dependencies

```
┌──────────────────────────────────────────────────────────────────────┐
│                         Feature Dependency Graph                      │
└──────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────┐
                    │   Core Features     │
                    │   (Stages 1-8)      │
                    └──────────┬──────────┘
                               │
                ┌──────────────┼──────────────┐
                │              │              │
                ▼              ▼              ▼
        ┌───────────┐  ┌───────────┐  ┌───────────┐
        │  v0.5.0   │  │  v0.7.0   │  │  v0.8.0   │
        │  Kraken   │  │  Dev Tools│  │  X-Plat   │
        └─────┬─────┘  └─────┬─────┘  └─────┬─────┘
              │              │              │
              └──────┬───────┴──────┬───────┘
                     │              │
                     ▼              ▼
             ┌───────────┐  ┌───────────┐
             │ v0.9.0    │  │  v0.2.1   │
             │  Multi-   │  │  File     │
             │  Provider │  │  Upload   │
             └─────┬─────┘  └─────┬─────┘
                   │              │
                   └──────┬───────┘
                          │
                          ▼
                  ┌───────────┐
                  │  v0.6.0   │
                  │  Intel.   │
                  │  Layer    │
                  └───────────┘
```





---

**Last Updated:** 2026-01-16  
**Document Version:** 1.1  
**Status:** Living document - Updated as development progresses
