# Progressive Checkpoint Compression - Flow Diagram

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    Context Manager                               │
│                                                                  │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────┐ │
│  │  Messages  │  │ Checkpoints│  │   Recent   │  │  Goals   │ │
│  │  (System)  │  │  (History) │  │  Messages  │  │ (Active) │ │
│  └────────────┘  └────────────┘  └────────────┘  └──────────┘ │
│                                                                  │
│  ┌────────────┐  ┌────────────┐                                │
│  │ Reasoning  │  │ Never-     │                                │
│  │  Traces    │  │ Compressed │                                │
│  └────────────┘  └────────────┘                                │
│                                                                  │
│  Token Count: ████████░░░░░░░░░░ 45% (14.4K / 32K)            │
│  Tier: 3 (8-32K) | Mode: Developer | Prompt: 1000 tokens      │
│  Hardware Tier: 3 (locked) | Auto-sizing: Enabled            │
│  Active Goal: "Implement authentication" | 3 checkpoints      │
│  Reasoning Traces: 5 recent, 12 archived                      │
└─────────────────────────────────────────────────────────────────┘
```

## Tier-Specific Compression

```
┌─────────────────────────────────────────────────────────────────┐
│ Tier Detection: Based on Context Size                           │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
                    ┌──────────────┐
                    │ Context Size?│
                    └──────────────┘
                            │
        ┌───────────────────┼───────────────────┼───────────────┬───────────────┐
        │                   │                   │               │               │
        ▼                   ▼                   ▼               ▼               ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│ Tier 1       │    │ Tier 2       │    │ Tier 3 ⭐    │    │ Tier 4       │    │ Tier 5       │
│ 2-4K         │    │ 4-8K         │    │ 8-32K        │    │ 32-64K       │    │ 64K+         │
│              │    │              │    │              │    │              │    │              │
│ Rollover     │    │ Smart        │    │ Progressive  │    │ Structured   │    │ Structured   │
│ 0 checkpts   │    │ 1 checkpt    │    │ 5 checkpts   │    │ 10 checkpts  │    │ 15 checkpts  │
└──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
```

## Compression Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ Step 1: Context Reaches Threshold (80% of 85% cap)             │
│                                                                  │
│ Note: With 85% cap, user's 4K = 3482 tokens sent to Ollama     │
│       Compression triggers at 80% of 3482 = ~2786 tokens        │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 2: Create Snapshot (for recovery)                          │
│                                                                  │
│  [Snapshot] ← Full context saved to disk                        │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 3: Compress Messages → Create Checkpoint                   │
│                                                                  │
│  Messages 1-50 → [LLM Summarization] → Checkpoint Summary       │
│                                                                  │
│  Checkpoint {                                                    │
│    level: 3 (DETAILED)                                          │
│    range: "Messages 1-50"                                       │
│    summary: "Built authentication system..."                    │
│    keyDecisions: ["Use JWT", "OAuth2 flow"]                     │
│    filesModified: ["auth.ts", "user.ts"]                        │
│    tokens: 800                                                   │
│  }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 4: Add Checkpoint to History (ADDITIVE!)                   │
│                                                                  │
│  checkpoints = [                                                 │
│    checkpoint1,  ← Preserved                                     │
│    checkpoint2,  ← Preserved                                     │
│    checkpoint3   ← Just created                                  │
│  ]                                                               │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 5: Compress Older Checkpoints Hierarchically               │
│                                                                  │
│  For each checkpoint:                                            │
│    age = total_checkpoints - index                              │
│                                                                  │
│    if age >= 10:                                                │
│      compress to COMPACT (level 1)                              │
│    else if age >= 5:                                            │
│      compress to MODERATE (level 2)                             │
│    else:                                                         │
│      keep as DETAILED (level 3)                                 │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 6: Merge if > MAX_CHECKPOINTS (10)                         │
│                                                                  │
│  If checkpoints.length > 10:                                     │
│    oldest_checkpoints → merge into single COMPACT checkpoint    │
└─────────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Step 7: Reconstruct Context                                     │
│                                                                  │
│  context.messages = [                                            │
│    systemPrompt,                                                 │
│    checkpoint1.summary,  ← COMPACT (80 tokens)                  │
│    checkpoint2.summary,  ← MODERATE (300 tokens)                │
│    checkpoint3.summary,  ← DETAILED (800 tokens)                │
│    ...recentMessages     ← Full detail (4096 tokens)            │
│  ]                                                               │
└─────────────────────────────────────────────────────────────────┘
```

## Checkpoint Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                    Checkpoint Aging                              │
└─────────────────────────────────────────────────────────────────┘

Creation (Age 0):
┌──────────────────────────────────────┐
│ Level 3 - DETAILED                   │
│ ────────────────────────────────────│
│ Range: Messages 1-50                 │
│ Summary: Full detailed summary...    │
│ Key Decisions: [...]                 │
│ Files Modified: [...]                │
│ Next Steps: [...]                    │
│ Tokens: 800                          │
└──────────────────────────────────────┘
            │
            │ 5 more compressions
            ▼
┌──────────────────────────────────────┐
│ Level 2 - MODERATE                   │
│ ────────────────────────────────────│
│ Range: Messages 1-50                 │
│ Summary: Condensed summary...        │
│ Key Decisions: [...]  ← Preserved    │
│ Tokens: 300                          │
└──────────────────────────────────────┘
            │
            │ 5 more compressions
            ▼
┌──────────────────────────────────────┐
│ Level 1 - COMPACT                    │
│ ────────────────────────────────────│
│ Range: Messages 1-50                 │
│ Summary: "Built auth system..."      │
│ Tokens: 80                           │
└──────────────────────────────────────┘
```

## Token Budget Over Time

```
┌─────────────────────────────────────────────────────────────────┐
│                Token Usage Across Compressions                   │
└─────────────────────────────────────────────────────────────────┘

Compression 1:
├─ System:     1,000 tokens
├─ CP1 (D):      800 tokens
└─ Recent:     4,096 tokens
   Total:      5,896 tokens (18% of 32K)

Compression 5:
├─ System:     1,000 tokens
├─ CP1 (D):      800 tokens
├─ CP2 (D):      800 tokens
├─ CP3 (D):      800 tokens
├─ CP4 (D):      800 tokens
├─ CP5 (D):      800 tokens
└─ Recent:     4,096 tokens
   Total:      9,096 tokens (28% of 32K)

Compression 10:
├─ System:     1,000 tokens
├─ CP1 (C):       80 tokens  ← Compressed!
├─ CP2 (C):       80 tokens  ← Compressed!
├─ CP3 (M):      300 tokens  ← Compressed!
├─ CP4 (M):      300 tokens  ← Compressed!
├─ CP5 (D):      800 tokens
├─ CP6 (D):      800 tokens
├─ CP7 (D):      800 tokens
├─ CP8 (D):      800 tokens
├─ CP9 (D):      800 tokens
├─ CP10 (D):     800 tokens
└─ Recent:     4,096 tokens
   Total:     10,656 tokens (33% of 32K)

Compression 20:
├─ System:     1,000 tokens
├─ CP1-5 (M):    100 tokens  ← Merged!
├─ CP11 (C):      80 tokens
├─ CP12 (C):      80 tokens
├─ CP13 (M):     300 tokens
├─ CP14 (M):     300 tokens
├─ CP15 (D):     800 tokens
├─ CP16 (D):     800 tokens
├─ CP17 (D):     800 tokens
├─ CP18 (D):     800 tokens
├─ CP19 (D):     800 tokens
├─ CP20 (D):     800 tokens
└─ Recent:     4,096 tokens
   Total:     10,756 tokens (34% of 32K)

Legend: D=DETAILED, M=MODERATE, C=COMPACT
```

## System Benefits

### 85% Context Cap Strategy ⭐ NEW (v2.1)

**Transparent User Experience:**
```
User Selects: 4K context
UI Shows: "Context: 4096 tokens"
Behind the Scenes: Sends num_ctx: 3482 (85%) to Ollama
Ollama Stops: At ~3482 tokens with done_reason: 'length'
Compression Triggers: Naturally at predictable point
```

**Benefits:**
- ✅ **No Overflow** - Ollama never exceeds context limit
- ✅ **Natural Stops** - Clean stop with `done_reason: 'length'`
- ✅ **Predictable** - Always triggers at same point
- ✅ **Buffer** - 15% (614 tokens for 4K) for response completion
- ✅ **Transparent** - User doesn't need to understand technical details

**How It Works with Compression:**
```
User's 4K Context:
├─ Displayed to user: 4096 tokens
├─ Sent to Ollama: 3482 tokens (85%)
├─ Compression trigger: 2786 tokens (80% of 3482)
└─ Buffer for response: 696 tokens (20% of 3482)

When Ollama hits 3482:
├─ Returns: done_reason: 'length'
├─ App detects: Natural stop
├─ Triggers: Compression
├─ Creates: Checkpoint
└─ User sees: "Context limit reached, type 'continue' to resume"
```

**See Also:** [85% Cap Implementation](./85-PERCENT-CAP-IMPLEMENTATION.md)

---

### Progressive Preservation

**Without Progressive Checkpoints:**
```
After 10 compressions:
[System] + [Single Summary] + [Recent]
1,000    + 500             + 4,096 = 5,596 tokens
                            ↑
                ❌ Lost all conversation history!
```

**With Progressive Checkpoints:**
```
After 10 compressions:
[System] + [CP1] + [CP2] + ... + [CP10] + [Recent]
1,000    + 80    + 80    + ... + 800     + 4,096 = 10,656 tokens
                                          ↑
                          ✅ Full journey preserved!
```

**Key Advantages:**
- ✅ **No Information Loss**: All conversation history preserved
- ✅ **Hierarchical Compression**: Recent = detailed, old = compact
- ✅ **Automatic Aging**: Checkpoints compress as they age
- ✅ **Bounded Growth**: Merging prevents unlimited expansion
- ✅ **Context Continuity**: LLM maintains full conversation awareness

## Decision Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              Should Compress Checkpoint?                         │
└─────────────────────────────────────────────────────────────────┘

                    checkpoint.age
                         │
                         ▼
                  ┌──────────────┐
                  │  age >= 10?  │
                  └──────────────┘
                    │           │
                   Yes          No
                    │           │
                    ▼           ▼
            ┌──────────────┐  ┌──────────────┐
            │ Compress to  │  │  age >= 5?   │
            │   COMPACT    │  └──────────────┘
            │  (level 1)   │    │           │
            └──────────────┘   Yes          No
                               │           │
                               ▼           ▼
                       ┌──────────────┐  ┌──────────────┐
                       │ Compress to  │  │ Keep as      │
                       │  MODERATE    │  │  DETAILED    │
                       │  (level 2)   │  │  (level 3)   │
                       └──────────────┘  └──────────────┘
```

## Checkpoint Merging

```
┌─────────────────────────────────────────────────────────────────┐
│              When checkpoints.length > 10                        │
└─────────────────────────────────────────────────────────────────┘

Before Merge (12 checkpoints):
┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ 1  │ 2  │ 3  │ 4  │ 5  │ 6  │ 7  │ 8  │ 9  │ 10 │ 11 │ 12 │
└────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
  ↓    ↓    ↓
  └────┴────┘
  Merge these 3
       ↓
┌──────────┐
│ Merged   │
│ 1-3      │
└──────────┘

After Merge (10 checkpoints):
┌──────────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ Merged   │ 4  │ 5  │ 6  │ 7  │ 8  │ 9  │ 10 │ 11 │ 12 │
│ 1-3      │    │    │    │    │    │    │    │    │    │
└──────────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
```

## Event Timeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    Event Sequence                                │
└─────────────────────────────────────────────────────────────────┘

Time ──────────────────────────────────────────────────────────▶

  │
  ├─ message-added ──────────────────────────────────────────────┐
  │                                                               │
  ├─ message-added ──────────────────────────────────────────────┤
  │                                                               │
  ├─ message-added ──────────────────────────────────────────────┤
  │                                                               │
  ├─ context-threshold-reached (80%) ────────────────────────────┤
  │                                                               │
  ├─ summarizing ─────────────────────────────────────────────────┤
  │                                                               │
  ├─ auto-snapshot-created ──────────────────────────────────────┤
  │                                                               │
  ├─ auto-summary-created ───────────────────────────────────────┤
  │   └─ checkpoint created                                       │
  │   └─ old checkpoints compressed                               │
  │   └─ context reconstructed                                    │
  │                                                               │
  ├─ compressed ──────────────────────────────────────────────────┤
  │                                                               │
  └─ message-added ──────────────────────────────────────────────┘
```

## Legend

```
Checkpoint Levels:
  D = DETAILED (Level 3)   - 800 tokens
  M = MODERATE (Level 2)   - 300 tokens
  C = COMPACT (Level 1)    - 80 tokens

Symbols:
  ✅ = Success / Benefit
  ❌ = Problem / Issue
  ← = Preserved / Maintained
  → = Transformed / Compressed
  ▼ = Flow direction
```


## Goal Management Integration ⭐ NEW (v2.2)

### Goal Tracking Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Goal Lifecycle                                │
└─────────────────────────────────────────────────────────────────┘

User Request: "Build authentication system"
            │
            ▼
┌──────────────────────────────────────┐
│ Goal Created                         │
│ ────────────────────────────────────│
│ ID: goal-abc123                      │
│ Description: Build authentication    │
│ Priority: high                       │
│ Status: active 🎯                    │
│ Subtasks: []                         │
│ Checkpoints: []                      │
│ Decisions: []                        │
└──────────────────────────────────────┘
            │
            │ Work progresses...
            ▼
┌──────────────────────────────────────┐
│ Checkpoint Created                   │
│ ────────────────────────────────────│
│ Description: JWT token generation    │
│ Timestamp: 2026-01-21T10:30:00Z      │
│ Associated Goal: goal-abc123         │
└──────────────────────────────────────┘
            │
            │ Decision made...
            ▼
┌──────────────────────────────────────┐
│ Decision Recorded                    │
│ ────────────────────────────────────│
│ What: Use bcrypt for passwords       │
│ Why: Industry standard, secure       │
│ Locked: true                         │
│ Associated Goal: goal-abc123         │
└──────────────────────────────────────┘
            │
            │ Files created...
            ▼
┌──────────────────────────────────────┐
│ Artifacts Tracked                    │
│ ────────────────────────────────────│
│ src/auth/login.ts - created          │
│ src/auth/jwt.ts - created            │
│ tests/auth.test.ts - created         │
│ Associated Goal: goal-abc123         │
└──────────────────────────────────────┘
            │
            │ Goal completed...
            ▼
┌──────────────────────────────────────┐
│ Goal Completed ✅                    │
│ ────────────────────────────────────│
│ Summary: Auth system with JWT        │
│ Checkpoints: 3                       │
│ Decisions: 5                         │
│ Artifacts: 8 files                   │
│ Duration: 2.5 hours                  │
└──────────────────────────────────────┘
```

### Reasoning Trace Capture

```
┌─────────────────────────────────────────────────────────────────┐
│              Reasoning Model Flow (DeepSeek-R1, QwQ, o1)         │
└─────────────────────────────────────────────────────────────────┘

User: "How should we implement password hashing?"
            │
            ▼
┌──────────────────────────────────────┐
│ Model Generates Response             │
│ ────────────────────────────────────│
│ <think>                              │
│ Let me consider the options:         │
│                                      │
│ Alternative 1: Use bcrypt            │
│ - Industry standard                  │
│ - Adaptive cost factor               │
│ - Well-tested                        │
│                                      │
│ Alternative 2: Use argon2            │
│ - Newer algorithm                    │
│ - Memory-hard                        │
│ - Less ecosystem support             │
│                                      │
│ I've chosen: bcrypt                  │
│ Rationale: Better ecosystem support  │
│ and proven track record              │
│ </think>                             │
│                                      │
│ I recommend using bcrypt...          │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ Reasoning Trace Captured             │
│ ────────────────────────────────────│
│ ID: trace-xyz789                     │
│ Message ID: msg-456                  │
│ Thinking: [full content above]       │
│ Structured:                          │
│   alternatives: [bcrypt, argon2]     │
│   chosen: bcrypt                     │
│   rationale: ecosystem support       │
│   confidence: 85                     │
│   keyInsights: [...]                 │
│ Context:                             │
│   goalId: goal-abc123                │
│   checkpointId: checkpoint-3         │
│ Metadata:                            │
│   model: deepseek-r1                 │
│   thinkingTokens: 150                │
│   answerTokens: 50                   │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ Stored in Reasoning Manager          │
│ ────────────────────────────────────│
│ Recent Traces: 5 (full detail)       │
│ Archived Traces: 12 (summaries)      │
│ Total Thinking Tokens: 2,450         │
│                                      │
│ Preserved across compression!        │
└──────────────────────────────────────┘
```

### Goal-Aware Compression

```
┌─────────────────────────────────────────────────────────────────┐
│              Compression with Goals                              │
└─────────────────────────────────────────────────────────────────┘

Before Compression (32K tokens):
├─ System Prompt: 1,000 tokens
├─ Active Goal: 400 tokens
│  ├─ Description: Build authentication
│  ├─ Checkpoints: 3 milestones
│  ├─ Decisions: 5 locked decisions
│  ├─ Artifacts: 8 files tracked
│  └─ Reasoning Traces: 5 recent
├─ Checkpoints: 2,100 tokens
└─ Recent Messages: 28,500 tokens

After Compression (22K tokens):
├─ System Prompt: 1,000 tokens
├─ Active Goal: 400 tokens  ← NEVER COMPRESSED!
│  ├─ All checkpoints preserved
│  ├─ All decisions preserved
│  ├─ All artifacts preserved
│  └─ Reasoning traces preserved
├─ Checkpoints: 2,100 tokens
└─ Recent Messages: 18,500 tokens

Result: Goal context maintained perfectly!
```

### Marker-Based Goal Tracking (Non-Tool Models)

```
┌─────────────────────────────────────────────────────────────────┐
│              Marker Parsing Flow                                 │
└─────────────────────────────────────────────────────────────────┘

Model Response (without tool support):
│
│ I'll help you build the authentication system.
│
│ NEW_GOAL: Implement user authentication | high
│
│ First, let me analyze the requirements...
│
│ CHECKPOINT: Completed requirements analysis
│ DECISION: Use JWT tokens | Stateless, scalable
│
│ Now implementing the login endpoint...
│
│ ARTIFACT: src/auth/login.ts | created
│ ARTIFACT: tests/login.test.ts | created
│
│ GOAL_COMPLETE: Authentication system implemented with tests
│
            ▼
┌──────────────────────────────────────┐
│ Marker Parser Extracts               │
│ ────────────────────────────────────│
│ newGoals: [                          │
│   {                                  │
│     description: "Implement user...", │
│     priority: "high"                 │
│   }                                  │
│ ]                                    │
│ checkpoints: [                       │
│   "Completed requirements analysis"  │
│ ]                                    │
│ decisions: [                         │
│   {                                  │
│     description: "Use JWT tokens",   │
│     rationale: "Stateless, scalable",│
│     locked: false                    │
│   }                                  │
│ ]                                    │
│ artifacts: [                         │
│   { path: "src/auth/login.ts",       │
│     action: "created" },             │
│   { path: "tests/login.test.ts",     │
│     action: "created" }              │
│ ]                                    │
│ goalComplete: "Authentication..."    │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ Goal Manager Actions Executed        │
│ ────────────────────────────────────│
│ ✅ Goal created                      │
│ ✅ Checkpoint added                  │
│ ✅ Decision recorded                 │
│ ✅ Artifacts tracked                 │
│ ✅ Goal marked complete              │
└──────────────────────────────────────┘
```

### Benefits

**For Tool-Capable Models:**
- ✅ Explicit goal tracking via tool calls
- ✅ Structured data from the start
- ✅ Real-time progress updates
- ✅ Clean separation of concerns

**For Non-Tool Models:**
- ✅ Marker-based tracking (no tools needed)
- ✅ Automatic parsing and extraction
- ✅ Same goal management features
- ✅ Works with any model

**For Reasoning Models:**
- ✅ Automatic reasoning trace capture
- ✅ Structured data extraction
- ✅ Preserved across compression
- ✅ Full audit trail of thinking

**For All Models:**
- ✅ Goal context never compressed
- ✅ Decisions preserved with rationale
- ✅ Artifacts tracked automatically
- ✅ Progress visible throughout conversation
- ✅ Maintains context across rollovers
