# Missing Features Implementation

**Date**: January 22, 2026  
**Status**: ✅ **File Search COMPLETE** | 🚧 Other features pending

## Overview

Implementing missing features identified in the tools audit to enhance File Explorer functionality.

## Features Implemented

### 1. File Search with grep Tool ✅ **COMPLETE**

**File Created**: `packages/cli/src/ui/components/file-explorer/FileSearchDialog.tsx`

**Integration Status**: ✅ **FULLY INTEGRATED**
- ✅ Search dialog component created
- ✅ Integrated into FileTreeView
- ✅ Keyboard shortcut (Ctrl+F) added
- ✅ Result selection handler implemented
- ✅ ToolRegistry passed from FileExplorerComponent
- ✅ Opens files at specific line numbers

**Features**:
- ✅ Search file contents using grep tool
- ✅ Regex pattern support
- ✅ Case sensitivity toggle
- ✅ File pattern filtering (*.ts, *.js, etc.)
- ✅ Results list with preview
- ✅ Keyboard navigation
- ✅ Integration with ToolRegistry

**Usage**:
```typescript
// In FileTreeView - press Ctrl+F to open
<FileSearchDialog
  visible={searchDialogOpen}
  onClose={() => setSearchDialogOpen(false)}
  onSelect={handleSearchSelect}
  toolRegistry={toolRegistry}
  rootPath={treeState.root?.path || rootPath}
/>
```

**Keyboard Shortcuts**:
- `Ctrl+F` - Open search dialog
- `Tab` - Switch between search query and file pattern
- `Enter` - Perform search / Select result
- `↑↓` - Navigate results
- `Ctrl+C` - Toggle case sensitivity
- `Ctrl+N` - New search
- `ESC` - Close dialog

**How It Works**:
```
User opens search dialog (Ctrl+F)
  ↓
Enter search pattern
  ↓
Optionally specify file pattern (*.ts)
  ↓
Press Enter to search
  ↓
grep tool searches file contents
  ↓
Results displayed with file:line:content
  ↓
Navigate with arrow keys
  ↓
Press Enter to open file at that line
  ↓
File opens in SyntaxViewer at correct location
```

**Files Modified**:
- ✅ `FileSearchDialog.tsx` - Created search dialog component
- ✅ `FileTreeView.tsx` - Added search dialog state, keyboard handler, result handler
- ✅ `FileExplorerComponent.tsx` - Passes toolRegistry and rootPath to FileTreeView

## Features To Implement

### 2. Batch Operations ⏳

**Goal**: Perform operations on multiple files at once

**Features Needed**:
- Multi-select mode (Space to toggle selection)
- Batch delete
- Batch rename (with pattern)
- Batch move
- Selection counter in status bar

**Implementation Plan**:
```typescript
// Add to FileTreeView state
const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
const [multiSelectMode, setMultiSelectMode] = useState(false);

// Keyboard shortcuts
// 'v' - Toggle multi-select mode
// 'Space' - Toggle file selection
// 'a' - Select all
// 'Ctrl+D' - Batch delete selected
```

**Estimated Effort**: 2-3 hours

---

### 3. FileTreeService Integration with ls Tool ⏳

**Goal**: Unify directory traversal logic

**Current State**:
- FileTreeService has its own directory traversal
- ls tool has its own directory traversal
- Duplicate logic

**Target State**:
- FileTreeService uses ls tool internally
- Single source of truth for directory listing
- Consistent .gitignore handling

**Implementation Plan**:
```typescript
// In FileTreeService.buildTree()
async buildTree(rootPath: string): Promise<FileNode[]> {
  if (this.toolRegistry) {
    // Use ls tool
    const lsTool = this.toolRegistry.get('ls');
    const result = await lsTool.createInvocation({
      path: rootPath,
      recursive: true,
      maxDepth: 3,
      includeHidden: false
    }, {}).execute(signal);
    
    return this.parseTreeFromLsOutput(result.llmContent);
  }
  
  // Fallback to direct traversal
  return this.buildTreeDirectly(rootPath);
}
```

**Estimated Effort**: 1-2 hours

---

### 4. File Watching ⏳

**Goal**: Auto-reload files when they change externally

**Features Needed**:
- Watch focused files for changes
- Show notification when file changes
- Option to reload automatically
- Option to show diff

**Implementation Plan**:
```typescript
import chokidar from 'chokidar';

class FileWatcher {
  private watcher?: chokidar.FSWatcher;
  
  watchFiles(paths: string[], onChange: (path: string) => void) {
    this.watcher = chokidar.watch(paths, {
      persistent: true,
      ignoreInitial: true,
    });
    
    this.watcher.on('change', onChange);
  }
  
  stopWatching() {
    this.watcher?.close();
  }
}
```

**Dependencies**:
- `chokidar` package for file watching

**Estimated Effort**: 2-3 hours

---

### 5. Diff Viewer ⏳

**Goal**: View changes before committing

**Features Needed**:
- Show unified diff
- Syntax highlighting
- Side-by-side view option
- Accept/reject changes

**Implementation Plan**:
```typescript
import { diffLines } from 'diff';

function DiffViewer({ oldContent, newContent }: DiffViewerProps) {
  const diff = diffLines(oldContent, newContent);
  
  return (
    <Box flexDirection="column">
      {diff.map((part, index) => (
        <Text
          key={index}
          color={part.added ? 'green' : part.removed ? 'red' : 'white'}
          backgroundColor={part.added ? 'greenBright' : part.removed ? 'redBright' : undefined}
        >
          {part.added ? '+ ' : part.removed ? '- ' : '  '}
          {part.value}
        </Text>
      ))}
    </Box>
  );
}
```

**Dependencies**:
- `diff` package for diffing

**Estimated Effort**: 3-4 hours

---

## Priority Order

1. ✅ **File Search** (DONE) - High impact, enables content search
2. ⏳ **Batch Operations** - High impact, improves productivity
3. ⏳ **FileTreeService Integration** - Medium impact, code quality
4. ⏳ **File Watching** - Medium impact, better UX
5. ⏳ **Diff Viewer** - Low impact, nice to have

## Next Steps

### Immediate (This Session)
1. ✅ Implement File Search Dialog - **COMPLETE**
2. ✅ Integrate search dialog into FileTreeView - **COMPLETE**
3. ✅ Add keyboard shortcut (Ctrl+F) to open search - **COMPLETE**
4. ⏳ Test search functionality - **READY FOR TESTING**

### Short Term (Next Session)
1. Implement batch operations
2. Add multi-select mode
3. Add batch delete/rename

### Medium Term (Future)
1. Integrate FileTreeService with ls tool
2. Add file watching
3. Add diff viewer

## Testing

### File Search Testing

**Manual Tests**:
1. Open File Explorer
2. Press Ctrl+F to open search
3. Enter search pattern: "function"
4. Verify results show matching lines
5. Navigate with arrow keys
6. Press Enter to open file
7. Verify file opens at correct line

**Edge Cases**:
- Empty search query
- No results found
- Regex patterns
- Case sensitivity
- File pattern filtering

## Dependencies

### Already Installed
- ✅ `ink` - Terminal UI
- ✅ `ink-text-input` - Text input component
- ✅ Tool Registry with grep tool

### To Install
- ⏳ `chokidar` - File watching (for feature #4)
- ⏳ `diff` - Text diffing (for feature #5)

## Status Summary

- ✅ **File Search**: **COMPLETE** - Fully integrated with Ctrl+F shortcut
- ⏳ **Batch Operations**: Not started
- ⏳ **FileTreeService Integration**: Not started
- ⏳ **File Watching**: Not started
- ⏳ **Diff Viewer**: Not started

---

**Implementation by**: Kiro AI Assistant  
**Date**: January 22, 2026  
**Status**: ✅ File Search complete and integrated | Ready for next feature
