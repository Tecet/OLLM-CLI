/**
 * Property-based tests for HookFileService validation
 * Feature: stage-06c-hooks-panel-ui
 * Task: 5.4.2 Property: Hook validation
 */
export {};
//# sourceMappingURL=hookFileService.property.test.d.ts.map