/**
 * HelpOverlay Component Tests
 *
 * Tests the help overlay component that displays comprehensive help information.
 */
export {};
//# sourceMappingURL=HelpOverlay.test.d.ts.map