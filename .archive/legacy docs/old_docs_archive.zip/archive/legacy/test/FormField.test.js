import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { render } from 'ink-testing-library';
import { describe, it, expect, vi } from 'vitest';
import { FormField } from '../FormField.js';
import { Text } from 'ink';
// Mock UIContext
vi.mock('../../../../features/context/UIContext.js', () => ({
    useUI: () => ({
        state: {
            theme: {
                text: {
                    primary: 'white',
                    secondary: 'gray',
                },
                status: {
                    error: 'red',
                },
            },
        },
    }),
}));
describe('FormField', () => {
    it('should render label', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('Test Label');
    });
    it('should render required indicator when required is true', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Required Field", required: true, children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('Required Field');
        expect(lastFrame()).toContain('*');
    });
    it('should not render required indicator when required is false', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Optional Field", required: false, children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('Optional Field');
        expect(lastFrame()).not.toMatch(/\*/);
    });
    it('should render children', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", children: _jsx(Text, { children: "Test Input Content" }) }));
        expect(lastFrame()).toContain('Test Input Content');
    });
    it('should render help text when provided and no error', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", helpText: "This is help text", children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('This is help text');
    });
    it('should render error message when provided', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", error: "This field is required", children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('⚠ This field is required');
    });
    it('should not render help text when error is present', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", helpText: "Help text", error: "Error message", children: _jsx(Text, { children: "Input" }) }));
        expect(lastFrame()).toContain('Error message');
        expect(lastFrame()).not.toContain('Help text');
    });
    it('should render with proper spacing', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", children: _jsx(Text, { children: "Input" }) }));
        const output = lastFrame();
        expect(output).toBeTruthy();
        expect(output).toContain('Test Label');
        expect(output).toContain('Input');
    });
    it('should handle empty children', () => {
        const { lastFrame } = render(_jsx(FormField, { label: "Test Label", children: _jsx(_Fragment, {}) }));
        expect(lastFrame()).toContain('Test Label');
    });
    it('should handle multiple children', () => {
        const { lastFrame } = render(_jsxs(FormField, { label: "Test Label", children: [_jsx(Text, { children: "Input 1" }), _jsx(Text, { children: "Input 2" })] }));
        expect(lastFrame()).toContain('Input 1');
        expect(lastFrame()).toContain('Input 2');
    });
});
//# sourceMappingURL=FormField.test.js.map