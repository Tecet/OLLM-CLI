/**
 * Checkbox Component Tests
 *
 * Tests:
 * - Checked/unchecked state rendering
 * - Label display
 * - Description display
 * - Disabled state
 * - CheckboxGroup functionality
 */
export {};
//# sourceMappingURL=Checkbox.test.d.ts.map