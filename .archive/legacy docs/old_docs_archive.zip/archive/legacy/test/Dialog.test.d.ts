/**
 * Dialog Component Tests
 *
 * Tests the base Dialog component functionality:
 * - Rendering with title and content
 * - Esc key handling for closing
 * - Border and padding styling
 * - Theme integration
 * - Custom width and colors
 */
export {};
//# sourceMappingURL=Dialog.test.d.ts.map