# OLLM CLI - Command Reference

**Created:** January 16, 2026  
**Status:** Implementation Complete  
**Coverage:** Extension Management, MCP Management, Hook Debugging

---

## Overview

This document provides a comprehensive reference for all CLI commands implemented for the OLLM CLI extensibility system. Commands are organized by functional area.

---

## Extension Management Commands

### `/extensions search`

Search for extensions in the marketplace.

**Usage:**
```bash
/extensions search <query> [--tags tag1,tag2] [--sort relevance|downloads|updated] [--limit 20]
```

**Examples:**
```bash
/extensions search github
/extensions search "code review" --tags git,vcs
/extensions search tools --sort downloads --limit 10
```

**Output:**
- List of matching extensions with metadata
- Relevance score for each result
- Author, tags, downloads, and description

---

### `/extensions install`

Install an extension from the marketplace.

**Usage:**
```bash
/extensions install <name> [version]
```

**Examples:**
```bash
/extensions install github-tools
/extensions install github-tools 1.2.0
```

**Behavior:**
- Downloads extension from registry
- Verifies checksum
- Extracts to `~/.ollm/extensions/`
- Automatically enables extension
- Registers hooks and MCP servers

---

### `/extensions uninstall`

Uninstall an extension.

**Usage:**
```bash
/extensions uninstall <name>
```

**Examples:**
```bash
/extensions uninstall github-tools
```

**Behavior:**
- Disables extension first
- Removes from filesystem
- Unregisters hooks and MCP servers
- Cleans up resources

---

### `/extensions list`

List installed extensions.

**Usage:**
```bash
/extensions list [--enabled|--disabled|--all]
```

**Examples:**
```bash
/extensions list
/extensions list --enabled
/extensions list --disabled
```

**Output:**
- Extension name and version
- Enabled/disabled status
- Description
- Path
- Hook, MCP server, and skill counts

---

### `/extensions update`

Check for extension updates.

**Usage:**
```bash
/extensions update [name]
```

**Examples:**
```bash
/extensions update
/extensions update github-tools
```

**Output:**
- Available updates with version numbers
- Instructions for updating

---

### `/extensions watch`

Enable/disable hot-reload for extensions.

**Usage:**
```bash
/extensions watch [on|off|status]
```

**Examples:**
```bash
/extensions watch on
/extensions watch off
/extensions watch status
```

**Behavior:**
- `on` - Start watching for file changes
- `off` - Stop watching
- `status` - Show current state and watched extensions

---

### `/extensions permissions`

View or manage extension permissions.

**Usage:**
```bash
/extensions permissions <name> [--grant|--revoke type:scope]
```

**Examples:**
```bash
/extensions permissions github-tools
/extensions permissions github-tools --grant filesystem:./src
/extensions permissions github-tools --revoke network:api.github.com
```

**Permission Types:**
- `filesystem:<path>` - File system access
- `network:<domain>` - Network access
- `env:<variable>` - Environment variable access
- `shell` - Shell command execution
- `mcp` - MCP server management

---

### `/extensions enable`

Enable a disabled extension.

**Usage:**
```bash
/extensions enable <name>
```

**Examples:**
```bash
/extensions enable github-tools
```

---

### `/extensions disable`

Disable an enabled extension.

**Usage:**
```bash
/extensions disable <name>
```

**Examples:**
```bash
/extensions disable github-tools
```

---

### `/extensions info`

Show detailed information about an extension.

**Usage:**
```bash
/extensions info <name>
```

**Examples:**
```bash
/extensions info github-tools
```

**Output:**
- Name, version, status
- Description and path
- Hooks, MCP servers, skills
- Settings
- Permissions

---

## MCP Management Commands

### `/mcp list`

List all MCP servers and their capabilities.

**Usage:**
```bash
/mcp list [--tools|--resources|--prompts]
```

**Examples:**
```bash
/mcp list
/mcp list --tools
/mcp list --resources
/mcp list --prompts
```

**Output:**
- Server name and status
- Tool count and names
- Resource count and URIs (if --resources)
- Prompt count and names (if --prompts)

---

### `/mcp status`

Show status of MCP servers.

**Usage:**
```bash
/mcp status [server]
```

**Examples:**
```bash
/mcp status
/mcp status github
```

**Output:**
- Server status (connected, error, etc.)
- Error messages if any
- Tool count

---

### `/mcp tools`

List tools from a specific MCP server.

**Usage:**
```bash
/mcp tools <server>
```

**Examples:**
```bash
/mcp tools github
```

**Output:**
- Tool names and descriptions
- Input schemas

---

### `/mcp resources`

List resources from a specific MCP server.

**Usage:**
```bash
/mcp resources <server>
```

**Examples:**
```bash
/mcp resources github
```

**Output:**
- Resource names and URIs
- Descriptions
- MIME types

---

### `/mcp prompts`

List prompts from a specific MCP server.

**Usage:**
```bash
/mcp prompts <server>
```

**Examples:**
```bash
/mcp prompts github
```

**Output:**
- Prompt names and descriptions
- Required and optional arguments

---

### `/mcp auth status`

Check OAuth authentication status for a server.

**Usage:**
```bash
/mcp auth status <server>
```

**Examples:**
```bash
/mcp auth status github
```

**Status:** Not yet implemented (placeholder)

---

### `/mcp auth revoke`

Revoke OAuth tokens for a server.

**Usage:**
```bash
/mcp auth revoke <server>
```

**Examples:**
```bash
/mcp auth revoke github
```

**Status:** Not yet implemented (placeholder)

---

### `/mcp auth refresh`

Refresh OAuth tokens for a server.

**Usage:**
```bash
/mcp auth refresh <server>
```

**Examples:**
```bash
/mcp auth refresh github
```

**Status:** Not yet implemented (placeholder)

---

## Hook Debugging Commands

### `/hooks debug`

Manage hook debugging mode.

**Usage:**
```bash
/hooks debug <on|off|status|clear|export|summary|failed|format>
```

**Subcommands:**
- `on` - Enable hook tracing
- `off` - Disable hook tracing
- `status` - Show debug status
- `clear` - Clear trace history
- `export` - Export traces to file
- `summary` - Show execution summary
- `failed` - Show failed hook executions
- `format <json|pretty|compact>` - Set output format

**Examples:**
```bash
/hooks debug on
/hooks debug summary
/hooks debug export traces.json
/hooks debug format pretty
```

**Output:**
- Trace data with timing information
- Success/failure status
- Input/output data
- Error messages

---

## Command Context

All commands receive a `CommandContext` object with access to system components:

```typescript
interface CommandContext {
  flags?: Record<string, string | boolean>;
  extensionManager?: ExtensionManager;
  extensionRegistry?: ExtensionRegistry;
  extensionWatcher?: ExtensionWatcher;
  extensionSandbox?: ExtensionSandbox;
  mcpClient?: MCPClient;
  hookRegistry?: HookRegistry;
  hookDebugger?: HookDebugger;
}
```

---

## Command Registration

Commands are registered in the command registry:

```typescript
import { commandRegistry } from './commandRegistry.js';

// Register extension commands
commandRegistry.register({
  name: 'extensions',
  description: 'Manage extensions',
  subcommands: {
    search: extensionSearchCommand,
    install: extensionInstallCommand,
    uninstall: extensionUninstallCommand,
    list: extensionListCommand,
    update: extensionUpdateCommand,
    watch: extensionWatchCommand,
    permissions: extensionPermissionsCommand,
    enable: extensionEnableCommand,
    disable: extensionDisableCommand,
    info: extensionInfoCommand,
  },
});

// Register MCP commands
commandRegistry.register({
  name: 'mcp',
  description: 'Manage MCP servers',
  subcommands: {
    list: mcpListCommand,
    status: mcpStatusCommand,
    tools: mcpToolsCommand,
    resources: mcpResourcesCommand,
    prompts: mcpPromptsCommand,
    auth: {
      status: mcpAuthStatusCommand,
      revoke: mcpAuthRevokeCommand,
      refresh: mcpAuthRefreshCommand,
    },
  },
});
```

---

## Error Handling

All commands follow a consistent error handling pattern:

```typescript
try {
  // Command logic
  return {
    success: true,
    message: 'Operation successful',
  };
} catch (error) {
  return {
    success: false,
    message: `Failed: ${error instanceof Error ? error.message : String(error)}`,
  };
}
```

---

## Future Enhancements

### Planned Commands

1. **Extension Development**
   - `/extensions create <name>` - Create new extension
   - `/extensions validate <path>` - Validate manifest
   - `/extensions publish` - Publish to registry

2. **MCP Development**
   - `/mcp test <server>` - Test MCP server
   - `/mcp logs <server>` - View server logs
   - `/mcp restart <server>` - Restart server

3. **Hook Management**
   - `/hooks list` - List all hooks
   - `/hooks enable <id>` - Enable hook
   - `/hooks disable <id>` - Disable hook
   - `/hooks test <id>` - Test hook execution

---

## Implementation Status

| Command Group | Status | Commands | Notes |
|---------------|--------|----------|-------|
| Extension Management | ✅ Complete | 10 | All commands implemented |
| MCP Management | ✅ Complete | 9 | OAuth commands are placeholders |
| Hook Debugging | ✅ Complete | 1 | Implemented in Week 1 |

**Total Commands:** 20 commands implemented

---

## Files Created

1. `packages/cli/src/commands/extensionCommands.ts` (500+ lines)
2. `packages/cli/src/commands/mcpCommands.ts` (400+ lines)
3. `packages/cli/src/commands/types.ts` (updated with CommandContext)

---

## Integration Requirements

### Command Registry

Commands need to be registered in the command registry during CLI initialization:

```typescript
// In CLI initialization
import { extensionCommands } from './commands/extensionCommands.js';
import { mcpCommands } from './commands/mcpCommands.js';

commandRegistry.registerGroup('extensions', extensionCommands);
commandRegistry.registerGroup('mcp', mcpCommands);
```

### Context Injection

The command context must be populated with system components:

```typescript
const context: CommandContext = {
  extensionManager,
  extensionRegistry,
  extensionWatcher,
  extensionSandbox,
  mcpClient,
  hookRegistry,
  hookDebugger,
};

// Execute command with context
await command.handler(args, context);
```

---

## Testing

### Manual Testing Checklist

- [ ] Extension search returns results
- [ ] Extension installation works
- [ ] Extension uninstallation cleans up
- [ ] Extension list shows correct status
- [ ] Extension update checking works
- [ ] Extension watch enables/disables
- [ ] Extension permissions display correctly
- [ ] Extension enable/disable works
- [ ] Extension info shows all details
- [ ] MCP list shows servers
- [ ] MCP status shows correct state
- [ ] MCP tools/resources/prompts list correctly
- [ ] Hook debugging commands work

### Unit Tests

Tests should be created for each command:

```typescript
describe('extensionSearchCommand', () => {
  it('should search for extensions', async () => {
    const result = await extensionSearchCommand(['github'], context);
    expect(result.success).toBe(true);
  });

  it('should handle no results', async () => {
    const result = await extensionSearchCommand(['nonexistent'], context);
    expect(result.success).toBe(true);
    expect(result.message).toContain('No extensions found');
  });
});
```

---

## Documentation

### User Guide

A user guide should be created covering:
- How to search and install extensions
- How to manage permissions
- How to use hot-reload during development
- How to manage MCP servers
- How to debug hooks

### Developer Guide

A developer guide should cover:
- How to create custom commands
- How to access system components
- How to handle errors
- How to format output

---

**Document Status:** ✅ Complete  
**Created:** January 16, 2026  
**Last Updated:** January 16, 2026  
**Next Review:** After CLI integration testing
