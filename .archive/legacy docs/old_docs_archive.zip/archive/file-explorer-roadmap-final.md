# File Explorer — Final Implementation Roadmap

> **Status:** APPROVED FOR IMPLEMENTATION  
> **Estimated Total:** 22-31 dev days (includes Vision support)  
> **Dependencies:** None (new feature)

---

## Design Decisions Summary

| Decision | Choice |
|----------|--------|
| Editor Strategy | `$EDITOR` spawn from day 1 |
| Focus Token Limit | 8KB default |
| Git Integration | Basic status colors only (full git = future) |
| Multi-Project | VS Code-style workspaces |
| Config Format | Per-project `.ollm-project` files |

---

## Phase 1: Foundation & Workspace (5-7 days)

### 1.1 Workspace & Project Services

**File:** `packages/cli/src/features/workspace/WorkspaceManager.ts`
- [ ] Create `WorkspaceManager` class
  - Load/save `.ollm-workspace` JSON files
  - Track open workspace path
  - Emit events on workspace changes
  - Methods: `openWorkspace()`, `saveWorkspace()`, `addFolder()`, `removeFolder()`

**File:** `packages/cli/src/features/workspace/ProjectRegistry.ts`
- [ ] Create `ProjectRegistry` class
  - Load `.ollm-project` files from each folder
  - Track project metadata (name, llmAccess, exclude patterns)
  - Track "active" project for LLM context
  - Methods: `loadProject()`, `setActiveProject()`, `getActiveProject()`

**File:** `packages/cli/src/features/workspace/WorkspaceFS.ts`
- [ ] Create `WorkspaceFS` class
  - Path sanitization (reject `../` traversal)
  - Safe file operations within project roots only
  - Methods: `list()`, `stat()`, `read()`, `write()`, `mkdir()`, `delete()`
  - Quota enforcement (optional for MVP)

**File:** `packages/cli/src/features/workspace/types.ts`
- [ ] Define TypeScript interfaces:
  ```typescript
  interface Workspace { path, folders, settings }
  interface WorkspaceFolder { path, name, project? }
  interface Project { id, name, rootPath, llmAccess, exclude, include }
  interface FocusedFile { projectId, relativePath, absolutePath, markedAt }
  ```

### 1.2 Context Providers

**File:** `packages/cli/src/ui/contexts/WorkspaceContext.tsx`
- [ ] Create `WorkspaceProvider`
  - State: currentWorkspace, projects, activeProject
  - Actions: openWorkspace, addFolder, removeFolder, setActiveProject
  - Integrate with WorkspaceManager service

**File:** `packages/cli/src/ui/contexts/FileFocusContext.tsx`
- [ ] Create `FileFocusProvider`
  - State: focusedFiles[], activeFocusFile
  - Actions: focusFile, unfocusFile, clearFocus
  - Enforce 8KB limit per focused file

### 1.3 Basic File Tree Component

**File:** `packages/cli/src/ui/components/files/WorkspaceTree.tsx`
- [ ] Create `WorkspaceTree` component
  - Display project roots as collapsible tree
  - Virtual scrolling (WINDOW_SIZE = 15)
  - Support Browse/Active navigation modes
  - Highlight focused files with 📌 icon
  - Show git status colors (basic)

**File:** `packages/cli/src/ui/components/files/FileNode.tsx`  
- [ ] Create `FileNode` component
  - File/folder icon (Nerd Fonts lookup)
  - Name + size display
  - Expand/collapse indicator for directories
  - Focus indicator for pinned files

### 1.4 SidePanel Integration

**File:** `packages/cli/src/ui/components/layout/SidePanel.tsx`
- [ ] Replace "File Tree (Coming Soon)" placeholder with `<WorkspaceTree />`
- [ ] Pass workspace data from context
- [ ] Wire focus highlighting via `isFocused('file-tree')`

### 1.5 App.tsx Provider Integration

**File:** `packages/cli/src/ui/App.tsx`
- [ ] Add `<WorkspaceProvider>` to provider tree
- [ ] Add `<FileFocusProvider>` to provider tree
- [ ] Position after `<FocusProvider>`, before `<ActiveContextProvider>`

---

## Phase 2: Core Interactions (3-4 days)

### 2.1 Global Explorer

**File:** `packages/cli/src/ui/components/files/GlobalExplorer.tsx`
- [ ] Create full filesystem browser component
- [ ] Start at system drives (Windows) or `/` (Unix)
- [ ] Navigate with arrow keys, Enter to expand
- [ ] "Add to Workspace" action (`p` key)
- [ ] Display in FilesTab when not viewing workspace

### 2.2 FilesTab Enhancement

**File:** `packages/cli/src/ui/components/tabs/FilesTab.tsx`
- [ ] Add mode toggle: "Workspace" vs "Browse"
- [ ] Workspace mode: Show WorkspaceTree
- [ ] Browse mode: Show GlobalExplorer
- [ ] Wire "Add to Workspace" to WorkspaceManager

### 2.3 Quick Actions Menu

**File:** `packages/cli/src/ui/components/files/QuickActionsMenu.tsx`
- [ ] Create popup menu component
- [ ] Actions: Open, Focus/Unpin, Edit, Rename, Delete, Copy Path
- [ ] Trigger on Enter/Space when file selected
- [ ] Dismiss on Esc

### 2.4 Keyboard Navigation

**File:** `packages/cli/src/ui/components/files/WorkspaceTree.tsx`
- [ ] Implement vim-style navigation (hjkl + arrows)
- [ ] `f` key: Toggle focus on selected file
- [ ] `e` key: Open in external editor
- [ ] `n` key: Create new file/folder
- [ ] `d` key: Delete (with confirmation)
- [ ] `r` key: Rename

---

## Phase 3: Focus System (2-3 days)

### 3.1 FocusManager Service

**File:** `packages/cli/src/features/workspace/FocusManager.ts`
- [ ] Track focused files per session
- [ ] Enforce 8KB content limit
- [ ] Read file content on focus
- [ ] Emit events on focus changes

### 3.2 ContextSection Enhancement

**File:** `packages/cli/src/ui/components/layout/ContextSection.tsx`
- [ ] Add focused files display section
- [ ] Show 📌 icon with file names
- [ ] Show "None" when no files focused

### 3.3 LLM Context Integration

**File:** `packages/cli/src/features/context/ActiveContextState.tsx`
- [ ] Add `focusedFiles` to active context
- [ ] Expose via `useActiveContext()` hook

**File:** `packages/core/src/context/ContextManager.ts` (or equivalent)
- [ ] Inject focused file content into prompts
- [ ] Format as per spec:
  ```
  Focus file: path/to/file.ts (project: ProjectName)
  [File content truncated to 8KB]
  ```

### 3.4 Functions/Info Panel

**File:** `packages/cli/src/ui/components/layout/SidePanel.tsx`
- [ ] Update Row 4 to display focused files list
- [ ] Show file path + size for each focused file

---

## Phase 4: Viewer & Editor (3-4 days)

### 4.1 File Viewer

**File:** `packages/cli/src/ui/components/files/FileViewer.tsx`
- [ ] Create syntax-highlighted viewer component
- [ ] Integrate `shiki` for highlighting
- [ ] Display in main content area
- [ ] Support scroll with keyboard

### 4.2 External Editor Integration

**File:** `packages/cli/src/features/workspace/EditorService.ts`
- [ ] Create `EditorService` class
- [ ] Detect `$EDITOR` / `$VISUAL` environment variables
- [ ] Fallback to `nano` or `notepad` if not set
- [ ] Spawn editor with `child_process`
- [ ] Handle editor exit and file reload

### 4.3 Editor Wiring

**File:** `packages/cli/src/ui/components/files/QuickActionsMenu.tsx`
- [ ] Wire "Edit" action to EditorService
- [ ] Show "Opening in $EDITOR..." message

---

## Phase 5: File Operations (2-3 days)

### 5.1 Create Operations

**File:** `packages/cli/src/ui/components/files/CreateDialog.tsx`
- [ ] Create dialog for new file/folder
- [ ] Input: name, type (file/folder)
- [ ] Validation: no special characters, no duplicates
- [ ] Wire to WorkspaceFS.mkdir() / WorkspaceFS.write()

### 5.2 Rename Operations

**File:** `packages/cli/src/ui/components/files/RenameDialog.tsx`
- [ ] Create rename dialog
- [ ] Pre-populate with current name
- [ ] Validation: valid filename, no duplicates

### 5.3 Delete Operations

**File:** `packages/cli/src/ui/components/files/DeleteConfirmDialog.tsx`
- [ ] Create confirmation dialog
- [ ] Show file/folder name being deleted
- [ ] Require explicit confirmation

### 5.4 Project Config Wizard

**File:** `packages/cli/src/ui/components/files/ProjectConfigWizard.tsx`
- [ ] Create `.ollm-project` file wizard
- [ ] Inputs: name, llmAccess, exclude patterns
- [ ] Save to project root

---

## Phase 6: Polish & Intelligence (3-4 days)

### 6.1 Git Integration (Basic)

**File:** `packages/cli/src/features/workspace/GitService.ts`
- [ ] Create `GitService` using `simple-git`
- [ ] Detect if folder is git repo
- [ ] Get file status (new, modified, ignored)
- [ ] Return status for tree coloring

**File:** `packages/cli/src/ui/components/files/FileNode.tsx`
- [ ] Color files based on git status:
  - Green: New/untracked
  - Yellow: Modified
  - Grey: Ignored

### 6.2 File Icons

**File:** `packages/cli/src/ui/components/files/fileIcons.ts`
- [ ] Create file extension → icon mapping
- [ ] Use Nerd Font codepoints
- [ ] Cover common file types (ts, js, json, md, etc.)

### 6.3 Follow Mode

**File:** `packages/cli/src/ui/components/files/WorkspaceTree.tsx`
- [ ] Listen for LLM file references
- [ ] Auto-expand tree to referenced file
- [ ] Highlight referenced file

### 6.4 Quick Open (Fuzzy Search)

**File:** `packages/cli/src/ui/components/files/QuickOpen.tsx`
- [ ] Create fuzzy file search dialog
- [ ] Trigger with `Ctrl+O` or similar
- [ ] Search across all workspace files
- [ ] Open selected file in viewer

---

## Phase 7: Vision and Image Support (2-3 days)

### 7.1 Image Processing

**File:** `packages/core/src/vision/ImageProcessor.ts`
- [ ] Create `ImageProcessor` class
  - Implement image dimension detection
  - Implement image resizing (preserve aspect ratio, max 2048px)
  - Implement base64 encoding
  - Support multiple formats (JPEG, PNG, GIF, WebP)

### 7.2 Vision Service

**File:** `packages/core/src/vision/VisionService.ts`
- [ ] Create `VisionService` interface
  - Implement `loadImage()` method
  - Implement `isVisionModel()` method
  - Implement `getVisionModels()` method
  - Implement `analyzeImage()` method
  - Integrate with provider for vision models

### 7.3 Provider Integration

**File:** `packages/core/src/provider/types.ts`
- [ ] Update `Message` type to support image parts
- [ ] Update `LocalProvider.mapMessages()` to handle images
- [ ] Create message with image_url content part
- [ ] Handle vision vs non-vision model differences

### 7.4 Image Analyze Tool

**File:** `packages/core/src/tools/image-analyze.ts`
- [ ] Create `ImageAnalyzeTool` class
- [ ] Define `ImageAnalyzeParams` interface
- [ ] Implement tool using vision service
- [ ] Register tool with tool registry
- [ ] Display analysis results in UI

### 7.5 Screenshot Service (Optional)

**File:** `packages/core/src/vision/ScreenshotService.ts`
- [ ] Create `ScreenshotService` class
- [ ] Implement browser automation (Puppeteer/Playwright)
- [ ] Implement full page screenshot capture
- [ ] Implement element-specific screenshots (CSS selectors)
- [ ] Implement screenshot availability detection

### 7.6 Integration with File Upload

- [ ] Wire image uploads to vision service
- [ ] Process images for vision models (resize, encode)
- [ ] Display image analysis in uploads section
- [ ] Handle non-vision model fallback (text description)

**Configuration:**
```yaml
vision:
  enabled: true
  defaultModel: 'llava'           # Default vision model
  imageProcessing:
    maxDimension: 2048            # Resize images larger than this
    quality: 85                   # JPEG quality (1-100)
  screenshot:
    enabled: false                # Requires browser automation
    defaultWidth: 1920
    defaultHeight: 1080
```

---

## Phase 8: Verification Plan

### Automated Tests

**Unit Tests:**
```bash
# Run after implementing each service
npm run test:unit -- --grep "WorkspaceManager"
npm run test:unit -- --grep "ProjectRegistry"
npm run test:unit -- --grep "WorkspaceFS"
npm run test:unit -- --grep "FocusManager"
```

**Test Files to Create:**
- `packages/cli/src/features/workspace/__tests__/WorkspaceManager.test.ts`
- `packages/cli/src/features/workspace/__tests__/ProjectRegistry.test.ts`
- `packages/cli/src/features/workspace/__tests__/WorkspaceFS.test.ts`
- `packages/cli/src/ui/components/files/__tests__/WorkspaceTree.test.tsx`

**Key Test Cases:**
1. WorkspaceFS path sanitization rejects `../` traversal
2. ProjectRegistry loads `.ollm-project` correctly
3. FocusManager enforces 8KB limit
4. WorkspaceTree renders with virtual scrolling

### Manual Verification

**Phase 1 Smoke Test:**
1. Start app: `npm run dev`
2. Look for WorkspaceTree in side panel (no longer "Coming Soon")
3. Verify keyboard focus works on file tree

**Phase 2 Smoke Test:**
1. Navigate to Files tab
2. Switch to "Browse" mode
3. Navigate filesystem with arrow keys
4. Press `p` to add folder to workspace
5. Verify folder appears in workspace tree

**Phase 3 Smoke Test:**
1. Select a file in workspace tree
2. Press `f` to focus
3. Verify 📌 appears on file
4. Verify file shows in ContextSection
5. Send chat message and verify focused file content in context

**Phase 4 Smoke Test:**
1. Select a file and press `e`
2. Verify $EDITOR opens with file
3. Edit and save in editor
4. Verify changes reflected in app

---

## Dependencies

| Package | Purpose | Command |
|---------|---------|---------|
| `shiki` | Syntax highlighting | `npm install shiki` |
| `simple-git` | Git status | `npm install simple-git` |
| `chokidar` | File watching | Already installed |
| `sharp` (optional) | Image resizing | `npm install sharp` |
| `file-type` | MIME detection | `npm install file-type` |
| `puppeteer` (optional) | Screenshot capture | `npm install puppeteer` |

---

## File Tree Summary

```
packages/cli/src/
├── features/workspace/
│   ├── WorkspaceManager.ts      [NEW]
│   ├── ProjectRegistry.ts       [NEW]
│   ├── WorkspaceFS.ts           [NEW]
│   ├── FocusManager.ts          [NEW]
│   ├── EditorService.ts         [NEW]
│   ├── GitService.ts            [NEW]
│   └── types.ts                 [NEW]
│
├── ui/
│   ├── contexts/
│   │   ├── WorkspaceContext.tsx [NEW]
│   │   └── FileFocusContext.tsx [NEW]
│   │
│   ├── components/
│   │   ├── files/
│   │   │   ├── WorkspaceTree.tsx      [NEW]
│   │   │   ├── FileNode.tsx           [NEW]
│   │   │   ├── GlobalExplorer.tsx     [NEW]
│   │   │   ├── FileViewer.tsx         [NEW]
│   │   │   ├── QuickActionsMenu.tsx   [NEW]
│   │   │   ├── QuickOpen.tsx          [NEW]
│   │   │   ├── CreateDialog.tsx       [NEW]
│   │   │   ├── RenameDialog.tsx       [NEW]
│   │   │   ├── DeleteConfirmDialog.tsx[NEW]
│   │   │   ├── ProjectConfigWizard.tsx[NEW]
│   │   │   └── fileIcons.ts           [NEW]
│   │   │
│   │   ├── layout/
│   │   │   ├── SidePanel.tsx          [MODIFY]
│   │   │   └── ContextSection.tsx     [MODIFY]
│   │   │
│   │   └── tabs/
│   │       └── FilesTab.tsx           [MODIFY]
│   │
│   └── App.tsx                        [MODIFY]
```

---

## References

- [file-explorer-consolidated.md](file:///d:/Workspaces/OLLM%20CLI/.dev/docs/Development-Roadmap/file%20explorer/file-explorer-consolidated.md)
- [integration-analysis.md](file:///d:/Workspaces/OLLM%20CLI/.dev/docs/Development-Roadmap/file%20explorer/integration-analysis.md)
- [navigation_menu.md](file:///d:/Workspaces/OLLM%20CLI/.dev/docs/Ui/navigation_menu.md)
- [scroll.md](file:///d:/Workspaces/OLLM%20CLI/.dev/docs/Ui/scroll.md)
