# Memory Management Patterns

**Date**: January 23, 2026  
**Purpose**: Document best practices for preventing memory leaks in OLLM CLI

## Overview

This document provides guidelines and patterns for proper memory management in React components, particularly focusing on cleanup in useEffect hooks.

## Core Principles

1. **Every subscription needs cleanup**: If you subscribe to something, you must unsubscribe
2. **Every timer needs cleanup**: All `setInterval` and `setTimeout` must be cleared
3. **Every event listener needs cleanup**: All event listeners must be removed
4. **Every async operation should be cancellable**: Use AbortController or cancellation tokens
5. **Refs should be nulled on cleanup**: Clear refs to prevent memory retention

## Patterns

### 1. Event Listener Cleanup

#### ✅ Good Pattern - PTY Event Listeners
```typescript
useEffect(() => {
  const ptyProcess = pty.spawn(shell, [], {...});
  
  // Store disposables for cleanup
  const dataDisposable = ptyProcess.onData((data) => {
    // Handle data
  });
  
  const exitDisposable = ptyProcess.onExit(() => {
    // Handle exit
  });
  
  return () => {
    // Dispose event listeners first
    if (dataDisposable) {
      dataDisposable.dispose();
    }
    if (exitDisposable) {
      exitDisposable.dispose();
    }
    
    // Then cleanup the resource
    if (ptyProcess) {
      ptyProcess.kill();
    }
  };
}, []);
```

#### ✅ Good Pattern - Node.js Event Emitter
```typescript
useEffect(() => {
  if (!stdin) return;
  
  const handleData = (data: Buffer) => {
    // Handle data
  };
  
  stdin.on('data', handleData);
  
  return () => {
    // Use removeListener for better compatibility
    stdin.removeListener('data', handleData);
  };
}, [stdin]);
```

#### ❌ Bad Pattern - Missing Cleanup
```typescript
useEffect(() => {
  stdin.on('data', handleData);
  // Missing cleanup!
}, []);
```

### 2. Timer Cleanup

#### ✅ Good Pattern - setInterval
```typescript
useEffect(() => {
  const interval = setInterval(() => {
    // Do something periodically
  }, 1000);
  
  return () => clearInterval(interval);
}, []);
```

#### ✅ Good Pattern - setTimeout
```typescript
useEffect(() => {
  if (condition) {
    const timer = setTimeout(() => {
      // Do something after delay
    }, 5000);
    
    return () => clearTimeout(timer);
  }
}, [condition]);
```

#### ❌ Bad Pattern - Missing Cleanup
```typescript
useEffect(() => {
  setInterval(() => {
    // This will keep running forever!
  }, 1000);
}, []);
```

### 3. Subscription Cleanup

#### ✅ Good Pattern - Custom Subscription
```typescript
useEffect(() => {
  const unsubscribe = service.subscribe((data) => {
    // Handle data
  });
  
  return () => {
    if (typeof unsubscribe === 'function') {
      unsubscribe();
    }
  };
}, [service]);
```

#### ✅ Good Pattern - Multiple Subscriptions
```typescript
useEffect(() => {
  const unsubscribe1 = service1.subscribe(handler1);
  const unsubscribe2 = service2.subscribe(handler2);
  
  return () => {
    unsubscribe1?.();
    unsubscribe2?.();
  };
}, [service1, service2]);
```

#### ❌ Bad Pattern - Missing Cleanup
```typescript
useEffect(() => {
  service.subscribe((data) => {
    // This subscription will never be cleaned up!
  });
}, []);
```

### 4. Async Operation Cancellation

#### ✅ Good Pattern - AbortController
```typescript
useEffect(() => {
  const abortController = new AbortController();
  
  const fetchData = async () => {
    try {
      const response = await fetch(url, {
        signal: abortController.signal
      });
      const data = await response.json();
      setState(data);
    } catch (error) {
      if (error.name === 'AbortError') {
        // Request was cancelled, ignore
        return;
      }
      console.error('Fetch failed:', error);
    }
  };
  
  fetchData();
  
  return () => {
    abortController.abort();
  };
}, [url]);
```

#### ✅ Good Pattern - Cancellation Flag
```typescript
useEffect(() => {
  let cancelled = false;
  
  const loadData = async () => {
    const data = await fetchData();
    
    // Check if still mounted before updating state
    if (!cancelled) {
      setState(data);
    }
  };
  
  loadData();
  
  return () => {
    cancelled = true;
  };
}, []);
```

#### ❌ Bad Pattern - No Cancellation
```typescript
useEffect(() => {
  const loadData = async () => {
    const data = await fetchData();
    setState(data); // May update state after unmount!
  };
  
  loadData();
}, []);
```

### 5. Ref Cleanup

#### ✅ Good Pattern - Clear Refs
```typescript
useEffect(() => {
  const resource = createResource();
  resourceRef.current = resource;
  
  return () => {
    if (resourceRef.current) {
      resourceRef.current.cleanup();
      resourceRef.current = null; // Clear ref
    }
  };
}, []);
```

#### ❌ Bad Pattern - Lingering Refs
```typescript
useEffect(() => {
  const resource = createResource();
  resourceRef.current = resource;
  
  return () => {
    // Ref still holds reference to resource!
  };
}, []);
```

### 6. State Array Management

#### ✅ Good Pattern - Bounded Arrays
```typescript
const handleNewData = (data: string) => {
  setOutput(prev => {
    const newOutput = [...prev, data];
    // Keep only last N items
    return newOutput.slice(-500);
  });
};
```

#### ✅ Good Pattern - Circular Buffer
```typescript
const handleNewData = (data: string) => {
  setOutput(prev => {
    // Use slice to prevent unbounded growth
    const bounded = prev.length >= MAX_SIZE 
      ? prev.slice(-MAX_SIZE + 1)
      : prev;
    return [...bounded, data];
  });
};
```

#### ❌ Bad Pattern - Unbounded Growth
```typescript
const handleNewData = (data: string) => {
  setOutput(prev => [...prev, data]); // Grows forever!
};
```

### 7. Map/Set Cleanup

#### ✅ Good Pattern - Cleanup Disconnected Entries
```typescript
const cleanupDisconnectedServers = useCallback(() => {
  setState(prev => {
    const servers = new Map(prev.servers);
    
    // Remove servers that have been disconnected for > 1 hour
    const oneHourAgo = Date.now() - 3600000;
    for (const [name, server] of servers.entries()) {
      if (server.status === 'disconnected' && 
          server.lastCheckTime && 
          server.lastCheckTime < oneHourAgo) {
        servers.delete(name);
      }
    }
    
    return { ...prev, servers };
  });
}, []);
```

#### ❌ Bad Pattern - Never Cleanup
```typescript
const addServer = (name: string, server: Server) => {
  setState(prev => {
    const servers = new Map(prev.servers);
    servers.set(name, server); // Map grows forever!
    return { ...prev, servers };
  });
};
```

### 8. Tool Registration Cleanup

#### ✅ Good Pattern - Track and Unregister
```typescript
const registerServerTools = useCallback((serverName: string, tools: MCPTool[]) => {
  // Unregister previous tools first
  const prevTools = lastRegisteredTools.current.get(serverName);
  if (prevTools) {
    prevTools.forEach(tool => {
      toolRegistry.unregister(`${serverName}:${tool.name}`);
    });
  }
  
  // Register new tools
  tools.forEach(tool => {
    const wrappedTool = wrapperFactory.wrapTool(serverName, tool);
    toolRegistry.register(wrappedTool);
  });
  
  // Track for cleanup
  lastRegisteredTools.current.set(serverName, tools);
}, [toolRegistry]);

// Cleanup on unmount
useEffect(() => {
  return () => {
    // Unregister all tools
    for (const [serverName, tools] of lastRegisteredTools.current.entries()) {
      tools.forEach(tool => {
        toolRegistry.unregister(`${serverName}:${tool.name}`);
      });
    }
    lastRegisteredTools.current.clear();
  };
}, [toolRegistry]);
```

#### ❌ Bad Pattern - No Cleanup
```typescript
const registerServerTools = (serverName: string, tools: MCPTool[]) => {
  tools.forEach(tool => {
    toolRegistry.register(tool); // Never unregistered!
  });
};
```

## Common Pitfalls

### 1. Dependency Array Issues

#### ❌ Problem: Stale Closures
```typescript
useEffect(() => {
  const interval = setInterval(() => {
    console.log(count); // Always logs initial count!
  }, 1000);
  
  return () => clearInterval(interval);
}, []); // Missing count dependency
```

#### ✅ Solution: Include Dependencies
```typescript
useEffect(() => {
  const interval = setInterval(() => {
    console.log(count); // Logs current count
  }, 1000);
  
  return () => clearInterval(interval);
}, [count]); // Include count
```

### 2. Cleanup Function Complexity

#### ❌ Problem: Complex Cleanup Logic
```typescript
useEffect(() => {
  // Setup code
  return () => {
    // Complex cleanup that might fail
    resource1.cleanup();
    resource2.cleanup();
    resource3.cleanup();
  };
}, []);
```

#### ✅ Solution: Safe Cleanup
```typescript
useEffect(() => {
  // Setup code
  return () => {
    try {
      resource1?.cleanup();
    } catch (error) {
      console.warn('Failed to cleanup resource1:', error);
    }
    
    try {
      resource2?.cleanup();
    } catch (error) {
      console.warn('Failed to cleanup resource2:', error);
    }
    
    try {
      resource3?.cleanup();
    } catch (error) {
      console.warn('Failed to cleanup resource3:', error);
    }
  };
}, []);
```

### 3. Conditional Cleanup

#### ❌ Problem: Conditional Without Return
```typescript
useEffect(() => {
  if (condition) {
    const subscription = service.subscribe(handler);
    // Missing return for cleanup!
  }
}, [condition]);
```

#### ✅ Solution: Always Return Cleanup
```typescript
useEffect(() => {
  if (!condition) return;
  
  const subscription = service.subscribe(handler);
  
  return () => {
    subscription.unsubscribe();
  };
}, [condition]);
```

## Testing for Memory Leaks

### Manual Testing

```typescript
// Test component mount/unmount cycles
for (let i = 0; i < 100; i++) {
  const { unmount } = render(<Component />);
  unmount();
}

// Check memory usage
console.log(process.memoryUsage());
```

### Automated Testing

```typescript
describe('Memory Leak Tests', () => {
  it('should cleanup event listeners on unmount', () => {
    const { unmount } = render(<Component />);
    
    // Verify listeners are added
    expect(mockEventEmitter.listenerCount('data')).toBe(1);
    
    // Unmount
    unmount();
    
    // Verify listeners are removed
    expect(mockEventEmitter.listenerCount('data')).toBe(0);
  });
  
  it('should clear timers on unmount', () => {
    jest.useFakeTimers();
    const { unmount } = render(<Component />);
    
    // Verify timer is set
    expect(jest.getTimerCount()).toBe(1);
    
    // Unmount
    unmount();
    
    // Verify timer is cleared
    expect(jest.getTimerCount()).toBe(0);
  });
});
```

## Profiling Tools

### Node.js Memory Profiling

```bash
# Run with inspector
node --inspect dist/cli.js

# Take heap snapshots
node --inspect --heap-prof dist/cli.js

# Monitor memory usage
node --trace-gc dist/cli.js
```

### Chrome DevTools

1. Open Chrome DevTools
2. Go to Memory tab
3. Take heap snapshot before operation
4. Perform operation (mount/unmount components)
5. Take heap snapshot after operation
6. Compare snapshots to find leaks

### Memory Usage Tracking

```typescript
// Track memory usage over time
const trackMemory = () => {
  const usage = process.memoryUsage();
  console.log({
    rss: `${(usage.rss / 1024 / 1024).toFixed(2)} MB`,
    heapTotal: `${(usage.heapTotal / 1024 / 1024).toFixed(2)} MB`,
    heapUsed: `${(usage.heapUsed / 1024 / 1024).toFixed(2)} MB`,
    external: `${(usage.external / 1024 / 1024).toFixed(2)} MB`,
  });
};

// Track periodically
setInterval(trackMemory, 5000);
```

## Checklist

Before merging any component with useEffect:

- [ ] All event listeners have cleanup
- [ ] All timers (setInterval/setTimeout) have cleanup
- [ ] All subscriptions have cleanup
- [ ] Async operations can be cancelled
- [ ] Refs are cleared on cleanup
- [ ] Arrays/Maps have size limits
- [ ] Dependencies are correct
- [ ] Cleanup handles errors gracefully
- [ ] Memory leak tests added
- [ ] Profiling shows no leaks

## References

- [React useEffect Cleanup](https://react.dev/reference/react/useEffect#cleanup-function)
- [Node.js Memory Management](https://nodejs.org/en/docs/guides/simple-profiling/)
- [Chrome DevTools Memory Profiler](https://developer.chrome.com/docs/devtools/memory-problems/)
- [Ink Best Practices](https://github.com/vadimdemedes/ink#best-practices)

## Conclusion

Proper memory management is critical for long-running CLI applications. Always:

1. Clean up what you set up
2. Test for leaks
3. Profile regularly
4. Document patterns
5. Review cleanup code carefully

Following these patterns will prevent memory leaks and ensure stable, performant applications.
