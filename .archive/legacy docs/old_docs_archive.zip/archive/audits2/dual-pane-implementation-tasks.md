# Dual-Pane Input Routing - Implementation Tasks

**Date:** January 24, 2026  
**Status:** 📋 Ready to Start

## Overview

Implement dual-pane system with independent view navigation and input routing, allowing users to view one thing while typing into another.

---

## Scope Clarification (January 24, 2026)

Deliver the **full dual-pane system** in one pass with **zero LLM regressions**:
- Wrap existing LLM input logic with an early return for terminal destinations.
- Do **not** modify model picker, slash commands, menus, history, or multi-line behavior.
- Raw input is active only for `terminal1` / `terminal2`.
- Ctrl+Left/Right handling belongs to the **input box**, not global view logic.
- Right panel expansion (LLM Chat + Terminal 2 views) and UI indicators are part of this delivery.
- LLM chat is **mirrored left/right** (single model). No independent right-panel model in this phase.
- Editor input remains **disabled**; it is only a routing destination for future work.

---

## Phase 1: Foundation - Input Routing System

### Task 1.1: Create InputRoutingContext
**File:** `packages/cli/src/ui/contexts/InputRoutingContext.tsx`

**Requirements:**
- Create context for managing input routing
- Support 4 destinations: LLM, Editor, Terminal1, Terminal2
- Provide cycling function (next/prev)
- Derive input mode from active destination

**Implementation:**
```typescript
type InputDestination = 'llm' | 'editor' | 'terminal1' | 'terminal2';
type InputMode = 'line-buffered' | 'raw' | 'disabled';

interface InputRoutingContextValue {
  activeDestination: InputDestination;
  setActiveDestination: (dest: InputDestination) => void;
  cycleDestination: (direction: 'next' | 'prev') => void;
  inputMode: InputMode;
}
```

**Acceptance Criteria:**
- [ ] Context created and exported
- [ ] Provider wraps App
- [ ] Hook `useInputRouting()` available
- [ ] Cycling works: LLM → E → T1 → T2 → LLM
- [ ] Input mode correctly derived

---

### Task 1.2: Create InputRoutingIndicator Component
**File:** `packages/cli/src/ui/components/InputRoutingIndicator.tsx`

**Requirements:**
- Visual indicator showing `[LLM | E | T1 | T2]`
- Active destination highlighted with `●`
- Inactive destinations shown with text only
- Positioned above input box

**Implementation:**
```typescript
// Display format:
// Active LLM:  [●LLM | E | T1 | T2]
// Active T1:   [LLM | E | ●T1 | T2]
```

**Acceptance Criteria:**
- [ ] Component renders indicator
- [ ] Active destination highlighted
- [ ] Updates when destination changes
- [ ] Styled with theme colors
- [ ] Positioned correctly above input

---

### Task 1.3: Separate Input Routing from View Navigation
**File:** `packages/cli/src/ui/components/layout/ChatInputArea.tsx`

**Requirements:**
- Ctrl+Left/Right cycles input destination (NOT view)
- Tab/Shift+Tab cycles view (existing behavior)
- Input routing independent from view navigation
- Keep all existing LLM input logic unchanged below the new early return

**Changes:**
```typescript
useInput((input, key) => {
  // NEW: Input routing (in input box)
  if (key.ctrl && key.leftArrow) {
    cycleDestination('prev');
    return;
  }
  if (key.ctrl && key.rightArrow) {
    cycleDestination('next');
    return;
  }
  
  // EXISTING: View navigation handled elsewhere
  // ...
});
```

**Acceptance Criteria:**
- [ ] Ctrl+Left/Right cycles input destination
- [ ] Tab still cycles view
- [ ] No conflict between the two systems
- [ ] Visual indicator updates on cycle

---

## Phase 2: Raw Input Mode for Terminals

### Task 2.1: Implement Character-by-Character Input
**File:** `packages/cli/src/ui/components/layout/ChatInputArea.tsx`

**Requirements:**
- When destination is T1 or T2, send keypresses immediately
- No buffering, no waiting for Enter
- Handle special keys (Ctrl+C, Ctrl+D, backspace, etc.)

**Implementation:**
```typescript
const sendRawInput = (input: string, key: Key) => {
  const dest = activeDestination;
  
  if (dest === 'terminal1' || dest === 'terminal2') {
    if (key.return) {
      sendToTerminal(dest, '\r');
    } else if (key.backspace) {
      sendToTerminal(dest, '\x7f');
    } else if (key.ctrl && input === 'c') {
      sendToTerminal(dest, '\x03');
    } else if (input) {
      sendToTerminal(dest, input);
    }
  }
};
```

**Acceptance Criteria:**
- [ ] Keypresses sent immediately to terminal
- [ ] No input box buffering in raw mode
- [ ] Special keys handled correctly
- [ ] Works for both T1 and T2

---

### Task 2.2: Update TerminalContext for Raw Input
**File:** `packages/cli/src/ui/contexts/TerminalContext.tsx`

**Requirements:**
- Add `sendRawInput(char: string)` method
- Expose in context value
- Write directly to PTY without newline

**Implementation:**
```typescript
const sendRawInput = useCallback((char: string) => {
  if (ptyProcessRef.current && isRunning) {
    ptyProcessRef.current.write(char);
  }
}, [isRunning]);
```

**Acceptance Criteria:**
- [ ] `sendRawInput` method added
- [ ] Exposed in context
- [ ] Writes to PTY immediately
- [ ] No newline added

---

## Phase 3: Right Panel Expansion

### Task 3.1: Update WindowContext for Right Panel
**File:** `packages/cli/src/ui/contexts/WindowContext.tsx`

**Requirements:**
- Add right panel type: `'tools' | 'workspace' | 'llm-chat' | 'terminal2'`
- Add state for active right panel
- Add cycling function for right panel
- Keep main panel logic unchanged

**Implementation:**
```typescript
type RightPanelType = 'tools' | 'workspace' | 'llm-chat' | 'terminal2';

interface WindowContextValue {
  // Main panel (existing)
  activeWindow: WindowType;
  setActiveWindow: (window: WindowType) => void;
  cycleMainWindow: () => void;
  
  // Right panel (new)
  activeRightPanel: RightPanelType;
  setActiveRightPanel: (panel: RightPanelType) => void;
  cycleRightPanel: () => void;
}
```

**Acceptance Criteria:**
- [ ] Right panel types defined
- [ ] State management added
- [ ] Cycling function works
- [ ] Default to 'tools'
- [ ] Main panel unchanged

---

### Task 3.2: Add Right Panel Dot Indicators
**File:** Find where right panel dots are rendered (likely in side panel component)

**Requirements:**
- Currently shows 2 dots (Tools, Workspace)
- Add 2 more dots (LLM Chat, Terminal 2)
- Total: 4 dots
- Active dot highlighted in purple

**Implementation:**
```typescript
// Use existing DotIndicator component
<DotIndicator 
  total={4} 
  active={activeRightPanelIndex} 
  theme={theme} 
/>

// Map panel to index:
// 0: Tools
// 1: Workspace  
// 2: LLM Chat
// 3: Terminal 2
```

**Acceptance Criteria:**
- [ ] 4 dots visible in right panel
- [ ] Active dot highlighted
- [ ] Updates when cycling
- [ ] Positioned correctly

---

### Task 3.3: Create Terminal 2 Component
**File:** `packages/cli/src/ui/components/Terminal2.tsx`

**Requirements:**
- Separate terminal instance from Terminal 1
- Independent PTY process
- Same rendering as Terminal 1
- Uses xterm.js headless

**Implementation:**
```typescript
// Option 1: Duplicate Terminal component
// Option 2: Make Terminal accept instance ID
// Option 3: Create Terminal2Context with separate PTY
```

**Acceptance Criteria:**
- [ ] Terminal 2 renders independently
- [ ] Separate PTY instance
- [ ] Can run different commands than T1
- [ ] Same ANSI rendering as T1

---

### Task 3.4: Create Right Panel LLM Chat View
**File:** `packages/cli/src/ui/components/RightPanelLLMChat.tsx`

**Requirements:**
- Display LLM chat in right panel
- **Mirror the main chat** (same messages, same streaming)
- Shows message history
- Scrollable

**Implementation:**
```typescript
// Mirror main chat (same messages)
```

**Acceptance Criteria:**
- [ ] LLM chat displays in right panel
- [ ] Shows message history
- [ ] Scrollable
- [ ] Styled consistently
- [ ] Uses the same chat state as main panel
- [ ] No separate model/session (mirror only)

---

### Task 3.5: Wire Right Panel Views
**File:** `packages/cli/src/ui/components/tabs/ChatTab.tsx` or side panel component

**Requirements:**
- Render correct view based on `activeRightPanel`
- Switch between Tools, Workspace, LLM Chat, Terminal 2
- Smooth transitions

**Implementation:**
```typescript
{activeRightPanel === 'tools' && <ToolsPanel />}
{activeRightPanel === 'workspace' && <WorkspacePanel />}
{activeRightPanel === 'llm-chat' && <RightPanelLLMChat />}
{activeRightPanel === 'terminal2' && <Terminal2 />}
```

**Acceptance Criteria:**
- [ ] All 4 views render correctly
- [ ] Switching works smoothly
- [ ] No layout issues
- [ ] Proper cleanup on unmount

---

## Phase 4: Status Messages

### Task 4.1: Update Status Bar Messages
**File:** Find where status messages are displayed

**Requirements:**
- Add messages for new views
- Update based on active window/panel

**Messages:**
- Main Chat: `OLLM: Idle` or `OLLM: Streaming`
- Main Editor: `OLLM: Editor`
- Main Terminal: `OLLM: Terminal Mode`
- Right LLM: `OLLM: LLM Chat (Right)`
- Right Terminal: `OLLM: Terminal 2`

**Acceptance Criteria:**
- [ ] All status messages defined
- [ ] Updates when switching views
- [ ] Correct message for each view
- [ ] Styled consistently

---

## Phase 5: Keyboard Shortcuts

### Task 5.1: Add Quick Switch Shortcuts
**File:** `packages/cli/src/ui/App.tsx` or global input handler

**Requirements:**
- Ctrl+1: Switch input to LLM
- Ctrl+2: Switch input to Terminal 1
- Ctrl+3: Switch input to Terminal 2
- Ctrl+Tab: Cycle right panel
- Ctrl+Shift+Tab: Cycle right panel (reverse)

**Implementation:**
```typescript
useInput((input, key) => {
  if (key.ctrl && input === '1') {
    setActiveDestination('llm');
  }
  if (key.ctrl && input === '2') {
    setActiveDestination('terminal1');
  }
  if (key.ctrl && input === '3') {
    setActiveDestination('terminal2');
  }
  // ...
});
```

**Acceptance Criteria:**
- [ ] All shortcuts work
- [ ] No conflicts with existing shortcuts
- [ ] Visual feedback on switch
- [ ] Documented in help

---

## Phase 6: Testing & Polish

### Task 6.1: Integration Testing
**Requirements:**
- Test all view combinations
- Test all input routing combinations
- Test terminal raw input
- Test dual terminal setup

**Test Cases:**
- [ ] View T1, Input to T1 (Gemini CLI works)
- [ ] View Chat, Input to T1 (background commands)
- [ ] View T1, Input to T2 (dual terminal)
- [ ] View Chat, Input to LLM (normal chat)
- [ ] Cycle through all views
- [ ] Cycle through all input destinations
- [ ] Quick switch shortcuts work

---

### Task 6.2: Visual Polish
**Requirements:**
- Smooth transitions
- Clear visual indicators
- Consistent styling
- No layout glitches

**Checklist:**
- [ ] Input routing indicator always visible
- [ ] Dot indicators update smoothly
- [ ] Status messages clear
- [ ] No flickering on switch
- [ ] Proper spacing and alignment

---

### Task 6.3: Documentation
**Requirements:**
- Update user documentation
- Add keyboard shortcuts reference
- Document input routing system
- Add examples

**Files to Update:**
- [ ] `docs/keyboard-shortcuts.md`
- [ ] `docs/UI and Settings/keybinds.md`
- [ ] README with new features
- [ ] In-app help text

---

## Implementation Order

### Single Pass Delivery
- [ ] Task 1.1: InputRoutingContext
- [ ] Task 1.2: InputRoutingIndicator
- [ ] Task 1.3: Separate input routing
- [ ] Task 2.1: Character-by-character input
- [ ] Task 2.2: Update TerminalContext
- [ ] Task 3.1: Update WindowContext
- [ ] Task 3.2: Add dot indicators
- [ ] Task 3.3: Create Terminal 2
- [ ] Task 3.4: Create LLM Chat view (mirror only)
- [ ] Task 3.5: Wire views
- [ ] Task 4.1: Status messages
- [ ] Task 5.1: Keyboard shortcuts
- [ ] Task 6.1: Integration testing
- [ ] Task 6.2: Visual polish
- [ ] Task 6.3: Documentation

---

## Success Criteria

✅ **Input Routing:**
- User can cycle input destinations with Ctrl+Left/Right
- Visual indicator shows active destination
- Input goes to correct destination

✅ **Raw Input Mode:**
- Terminal 1 receives character-by-character input
- Terminal 2 receives character-by-character input
- Gemini CLI and interactive apps work

✅ **Right Panel:**
- 4 views available: Tools, Workspace, LLM Chat, Terminal 2
- Dot indicators show 4 dots
- Cycling works smoothly

✅ **Independence:**
- View navigation independent from input routing
- Can view one thing while typing to another
- No conflicts between systems

✅ **Polish:**
- All keyboard shortcuts work
- Status messages correct
- Visual indicators clear
- No bugs or glitches

---

## Files to Create

- [ ] `packages/cli/src/ui/contexts/InputRoutingContext.tsx`
- [ ] `packages/cli/src/ui/components/InputRoutingIndicator.tsx`
- [ ] `packages/cli/src/ui/components/Terminal2.tsx`
- [ ] `packages/cli/src/ui/components/RightPanelLLMChat.tsx`
- [ ] `packages/cli/src/ui/contexts/Terminal2Context.tsx` (if separate)

## Files to Modify

- [ ] `packages/cli/src/ui/contexts/WindowContext.tsx`
- [ ] `packages/cli/src/ui/components/layout/ChatInputArea.tsx`
- [ ] `packages/cli/src/ui/contexts/TerminalContext.tsx`
- [ ] `packages/cli/src/ui/components/tabs/ChatTab.tsx`
- [ ] `packages/cli/src/ui/App.tsx`
- [ ] Side panel component (find and update)
- [ ] Status bar component (find and update)

---

## Notes

- Terminal 1 is working with xterm.js ✅
- Need to ensure Terminal 2 uses same approach
- Input routing is key feature - prioritize this
- Right panel expansion can be done incrementally
- Test with Gemini CLI throughout development

---

## Questions to Resolve

1. **Terminal 2 Context:** Separate context or shared with instance ID?
2. **LLM Chat Right Panel:** Mirror (single model) now; independent conversation later.
3. **Dual Streaming:** Send to both LLMs simultaneously? (future)
4. **Input Box Visibility:** Hide in raw mode or keep visible?
5. **Editor Input:** Keep disabled (this phase); implement later.

---

## Risk Mitigation

**Risk:** Breaking existing terminal functionality  
**Mitigation:** Test Terminal 1 after each change

**Risk:** Input routing conflicts with existing shortcuts  
**Mitigation:** Document all shortcuts, test combinations

**Risk:** Performance with two terminals  
**Mitigation:** Profile PTY usage, optimize if needed

**Risk:** Complex state management  
**Mitigation:** Keep contexts focused, clear separation of concerns
