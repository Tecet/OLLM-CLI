# Gemini CLI Terminal Solution

**Date:** January 24, 2026  
**Status:** ✅ Solution Found  
**Source:** Gemini CLI codebase analysis

---

## How Gemini CLI Solves Terminal Rendering

### The Problem They Solved
- Need to display terminal output with proper ANSI rendering
- Using React + Ink (same as us)
- Want colors, formatting, and proper terminal emulation

### Their Solution: xterm.js Headless + Structured Tokens

**Architecture:**
```
Terminal Output (ANSI codes)
    ↓
@xterm/headless (Terminal emulator)
    ↓
terminalSerializer.ts (Parse to structured tokens)
    ↓
AnsiOutput.tsx (Render with Ink Text components)
```

---

## Code Analysis

### 1. Terminal Emulation (`@xterm/headless`)

**Package:** `@xterm/headless`  
**Purpose:** Headless terminal emulator (xterm.js without DOM)

- Properly parses all ANSI escape codes
- Maintains terminal buffer state
- Handles cursor positioning, colors, formatting
- Industry-standard terminal emulation

### 2. Serialization (`terminalSerializer.ts`)

**Location:** `packages/core/src/utils/terminalSerializer.ts`

**Data Structures:**
```typescript
export interface AnsiToken {
  text: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  dim: boolean;
  inverse: boolean;
  fg: string;      // Foreground color
  bg: string;      // Background color
}

export type AnsiLine = AnsiToken[];
export type AnsiOutput = AnsiLine[];
```

**Process:**
1. Read from xterm.js buffer
2. Extract each cell's attributes (bold, color, etc.)
3. Group consecutive cells with same attributes into tokens
4. Build structured output (array of lines, each line is array of tokens)

**Key Features:**
- Handles RGB colors, palette colors, and default colors
- Preserves all formatting attributes
- Cursor position tracking
- Efficient token merging (consecutive cells with same style)

### 3. Rendering (`AnsiOutput.tsx`)

**Location:** `packages/cli/src/ui/components/AnsiOutput.tsx`

```typescript
export const AnsiOutputText: React.FC<AnsiOutputProps> = ({
  data,
  availableTerminalHeight,
  width,
}) => {
  const lastLines = data.slice(-(availableTerminalHeight || 24));
  
  return (
    <Box flexDirection="column" width={width} flexShrink={0}>
      {lastLines.map((line: AnsiLine, lineIndex: number) => (
        <Text key={lineIndex} wrap="truncate">
          {line.length > 0
            ? line.map((token: AnsiToken, tokenIndex: number) => (
                <Text
                  key={tokenIndex}
                  color={token.fg}
                  backgroundColor={token.bg}
                  inverse={token.inverse}
                  dimColor={token.dim}
                  bold={token.bold}
                  italic={token.italic}
                  underline={token.underline}
                >
                  {token.text}
                </Text>
              ))
            : null}
        </Text>
      ))}
    </Box>
  );
};
```

**Benefits:**
- ✅ Uses native Ink Text props (color, bold, etc.)
- ✅ No custom ANSI parsing needed
- ✅ Perfect rendering of all terminal features
- ✅ Efficient (only renders visible lines)

---

## Why This Works Better

### vs. strip-ansi (Our Current Approach)
❌ **strip-ansi:** Removes all ANSI codes → loses colors/formatting  
✅ **xterm.js:** Parses ANSI codes → preserves everything

### vs. ansi-to-react
❌ **ansi-to-react:** Direct ANSI → React (module issues, limited parsing)  
✅ **xterm.js:** ANSI → Structured data → Ink components (clean, reliable)

### vs. Custom ANSI Parser
❌ **Custom parser:** Need to implement all ANSI codes (complex, error-prone)  
✅ **xterm.js:** Industry-standard, battle-tested, complete implementation

### vs. Blessed
❌ **Blessed:** Complete rewrite, different paradigm  
✅ **xterm.js + Ink:** Keep React/Ink, just better parsing

---

## Implementation for Our Project

### Step 1: Add Dependencies

```bash
npm install @xterm/headless
```

### Step 2: Create Terminal Serializer

Copy/adapt Gemini's `terminalSerializer.ts`:
- Parse xterm.js buffer to AnsiToken[]
- Handle colors, formatting, cursor

### Step 3: Update Terminal Component

Replace current rendering with token-based approach:
```typescript
// Instead of:
<Text>{stripAnsi(line)}</Text>

// Use:
{line.map(token => (
  <Text
    color={token.fg}
    bold={token.bold}
    // ... other props
  >
    {token.text}
  </Text>
))}
```

### Step 4: Connect PTY to xterm.js

```typescript
import { Terminal } from '@xterm/headless';

const xtermTerminal = new Terminal({
  cols: 80,
  rows: 30
});

// Pipe PTY output to xterm
ptyProcess.onData(data => {
  xtermTerminal.write(data);
});

// Serialize for rendering
const output = serializeTerminalToObject(xtermTerminal);
```

---

## Effort Estimate

**Time:** 1-2 days

**Tasks:**
1. Install `@xterm/headless` (5 min)
2. Copy/adapt `terminalSerializer.ts` (2-3 hours)
3. Update `TerminalContext` to use xterm.js (2-3 hours)
4. Update `Terminal.tsx` rendering (1-2 hours)
5. Test and fix issues (2-4 hours)

**Complexity:** Medium
- Mostly copying proven code from Gemini CLI
- Well-documented xterm.js API
- Clean integration with existing PTY setup

---

## Benefits

✅ **Perfect ANSI rendering** - All colors, formatting work  
✅ **Industry standard** - xterm.js used by VS Code, Hyper, etc.  
✅ **Keep React/Ink** - No rewrite needed  
✅ **Proven solution** - Google uses it in production  
✅ **Future-proof** - Full terminal emulation capabilities  
✅ **Better than Blessed** - No paradigm shift, just better parsing

---

## Comparison

| Solution | Effort | Quality | Compatibility |
|----------|--------|---------|---------------|
| **strip-ansi (current)** | ✅ Done | ❌ Poor | ✅ Works |
| **ansi-to-react** | ⚠️ 1 day | ⚠️ Medium | ❌ Module issues |
| **Custom parser** | ❌ 1 week | ⚠️ Medium | ✅ Works |
| **xterm.js + tokens** | ✅ 1-2 days | ✅ Excellent | ✅ Perfect |
| **Blessed rewrite** | ❌ 2-4 weeks | ✅ Excellent | ❌ Complete rewrite |

---

## Recommendation

**Use Gemini CLI's approach: xterm.js headless + token serialization**

**Why:**
1. **Proven** - Google uses it in production
2. **Clean** - Structured data, easy to render
3. **Complete** - Full terminal emulation
4. **Fast** - 1-2 days vs weeks for Blessed
5. **Maintainable** - Standard library, well-documented

**Next Steps:**
1. Install `@xterm/headless`
2. Copy `terminalSerializer.ts` from Gemini CLI
3. Update `TerminalContext` to use xterm.js
4. Update `Terminal.tsx` to render tokens
5. Test with Gemini CLI and other tools

---

## Files to Reference

**From Gemini CLI:**
- `packages/core/src/utils/terminalSerializer.ts` - ANSI parsing logic
- `packages/cli/src/ui/components/AnsiOutput.tsx` - Rendering component

**Our Files to Update:**
- `packages/cli/src/ui/contexts/TerminalContext.tsx` - Add xterm.js
- `packages/cli/src/ui/components/Terminal.tsx` - Token-based rendering
- `packages/cli/src/ui/components/AnsiText.tsx` - Delete (not needed)

---

**Status:** ✅ Solution identified - Ready to implement  
**Decision:** Use xterm.js headless + token serialization (Gemini CLI approach)
