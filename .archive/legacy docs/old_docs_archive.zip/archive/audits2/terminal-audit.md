# Terminal Module Audit

**Date:** January 24, 2026  
**Status:** Initial Audit - Issues Identified  
**Priority:** High

---

## Executive Summary

The terminal feature in the left column allows users to switch between Chat, Terminal, and Editor windows. This audit documents the current implementation, identifies issues, and prepares for upcoming changes requested by the user.

**Current Status:** ⚠️ Terminal feature reported as broken

---

## Architecture Overview

### Component Structure

```
Terminal Feature
├── Context Layer
│   ├── TerminalContext.tsx       - Manages PTY session and output
│   └── WindowContext.tsx         - Manages window switching (chat/terminal/editor)
├── Component Layer
│   ├── Terminal.tsx              - Renders terminal output
│   ├── WindowSwitcher.tsx        - Visual indicator for active window
│   └── ChatInputArea.tsx         - Handles input routing
├── Hook Layer
│   └── useTerminal.ts            - Proxy hook for terminal context
└── Utility Layer
    ├── terminal.ts               - Terminal control sequences (mouse, keyboard)
    └── windowDisplayLabels.ts    - Display labels for windows

```

### Window Types

The application supports three window types in the left column:

1. **Chat** - Default window showing message history
2. **Terminal** - Interactive terminal for command execution  
3. **Editor** - Code editor for file editing

---

## Current Implementation

### 1. Terminal Context (`TerminalContext.tsx`)

**Purpose:** Manages a shared terminal session using `node-pty`

**Key Features:**
- Spawns a PTY process (PowerShell on Windows, Bash on Unix)
- Manages terminal output buffer (last 500 chunks)
- Provides commands: `sendCommand`, `clear`, `interrupt`, `resize`
- Handles cleanup on unmount

**State Management:**
```typescript
interface TerminalContextValue {
  output: TerminalLine[];        // Parsed output lines
  isRunning: boolean;            // PTY process status
  sendCommand: (cmd: string) => void;
  clear: () => void;
  interrupt: () => void;         // Sends Ctrl+C
  resize: (cols, rows) => void;
  rawOutput: string[];           // Raw output buffer
}
```

**Issues Identified:**
- ✅ Memory leak prevention implemented (disposables)
- ⚠️ No error recovery if PTY spawn fails
- ⚠️ Output buffer limited to 500 chunks (may lose history)
- ⚠️ No persistence between sessions

### 2. Window Context (`WindowContext.tsx`)

**Purpose:** Manages window switching between Chat, Terminal, and Editor

**Key Features:**
- Tracks active window state
- Provides `switchWindow()` to cycle through windows
- Convenience flags: `isTerminalActive`, `isChatActive`, `isEditorActive`

**Window Cycle:**
```
chat → terminal → editor → chat
```

**Issues Identified:**
- ✅ Clean implementation, no obvious issues
- ℹ️ No direct window selection (only cycling)
- ℹ️ No window history or back navigation

### 3. Terminal Component (`Terminal.tsx`)

**Purpose:** Renders terminal output with scrolling support

**Key Features:**
- Responsive width calculation based on side panel state
- Scrolling with Up/Down arrows (when focused)
- Auto-scroll to bottom on new output
- Line collapsing for repeated output
- ANSI code stripping for display

**Scroll Behavior:**
- Scrolls when terminal is focused OR Alt+Up/Down is pressed
- Auto-resets to bottom when new output arrives
- Max scroll = total lines - visible height

**Issues Identified:**
- ⚠️ Scroll state resets on ANY new output (even if user is scrolling)
- ⚠️ No visual indicator for scroll position
- ⚠️ Line collapsing may hide important repeated messages
- ⚠️ Width calculation may not account for all UI elements

### 4. Input Routing (`ChatInputArea.tsx`)

**Purpose:** Routes input to either chat or terminal based on active window

**Logic:**
```typescript
if (isTerminalActive) {
  sendCommand(value);  // Send to PTY
} else {
  sendMessage(value);  // Send to chat
}
```

**Issues Identified:**
- ✅ Clean separation between chat and terminal input
- ℹ️ No command history for terminal
- ℹ️ No autocomplete or suggestions

---

## Integration Points

### 1. Window Switching

**Keyboard Shortcuts:**
- `Ctrl+Left/Right` - Cycle through windows (handled in App.tsx)
- Window switcher shows visual indicator (dots)

**Display Labels:**
- Left column: "Chat", "Terminal", "Editor"
- Right panel header changes based on active window:
  - Chat → "Tools"
  - Terminal → "Workspace"
  - Editor → "Tools"

### 2. Focus Management

Terminal respects focus system:
- Only scrolls when `chat-input` is focused AND terminal is active
- Alt+Up/Down works globally for scrolling

### 3. Layout Integration

Terminal width adapts to:
- Side panel visibility (70% width when visible, 100% when hidden)
- Terminal columns (stdout.columns - 6 for padding)

---

## Known Issues

### Critical Issues

1. **Terminal Feature Broken** (Reported by User)
   - Status: ⚠️ Needs investigation
   - Impact: High
   - Details: User reports terminal is not working properly

### High Priority Issues

2. **Scroll Reset on New Output**
   - When user is scrolling through history, any new output resets scroll to bottom
   - Makes it impossible to review history while commands are running
   - Fix: Only auto-scroll if user is already at bottom (scrollOffset === 0)

3. **No Visual Scroll Indicator**
   - Users can't tell if they're scrolled up or at the bottom
   - No indication of how much history is available
   - Fix: Add scroll position indicator (e.g., "↑ 50 lines above")

### Medium Priority Issues

4. **No Command History**
   - Terminal doesn't provide Up/Down arrow command history
   - Users must retype commands
   - Fix: Implement command history buffer

5. **No Error Recovery**
   - If PTY spawn fails, terminal is permanently broken
   - No retry mechanism or error message
   - Fix: Add error state and retry button

6. **Limited Output Buffer**
   - Only keeps last 500 chunks (may be insufficient)
   - No way to export or save terminal history
   - Fix: Make buffer size configurable, add export feature

### Low Priority Issues

7. **Line Collapsing May Hide Important Output**
   - Repeated lines are collapsed with "(x5)" notation
   - May hide important repeated errors or status messages
   - Fix: Make collapsing optional or smarter (don't collapse errors)

8. **No Direct Window Selection**
   - Users must cycle through windows to reach desired one
   - Inefficient for quick switching
   - Fix: Add direct selection (e.g., Ctrl+1/2/3)

---

## Pending Changes

The user has indicated several changes they want to make to the terminal feature. These will be documented in subsequent messages.

**Preparation:**
- ✅ Audit document created
- ✅ Current implementation documented
- ✅ Issues identified
- ⏳ Awaiting user requirements

---

## Testing Status

### Existing Tests

**Memory Leak Tests** (`.ui/__tests__/memory-leaks.test.tsx`):
- ✅ PTY event listener cleanup on unmount
- ✅ No memory leaks on multiple mount/unmount cycles

**Missing Tests:**
- ❌ Terminal output rendering
- ❌ Command execution
- ❌ Scroll behavior
- ❌ Window switching
- ❌ Input routing
- ❌ Error handling

---

## Dependencies

### External Dependencies
- `node-pty` - PTY process management
- `strip-ansi` - ANSI code removal for display

### Internal Dependencies
- `FocusContext` - Focus management
- `WindowContext` - Window switching
- `UIContext` - Theme and UI state

---

## Terminal Rendering Options Analysis

### Current Approach: node-pty + Ink Text Components

**What we're using:**
- `node-pty` (v1.1.0) - Spawns PTY process (PowerShell/Bash)
- `strip-ansi` (v7.1.2) - Strips ANSI codes from output
- Ink `<Text>` components - Renders plain text in terminal

**Problems with current approach:**
1. **ANSI codes are stripped** - Loses all colors, formatting, cursor positioning
2. **No proper terminal emulation** - Just displays raw text output
3. **Layout issues** - Terminal control sequences don't work (clear screen, cursor movement)
4. **Poor rendering** - Can't display complex terminal UIs (progress bars, spinners, etc.)
5. **Line wrapping issues** - Doesn't respect terminal width properly

### Alternative Solutions

#### Option 1: Keep node-pty + Add ANSI Rendering (RECOMMENDED)

**Approach:** Use `node-pty` for PTY but render ANSI codes properly

**Libraries to consider:**
- `ansi-to-react` - Converts ANSI codes to React components
- `ansi-escapes` - Generate ANSI escape codes
- `chalk` / `ansi-colors` - Color support
- Keep `strip-ansi` for fallback

**Pros:**
- ✅ Minimal changes to existing architecture
- ✅ Preserves colors and formatting
- ✅ Works with Ink's React model
- ✅ Better terminal output display

**Cons:**
- ⚠️ Still not a full terminal emulator
- ⚠️ May not handle complex cursor positioning
- ⚠️ Limited support for advanced terminal features

**Implementation:**
```typescript
// Instead of strip-ansi, use ansi-to-react
import AnsiToReact from 'ansi-to-react';

<AnsiToReact>{terminalOutput}</AnsiToReact>
```

#### Option 2: Blessed/Neo-Blessed Terminal Widget

**Approach:** Use blessed's terminal widget for full terminal emulation

**Libraries:**
- `neo-blessed` - Maintained fork of blessed
- `blessed-contrib` - Additional widgets

**Pros:**
- ✅ Full terminal emulation (like xterm)
- ✅ Handles all ANSI codes properly
- ✅ Built-in terminal widget
- ✅ Mature and battle-tested

**Cons:**
- ❌ **NOT compatible with Ink** - Uses different rendering system
- ❌ Would require rewriting entire UI
- ❌ Different component model (not React)
- ❌ Major architectural change

**Verdict:** Not feasible - incompatible with Ink

#### Option 3: React-Blessed

**Approach:** React renderer for blessed

**Libraries:**
- `react-blessed` - React bindings for blessed

**Pros:**
- ✅ React-based (similar to Ink)
- ✅ Full terminal emulation via blessed
- ✅ Terminal widget support

**Cons:**
- ❌ **Incompatible with Ink** - Different React renderer
- ❌ Would require complete UI rewrite
- ❌ Less actively maintained than Ink
- ❌ Can't mix with Ink components

**Verdict:** Not feasible - would require full rewrite

#### Option 4: Embedded xterm.js (Browser-based)

**Approach:** Run xterm.js in a browser context

**Libraries:**
- `xterm.js` - Full terminal emulator
- `xterm-addon-fit` - Auto-sizing
- `xterm-addon-web-links` - Clickable links

**Pros:**
- ✅ Full terminal emulation
- ✅ Industry standard (used by VS Code)
- ✅ Excellent ANSI support

**Cons:**
- ❌ **Requires browser environment** - Not for CLI
- ❌ Completely different architecture
- ❌ Would need Electron or similar
- ❌ Defeats purpose of terminal CLI

**Verdict:** Not applicable for CLI application

#### Option 5: Custom ANSI Parser + Ink Renderer

**Approach:** Build custom ANSI parser that outputs Ink components

**Implementation:**
- Parse ANSI codes manually
- Convert to Ink `<Text>` with color props
- Handle cursor positioning with layout

**Pros:**
- ✅ Full control over rendering
- ✅ Works perfectly with Ink
- ✅ Can optimize for our use case
- ✅ No additional dependencies

**Cons:**
- ⚠️ Significant development effort
- ⚠️ Need to handle all ANSI codes
- ⚠️ Maintenance burden
- ⚠️ Potential bugs in parser

**Verdict:** Possible but high effort

### Recommendation: Option 1 (node-pty + ANSI Rendering)

**Best approach for our use case:**

1. **Keep `node-pty`** - It works well for PTY management
2. **Add ANSI rendering** - Use `ansi-to-react` or similar
3. **Preserve colors** - Don't strip ANSI codes
4. **Gradual enhancement** - Can improve incrementally

**Implementation plan:**
```typescript
// packages/cli/package.json
{
  "dependencies": {
    "node-pty": "^1.1.0",
    "ansi-to-react": "^6.1.6",  // Add this
    "strip-ansi": "^7.1.2"      // Keep for fallback
  }
}

// Terminal.tsx
import Ansi from 'ansi-to-react';

export function Terminal({ height }: TerminalProps) {
  const { output } = useTerminal();
  
  return (
    <Box flexDirection="column">
      {output.map((line, i) => (
        <Box key={i}>
          <Ansi>{line.text}</Ansi>
        </Box>
      ))}
    </Box>
  );
}
```

**Benefits:**
- Minimal code changes
- Preserves existing architecture
- Improves display quality immediately
- Can iterate and improve over time

**Packages to add:**
- `ansi-to-react` (6.1.6) - ANSI to React components
- `ansi-escapes` (7.0.0) - Generate ANSI codes (optional)
- `chalk` (5.3.0) - Color support for our output (optional)

---

## File Locations

### Core Files
```
packages/cli/src/
├── ui/
│   ├── contexts/
│   │   ├── TerminalContext.tsx      - PTY session management
│   │   └── WindowContext.tsx        - Window switching logic
│   ├── components/
│   │   ├── Terminal.tsx             - Terminal display component
│   │   ├── WindowSwitcher.tsx       - Visual window indicator
│   │   └── layout/
│   │       ├── ChatInputArea.tsx    - Input routing
│   │       └── SystemBar.tsx        - Status bar (shows terminal mode)
│   ├── hooks/
│   │   └── useTerminal.ts           - Terminal hook proxy
│   └── utils/
│       └── windowDisplayLabels.ts   - Display label utilities
└── utils/
    └── terminal.ts                  - Terminal control sequences
```

---

## Recommendations

### Immediate Actions

1. **Investigate Reported Issue**
   - Test terminal functionality on Windows
   - Check PTY spawn errors
   - Verify input routing works correctly

2. **Fix Scroll Behavior**
   - Only auto-scroll when user is at bottom
   - Add visual scroll indicator
   - Preserve scroll position during output

3. **Add Error Handling**
   - Display error message if PTY fails to spawn
   - Add retry mechanism
   - Graceful degradation

### Short-term Improvements

4. **Command History**
   - Implement Up/Down arrow history navigation
   - Store last 100 commands
   - Persist history between sessions

5. **Direct Window Selection**
   - Add Ctrl+1/2/3 shortcuts for direct selection
   - Update documentation

### Long-term Enhancements

6. **Terminal Features**
   - Export terminal history
   - Search in terminal output
   - Configurable buffer size
   - Terminal themes/colors

7. **Testing**
   - Add comprehensive test suite
   - Integration tests for window switching
   - E2E tests for terminal commands

---

## Implementation Summary

### Changes Made (January 24, 2026)

**Problem:** Terminal output was displaying incorrectly - ANSI codes were being stripped, causing:
- No colors or formatting
- Broken box-drawing characters
- Malformed UI elements (borders, spinners, progress bars)
- Example: Gemini CLI output was completely broken

**Solution Implemented:** Added ANSI rendering support

**Changes:**
1. ✅ Added `ansi-to-react` package (v6.1.6)
2. ✅ Updated `Terminal.tsx` to use ANSI renderer
3. ✅ Removed `strip-ansi` usage from terminal display
4. ✅ Preserved ANSI codes in output processing
5. ✅ Removed line collapsing (was breaking ANSI sequences)

**Files Modified:**
- `packages/cli/src/ui/components/Terminal.tsx` - Added Ansi component
- `package.json` - Added ansi-to-react dependency

**Benefits:**
- ✅ Proper color rendering
- ✅ Box-drawing characters display correctly
- ✅ Progress bars and spinners work
- ✅ Formatted output preserved
- ✅ Compatible with tools like Gemini CLI

**Testing Required:**
- Test with Gemini CLI to verify rendering
- Test with colored output (ls --color, npm, etc.)
- Test with progress bars and spinners
- Verify scrolling still works correctly

---

## Next Steps

1. ⏳ **Await user requirements** - User will provide specific changes needed
2. ⏳ **Investigate broken functionality** - Determine root cause of reported issue
3. ⏳ **Plan implementation** - Create task breakdown for requested changes
4. ⏳ **Implement fixes** - Address critical issues first
5. ⏳ **Add tests** - Ensure changes don't break existing functionality

---

## Notes

- Terminal uses `node-pty` which requires native compilation
- Windows uses PowerShell by default, Unix uses Bash
- Terminal output is stripped of ANSI codes for Ink rendering
- Focus system integration is critical for proper keyboard handling

---

**Status:** Ready for user requirements  
**Next Update:** After user provides specific change requests
