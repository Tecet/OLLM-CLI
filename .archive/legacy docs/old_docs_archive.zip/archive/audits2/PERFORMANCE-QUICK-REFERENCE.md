# Performance Optimization Quick Reference

Quick guide for optimizing React component performance in OLLM CLI.

## Enable Profiling

```bash
# Windows PowerShell
$env:OLLM_PROFILE_RENDERS="true"

# Linux/Mac
export OLLM_PROFILE_RENDERS=true

# Then run
npm run dev
```

## Common Patterns

### 1. Memoize Component

```typescript
import { memo } from 'react';

// Before
export function MyComponent(props) {
  return <div>{props.value}</div>;
}

// After
const MyComponentImpl = (props) => {
  return <div>{props.value}</div>;
};

export const MyComponent = memo(MyComponentImpl);
```

### 2. Memoize Expensive Computation

```typescript
import { useMemo } from 'react';

// Before
function MyComponent({ items }) {
  const processed = expensiveOperation(items); // Runs every render!
  return <div>{processed}</div>;
}

// After
function MyComponent({ items }) {
  const processed = useMemo(
    () => expensiveOperation(items),
    [items] // Only when items change
  );
  return <div>{processed}</div>;
}
```

### 3. Stable Config Objects

```typescript
import { useMemo } from 'react';

// Before - new object every render
function Parent() {
  return <Child config={{ enabled: true, mode: 'fast' }} />;
}

// After - stable reference
function Parent() {
  const config = useMemo(() => ({ 
    enabled: true, 
    mode: 'fast' 
  }), []);
  return <Child config={config} />;
}
```

### 4. Stable Callbacks

```typescript
import { useCallback } from 'react';

// Before - new function every render
function Parent() {
  const handleClick = () => console.log('clicked');
  return <Child onClick={handleClick} />;
}

// After - stable reference
function Parent() {
  const handleClick = useCallback(
    () => console.log('clicked'),
    [] // No dependencies
  );
  return <Child onClick={handleClick} />;
}
```

### 5. Custom Memo Comparison

```typescript
import { memo } from 'react';

const MyComponent = memo(
  (props) => <div>{props.value}</div>,
  (prevProps, nextProps) => {
    // Return true if props are equal (skip render)
    // Return false if props changed (do render)
    return prevProps.value === nextProps.value;
  }
);
```

## Performance Targets

- **Render Time**: <16ms (60fps)
- **Render Count**: Should match props changes
- **No Warnings**: From profiler

## Profiler Warnings

| Warning | Cause | Fix |
|---------|-------|-----|
| High render count | Component renders too often | Add React.memo |
| Slow renders | Expensive operations | Add useMemo |
| Renders without props changes | Unstable prop references | Memoize props |

## Quick Checklist

Before committing:
- [ ] Enable profiling and test your changes
- [ ] No profiler warnings for your component
- [ ] Render time <16ms
- [ ] Render count matches props changes
- [ ] Tests pass

## When to Optimize

✅ **Do optimize**:
- Components that render frequently (>10 times)
- Components with expensive computations
- Components with many children
- Leaf components in component tree

❌ **Don't optimize**:
- Components that rarely render
- Simple components (just props display)
- Before measuring (premature optimization)

## Measuring Impact

```typescript
import { printRenderStats } from './utils/performanceProfiler.js';

// After using the app for a while
printRenderStats();
```

Look for:
- Render count vs props changes ratio
- Average render time
- Total time spent rendering

## Common Mistakes

### ❌ Inline Object Props
```typescript
<MyComponent config={{ enabled: true }} />
```

### ✅ Memoized Object Props
```typescript
const config = useMemo(() => ({ enabled: true }), []);
<MyComponent config={config} />
```

### ❌ Inline Array Props
```typescript
<MyComponent items={[1, 2, 3]} />
```

### ✅ Memoized Array Props
```typescript
const items = useMemo(() => [1, 2, 3], []);
<MyComponent items={items} />
```

### ❌ Inline Functions
```typescript
<MyComponent onClick={() => console.log('click')} />
```

### ✅ Memoized Functions
```typescript
const handleClick = useCallback(() => console.log('click'), []);
<MyComponent onClick={handleClick} />
```

## Resources

- [Full Optimization Guide](.dev/audits/window-rendering-optimization.md)
- [Profiler README](../packages/cli/src/ui/utils/README.md)
- [React Performance](https://react.dev/learn/render-and-commit)
- [useMemo](https://react.dev/reference/react/useMemo)
- [React.memo](https://react.dev/reference/react/memo)
