# Blessed/Neo-Blessed Migration Analysis

**Date:** January 24, 2026  
**Status:** Analysis - Decision Pending  
**Priority:** High - Architectural Decision

---

## Executive Summary

Analysis of migrating from **Ink (React-based TUI)** to **Blessed/Neo-Blessed (ncurses-like TUI)** for better terminal rendering, especially for split windows and multiple terminal panes.

**TL;DR:** 
- **Scope:** Complete UI rewrite (~50+ components)
- **Effort:** 2-4 weeks of full-time work
- **Benefits:** Native terminal widgets, better rendering, split panes
- **Risks:** Loss of React ecosystem, different mental model

---

## Current Architecture (Ink)

### What is Ink?

- **React renderer for terminals** - Uses React components
- **Flexbox layout** - CSS-like layout with Yoga engine
- **Declarative** - Component-based UI like web React
- **Modern** - Actively maintained, 28k+ GitHub stars

### Current Usage

**Components using Ink:** ~50+ files
- All UI components (`Box`, `Text`, `useInput`, `useStdout`)
- Layout system (TwoColumnLayout, TabContainer, etc.)
- All tabs (ChatTab, MCPTab, FilesTab, etc.)
- All panels (ToolsPanel, SettingsPanel, etc.)
- Input handling (ChatInputArea, InputBox)
- Status displays (SystemBar, StatusBar, etc.)

**Key Ink Features We Use:**
- `Box` - Flexbox containers (used everywhere)
- `Text` - Text rendering with colors
- `useInput` - Keyboard input handling
- `useStdout` - Terminal size detection
- React hooks - State management
- Component composition - Reusable UI pieces

---

## Blessed/Neo-Blessed Alternative

### What is Blessed?

- **ncurses-like library** - Low-level terminal control
- **Widget-based** - Pre-built widgets (boxes, lists, terminals)
- **Imperative** - Direct manipulation of screen elements
- **Mature** - 16,000+ lines of code, battle-tested

### Key Features

**Terminal Widget:**
```javascript
const terminal = blessed.terminal({
  parent: screen,
  top: 0,
  left: 0,
  width: '50%',
  height: '100%',
  border: 'line',
  scrollback: 1000,
  shell: 'bash'
});
```

**Split Panes:**
```javascript
const layout = blessed.layout({
  parent: screen,
  width: '100%',
  height: '100%',
  layout: 'grid',
  rows: 2,
  cols: 2
});
```

**Built-in Widgets:**
- `terminal` - Full terminal emulator
- `box` - Container widget
- `list` - Scrollable lists
- `textbox` - Text input
- `table` - Data tables
- `log` - Scrolling log viewer
- `progressbar` - Progress indicators

---

## Migration Scope

### Phase 1: Core Infrastructure (Week 1)

**Replace:**
- Ink's `Box` → Blessed's `box`
- Ink's `Text` → Blessed's `text`
- Ink's `useInput` → Blessed's key event handlers
- React state → Blessed screen updates

**Files to Rewrite:** ~15 core files
- `App.tsx` - Main app structure
- `TwoColumnLayout.tsx` - Layout system
- `TabContainer.tsx` - Tab management
- `SystemBar.tsx` - Status bar
- All context providers (need different state management)

**Effort:** 3-5 days

### Phase 2: Components (Week 2)

**Rewrite all UI components:**
- Chat components (~10 files)
- MCP components (~15 files)
- Tools panel (~5 files)
- Settings panel (~8 files)
- File explorer (~3 files)

**Challenges:**
- No React hooks - need different state management
- No component composition - need widget hierarchy
- Different event model - imperative vs declarative
- Different styling - blessed options vs CSS-like props

**Effort:** 5-7 days

### Phase 3: Terminal Integration (Week 3)

**Implement terminal features:**
- Terminal widget integration
- PTY connection (keep node-pty)
- Split pane support
- Focus management between panes
- Input routing to active terminal

**Benefits:**
- ✅ Native terminal widget (perfect rendering)
- ✅ Built-in split pane support
- ✅ Proper ANSI handling
- ✅ Scrollback buffer
- ✅ Terminal resizing

**Effort:** 4-6 days

### Phase 4: Testing & Polish (Week 4)

**Test and fix:**
- All keyboard shortcuts
- Focus management
- Layout responsiveness
- Terminal rendering
- Edge cases

**Effort:** 3-5 days

---

## Detailed Comparison

### Architecture Differences

| Aspect | Ink (Current) | Blessed (Proposed) |
|--------|---------------|-------------------|
| **Paradigm** | Declarative (React) | Imperative (Direct manipulation) |
| **State** | React hooks | Manual state tracking |
| **Layout** | Flexbox (Yoga) | Absolute/relative positioning |
| **Components** | React components | Blessed widgets |
| **Composition** | Component tree | Widget hierarchy |
| **Updates** | React reconciliation | Manual screen.render() |
| **Events** | React event system | EventEmitter pattern |

### Code Example Comparison

**Ink (Current):**
```tsx
function MyComponent() {
  const [count, setCount] = useState(0);
  
  useInput((input, key) => {
    if (key.upArrow) setCount(c => c + 1);
  });
  
  return (
    <Box flexDirection="column">
      <Text color="green">Count: {count}</Text>
    </Box>
  );
}
```

**Blessed (Proposed):**
```javascript
function createMyComponent(screen) {
  let count = 0;
  
  const box = blessed.box({
    parent: screen,
    top: 0,
    left: 0,
    width: '100%',
    height: 3,
    content: `Count: ${count}`,
    tags: true
  });
  
  screen.key('up', () => {
    count++;
    box.setContent(`{green-fg}Count: ${count}{/green-fg}`);
    screen.render();
  });
  
  return box;
}
```

---

## Impact Analysis

### What We Lose

❌ **React Ecosystem**
- No React hooks (useState, useEffect, useMemo, etc.)
- No component composition patterns
- No React DevTools
- No JSX syntax

❌ **Modern Development Experience**
- More verbose code
- Manual memory management
- Imperative style (harder to reason about)
- Less type safety

❌ **Existing Code**
- All 50+ components need rewrite
- All context providers need replacement
- All hooks need reimplementation
- Testing infrastructure needs update

### What We Gain

✅ **Better Terminal Support**
- Native terminal widget (perfect rendering)
- Built-in ANSI handling
- Proper cursor positioning
- Terminal emulation features

✅ **Split Panes**
- Built-in layout system for splits
- Multiple terminal instances
- Easy focus management between panes
- Resizable panes

✅ **Performance**
- Lower overhead (no React reconciliation)
- Direct screen manipulation
- Faster rendering for large outputs

✅ **Advanced Features**
- Mouse support (built-in)
- Scrollable regions
- Overlapping windows
- Z-index management

---

## Split Window Implementation

### Current Approach (Ink)

**Problem:** Ink doesn't have built-in terminal widgets
- We use node-pty + custom rendering
- Split windows would require complex layout management
- Each "terminal" is just text output
- No native terminal features

### Blessed Approach

**Solution:** Native terminal widgets with split support

```javascript
// Create split layout
const layout = blessed.layout({
  parent: screen,
  width: '100%',
  height: '100%',
  layout: 'inline'
});

// Terminal 1
const term1 = blessed.terminal({
  parent: layout,
  width: '50%',
  height: '100%',
  border: 'line',
  label: ' Terminal 1 ',
  shell: 'bash',
  scrollback: 1000
});

// Terminal 2
const term2 = blessed.terminal({
  parent: layout,
  width: '50%',
  height: '100%',
  border: 'line',
  label: ' Terminal 2 ',
  shell: 'bash',
  scrollback: 1000
});

// Focus management
screen.key('C-1', () => term1.focus());
screen.key('C-2', () => term2.focus());
```

**Benefits:**
- ✅ Each terminal is independent
- ✅ Native terminal emulation
- ✅ Easy to add more splits
- ✅ Built-in focus management
- ✅ Resizable panes

---

## Input Handling Comparison

### Current (Ink + Shared Input)

**Problem:** Single input field shared between chat and terminal
- Input goes to either chat OR terminal
- Can't type in multiple terminals
- Focus on container doesn't help (still shared input)

```tsx
// Current approach
<ChatInputArea 
  onSubmit={(value) => {
    if (activeWindow === 'terminal') {
      sendToTerminal(value);
    } else {
      sendToChat(value);
    }
  }}
/>
```

### Blessed Approach

**Solution:** Each terminal has its own input
- Terminal widget handles its own input
- Focus determines which terminal receives keys
- No shared input field needed

```javascript
// Blessed approach
term1.on('focus', () => {
  // Terminal 1 receives all keyboard input
  // No need for routing logic
});

term2.on('focus', () => {
  // Terminal 2 receives all keyboard input
});
```

**Benefits:**
- ✅ Natural terminal behavior
- ✅ No input routing logic
- ✅ Multiple terminals work independently
- ✅ Focus-based input (like real terminals)

---

## Recommendation

### Option A: Stay with Ink + Custom ANSI Renderer

**Pros:**
- ✅ Keep existing code (~50 components)
- ✅ React ecosystem and patterns
- ✅ Modern development experience
- ✅ Faster to implement (already done)

**Cons:**
- ❌ Limited terminal rendering
- ❌ Complex split window implementation
- ❌ Shared input model (not ideal for terminals)
- ❌ No native terminal features

**Effort:** 1-2 days (fix current ANSI issues)

### Option B: Migrate to Blessed

**Pros:**
- ✅ Native terminal widgets
- ✅ Perfect ANSI rendering
- ✅ Built-in split panes
- ✅ Independent terminal inputs
- ✅ Better for terminal-focused app

**Cons:**
- ❌ Complete rewrite (2-4 weeks)
- ❌ Lose React ecosystem
- ❌ More verbose code
- ❌ Different mental model

**Effort:** 2-4 weeks full-time

### Option C: Hybrid Approach

**Idea:** Use Blessed only for terminal panes, keep Ink for UI

**Pros:**
- ✅ Best of both worlds
- ✅ Native terminals where needed
- ✅ Keep React for UI components
- ✅ Gradual migration

**Cons:**
- ❌ Complex integration
- ❌ Two rendering systems
- ❌ Potential conflicts
- ❌ Harder to maintain

**Effort:** 1-2 weeks

---

## Decision Factors

### Choose Blessed if:
1. Terminal rendering is **critical** to your app
2. You need **multiple independent terminals**
3. You want **native terminal features** (scrollback, ANSI, etc.)
4. You're willing to invest **2-4 weeks** in rewrite
5. You prefer **terminal-native** behavior over React patterns

### Stay with Ink if:
1. Terminal is **one feature** among many
2. You value **React patterns** and ecosystem
3. You need to **ship quickly**
4. You're okay with **good enough** terminal rendering
5. Split windows are **nice-to-have**, not critical

---

## My Recommendation

**Start with Option A (Ink + Custom ANSI), plan for Option B (Blessed) later**

**Reasoning:**
1. **Short-term:** Fix ANSI rendering with custom parser (1-2 days)
2. **Validate:** Test if terminal rendering is good enough
3. **Decide:** If terminal is critical, migrate to Blessed
4. **Long-term:** Blessed is better for terminal-focused app

**Migration Path:**
```
Phase 1: Fix ANSI rendering (now) → 1-2 days
Phase 2: Test with real usage → 1 week
Phase 3: Decide on Blessed migration → Based on feedback
Phase 4: If yes, migrate to Blessed → 2-4 weeks
```

---

## Questions for You

1. **How critical is terminal rendering?** Is it a core feature or secondary?
2. **Split windows timeline?** When do you need this feature?
3. **Development time?** Can you invest 2-4 weeks in a rewrite?
4. **Terminal vs Chat?** Is this primarily a terminal app or chat app?
5. **User expectations?** Do users expect native terminal behavior?

---

**Status:** Awaiting decision  
**Next Steps:** Based on your answers, we'll choose the path forward
