# Terminal Output Debugging Log

**Date:** January 24, 2026  
**Issue:** Terminal receives PTY data but doesn't display output

## Timeline of Investigation

### Initial Problem
- User reported: "app is closing as soon i tried to start it"
- **Cause:** `useTerminal` hook was exporting non-existent `TerminalLine` type
- **Fix:** Removed the obsolete type export
- **Result:** App starts successfully

### Second Problem
- User reported: "app is started but cant interact with it"
- **Cause:** Terminal component's `useInput` hook had `{ isActive: true }`, capturing ALL input events
- **Fix:** Changed to `{ isActive: activeWindow === 'terminal' && !hasFocus }`
- **Result:** Input field now works, user can type

### Third Problem (Current)
- User reported: "when i type ping google.com nothing happens"
- **Symptoms:**
  - Input works ✅
  - Commands are sent to PTY ✅
  - PTY sends data back (295 bytes) ✅
  - Terminal shows "Total lines: 0" ❌
  - No output visible ❌

## Debug Data Collected

### Test Case: `ping google.com`
```
Data events: 18
Last size: 295 bytes
Total lines: 0
Visible: 0
Scroll: 0
```

**Analysis:**
- PTY is definitely sending data (18 events, 295 bytes)
- But `output` array in Terminal component is empty
- This means either:
  1. `setOutput()` is not being called
  2. State update is being lost
  3. Output is being cleared elsewhere

## Debugging Attempts

### Attempt 1: Check Serialization
**Action:** Used `serializeTerminalToObject()` from Gemini CLI  
**Result:** Returns empty array  
**Conclusion:** Complex serialization failing

### Attempt 2: Simple Fallback
**Action:** Used `line.translateToString(true)` with trim  
**Result:** Still empty  
**Conclusion:** Even simple extraction failing

### Attempt 3: Aggressive Fallback
**Action:** Extract ALL 30 rows, no filtering, use `translateToString(false)`  
**Result:** Still shows "Total lines: 0"  
**Conclusion:** State update issue suspected

### Attempt 4: Add Debug Tracking
**Action:** Added `debugInfo.outputLines` to track how many lines `setOutput()` is called with  
**Status:** Waiting for user to test  
**Expected:** Should show 30 if setOutput is being called

## Code Changes Made

### TerminalContext.tsx
```typescript
// Added debug state
const [debugInfo, setDebugInfo] = useState({ 
  dataEvents: 0, 
  lastDataSize: 0, 
  outputLines: 0, 
  lastError: '' 
});

// Track output lines being set
setOutput(simpleOutput);
setDebugInfo(prev => ({ 
  ...prev,
  outputLines: simpleOutput.length
}));
```

### Terminal.tsx
```typescript
// Display debug info
<Text dimColor>Output lines set: {debugInfo.outputLines}</Text>
{debugInfo.lastError && <Text color="red">Error: {debugInfo.lastError}</Text>}
```

## Hypotheses

### Hypothesis 1: State Update Lost
- `setOutput()` is called with 30 lines
- But `output` in Terminal component shows 0 lines
- Possible causes:
  - Multiple TerminalProvider instances
  - Context not propagating correctly
  - State being reset elsewhere

### Hypothesis 2: xterm Buffer Empty
- xterm.write() is called but buffer stays empty
- `getLine()` returns null or empty lines
- Possible causes:
  - xterm not initialized correctly
  - Buffer not being populated
  - Wrong buffer being read (active vs normal)

### Hypothesis 3: React Rendering Issue
- State is correct but not triggering re-render
- Possible causes:
  - Memoization preventing updates
  - Reference equality issue with arrays
  - Component not subscribed to context updates

## Next Steps

1. **Check outputLines value** - If 30, state update is being called
2. **Check for multiple providers** - Search for `<TerminalProvider>` in codebase
3. **Verify context consumption** - Ensure Terminal uses same context instance
4. **Add raw data display** - Show the actual data received from PTY
5. **Compare with Gemini CLI** - Check if they do anything different with xterm setup

## Questions to Answer

- [ ] Is `setOutput()` being called? (check outputLines)
- [ ] Is it being called with 30 lines?
- [ ] Does Terminal component see the updated output?
- [ ] Are there multiple TerminalProvider instances?
- [ ] Is the xterm buffer actually populated?
- [ ] Is there an error being thrown silently?

## Useful Debug Commands

```bash
# Build and run
npm run build
npm start

# Check for multiple providers
grep -r "TerminalProvider" packages/cli/src

# Check context usage
grep -r "useTerminal" packages/cli/src
```

## References

- xterm.js API: https://xtermjs.org/docs/api/terminal/
- React Context: https://react.dev/reference/react/useContext
- Ink rendering: https://github.com/vadimdemedes/ink
