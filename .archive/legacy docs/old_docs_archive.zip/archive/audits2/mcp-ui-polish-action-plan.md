uary 23, 2026  
**Approved By**: Pending review
r rollback points
- Bug tracking throughout implementation
- Code review before final merge

### Low Risk
- UI redesign (visual only, no logic changes)
- System messages (additive feature)
- Loading indicator (simple UI change)

---

## Next Steps

1. ✅ Baseline established (tests, lint, build all clean)
2. ✅ Action plan documented
3. ⏳ Begin Phase 1: Non-Blocking Loading
4. ⏳ Continue with remaining phases
5. ⏳ Final testing and deployment

---

**Plan Status**: Ready for Implementation  
**Last Updated**: Janol registry always in sync with server state
5. ✅ LLM receives accurate tool list
6. ✅ Error messages are non-invasive
7. ✅ All tests passing
8. ✅ No performance regressions
9. ✅ Production-ready code quality

---

## Risk Assessment

### High Risk
- Registry integration changes could break existing functionality
- Performance optimizations might introduce race conditions
- State management changes could cause subtle bugs

### Mitigation
- Comprehensive testing after each phase
- Incremental commits with cleaner displays correctly
- [ ] Actions → Enable/disable/delete work correctly
- [ ] LLM → Can see and use MCP tools

### Performance Benchmarks
- [ ] Initial health check < 1s
- [ ] Server connection feedback < 2s
- [ ] Tool loading doesn't block UI
- [ ] Multiple servers connect in parallel
- [ ] No memory leaks during enable/disable cycles

---

## Success Criteria

1. ✅ No full-screen blocking overlays
2. ✅ Server connections show feedback within 2 seconds
3. ✅ Enable/disable works 100% of the time
4. ✅ Toass (380/380)
- [ ] Add tests for new components
- [ ] Add tests for performance improvements
- [ ] Add integration tests for registry

### Manual Testing Checklist
- [ ] App restart → MCP tab loads without blocking
- [ ] Add server → UI remains interactive
- [ ] Enable server → Fast feedback, no blocking
- [ ] Disable server → Immediate update
- [ ] Multiple servers → Parallel connections
- [ ] Error scenarios → Messages in left column
- [ ] Marketplace → Always accessible
- [ ] Server details → Status banion tests

Steps:
1. Deep audit of tool registry
2. Audit enable/disable flow
3. Audit LLM integration
4. Identify and fix issues
5. Add integration tests
6. Verify with real LLM

### Phase 6: Final Testing & Bug Fixes (Priority: High)
**Estimated Time**: 4-6 hours
**Testing**: Full regression suite

Steps:
1. Run all automated tests
2. Manual testing of all scenarios
3. Fix any discovered bugs
4. Update documentation
5. Final commit and review

---

## Testing Strategy

### Automated Tests
- [ ] All existing tests pnsistency

### Phase 4: System Messages (Priority: Medium)
**Estimated Time**: 3-4 hours
**Files**: MCPTab.tsx, MCPContext.tsx, new SystemMessages.tsx
**Testing**: Manual + error scenarios

Steps:
1. Create SystemMessages component
2. Add to left column layout
3. Replace error state with message system
4. Test error scenarios
5. Verify dismissal works

### Phase 5: Registry Integration Audit (Priority: High)
**Estimated Time**: 6-8 hours
**Files**: Multiple (TBD after audit)
**Testing**: Comprehensive integrats

Steps:
1. Implement fast initial health checks
2. Parallelize health checks
3. Add lazy tool loading
4. Add optimistic UI updates
5. Measure and verify performance improvements

### Phase 3: UI Redesign (Priority: Medium)
**Estimated Time**: 3-4 hours
**Files**: MCPTab.tsx, new ServerStatusBanner.tsx
**Testing**: Manual + visual regression

Steps:
1. Create ServerStatusBanner component
2. Update ServerDetailsContent layout
3. Move enable/disable to actions section
4. Test navigation flow
5. Verify visual co
---

## Implementation Phases

### Phase 1: Non-Blocking Loading (Priority: High)
**Estimated Time**: 2-3 hours
**Files**: MCPTab.tsx
**Testing**: Manual + automated

Steps:
1. Remove full-screen loading check
2. Add loading indicator to left column
3. Test all three loading scenarios
4. Verify marketplace remains accessible

### Phase 2: Performance Optimization (Priority: High)
**Estimated Time**: 4-6 hours
**Files**: mcpHealthMonitor.ts, mcpClient.ts, MCPContext.tsx
**Testing**: Manual + performance benchmarkrmatErrorMessage(parsedError),
  dismissible: true,
});
```

**Add message emitter**:
```typescript
const [messageListeners, setMessageListeners] = useState<Array<(msg: SystemMessage) => void>>([]);

const emitSystemMessage = useCallback((msg: Omit<SystemMessage, 'id' | 'timestamp'>) => {
  const fullMessage: SystemMessage = {
    ...msg,
    id: `msg-${Date.now()}-${Math.random()}`,
    timestamp: Date.now(),
  };
  
  messageListeners.forEach(listener => listener(fullMessage));
}, [messageListeners]);
```
={(id) => {
        setSystemMessages(prev => prev.filter(m => m.id !== id));
      }}
      isActive={hasFocus && activeColumn === 'left'}
    />
  </Box>
</Box>
```

#### Step 6.3: Replace Error State with System Messages
**File**: `packages/cli/src/ui/contexts/MCPContext.tsx`

**Instead of setting error state**:
```typescript
// OLD:
setState(prev => ({
  ...prev,
  error: formatErrorMessage(parsedError),
}));

// NEW:
// Emit error event that UI can listen to
emitSystemMessage({
  type: 'error',
  message: fole**: `packages/cli/src/ui/components/tabs/MCPTab.tsx`

**Add state**:
```typescript
const [systemMessages, setSystemMessages] = useState<SystemMessage[]>([]);
```

**Add to left column layout**:
```typescript
<Box flexDirection="column" width="30%" flexShrink={0}>
  {/* Navigation items */}
  <Box flexDirection="column" flexGrow={1}>
    {/* ... existing navigation ... */}
  </Box>
  
  {/* System Messages at bottom */}
  <Box flexShrink={0}>
    <SystemMessages
      messages={systemMessages}
      onDismissmsg.type === 'warning' ? 'yellow' :
                     msg.type === 'info' ? 'cyan' : 'green';
        
        return (
          <Box key={msg.id} flexDirection="column" paddingX={1} paddingY={1}>
            <Text color={color}>
              {icon} {msg.message}
            </Text>
            {msg.dismissible && (
              <Text dimColor>Press X or ESC to dismiss</Text>
            )}
          </Box>
        );
      })}
    </Box>
  );
};
```

#### Step 6.2: Add System Messages to Left Column
**Fi
  if (messages.length === 0) return null;
  
  return (
    <Box flexDirection="column" borderStyle="single" borderColor="gray">
      <Box paddingX={1} borderStyle="single" borderColor="gray">
        <Text bold>📢 System Messages</Text>
      </Box>
      
      {messages.map(msg => {
        const icon = msg.type === 'error' ? '❌' :
                    msg.type === 'warning' ? '⚠️' :
                    msg.type === 'info' ? 'ℹ️' : '✓';
        const color = msg.type === 'error' ? 'red' :
                      SystemMessages: React.FC<SystemMessagesProps> = ({
  messages,
  onDismiss,
  isActive,
}) => {
  const { state: uiState } = useUI();
  
  // Handle dismiss on X or ESC
  useInput((input, key) => {
    if (!isActive || messages.length === 0) return;
    
    if (input === 'x' || input === 'X' || key.escape) {
      // Dismiss first dismissible message
      const dismissible = messages.find(m => m.dismissible);
      if (dismissible) {
        onDismiss(dismissible.id);
      }
    }
  }, { isActive });
  s/cli/src/ui/components/mcp/SystemMessages.tsx` (new file)

```typescript
import React from 'react';
import { Box, Text, useInput } from 'ink';
import { useUI } from '../../../features/context/UIContext.js';

export interface SystemMessage {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  message: string;
  timestamp: number;
  dismissible: boolean;
}

export interface SystemMessagesProps {
  messages: SystemMessage[];
  onDismiss: (id: string) => void;
  isActive: boolean;
}

export const (if known)
   - Related Files
   - Proposed Fix

### Categories to Monitor
- State Synchronization
- Race Conditions
- Error Recovery
- Memory Leaks
- UI Consistency
- Performance
- Edge Cases

---

## Issue #6: Fix Error Messages Display

### Current Problem
- Error overlays block UI
- Notification banners break layout
- Can't exit errors easily
- Very invasive

### Solution
Display all system errors in a fixed area at bottom of left column.

#### Step 6.1: Create System Messages Component
**File**: `package '▶ ' : '  '}[X] Delete Server
    </Text>
  </Box>
</Box>
```

---

## Issue #5: Track Bugs During Implementation

### Process
1. During each implementation step, actively watch for:
   - Potential bugs
   - Edge cases
   - Race conditions
   - State management issues
   - Error handling gaps
   - Performance bottlenecks

2. Document any discovered issues in `.dev/bugtracker.md`

3. Follow bug reporting template:
   - Title, Status, Priority, Discovered date
   - Description, Steps to Reproduce
   - Root Causek={0} marginTop={1}>
  <Text bold>Actions:</Text>
  <Box gap={4} marginTop={1}>
    {server.config.disabled ? (
      <Text bold color={navItem === 'enable' ? 'yellow' : 'green'}>
        {navItem === 'enable' ? '▶ ' : '  '}[E] Enable Server
      </Text>
    ) : (
      <Text bold color={navItem === 'disable' ? 'yellow' : 'gray'}>
        {navItem === 'disable' ? '▶ ' : '  '}[D] Disable Server
      </Text>
    )}
    <Text bold color={navItem === 'delete' ? 'yellow' : 'red'}>
      {navItem === 'delete' ?={navItem === 'toggle' ? ... : ...}>
    {navItem === 'toggle' ? '▶ ' : '  '}Status: ...
  </Text>
</Box>

// NEW:
<Box flexShrink={0} marginBottom={1}>
  <ServerStatusBanner
    health={server.health}
    isEnabled={!server.config.disabled}
    isConnecting={isRefreshing}
  />
</Box>
```

**Update navigation items**:
```typescript
// Remove 'toggle' from navigation
type ServerDetailNavItem = 'exit' | 'enable' | 'disable' | 'delete';

// Update action buttons section at bottom
<Box flexDirection="column" flexShrin   <Box
      borderStyle="round"
      borderColor={color}
      paddingX={1}
      width="100%"
    >
      <Text color={color}>
        {icon} {text}
      </Text>
    </Box>
  );
};
```

#### Step 4.2: Update ServerDetailsContent
**File**: `packages/cli/src/ui/components/tabs/MCPTab.tsx`

**Replace current health/status section**:
```typescript
// OLD:
<Box flexShrink={0}>
  <Text>
    <Text bold>Health:</Text>{' '}
    <Text color={...}>...</Text>
  </Text>
</Box>
<Box flexShrink={0}>
  <Text bold color  let color: string;
  
  if (!isEnabled) {
    icon = '⚪';
    text = 'Disabled';
    color = 'gray';
  } else if (isConnecting) {
    icon = '🟡';
    text = 'Connecting';
    color = 'yellow';
  } else if (health === 'healthy') {
    icon = '🟢';
    text = 'Healthy • Enabled';
    color = 'green';
  } else if (health === 'degraded') {
    icon = '🟡';
    text = 'Degraded • Enabled';
    color = 'yellow';
  } else {
    icon = '🔴';
    text = 'Unhealthy • Enabled';
    color = 'red';
  }
  
  return (
 ort React from 'react';
import { Box, Text } from 'ink';
import { useUI } from '../../../features/context/UIContext.js';

export interface ServerStatusBannerProps {
  health: 'healthy' | 'degraded' | 'unhealthy';
  isEnabled: boolean;
  isConnecting?: boolean;
}

export const ServerStatusBanner: React.FC<ServerStatusBannerProps> = ({
  health,
  isEnabled,
  isConnecting = false,
}) => {
  const { state: uiState } = useUI();
  
  // Determine banner content and color
  let icon: string;
  let text: string;
ks
3. Improve tool descriptions
4. Add LLM-friendly tool metadata
5. Test enable/disable cycles thoroughly

---

## Issue #4: Redesign Server Details UI

### Current Design Issues
- "Health" and "Status" are plain text
- Status is navigable but should be informational only
- Enable/Disable action hidden in Status line
- Delete button separate at bottom

### New Design

#### Step 4.1: Create Status Banner Component
**File**: `packages/cli/src/ui/components/mcp/ServerStatusBanner.tsx` (new file)

```typescript
impectly (server-name:tool-name)?
- [ ] Does registry handle multiple servers with same tool names?
- [ ] Is registry state consistent with server state?
- [ ] Are tool descriptions clear and informative for LLM?
- [ ] Does LLM receive tool schemas properly?
- [ ] Can LLM distinguish between similar tools from different servers?

#### Fix Plan (TBD after audit):
Will be determined based on audit findings. Likely fixes:
1. Ensure registerServerTools/unregisterServerTools called at right times
2. Add state validation checool descriptions for LLM

### Deep Audit Required

#### Files to Audit:
1. `packages/core/src/tools/tool-registry.ts` - Tool registration
2. `packages/cli/src/ui/contexts/MCPContext.tsx` - Tool reg/unreg flow
3. `packages/core/src/mcp/mcpToolWrapper.ts` - Tool wrapping for LLM
4. `packages/core/src/provider/` - LLM integration
5. `packages/core/src/prompts/` - System prompts

#### Investigation Checklist:
- [ ] Does tool registry properly register/unregister on enable/disable?
- [ ] Are tools namespaced corr
    // Revert optimistic update on error
    await loadServers();
    throw error;
  }
}, [state.servers, loadServers]);
```

#### Step 2.5: Performance Targets
- Initial health check: < 1 second
- Server connection feedback: < 2 seconds
- Multiple servers connect in parallel
- Tool loading doesn't block UI

---

## Issue #3: Fix MCP Registry Integration

### Current Problem
- Enable/disable is inconsistent
- Tool registry may not reflect server state
- LLM may not know what tools are available
- No clear t
    const isCurrentlyDisabled = server.config.disabled || false;
    
    // Optimistic update - show as "connecting" immediately
    setState(prev => {
      const servers = new Map(prev.servers);
      const serverState = servers.get(serverName);
      if (serverState) {
        servers.set(serverName, {
          ...serverState,
          status: isCurrentlyDisabled ? 'starting' : 'disconnected',
        });
      }
      return { ...prev, servers };
    });

    // ... rest of toggle logic
  } catch (error) {tails are viewed**:
```typescript
// In ServerDetailsContent component
useEffect(() => {
  if (server.toolsList.length === 0) {
    loadServerTools(server.name);
  }
}, [server.name]);
```

#### Step 2.4: Optimistic UI Updates
**File**: `packages/cli/src/ui/contexts/MCPContext.tsx`

**In toggleServer()**:
```typescript
const toggleServer = useCallback(async (serverName: string) => {
  try {
    const server = state.servers.get(serverName);
    if (!server) throw new Error(`Server '${serverName}' not found`);
0) return; // Already loaded
  
  try {
    const tools = await mcpClient.getTools(serverName);
    setState(prev => {
      const servers = new Map(prev.servers);
      const serverState = servers.get(serverName);
      if (serverState) {
        servers.set(serverName, { ...serverState, toolsList: tools });
      }
      return { ...prev, servers };
    });
  } catch (error) {
    console.warn(`Failed to load tools for ${serverName}:`, error);
  }
}, [mcpClient, state.servers]);
```

**Call when server dee);
  if (!server || server.toolsList.length > erNamt(servvers.geadServerTools = useCallback(async (serverName: string) => {
  const server = state.servoid> {
  this.initializeServerStates();
  
  // Check all servers in parallel
  const checks = Array.from(this.serverStates.entries()).map(
    ([serverName, state]) => this.checkServerHealth(serverName, state)
  );
  
  await Promise.allSettled(checks);
}
```

#### Step 2.3: Lazy Tool Loading
**File**: `packages/cli/src/ui/contexts/MCPContext.tsx`

**Current**: Tools loaded immediately in `loadServers()`
**New**: Load tools on-demand when server details are viewed

**Add new method**:
```typescript
const lo
  scheduleNextCheck();
}
```

#### Step 2.2: Parallelize Health Checks
**File**: `packages/core/src/mcp/mcpHealthMonitor.ts`

**Current** (sequential):
```typescript
private performHealthChecks(): void {
  this.initializeServerStates();
  
  for (const [serverName, state] of this.serverStates.entries()) {
    this.checkServerHealth(serverName, state);
  }
}
```

**New** (parallel):
```typescript
private async performHealthChecks(): Promise<;
  const scheduleNextCheck = () => {
    checkCount++;
    const interval = checkCount <= this.config.fastCheckCount
      ? this.config.fastCheckInterval
      : this.config.checkInterval;
    
    this.checkIntervalId = setTimeout(() => {
      this.performHealthChecks();
      scheduleNextCheck();
    }, interval);
  };
  
  // Perform immediate initial check
  this.performHealthChecks();typescript
start(): void {
  if (this.isRunning) return;
  
  this.isRunning = true;
  this.initializeServerStates();
  
  // Use fast interval initially
  let checkCount = 0nterval: 5000,
  fastCheckInterval: 1000, // 1 second for first checks
  fastCheckCount: 5, // First 5 checks are fast
  // ... existing defaults
};
```

**Modify start() method**:
```st DEFAULT_CONFIG: Required<HealthMonitorConfig> = {
  checkIlt: 5) */
  fastCheckCount?: number;
  // ... existing options
}

confast checks before switching to normal interval (defauhecks (default: 1000ms = 1s) */
  fastCheckInterval?: number;
  /** Number of ptimization Plan

#### Step 2.1: Implement Fast Initial Health Check
**File**: `packages/core/src/mcp/mcpHealthMonitor.ts`

**Add new config option**:
```typescript
export interface HealthMonitorConfig {
  checkInterval?: number;
  /** Fast check interval for first N cs`

**Connection Timeout**: 30 seconds (configurable)
**Tool Loading**: Happens after connection (sequential)

**Issues Found**:
1. Connection timeout is appropriate (30s for slow Python servers)
2. Tool loading happens synchronously after connection
3. No parallel server startup

### Orc/mcp/mcpHealthMonitor.ts`

**Current Settings**:
```typescript
const DEFAULT_CONFIG: Required<HealthMonitorConfig> = {
  checkInterval: 5000, // 5 seconds
  maxRestartAttempts: 3,
  initialBackoffDelay: 1000,
  maxBackoffDelay: 60000,
  autoRestart: true,
};
```

**Issues Found**:
1. 5-second interval is still too slow for initial connection feedback
2. Health checks run sequentially for all servers
3. No fast initial check on server start

#### MCPClient Analysis
**File**: `packages/core/src/mcp/mcpClient.tarketplace remains accessible
- [ ] Enable disabled server → Loading indicator appears, UI remains interactive
- [ ] Marketplace browsing works during all loading states

---

## Issue #2: Optimize Health Monitor Performance

### Current Problem
- Health check interval: 5 seconds (was 30s, reduced but still slow)
- Server connections take too long to show as "connected"
- Sequential operations that could be parallelized

### Performance Audit Findings

#### MCPHealthMonitor Analysis
**File**: `packages/core/s
- [ ] Add new server → Loading indicator appears, mleft columnicator in ios
- [ ] App restart → MCP tab shows immediately, loading indist rendering
)}
```

#### Step 1.3: Test Scenard</Text>
) : (
  // ... existing server l> item.type === 'server').length === 0 ? (
  <Text dimColor>  No servers installeoaded */}
{!state.isLoading && visibleItems.filter(item =dded={false}
    />
  </Box>
)}

{/* Server list when l    color="cyan"
      centered={false}
      pa"
      spinnerType="dots"
  Loading MCP servers...
    <LoadingSpinner
      message=" (
  <Box paddingLeft={2}>ading */}
{state.isLoading && </Text>

{/* Loading indicator when servers are loled Servers
</Text>
<Text>"📦 Installed Servers" header

**Add**:
```typescript
{/* Installed Servers Header - Always visible */}
<Text> </Text>
<Text> </Text>
<Text bold color={uiState.theme.text.accent}>
  📦 Instalonents/tabs/MCPTab.tsx`

**Location**: Inside left column, after ng Indicator to Left Column
**File**: `packages/cli/src/ui/compd Loadi 1.2: Adcolumn under "Installed Servers"
```

#### Step={true}
      padded={true}
    />
  );
}
```

**New Code**:
```typescript
// Remove full-screen loading check - show UI immediately
// Loading state will be shown in left bs/MCPTab.tsx`

**Current Code** (lines ~1065-1075):
```typescript
// Loading state
if (state.isLoading) {
  return (
    <LoadingSpinner
      message="Loading MCP servers..."
      spinnerType="dots"
      color="cyan"
      centeredn

#### Step 1.1: Modify MCPTab Loading State
**File**: `packages/cli/src/ui/components/taervers" label in left column.

### Implementation Plarlay with localized loading indicator under "Installed S section
- Adding new MCP server from marketplace
- Enabling a disabled server

### Solution
Replace full-screen ove" blocks entire screen in three scenarios:
- App restart + entering MCP**Fix Error Messages Display** - Non-invasive error notifications

---

## Issue #1: Remove Full-Screen Loading Overlay

### Current Problem
Black overlay with "Loading MCP servers...disable and LLM awareness
4. **Redesign Server Details UI** - Better visual hierarchy
5. **Track Bugs During Implementation** - Continuous quality monitoring
6. ce** - Faster server connections
3. **Fix MCP Registry Integration** - Reliable enable/Loading Overlay** - Non-blocking loading states
2. **Optimize Health Monitor Performancritical issues to prepare the MCP Tab UI for production:

1. **Remove Full-Screen eline**: All tests passing (380/380), Build clean, Lint clean, TypeScript clean

---

## Executive Summary

This plan addresses 6 6  
**Status**: Ready for Implementation  
**Bas# MCP UI Polish - Comprehensive Action Plan

**Date**: January 23, 202