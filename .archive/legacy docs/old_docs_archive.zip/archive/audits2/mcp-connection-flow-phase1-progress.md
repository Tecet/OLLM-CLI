# MCP Connection Flow - Phase 1 Progress

**Date**: January 23, 2026  
**Status**: Phase 1 Partially Complete  
**Commit**: PENDING

---

## What Was Completed

### 1. Connection Phase Type Added ✅
Added `ConnectionPhase` type with 7 states:
- `stopped` - Server is disabled/stopped
- `starting` - Server process starting
- `connecting` - Waiting for initial connection
- `health-check` - Running health checks (1-3 attempts)
- `connected` - Fully connected and healthy
- `unhealthy` - Connected but health checks failed
- `error` - Connection failed

### 2. Server Health State Updated ✅
Added to `ServerHealthState`:
- `phase: ConnectionPhase` - Current connection phase
- `healthCheckAttempts: number` - Track attempts during connection

### 3. Phase Change Events ✅
- Added `'phase-change'` to event types
- Created `updatePhase()` method to emit events when phase changes
- Updated `subscribeToHealthUpdates()` to include phase-change events

### 4. Initial Phase Detection ✅
Updated `initializeServerStates()` to set initial phase based on server status:
- `connected` → `'connected'`
- `starting` → `'starting'`
- `error` → `'error'`
- Other → `'stopped'`

---

## What Remains (Phase 1)

### 1. Update checkServerHealth Method ⏳
Need to add phase transition logic:
```typescript
// When server starts connecting
if (status.status === 'starting') {
  this.updatePhase(serverName, 'starting');
}

// When connection established, enter health check phase
if (status.status === 'connected' && state.phase === 'connecting') {
  this.updatePhase(serverName, 'health-check');
  state.healthCheckAttempts = 1;
}

// After 3 successful health checks, mark as connected
if (state.phase === 'health-check' && state.healthCheckAttempts >= 3) {
  this.updatePhase(serverName, 'connected');
}

// Only mark unhealthy after 3 consecutive failures
if (state.consecutiveFailures >= 3) {
  this.updatePhase(serverName, 'unhealthy');
}
```

### 2. Update getServerHealth Method ⏳
Add phase to HealthCheckResult:
```typescript
getServerHealth(serverName: string): HealthCheckResult | null {
  const state = this.serverStates.get(serverName);
  if (!state) return null;
  
  return {
    serverName,
    healthy: state.lastStatus === 'connected',
    status: state.lastStatus,
    phase: state.phase, // Add this
    timestamp: state.lastCheckTime,
  };
}
```

### 3. Reset Health Check Attempts ⏳
Reset `healthCheckAttempts` when:
- Server disconnects
- Server enters error state
- Server is restarted

---

## Phase 2: Update Health Check Logic

### Tasks Remaining:
1. Implement 3-attempt retry before marking unhealthy
2. Add grace period during initial connection
3. Reset failure counter on successful check
4. Update restart logic to respect phases

---

## Phase 3: Update UI Display

### Tasks Remaining:
1. Update MCPContext to listen to phase-change events
2. Add phase to ExtendedMCPServerStatus
3. Update server list to always show 2 lines
4. Add spinner for connecting/health-check phases
5. Update icon colors based on phase

---

## Phase 4: Suppress Premature Errors

### Tasks Remaining:
1. Don't emit system messages during 'connecting' or 'health-check' phases
2. Only show errors after phase is 'unhealthy' or 'error'
3. Add grace period configuration

---

## Testing Strategy

### Unit Tests Needed:
- [ ] Phase transitions work correctly
- [ ] Health check attempts increment properly
- [ ] Phase change events are emitted
- [ ] Unhealthy only after 3 failures

### Integration Tests Needed:
- [ ] UI updates when phase changes
- [ ] No premature error messages
- [ ] Spinner shows during connecting/checking

---

## Estimated Remaining Time

- Complete Phase 1: 1-2 hours
- Phase 2: 2-3 hours
- Phase 3: 2-3 hours
- Phase 4: 1-2 hours

**Total Remaining**: 6-10 hours

---

## Notes

- Phase tracking infrastructure is in place
- Need to carefully update checkServerHealth to avoid breaking existing logic
- Should test thoroughly after each change
- Consider adding debug logging for phase transitions

---

**Status**: Ready to continue with Phase 1 completion
**Next Step**: Update checkServerHealth method with phase transition logic

