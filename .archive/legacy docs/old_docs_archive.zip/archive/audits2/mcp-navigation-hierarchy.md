# MCP Tab Navigation Hierarchy

**Date**: January 23, 2026  
**Status**: ✅ Implemented

## Overview

The MCP tab implements a 3-level hierarchical navigation system for intuitive keyboard navigation through the two-column layout and detail views.

## Navigation Hierarchy

### Level 1: Left Column (Menu/List)
- **Focus**: Menu items in the left column
- **Content**: 
  - Exit option
  - Marketplace option
  - Installed servers list
- **Navigation**:
  - ↑↓: Navigate menu items
  - →: Move to right column (Level 2)
  - Enter: Select item (Exit, view Marketplace, or toggle server)
  - ESC: Exit MCP tab (bubble to global handler)

### Level 2: Right Column (Content Area)
- **Focus**: Content in the right column
- **Content**:
  - Marketplace list (when Marketplace is selected)
  - Server details (when a server is selected)
  - Welcome screen (when Exit is selected)
- **Navigation**:
  - ↑↓: Navigate content (marketplace list, server details options)
  - ←: Return to left column (Level 1)
  - Enter: View details (marketplace) or perform action (server)
  - ESC: Return to left column (Level 1)

### Level 3: Detail Views
- **Focus**: Detail view within right column
- **Content**:
  - Marketplace server detail view
  - API key input dialog (marketplace)
- **Navigation**:
  - ↑↓: Navigate detail options
  - Enter: Perform action (install, exit)
  - ESC: Return to Level 2 (marketplace list)

## ESC Key Behavior

The ESC key implements hierarchical navigation:

```
Level 3 (Detail View) → ESC → Level 2 (Right Column)
Level 2 (Right Column) → ESC → Level 1 (Left Column)
Level 1 (Left Column) → ESC → Exit MCP Tab
```

### Implementation Details

**Main MCPTab Component** (`MCPTabContent`):
- Handles Level 1 ↔ Level 2 navigation
- ESC from right column (Level 2) → left column (Level 1)
- ESC from left column (Level 1) → bubbles to global handler (exits tab)

**MarketplaceContent Component**:
- Handles Level 2 ↔ Level 3 navigation for marketplace
- ESC from detail view (Level 3) → marketplace list (Level 2)
- ESC from marketplace list (Level 2) → handled by parent (goes to left column)

**ServerDetailsContent Component**:
- Operates at Level 2 (right column)
- ESC handled by parent component (goes to left column)

## Code Locations

| Component | File | Lines | Purpose |
|-----------|------|-------|---------|
| MCPTabContent | `packages/cli/src/ui/components/tabs/MCPTab.tsx` | ~1350-1400 | Main ESC handler for Level 1 ↔ Level 2 |
| MarketplaceContent | `packages/cli/src/ui/components/tabs/MCPTab.tsx` | ~650-700 | ESC handler for Level 2 ↔ Level 3 (marketplace) |
| ServerDetailsContent | `packages/cli/src/ui/components/tabs/MCPTab.tsx` | ~60-400 | Server details display (Level 2) |

## User Experience

### Viewing Marketplace Server Details
1. User navigates to "Marketplace" in left column (Level 1)
2. User presses → to move to right column (Level 2)
3. User navigates marketplace list and presses Enter on a server (Level 2 → Level 3)
4. User views server details (Level 3)
5. User presses ESC → returns to marketplace list (Level 3 → Level 2)
6. User presses ESC → returns to left column (Level 2 → Level 1)
7. User presses ESC → exits MCP tab (Level 1 → nav-bar)

### Viewing Installed Server Details
1. User navigates to a server in left column (Level 1)
2. Server details automatically shown in right column (Level 2)
3. User presses → to move to right column (Level 2)
4. User navigates server details options
5. User presses ESC → returns to left column (Level 2 → Level 1)
6. User presses ESC → exits MCP tab (Level 1 → nav-bar)

## Benefits

1. **Consistent Navigation**: ESC always moves up one level in the hierarchy
2. **Intuitive Flow**: Users can explore deeply and back out step-by-step
3. **No Dead Ends**: Every view has a clear path back
4. **Predictable Behavior**: Same ESC pattern across all MCP tab content

## Testing

All 380 tests pass, including:
- MCP tab navigation tests
- Focus management tests
- Dialog handling tests

## Related Documentation

- [Focus Management System](../../packages/cli/src/features/context/FocusContext.tsx)
- [Navigation Fix Spec](.kiro/specs/navigation-fix/)
- [MCP Tab Component](../../packages/cli/src/ui/components/tabs/MCPTab.tsx)
