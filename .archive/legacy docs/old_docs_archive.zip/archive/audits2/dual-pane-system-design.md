# Dual-Pane Input Routing System - Design Document

**Date:** January 24, 2026  
**Version:** 1.0  
**Status:** 📐 Design Complete

---

## Executive Summary

A dual-pane system with independent view navigation and input routing, enabling users to view one interface while typing into another. This solves the terminal interactivity problem and enables advanced workflows like dual-terminal setups and side-by-side LLM comparisons.

---

## Problem Statement

### Current Limitations

1. **Terminal Input Issue**
   - Interactive apps (Gemini CLI, vim, nano) don't work
   - Input is line-buffered, not character-by-character
   - Can't type directly into terminal applications

2. **Single Focus**
   - Can only interact with what you're viewing
   - Can't monitor one thing while working on another
   - No dual-terminal capability

3. **Limited Workspace**
   - Right panel only shows Tools and Workspace
   - No way to compare LLM responses
   - No second terminal for parallel tasks

### Critical Requirement

**⚠️ PRESERVE ALL EXISTING LLM FUNCTIONALITY**

All current features must remain intact:
- ✅ Model selection on startup
- ✅ `/model` command and model picker
- ✅ All slash commands
- ✅ Menu navigation (Up/Down/Enter)
- ✅ History navigation
- ✅ Multi-line input (Shift+Enter)
- ✅ Streaming responses
- ✅ Tool confirmations

**We are ONLY adding the ability to switch input destinations, not changing how LLM chat works!**

---

## Solution Overview

### Two Independent Systems

#### System 1: View Navigation
**What you SEE on screen**
- Tab/Shift+Tab to cycle views
- Main panel: Chat → Editor → Terminal 1
- Right panel: Tools → Workspace → LLM Chat → Terminal 2
- Visual: Purple dot indicators

#### System 2: Input Routing  
**Where your typing GOES**
- Ctrl+Left/Right to cycle destinations
- Destinations: LLM | E | T1 | T2
- Visual: `[LLM | E | T1 | T2]` indicator
- Independent from view

---

## Scope Clarification (January 24, 2026)

**Key principle: preserve all existing LLM functionality while shipping the full dual-pane system in one pass.**

This clarification updates scope to implement all parts together, without breaking LLM chat:
- Input routing is added by **wrapping** the existing LLM input handler with an early return.
- **No changes** to existing LLM menu/command/history/multi-line logic.
- Raw input is only active when the destination is `terminal1` or `terminal2`.
- Input routing shortcuts are handled **in the input box only**.
- Right panel expansion (LLM Chat + Terminal 2 views) and UI indicators are included in the same delivery.
- LLM chat is **mirrored left/right** (single model). No second model or independent conversation in this phase.
- Editor input remains **disabled**; it is a destination only for future enablement.

---

## Architecture

### Component Hierarchy

```
App
├── InputRoutingProvider
│   └── InputRoutingContext (manages where input goes)
├── WindowProvider
│   └── WindowContext (manages what you see)
├── TerminalProvider
│   └── TerminalContext (Terminal 1 PTY)
├── Terminal2Provider (new)
│   └── Terminal2Context (Terminal 2 PTY)
└── Layout
    ├── Main Panel (Left)
    │   ├── Chat View
    │   ├── Editor View
    │   └── Terminal 1 View
    ├── Right Panel
    │   ├── Tools View
    │   ├── Workspace View
    │   ├── LLM Chat View (new)
    │   └── Terminal 2 View (new)
    └── Input Area
        ├── InputRoutingIndicator (new)
        └── ChatInputArea (modified)
```

### State Management

```typescript
// Input Routing State
interface InputRoutingState {
  activeDestination: 'llm' | 'editor' | 'terminal1' | 'terminal2';
  inputMode: 'line-buffered' | 'raw' | 'disabled';
}

// View Navigation State
interface WindowState {
  // Main panel
  activeWindow: 'chat' | 'terminal' | 'editor';
  
  // Right panel
  activeRightPanel: 'tools' | 'workspace' | 'llm-chat' | 'terminal2';
}
```

### Data Flow

```
User Keypress
    ↓
InputRoutingContext checks activeDestination
    ↓
    ├─→ LLM: Line-buffered → ChatContext → API
    ├─→ Editor: Disabled (mockup)
    ├─→ T1: Raw → TerminalContext → PTY1
    └─→ T2: Raw → Terminal2Context → PTY2
```

---

## User Interface Design

### Layout Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│ Top Bar: Chat | Tool | Hooks | Files | Search | Docs | GitHub | ... │
├──────────────────────────────────┬──────────────────────────────────┤
│ MAIN PANEL (Left 70%)            │ RIGHT PANEL (30%)                │
│                                  │                                  │
│ ┌──────────────────────────────┐ │ ┌────────────────────────────┐ │
│ │                              │ │ │                            │ │
│ │  Active View:                │ │ │  Active View:              │ │
│ │  • Chat (LLM conversation)   │ │ │  • Tools                   │ │
│ │  • Editor (code mockup)      │ │ │  • Workspace               │ │
│ │  • Terminal 1 (PTY output)   │ │ │  • LLM Chat (mirror)       │ │
│ │                              │ │ │  • Terminal 2 (second PTY) │ │
│ │                              │ │ │                            │ │
│ │                              │ │ │                            │ │
│ │                              │ │ │                            │ │
│ └──────────────────────────────┘ │ └────────────────────────────┘ │
│                                  │                                  │
│ View Indicators: ● ○ ○           │ View Indicators: ○ ● ○ ○        │
│ (Chat/Terminal/Editor)           │ (Tools/Work/LLM/Term2)          │
├──────────────────────────────────┴──────────────────────────────────┤
│ Status: OLLM: Terminal Mode                                         │
├─────────────────────────────────────────────────────────────────────┤
│ Input Routing: [LLM | E | ●T1 | T2]  ← Active destination          │
├─────────────────────────────────────────────────────────────────────┤
│ > Enter terminal command... (Enter to execute)                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Visual Indicators

#### 1. View Navigation Dots (Purple)
**Location:** Below each panel  
**Purpose:** Show which view is active in that panel

```
Main Panel:  ● ○ ○  (Chat active)
             ○ ● ○  (Terminal active)
             ○ ○ ●  (Editor active)

Right Panel: ● ○ ○ ○  (Tools active)
             ○ ● ○ ○  (Workspace active)
             ○ ○ ● ○  (LLM Chat active)
             ○ ○ ○ ●  (Terminal 2 active)
```

#### 2. Input Routing Indicator
**Location:** Above input box  
**Purpose:** Show where typing goes

```
[●LLM | E | T1 | T2]  ← Typing goes to LLM
[LLM | ●E | T1 | T2]  ← Typing goes to Editor (disabled)
[LLM | E | ●T1 | T2]  ← Typing goes to Terminal 1
[LLM | E | T1 | ●T2]  ← Typing goes to Terminal 2
```

#### 3. Status Messages
**Location:** Status bar  
**Purpose:** Describe current mode

```
OLLM: Idle              (Main chat, no activity)
OLLM: Streaming         (Main chat, receiving response)
OLLM: Terminal Mode     (Terminal 1 active)
OLLM: Terminal 2        (Terminal 2 active)
OLLM: Editor            (Editor active)
OLLM: LLM Chat (Right)  (Right panel LLM active)
```

---

## Input Modes

### Mode 1: Line-Buffered (LLM) - **DEFAULT MODE**
**Behavior:**
- Type message in input box
- Edit before sending
- Press Enter to send
- History navigation with Up/Down
- **ALL EXISTING FEATURES WORK:**
  - `/model` opens model picker
  - Menu navigation (Up/Down/Enter)
  - All slash commands
  - Multi-line input (Shift+Enter)
  - Tool confirmations
  - Everything that works now!

**Use Cases:**
- Chatting with AI
- Asking questions
- Model selection
- All current LLM interactions

### Mode 2: Raw (Terminal 1 & 2)
**Behavior:**
- Each keypress sent immediately
- No buffering
- No editing
- Direct PTY communication

**Special Keys:**
- Enter → `\r` (carriage return)
- Backspace → `\x7f` (DEL)
- Ctrl+C → `\x03` (interrupt)
- Ctrl+D → `\x04` (EOF)

**Use Cases:**
- Interactive CLI apps (Gemini CLI, vim, nano)
- Real-time terminal interaction
- Character-by-character input

### Mode 3: Disabled (Editor)
**Behavior:**
- Input box disabled
- No input accepted
- Editor is mockup only

**Use Cases:**
- Viewing code
- Future: Will enable editing

---

## Keyboard Shortcuts

### View Navigation

| Shortcut | Action | Scope |
|----------|--------|-------|
| **Tab** | Next main view | Chat → Terminal → Editor → Chat |
| **Shift+Tab** | Previous main view | Editor → Terminal → Chat → Editor |
| **Ctrl+Tab** | Next right view | Tools → Workspace → LLM → Term2 → Tools |
| **Ctrl+Shift+Tab** | Previous right view | Term2 → LLM → Workspace → Tools → Term2 |

### Input Routing

| Shortcut | Action | Result |
|----------|--------|--------|
| **Ctrl+Left** | Previous destination | T2 → T1 → E → LLM → T2 |
| **Ctrl+Right** | Next destination | LLM → E → T1 → T2 → LLM |
| **Ctrl+1** | Quick switch to LLM | Direct to LLM |
| **Ctrl+2** | Quick switch to T1 | Direct to Terminal 1 |
| **Ctrl+3** | Quick switch to T2 | Direct to Terminal 2 |

### Global

| Shortcut | Action |
|----------|--------|
| **Ctrl+C** | Interrupt (in terminal mode) |
| **Ctrl+D** | EOF (in terminal mode) |
| **Esc** | Exit/Cancel |

---

## User Workflows

### Workflow 1: Using Gemini CLI

**Goal:** Run Gemini CLI interactively

**Steps:**
1. Press Tab until Terminal 1 is active (view)
2. Press Ctrl+Right until T1 is highlighted (input)
3. Type `gemini` + Enter → Gemini starts
4. Type `/model` → Executes immediately (raw mode)
5. Continue using Gemini CLI normally

**Result:** ✅ Gemini CLI works perfectly with character-by-character input

---

### Workflow 2: Monitoring Build While Chatting

**Goal:** Watch build output while asking AI questions

**Steps:**
1. View: Terminal 1 (watching build)
2. Input: LLM (asking questions)
3. Type: "How do I fix this error?"
4. See: Build output on left, AI response in chat
5. Switch input to T1 if build needs interaction

**Result:** ✅ Can monitor one thing while working on another

---

### Workflow 3: Dual Terminal Setup

**Goal:** Run server in T1, tests in T2

**Steps:**
1. View: Terminal 1 (main panel)
2. Input: T1
3. Type: `npm run dev` → Server starts
4. Switch view: Ctrl+Tab to Terminal 2 (right panel)
5. Switch input: Ctrl+Right to T2
6. Type: `npm test` → Tests run
7. See: Server logs on left, test output on right

**Result:** ✅ Two independent terminals running simultaneously

---

### Workflow 4: Mirror LLM Chat (Right Panel)

**Goal:** See the same LLM conversation on both sides

**Steps:**
1. View: Main Chat
2. Right: LLM Chat (mirror)
3. Input: LLM
4. Type: "Explain async/await"
5. See: Same response mirrored on both panels

**Result:** ✅ Mirrored chat on left and right

**Note:** This is a single-model mirror only; independent right-panel LLM is deferred.

---

## Technical Implementation

### Input Routing Context

```typescript
// Context definition
interface InputRoutingContextValue {
  activeDestination: InputDestination;
  setActiveDestination: (dest: InputDestination) => void;
  cycleDestination: (direction: 'next' | 'prev') => void;
  inputMode: InputMode;
}

// Provider implementation
export function InputRoutingProvider({ children }) {
  const [activeDestination, setActiveDestination] = 
    useState<InputDestination>('llm');
  
  const inputMode = useMemo(() => {
    if (activeDestination === 'editor') return 'disabled';
    if (activeDestination === 'terminal1' || activeDestination === 'terminal2') {
      return 'raw';
    }
    return 'line-buffered';
  }, [activeDestination]);
  
  const cycleDestination = useCallback((direction: 'next' | 'prev') => {
    const destinations: InputDestination[] = ['llm', 'editor', 'terminal1', 'terminal2'];
    const currentIndex = destinations.indexOf(activeDestination);
    const nextIndex = direction === 'next' 
      ? (currentIndex + 1) % destinations.length
      : (currentIndex - 1 + destinations.length) % destinations.length;
    setActiveDestination(destinations[nextIndex]);
  }, [activeDestination]);
  
  return (
    <InputRoutingContext.Provider value={{
      activeDestination,
      setActiveDestination,
      cycleDestination,
      inputMode
    }}>
      {children}
    </InputRoutingContext.Provider>
  );
}
```

### Raw Input Handler

```typescript
// In ChatInputArea.tsx
const handleRawInput = useCallback((input: string, key: Key) => {
  const { activeDestination } = useInputRouting();
  
  if (activeDestination !== 'terminal1' && activeDestination !== 'terminal2') {
    return; // Not in raw mode
  }
  
  const terminal = activeDestination === 'terminal1' 
    ? terminal1Context 
    : terminal2Context;
  
  // Handle special keys
  if (key.return) {
    terminal.sendRawInput('\r');
  } else if (key.backspace) {
    terminal.sendRawInput('\x7f');
  } else if (key.ctrl && input === 'c') {
    terminal.sendRawInput('\x03');
  } else if (key.ctrl && input === 'd') {
    terminal.sendRawInput('\x04');
  } else if (input && !key.ctrl && !key.meta) {
    terminal.sendRawInput(input);
  }
}, [activeDestination, terminal1Context, terminal2Context]);
```

### Window Context Extension

```typescript
// Extended WindowContext
interface WindowContextValue {
  // Main panel (existing)
  activeWindow: WindowType;
  setActiveWindow: (window: WindowType) => void;
  cycleMainWindow: () => void;
  
  // Right panel (new)
  activeRightPanel: RightPanelType;
  setActiveRightPanel: (panel: RightPanelType) => void;
  cycleRightPanel: () => void;
}

// Cycling implementation
const cycleRightPanel = useCallback(() => {
  setActiveRightPanel(prev => {
    if (prev === 'tools') return 'workspace';
    if (prev === 'workspace') return 'llm-chat';
    if (prev === 'llm-chat') return 'terminal2';
    return 'tools';
  });
}, []);
```

---

## Component Design

### InputRoutingIndicator Component

```typescript
interface InputRoutingIndicatorProps {
  activeDestination: InputDestination;
  theme: Theme;
}

export function InputRoutingIndicator({ 
  activeDestination, 
  theme 
}: InputRoutingIndicatorProps) {
  const destinations = [
    { id: 'llm', label: 'LLM' },
    { id: 'editor', label: 'E' },
    { id: 'terminal1', label: 'T1' },
    { id: 'terminal2', label: 'T2' },
  ];
  
  return (
    <Box flexDirection="row" gap={1} paddingX={1}>
      <Text color={theme.text.secondary}>[</Text>
      {destinations.map((dest, index) => (
        <React.Fragment key={dest.id}>
          {index > 0 && <Text color={theme.text.secondary}> | </Text>}
          <Text 
            color={activeDestination === dest.id 
              ? theme.text.accent 
              : theme.text.secondary}
            bold={activeDestination === dest.id}
          >
            {activeDestination === dest.id && '●'}
            {dest.label}
          </Text>
        </React.Fragment>
      ))}
      <Text color={theme.text.secondary}>]</Text>
    </Box>
  );
}
```

### Terminal2 Component

```typescript
// Option 1: Separate context
export function Terminal2() {
  const { output, isRunning, resize } = useTerminal2();
  // Same rendering logic as Terminal1
}

// Option 2: Shared context with instance ID
export function Terminal2() {
  const { output, isRunning, resize } = useTerminal('terminal2');
  // Same rendering logic
}
```

---

## Data Models

### Input Destination

```typescript
type InputDestination = 
  | 'llm'        // Chat with AI
  | 'editor'     // Code editor (disabled)
  | 'terminal1'  // Main terminal
  | 'terminal2'; // Second terminal
```

### Input Mode

```typescript
type InputMode = 
  | 'line-buffered'  // Collect input, send on Enter
  | 'raw'            // Send each keypress immediately
  | 'disabled';      // No input accepted
```

### Window Types

```typescript
// Main panel
type WindowType = 
  | 'chat'      // LLM conversation
  | 'terminal'  // Terminal 1
  | 'editor';   // Code editor

// Right panel
type RightPanelType = 
  | 'tools'      // Tool configuration
  | 'workspace'  // File tree
  | 'llm-chat'   // Mirrored LLM chat (single model)
  | 'terminal2'; // Second terminal
```

---

## Performance Considerations

### Terminal Performance
- Two PTY instances running simultaneously
- Each terminal has independent xterm.js instance
- Serialization happens on data events only
- No performance impact on main chat

### State Updates
- Input routing state changes don't trigger re-renders
- View navigation uses memoization
- Terminal output updates are throttled

### Memory Management
- PTY processes properly cleaned up on unmount
- xterm.js instances disposed correctly
- No memory leaks from multiple terminals

---

## Security Considerations

### Terminal Input
- Raw input mode only active when explicitly selected
- No automatic switching to raw mode
- Clear visual indicator when in raw mode

### PTY Isolation
- Each terminal has separate PTY process
- No cross-contamination between terminals
- Proper process cleanup on exit

---

## Accessibility

### Visual Indicators
- Color-coded indicators
- Text labels for all destinations
- Status messages describe current state

### Keyboard Navigation
- All features accessible via keyboard
- No mouse required
- Consistent shortcut patterns

### Screen Readers
- Status messages announced
- Input mode changes announced
- View changes announced

---

## Future Enhancements

### Phase 2 Features
- [ ] Pane resizing (drag to resize)
- [ ] Pane layouts (horizontal/vertical split)
- [ ] Save/restore pane configurations
- [ ] More than 2 panes

### Phase 3 Features
- [ ] Independent right-panel LLM (separate model/session)
- [ ] Dual LLM streaming (send to both simultaneously)
- [ ] Terminal session recording
- [ ] Terminal search/filter
- [ ] Copy/paste between panes

### Phase 4 Features
- [ ] Editor implementation (replace mockup)
- [ ] Syntax highlighting in editor
- [ ] File editing capabilities
- [ ] Git integration in editor

---

## Success Metrics

### Functional
- ✅ Gemini CLI works with raw input
- ✅ Two terminals run independently
- ✅ Can view one thing while typing to another
- ✅ All keyboard shortcuts work
- ✅ No input conflicts

### Performance
- ✅ No lag in terminal input
- ✅ Smooth view switching
- ✅ No memory leaks
- ✅ Stable with long-running processes

### User Experience
- ✅ Clear visual indicators
- ✅ Intuitive keyboard shortcuts
- ✅ Consistent behavior
- ✅ No confusion about where input goes

---

## Conclusion

This design provides a flexible, powerful dual-pane system that solves the terminal interactivity problem while enabling advanced workflows. The separation of view navigation and input routing is key to the design, allowing users to monitor one interface while working in another.

The implementation is incremental, with each phase building on the previous one, ensuring stability and allowing for testing at each step.


---

## IMPORTANT: Preserving Existing Functionality

### Critical Design Principle

**⚠️ ALL EXISTING LLM FEATURES MUST REMAIN INTACT**

This implementation adds input routing WITHOUT changing how LLM chat works.

### What Stays Exactly The Same

When `activeDestination === 'llm'` (default):
- ✅ Model selection on startup
- ✅ `/model` command opens model picker
- ✅ Up/Down arrows navigate model list
- ✅ Enter selects model
- ✅ All slash commands (`/help`, `/clear`, etc.)
- ✅ Menu system and navigation
- ✅ History navigation (Up arrow for previous messages)
- ✅ Multi-line input (Shift+Enter)
- ✅ Streaming responses
- ✅ Tool confirmations
- ✅ Input validation
- ✅ Error handling
- ✅ ALL current features

### Implementation Strategy

```typescript
// In ChatInputArea.tsx - useInput handler

useInput((input, key) => {
  const { activeDestination } = useInputRouting();
  
  // STEP 1: Check if terminal mode
  if (activeDestination === 'terminal1' || activeDestination === 'terminal2') {
    // Route to terminal (raw mode)
    handleTerminalInput(input, key, activeDestination);
    return; // EXIT EARLY - don't process LLM input
  }
  
  // STEP 2: ALL EXISTING LLM CODE BELOW THIS LINE
  // Nothing changes! All current features work!
  
  // Existing: Model selection menu
  if (chatState.inputMode === 'menu') {
    if (key.upArrow) {
      navigateMenu('up');
    } else if (key.downArrow) {
      navigateMenu('down');
    } else if (key.return) {
      executeMenuOption();
    }
    // ... rest of menu logic
  }
  
  // Existing: Slash commands
  if (input.startsWith('/')) {
    // /model, /help, /clear, etc.
    // ... existing command handling
  }
  
  // Existing: Normal chat input
  // ... all existing chat logic
  // History, multi-line, streaming, etc.
});
```

### Testing Requirements

**Test 1: LLM Mode Unchanged**
```
1. Start app (default: LLM mode)
2. Verify indicator shows [●LLM | E | T1 | T2]
3. Type /model
4. Verify: Model picker opens (existing behavior)
5. Press Up/Down
6. Verify: Navigate models (existing behavior)
7. Press Enter
8. Verify: Model selected (existing behavior)
9. Type message
10. Verify: Sends to LLM (existing behavior)
```

**Expected: Everything works exactly as before**

**Test 2: Terminal Mode Works**
```
1. Press Ctrl+Right
2. Verify indicator shows [LLM | E | ●T1 | T2]
3. Type gemini
4. Verify: Characters go to terminal
5. Press Enter
6. Verify: Gemini starts
7. Type /model
8. Verify: Goes to Gemini CLI (NOT our model picker)
```

**Expected: Raw input to terminal**

**Test 3: Switch Back**
```
1. Press Ctrl+Left twice
2. Verify indicator shows [●LLM | E | T1 | T2]
3. Type /model
4. Verify: Our model picker opens (existing behavior restored)
```

**Expected: LLM mode fully restored**

### Code Review Checklist

Before merging, verify:
- [ ] No changes to existing LLM input handling code
- [ ] Terminal check is BEFORE existing code (early return)
- [ ] All existing features tested and working
- [ ] Model selection works
- [ ] Slash commands work
- [ ] Menu navigation works
- [ ] History navigation works
- [ ] Multi-line input works
- [ ] No regressions in LLM chat

### Risk Mitigation

**Risk:** Breaking existing LLM features  
**Mitigation:** Add terminal check at START of useInput, early return, don't modify existing code

**Risk:** Input conflicts  
**Mitigation:** Clear visual indicator, status messages, default to LLM mode

**Risk:** User confusion  
**Mitigation:** Default to LLM mode, preserve all familiar behavior, add clear indicators

---

## Summary

This design adds input routing as a **non-breaking addition**:
- Default mode: LLM (everything works as now)
- Switch to terminal: Raw input mode
- Switch back: LLM mode restored

**Key principle: Wrap, don't replace!**
