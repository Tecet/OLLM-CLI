# Input Router Architecture - Multi-Destination System

**Date:** January 24, 2026  
**Status:** 📋 Planning

## Vision

Transform the input system from a single-purpose chat input into a universal input router that can send keystrokes to multiple destinations based on the active window/pane.

## Current State

**Input Box Behavior:**
- Always captures input as complete lines
- Press Enter → sends entire line
- Works for: LLM chat, terminal commands
- Doesn't work for: Interactive terminal apps (Gemini CLI, vim, nano)

**Window System:**
- WindowContext manages: 'chat' | 'terminal' | 'editor'
- Ctrl+Left/Right to switch windows
- Input box always visible at bottom

## Proposed Architecture

### Input Destinations

| Destination | Location | Input Mode | Behavior |
|------------|----------|------------|----------|
| **Main LLM Chat** | Left pane | Line-buffered | Type message, Enter to send |
| **Terminal (Raw)** | Left pane | Character-by-character | Each keypress sent to PTY immediately |
| **Editor** | Left pane | Character-by-character | Direct text editing |
| **Right Terminal** | Right pane | Character-by-character | Second terminal instance |
| **Right LLM Chat** | Right pane | Stream mirror | Display LLM2 response or mirror LLM1 |

### Input Modes

```typescript
type InputMode = 
  | 'line-buffered'    // Collect input, send on Enter (LLM chat)
  | 'raw'              // Send each keypress immediately (Terminal, Editor)
  | 'disabled';        // No input (viewing only)

type InputDestination = 
  | 'main-chat'        // Left: LLM chat
  | 'main-terminal'    // Left: Terminal
  | 'main-editor'      // Left: Editor
  | 'right-terminal'   // Right: Second terminal
  | 'right-chat';      // Right: LLM chat mirror/LLM2
```

### Window Layout

```
┌─────────────────────────────────┬─────────────────────────────────┐
│                                 │                                 │
│  LEFT PANE                      │  RIGHT PANE                     │
│  (Active: main-terminal)        │  (Active: right-chat)           │
│                                 │                                 │
│  [Terminal Output]              │  [LLM Chat History]             │
│  > gemini                       │  User: How do I...              │
│  > /model                       │  AI: You can...                 │
│  [Gemini CLI running]           │                                 │
│                                 │                                 │
├─────────────────────────────────┴─────────────────────────────────┤
│  INPUT BOX (Routes to active destination)                         │
│  > [typing goes to main-terminal in raw mode]                     │
└───────────────────────────────────────────────────────────────────┘
```

### Navigation Flow

**Cycle through destinations:**
- Tab / Shift+Tab: Cycle focus
- Ctrl+1: Main Chat
- Ctrl+2: Main Terminal
- Ctrl+3: Main Editor
- Ctrl+4: Right Terminal
- Ctrl+5: Right Chat

**Visual indicators:**
- Active destination highlighted
- Input mode shown in status bar: `[RAW]` or `[LINE]`
- Cursor style changes based on mode

## Implementation Phases

### Phase 1: Input Mode System ✅ (Current)
- [x] WindowContext with 'chat' | 'terminal' | 'editor'
- [x] Basic input routing to terminal
- [x] Line-buffered mode for chat

### Phase 2: Raw Input Mode (Next)
- [ ] Add `inputMode` state to WindowContext
- [ ] Implement character-by-character input for terminal
- [ ] Add visual indicator for raw mode
- [ ] Handle special keys (Ctrl+C, Ctrl+D, etc.)

### Phase 3: Split Panes
- [ ] Add right pane to layout
- [ ] Implement pane switching
- [ ] Add second terminal instance
- [ ] Add LLM chat mirror to right pane

### Phase 4: Advanced Features
- [ ] Dual LLM streaming (LLM1 + LLM2)
- [ ] Pane resizing
- [ ] Pane layouts (horizontal/vertical split)
- [ ] Save/restore pane configurations

## Technical Details

### Raw Input Mode Implementation

**When Terminal is Active:**

```typescript
// In ChatInputArea or new InputRouter component
useInput((input, key) => {
  if (inputMode === 'raw' && activeDestination === 'main-terminal') {
    // Send each keypress directly to PTY
    if (key.return) {
      sendToPTY('\r');
    } else if (key.backspace) {
      sendToPTY('\x7f'); // DEL
    } else if (key.ctrl && input === 'c') {
      sendToPTY('\x03'); // Ctrl+C
    } else if (input) {
      sendToPTY(input);
    }
    return; // Don't buffer
  }
  
  // Line-buffered mode for chat
  // ... existing logic
});
```

**PTY Integration:**

```typescript
// In TerminalContext
const sendRawInput = useCallback((char: string) => {
  if (ptyProcessRef.current && isRunning) {
    ptyProcessRef.current.write(char);
  }
}, [isRunning]);
```

### State Management

**Enhanced WindowContext:**

```typescript
interface WindowContextValue {
  // Existing
  activeWindow: WindowType;
  setActiveWindow: (window: WindowType) => void;
  
  // New
  inputMode: InputMode;
  setInputMode: (mode: InputMode) => void;
  activeDestination: InputDestination;
  setActiveDestination: (dest: InputDestination) => void;
  
  // Pane management
  rightPaneVisible: boolean;
  setRightPaneVisible: (visible: boolean) => void;
  rightPaneContent: 'terminal' | 'chat' | 'none';
  setRightPaneContent: (content: 'terminal' | 'chat' | 'none') => void;
}
```

## Benefits

### For Terminal
✅ Interactive apps work perfectly (Gemini CLI, vim, nano)
✅ Real-time character input
✅ Proper handling of special keys
✅ No input lag

### For LLM Chat
✅ Existing line-buffered behavior preserved
✅ Can still edit before sending
✅ History navigation works

### For Editor
✅ Direct text editing
✅ No input box interference
✅ Natural editing experience

### For Multi-LLM
✅ Compare responses side-by-side
✅ Stream to multiple models simultaneously
✅ Different prompts to different models

## User Experience

**Scenario 1: Using Gemini CLI**
1. Switch to Terminal (Ctrl+2)
2. Type `gemini` + Enter → starts Gemini
3. Input mode automatically switches to RAW
4. Type `/model` → executes immediately
5. Type characters → appear in Gemini CLI in real-time

**Scenario 2: Comparing LLMs**
1. Main chat on left (LLM1)
2. Right chat on right (LLM2)
3. Type question in input box
4. Press Ctrl+Enter → sends to both
5. See responses side-by-side

**Scenario 3: Terminal + Chat**
1. Terminal on left (running build)
2. Chat on right (asking questions)
3. Switch focus with Tab
4. Terminal shows build output
5. Chat shows AI responses

## Migration Path

### Step 1: Add Input Mode Toggle
- Add `inputMode` state
- Add visual indicator
- Keep existing behavior as default

### Step 2: Implement Raw Mode
- Add character-by-character input
- Test with interactive apps
- Add keyboard shortcuts

### Step 3: Add Right Pane
- Implement split layout
- Add pane switching
- Add second terminal

### Step 4: Polish
- Add animations
- Add pane resizing
- Add configuration persistence

## Open Questions

1. **Input Box Visibility**: Hide input box in raw mode? Or keep visible with different styling?
2. **Mode Switching**: Automatic (based on active window) or manual toggle?
3. **Right Pane Default**: What should show in right pane by default?
4. **Keyboard Shortcuts**: Which keys for pane switching?
5. **Terminal Instances**: Share PTY or separate instances?

## Next Steps

1. Create detailed spec for Phase 2 (Raw Input Mode)
2. Update WindowContext to support input modes
3. Implement character-by-character input for terminal
4. Test with Gemini CLI and other interactive apps
5. Add visual indicators for input mode

## References

- Current WindowContext: `packages/cli/src/ui/contexts/WindowContext.tsx`
- Current Input: `packages/cli/src/ui/components/layout/ChatInputArea.tsx`
- Terminal: `packages/cli/src/ui/components/Terminal.tsx`
- PTY: `packages/cli/src/ui/contexts/TerminalContext.tsx`
