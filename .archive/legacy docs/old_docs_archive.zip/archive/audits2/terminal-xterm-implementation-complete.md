# Terminal xterm.js Headless Implementation - In Progress (Debugging)

**Date:** January 24, 2026  
**Status:** 🔧 Debugging - Output not rendering

## Overview

Implementing xterm.js headless terminal rendering to properly display ANSI codes, colors, and formatting in the terminal window. This replaces the previous approach that was stripping ANSI codes.

## Problem Statement

The previous terminal implementation used `node-pty` for PTY management but was stripping ANSI codes with `strip-ansi`, causing:
- Loss of all colors and formatting
- Broken rendering for tools with rich terminal UIs (boxes, tables, etc.)
- Poor user experience when running CLI tools

## Solution Approach

Adopted the same approach as Gemini CLI:
1. **PTY Management:** Continue using `node-pty` for process management
2. **ANSI Parsing:** Use `@xterm/headless` to parse ANSI codes into structured buffer
3. **Token Serialization:** Convert xterm buffer to `AnsiToken[]` with style attributes
4. **Ink Rendering:** Render tokens as Ink `<Text>` components with proper props

## Implementation Progress

### ✅ Completed

**`packages/cli/src/utils/terminalSerializer.ts`**
- Created serializer module (copied from Gemini CLI)
- Exports `AnsiToken`, `AnsiLine`, `AnsiOutput` types
- `serializeTerminalToObject()` function converts xterm buffer to structured tokens
- Handles ANSI color palette (256 colors) and RGB colors
- Preserves text attributes: bold, italic, underline, dim, inverse

**`packages/cli/src/ui/contexts/TerminalContext.tsx`**
- ✅ Added `@xterm/headless` Terminal instance
- ✅ Pipes PTY output to xterm: `ptyProcess.onData(data => xterm.write(data))`
- ✅ Attempts to serialize xterm buffer to `AnsiOutput` on each data event
- ✅ Returns `AnsiOutput` (array of `AnsiLine[]`) instead of `TerminalLine[]`
- ✅ Properly disposes xterm instance on cleanup
- ✅ Added debug info tracking (data events, output lines, errors)

**`packages/cli/src/ui/components/Terminal.tsx`**
- ✅ Removed `ansi-to-react` import
- ✅ Added imports for `AnsiToken`, `AnsiLine` from serializer
- ✅ Changed `output` type from `TerminalLine[]` to `AnsiOutput`
- ✅ Removed old line parsing logic
- ✅ Updated `renderLine()` to render `AnsiToken[]` with Ink Text props
- ✅ Fixed `useInput` hook to only be active when terminal window is shown
- ✅ Added debug display showing line counts and data events

**`packages/cli/src/ui/hooks/useTerminal.ts`**
- ✅ Removed export of obsolete `TerminalLine` type

**`package.json` & `esbuild.config.js`**
- ✅ Removed `ansi-to-react` dependency
- ✅ Kept `@xterm/headless` dependency

### 🔧 Current Issue: Output Not Rendering

**Symptoms:**
- ✅ Input is working - user can type commands
- ✅ PTY is receiving commands - `sendCommand()` works
- ✅ PTY is sending data back - debug shows "Data events: 18, Last size: 295 bytes"
- ❌ Terminal display shows "Total lines: 0" - no output visible
- ❌ Even with fallback using `translateToString()`, output is empty

**Debug Information Added:**
```typescript
debugInfo: {
  dataEvents: number;      // How many times PTY sent data
  lastDataSize: number;    // Size of last data chunk
  outputLines: number;     // How many lines setOutput() was called with
  lastError: string;       // Any errors during processing
}
```

**Debugging Steps Taken:**

1. **Verified PTY is working** - Data events counter increases when typing
2. **Verified xterm receives data** - `xterm.write(data)` is called
3. **Tried complex serialization** - `serializeTerminalToObject()` returns empty array
4. **Tried simple fallback** - `translateToString()` also returns empty
5. **Added aggressive fallback** - Creating 30 lines regardless of content
6. **Added error tracking** - To catch any silent failures

**Current Hypothesis:**
Either:
- The xterm buffer is not being populated correctly
- The state update from `setOutput()` is being lost
- There's a React rendering issue preventing the output from displaying
- The `output` state is being reset somewhere else

### 🔍 Next Debugging Steps

1. Check if `debugInfo.outputLines` shows 30 (confirming setOutput is called)
2. If outputLines = 30 but allLines = 0, there's a state propagation issue
3. Check if there are multiple TerminalProvider instances
4. Verify the Terminal component is reading from the correct context
5. Check if output is being cleared somewhere else

## Files Modified

### Created
- `packages/cli/src/utils/terminalSerializer.ts`

### Modified
- `packages/cli/src/ui/contexts/TerminalContext.tsx`
- `packages/cli/src/ui/components/Terminal.tsx`
- `packages/cli/src/ui/hooks/useTerminal.ts`
- `package.json`
- `esbuild.config.js`

## Architecture Flow

```
User types command
    ↓
InputBox captures input
    ↓
sendCommand(input) → PTY.write(input + '\r')
    ↓
PTY executes command
    ↓
PTY.onData(data) fires [✅ WORKING - 295 bytes received]
    ↓
xterm.write(data) [✅ CALLED]
    ↓
Extract lines from xterm.buffer [❓ UNKNOWN]
    ↓
setOutput(lines) [❓ CALLED WITH 30 LINES?]
    ↓
Terminal component receives output [❌ SHOWS 0 LINES]
    ↓
renderLine() for each line [❌ NEVER CALLED]
```

## Testing Status

- ✅ Build succeeds without errors
- ✅ No TypeScript diagnostics
- ✅ Dependencies installed correctly
- ✅ App starts and accepts input
- ✅ PTY receives commands and sends data back
- ❌ Terminal output not displaying

## References

- Gemini CLI source: `D:\Workspaces\Gemini`
- Gemini's serializer: `D:\Workspaces\Gemini\packages\core\src/utils/terminalSerializer.ts`
- Gemini's AnsiOutput: `D:\Workspaces\Gemini\packages\cli\src/ui/components/AnsiOutput.tsx`
- xterm.js docs: https://xtermjs.org/

## Temporary Debug Display

The terminal currently shows:
```
Terminal ready. Type commands and press Enter. ●
Total lines: 0, Visible: 0, Scroll: 0
Data events: 18, Last size: 295 bytes
Output lines set: [NEED TO CHECK]
```

This debug info will help identify where the data flow is breaking.
