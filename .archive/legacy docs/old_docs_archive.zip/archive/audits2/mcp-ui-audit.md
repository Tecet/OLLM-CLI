# MCP Tab UI Audit

**Date**: January 23, 2026  
**Auditor**: System  
**Scope**: MCP Tab UI - Enable/Disable Servers & System Notifications

---

## Executive Summary

This audit examines the MCP Tab UI implementation focusing on:
1. Server enable/disable functionality
2. System notification messages
3. Error handling and user feedback
4. State management issues

### Key Findings

✅ **Working Well**:
- Two-column layout with proper navigation
- Server details view with comprehensive information
- Marketplace integration with search
- Dialog system for configuration
- Status message area at bottom right (replacing overlays)

⚠️ **Issues Identified**:
1. **BUG-001**: React Hooks error when enabling server without API key
2. Missing proper error recovery for OAuth failures
3. Inconsistent notification patterns
4. State management complexity in toggleServer

---

## 1. Enable/Disable Server Functionality

### Current Implementation

**Location**: `packages/cli/src/ui/contexts/MCPContext.tsx` (lines 464-520)

```typescript
const toggleServer = useCallback(async (serverName: string) => {
  try {
    const server = state.servers.get(serverName);
    if (!server) {
      throw new Error(`Server '${serverName}' not found`);
    }

    const isCurrentlyDisabled = server.config.disabled || false;
    const newConfig = {
      ...server.config,
      disabled: !isCurrentlyDisabled,
    };

    // Update configuration first
    await mcpConfigService.updateServerConfig(serverName, newConfig as unknown as MCPServerConfig);

    // Start or stop the server with retry logic
    try {
      await retryWithBackoff(async () => {
        if (newConfig.disabled) {
          await mcpClient.stopServer(serverName);
        } else {
          await mcpClient.startServer(serverName, newConfig);
        }
      }, { maxAttempts: 2 });
    } catch (startError) {
      // If starting fails, revert the config change
      await mcpConfigService.updateServerConfig(serverName, {
        ...newConfig,
        disabled: true,
      } as unknown as MCPServerConfig);
      
      // Ensure tools are unregistered if start failed
      if (server.toolsList) {
          unregisterServerTools(serverName, server.toolsList);
      }

      // Re-throw with more context
      if (server.config.oauth?.enabled) {
        throw new Error(`OAuth authentication failed for ${serverName}. Please check OAuth configuration.`);
      }
      throw startError;
    }

    // Reload servers
    await loadServers();
  } catch (error) {
    const parsedError = parseError(error);
    setState(prev => ({
      ...prev,
      error: formatErrorMessage(parsedError),
    }));
    throw error;
  }
}, [state.servers, mcpClient, loadServers, unregisterServerTools]);
```

### Issues Found

#### Issue 1.1: React Hooks Error (BUG-001)
**Severity**: 🔴 Critical  
**Status**: Open

**Problem**:
When `toggleServer()` fails due to missing API key, it sets error state in MCPContext. This causes MCPTab component to re-render with error state, which has early returns that change component structure. React detects different number of hooks between renders.

**Location**: `packages/cli/src/ui/components/tabs/MCPTab.tsx` (lines 1323-1460)

**Root Cause**:
```typescript
// Error state with back navigation
if (state.error) {
  return (
    <Box flexDirection="column" padding={2}>
      <ErrorBanner message={state.error} />
      <Box marginTop={2}>
        <Text bold color={uiState.theme.text.accent}>▶ ← Back</Text>
        {/* ... */}
      </Box>
    </Box>
  );
}
```

This early return changes the component structure, causing hooks to be called in different order.

**Recommended Fix**:
1. Don't use error state for expected failures (missing API key)
2. Show API key requirement error in status message area instead
3. Add proper error recovery flow for OAuth configuration
4. Consider using error boundary for unexpected errors only

#### Issue 1.2: Config Rollback on Failure
**Severity**: 🟡 Medium  
**Status**: Implemented but needs testing

**Current Behavior**:
When server start fails, the code attempts to rollback the config change:
```typescript
await mcpConfigService.updateServerConfig(serverName, {
  ...newConfig,
  disabled: true,
} as unknown as MCPServerConfig);
```

**Concern**:
- What if rollback fails?
- User sees inconsistent state (config says enabled, server is stopped)
- No user notification about rollback

**Recommended Enhancement**:
1. Add try-catch around rollback
2. Show status message: "Failed to enable server, reverting changes..."
3. Log rollback failures for debugging

#### Issue 1.3: Tool Registration/Unregistration
**Severity**: 🟢 Low  
**Status**: Working but could be improved

**Current Behavior**:
Tools are registered/unregistered in `loadServers()` based on connection status.

**Observation**:
- Tools are unregistered on failure (good)
- But registration happens in loadServers, not in toggleServer
- Could lead to race conditions if multiple operations happen quickly

**Recommended Enhancement**:
Consider moving tool registration/unregistration closer to the toggle operation for better control.

---

## 2. System Notification Messages

### Current Implementation

**Status Message Area**: `packages/cli/src/ui/components/tabs/MCPTab.tsx`

The tab uses a status message system at the bottom right:
```typescript
const [statusMessage, setStatusMessage] = useState<string | null>(null);

// Usage:
setStatusMessage('Restarting server...');
setTimeout(() => setStatusMessage(null), 3000);
```

### Issues Found

#### Issue 2.1: Notification Overlays Removed
**Severity**: ✅ Fixed  
**Status**: Completed (Commit 5a9e0cc)

**Previous Problem**:
- Used notification overlays and popups
- Blocked user interaction
- Poor UX

**Current Solution**:
- Replaced with status message area at bottom right
- Non-blocking
- Auto-dismisses after 3-5 seconds

#### Issue 2.2: Inconsistent Notification Patterns
**Severity**: 🟡 Medium  
**Status**: Needs standardization

**Observations**:
1. Some operations use status messages (restart, uninstall)
2. Some operations use error state (toggle failure)
3. Some operations have no feedback (configure)

**Example Inconsistencies**:
```typescript
// Restart - uses status message ✅
setStatusMessage(`Restarting ${server.name}...`);

// Toggle - uses error state ⚠️
setState(prev => ({ ...prev, error: formatErrorMessage(parsedError) }));

// Configure - no feedback ❌
await configureServer(dialogState.serverName!, config);
handleCloseDialog(); // Just closes dialog
```

**Recommended Standardization**:
1. **Success operations**: Status message (green) with auto-dismiss
2. **Expected failures**: Status message (yellow/red) with longer timeout
3. **Unexpected errors**: Error state with manual dismiss
4. **Long operations**: Loading spinner + status message

#### Issue 2.3: No Loading Indicators for Toggle
**Severity**: 🟡 Medium  
**Status**: Missing

**Problem**:
When toggling a server, there's no visual feedback that the operation is in progress.

**Current Code**:
```typescript
const [toggleState, setToggleState] = useState<{
  status: 'idle' | 'toggling';
}>({ status: 'idle' });

// But toggleState is only used in ServerDetailsContent, not in MCPContext
```

**Recommended Enhancement**:
1. Add loading state to MCPContext for toggle operations
2. Show spinner or "Updating..." text next to server status
3. Disable toggle button during operation

---

## 3. Error Handling Patterns

### Current Implementation

**Error Handling in MCPContext**:
```typescript
catch (error) {
  const parsedError = parseError(error);
  setState(prev => ({
    ...prev,
    error: formatErrorMessage(parsedError),
  }));
  throw error;
}
```

### Issues Found

#### Issue 3.1: Error State Causes Re-render Issues
**Severity**: 🔴 Critical  
**Related**: BUG-001

**Problem**:
Setting error state causes MCPTab to re-render with different structure, breaking React hooks rules.

**Recommended Fix**:
1. Separate error types:
   - **User errors** (missing API key, invalid config): Show in status message
   - **System errors** (network failure, crash): Show in error state
2. Use error boundary for unexpected errors
3. Don't change component structure based on error state

#### Issue 3.2: OAuth Error Handling
**Severity**: 🟡 Medium  
**Status**: Partially implemented

**Current Behavior**:
```typescript
if (server.config.oauth?.enabled) {
  throw new Error(`OAuth authentication failed for ${serverName}. Please check OAuth configuration.`);
}
```

**Issues**:
- Generic error message
- No guidance on how to fix
- No link to OAuth configuration dialog

**Recommended Enhancement**:
1. Detect specific OAuth errors (missing token, expired token, invalid credentials)
2. Provide actionable error messages:
   - "OAuth token expired. Press 'O' to re-authenticate."
   - "OAuth not configured. Press 'O' to set up authentication."
3. Auto-open OAuth dialog on certain errors

---

## 4. State Management Issues

### Current Implementation

**MCPContext State**:
```typescript
export interface MCPState {
  servers: Map<string, ExtendedMCPServerStatus>;
  config: MCPConfigFile;
  marketplace: MCPMarketplaceServer[];
  isLoading: boolean;
  error: string | null;
  operationsInProgress: Map<string, 'restart' | 'install' | 'uninstall' | 'configure'>;
}
```

### Issues Found

#### Issue 4.1: operationsInProgress Not Used for Toggle
**Severity**: 🟡 Medium  
**Status**: Inconsistent

**Observation**:
- `operationsInProgress` tracks restart, install, uninstall, configure
- But NOT toggle operations
- This makes it hard to show loading state for toggle

**Recommended Fix**:
Add 'toggle' to the operation types:
```typescript
operationsInProgress: Map<string, 'restart' | 'install' | 'uninstall' | 'configure' | 'toggle'>;
```

#### Issue 4.2: Reconnecting Servers Tracking
**Severity**: 🟢 Low  
**Status**: Working but could be improved

**Current Implementation**:
```typescript
const reconnectingServers = useMemo(() => {
  return new Set(
    Array.from(state.servers.values())
      .filter(s => s.status === 'error' && !s.config.disabled)
      .map(s => s.name)
  );
}, [state.servers]);
```

**Observation**:
- Assumes all error status servers are reconnecting
- But some might be permanently failed
- No way to distinguish between "reconnecting" and "failed"

**Recommended Enhancement**:
Add explicit reconnecting state to server status:
```typescript
export interface ExtendedMCPServerStatus extends MCPServerStatus {
  isReconnecting?: boolean;
  lastConnectionAttempt?: number;
  reconnectAttempts?: number;
}
```

---

## 5. UI/UX Issues

### Issue 5.1: Health Check Countdown
**Severity**: 🟢 Low  
**Status**: Working

**Current Implementation**:
```typescript
const [healthCheckCountdown, setHealthCheckCountdown] = useState(30);

useEffect(() => {
  const interval = setInterval(() => {
    setHealthCheckCountdown(prev => {
      if (prev <= 1) {
        return 30; // Reset to 30 when it reaches 0
      }
      return prev - 1;
    });
  }, 1000);
  
  return () => clearInterval(interval);
}, []);
```

**Observation**:
- Countdown is purely cosmetic
- Doesn't actually trigger health checks
- Could be confusing if health check interval is different

**Recommendation**:
Either:
1. Remove countdown (simpler)
2. Sync with actual health check interval from MCPHealthMonitor

### Issue 5.2: Status Message Auto-Dismiss
**Severity**: 🟢 Low  
**Status**: Working but inconsistent

**Current Behavior**:
- Success messages: 3 seconds
- Error messages: 5 seconds
- No way to manually dismiss

**Recommendation**:
1. Standardize timeout (3 seconds for all)
2. Add manual dismiss option (press any key)
3. Show progress bar for timeout

---

## Recommendations Summary

### High Priority (Fix Immediately)

1. **Fix BUG-001**: React Hooks error on toggle failure
   - Don't use error state for expected failures
   - Show API key errors in status message area
   - Add proper error recovery flow

2. **Standardize Notification Patterns**:
   - Success → Status message (green, 3s)
   - Expected failure → Status message (yellow/red, 5s)
   - Unexpected error → Error state (manual dismiss)

3. **Add Loading Indicators**:
   - Show "Updating..." during toggle operations
   - Use operationsInProgress for all operations
   - Disable actions during operations

### Medium Priority (Fix Soon)

4. **Improve OAuth Error Handling**:
   - Detect specific OAuth error types
   - Provide actionable error messages
   - Auto-open OAuth dialog when needed

5. **Add Config Rollback Notifications**:
   - Show message when rollback happens
   - Log rollback failures
   - Handle rollback errors gracefully

6. **Track Reconnecting State Explicitly**:
   - Add isReconnecting to server status
   - Distinguish between reconnecting and failed
   - Show reconnect attempts count

### Low Priority (Nice to Have)

7. **Sync Health Check Countdown**:
   - Match actual health check interval
   - Or remove countdown entirely

8. **Improve Status Message UX**:
   - Standardize timeouts
   - Add manual dismiss
   - Show progress bar

---

## Testing Checklist

### Enable/Disable Server

- [ ] Enable disabled server (no API key required)
- [ ] Enable disabled server (API key required, configured)
- [ ] Enable disabled server (API key required, NOT configured) → Should show error in status message
- [ ] Disable enabled server
- [ ] Toggle server while another operation is in progress → Should be blocked
- [ ] Toggle server that doesn't exist → Should show error
- [ ] Toggle server with OAuth enabled but not authenticated → Should show OAuth error

### Notifications

- [ ] Restart server → Should show "Restarting..." then "Restarted successfully"
- [ ] Restart fails → Should show error in status message
- [ ] Uninstall server → Should show "Uninstalling..." then "Uninstalled successfully"
- [ ] Configure server → Should show "Saving..." then "Saved successfully"
- [ ] Install from marketplace → Should show progress and success/error

### Error Handling

- [ ] Network error during toggle → Should show error in status message, not crash
- [ ] OAuth error during toggle → Should show OAuth-specific error
- [ ] Config file locked → Should show error and retry
- [ ] Server crash during toggle → Should handle gracefully

---

## Files to Modify

1. **packages/cli/src/ui/contexts/MCPContext.tsx**
   - Fix toggleServer error handling
   - Add toggle to operationsInProgress
   - Improve OAuth error detection

2. **packages/cli/src/ui/components/tabs/MCPTab.tsx**
   - Remove error state early return (or make it safe)
   - Standardize notification patterns
   - Add loading indicators

3. **packages/cli/src/ui/components/tabs/ServerDetailsContent.tsx** (if separate)
   - Show loading state during toggle
   - Disable toggle button during operation

---

## Conclusion

The MCP Tab UI is well-structured with good separation of concerns. The main issues are:

1. **BUG-001** needs immediate attention to prevent React crashes
2. Notification patterns need standardization for consistency
3. Error handling needs improvement, especially for OAuth
4. Loading states need to be more visible

Most issues are medium-low severity and can be addressed incrementally. The critical issue (BUG-001) should be fixed before the next release.

---

**Next Steps**:
1. Review this audit with the team
2. Prioritize fixes based on severity
3. Create tasks for each recommendation
4. Test thoroughly after fixes
