# Error Handling Patterns - Standardization Guide

**Created**: January 23, 2026  
**Status**: ✅ Complete

## Overview

This document defines standardized error handling patterns for the OLLM CLI codebase. Following these patterns ensures consistent error handling, better error messages, and easier debugging.

## Core Principles

1. **Use Custom Error Classes**: Create specific error types for different error categories
2. **Preserve Error Context**: Include relevant context (file paths, operation names, etc.)
3. **Consistent Error Messages**: Follow a standard format for error messages
4. **Type-Safe Error Handling**: Use TypeScript's type system to handle errors safely
5. **Graceful Degradation**: Handle errors gracefully without crashing the application
6. **Helpful Error Messages**: Provide actionable information to users

## Custom Error Classes

### Base Error Pattern

```typescript
/**
 * Base error class with enhanced context
 */
export class OllmError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly context?: Record<string, unknown>
  ) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
  
  toJSON(): Record<string, unknown> {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      context: this.context,
    };
  }
}
```

### Specific Error Classes

```typescript
/**
 * File system operation errors
 */
export class FileSystemError extends OllmError {
  constructor(
    message: string,
    public readonly operation: 'read' | 'write' | 'delete' | 'stat' | 'mkdir',
    public readonly path: string,
    public readonly originalError?: Error
  ) {
    super(message, 'FILE_SYSTEM_ERROR', {
      operation,
      path,
      originalError: originalError?.message,
    });
  }
}

/**
 * Configuration errors
 */
export class ConfigError extends OllmError {
  constructor(
    message: string,
    public readonly filePath?: string,
    public readonly line?: number,
    public readonly column?: number
  ) {
    super(message, 'CONFIG_ERROR', {
      filePath,
      line,
      column,
    });
  }
}

/**
 * Provider connection errors
 */
export class ProviderError extends OllmError {
  constructor(
    message: string,
    public readonly provider: string,
    public readonly host?: string,
    public readonly originalError?: Error
  ) {
    super(message, 'PROVIDER_ERROR', {
      provider,
      host,
      originalError: originalError?.message,
    });
  }
}

/**
 * Model errors
 */
export class ModelError extends OllmError {
  constructor(
    message: string,
    public readonly model: string,
    public readonly operation: 'load' | 'list' | 'pull' | 'remove',
    public readonly originalError?: Error
  ) {
    super(message, 'MODEL_ERROR', {
      model,
      operation,
      originalError: originalError?.message,
    });
  }
}

/**
 * Workspace boundary errors
 */
export class WorkspaceBoundaryError extends OllmError {
  constructor(
    message: string,
    public readonly attemptedPath: string,
    public readonly workspacePath: string,
    public readonly allowedPaths: string[]
  ) {
    super(message, 'WORKSPACE_BOUNDARY_ERROR', {
      attemptedPath,
      workspacePath,
      allowedPaths,
    });
  }
}

/**
 * Tool execution errors
 */
export class ToolExecutionError extends OllmError {
  constructor(
    message: string,
    public readonly toolName: string,
    public readonly args: Record<string, unknown>,
    public readonly originalError?: Error
  ) {
    super(message, 'TOOL_EXECUTION_ERROR', {
      toolName,
      args,
      originalError: originalError?.message,
    });
  }
}

/**
 * Validation errors
 */
export class ValidationError extends OllmError {
  constructor(
    message: string,
    public readonly field: string,
    public readonly value: unknown,
    public readonly constraint: string
  ) {
    super(message, 'VALIDATION_ERROR', {
      field,
      value,
      constraint,
    });
  }
}

/**
 * Timeout errors
 */
export class TimeoutError extends OllmError {
  constructor(
    message: string,
    public readonly operation: string,
    public readonly timeoutMs: number
  ) {
    super(message, 'TIMEOUT_ERROR', {
      operation,
      timeoutMs,
    });
  }
}

/**
 * Abort errors
 */
export class AbortError extends OllmError {
  constructor(
    message: string,
    public readonly operation: string
  ) {
    super(message, 'ABORT_ERROR', {
      operation,
    });
  }
}
```

## Error Handling Patterns

### Pattern 1: Try-Catch with Type-Safe Error Handling

```typescript
// GOOD: Type-safe error handling
try {
  await fs.writeFile(path, content);
} catch (error) {
  // Type guard for Error instances
  if (error instanceof Error) {
    throw new FileSystemError(
      `Failed to write file: ${error.message}`,
      'write',
      path,
      error
    );
  }
  
  // Handle non-Error throws
  throw new FileSystemError(
    `Failed to write file: ${String(error)}`,
    'write',
    path
  );
}

// BAD: Unsafe error handling
try {
  await fs.writeFile(path, content);
} catch (err) {
  console.error(err); // No context, no type safety
}
```

### Pattern 2: Node.js Error Code Handling

```typescript
// GOOD: Handle specific error codes
try {
  const content = await fs.readFile(path, 'utf-8');
  return content;
} catch (error) {
  const nodeError = error as NodeJS.ErrnoException;
  
  if (nodeError.code === 'ENOENT') {
    throw new FileSystemError(
      `File not found: ${path}`,
      'read',
      path,
      nodeError
    );
  }
  
  if (nodeError.code === 'EACCES') {
    throw new FileSystemError(
      `Permission denied: ${path}`,
      'read',
      path,
      nodeError
    );
  }
  
  // Generic error for other cases
  throw new FileSystemError(
    `Failed to read file: ${nodeError.message}`,
    'read',
    path,
    nodeError
  );
}

// BAD: Ignore error codes
try {
  const content = await fs.readFile(path, 'utf-8');
  return content;
} catch (error) {
  throw new Error(`Failed to read file: ${error}`);
}
```

### Pattern 3: Async Error Handling

```typescript
// GOOD: Proper async error handling
async function loadConfig(path: string): Promise<Config> {
  try {
    const content = await fs.readFile(path, 'utf-8');
    const config = JSON.parse(content);
    return config;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new ConfigError(
        `Invalid JSON in config file: ${error.message}`,
        path
      );
    }
    
    const nodeError = error as NodeJS.ErrnoException;
    if (nodeError.code === 'ENOENT') {
      throw new ConfigError(
        `Config file not found: ${path}`,
        path
      );
    }
    
    throw new ConfigError(
      `Failed to load config: ${nodeError.message}`,
      path
    );
  }
}

// BAD: Unhandled promise rejection
async function loadConfig(path: string): Promise<Config> {
  const content = await fs.readFile(path, 'utf-8'); // Can throw!
  const config = JSON.parse(content); // Can throw!
  return config;
}
```

### Pattern 4: Error Recovery

```typescript
// GOOD: Graceful error recovery
async function loadMemory(): Promise<Memory> {
  try {
    const content = await fs.readFile(this.memoryPath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    const nodeError = error as NodeJS.ErrnoException;
    
    // File doesn't exist - return default
    if (nodeError.code === 'ENOENT') {
      logger.info('Memory file not found, creating new memory');
      return this.createDefaultMemory();
    }
    
    // Invalid JSON - log and return default
    if (error instanceof SyntaxError) {
      logger.warn('Invalid memory file, resetting to default', {
        error: error.message,
      });
      return this.createDefaultMemory();
    }
    
    // Other errors - throw
    throw new FileSystemError(
      `Failed to load memory: ${nodeError.message}`,
      'read',
      this.memoryPath,
      nodeError
    );
  }
}

// BAD: No error recovery
async function loadMemory(): Promise<Memory> {
  const content = await fs.readFile(this.memoryPath, 'utf-8');
  return JSON.parse(content);
}
```

### Pattern 5: Error Aggregation

```typescript
// GOOD: Collect multiple errors
async function validateFiles(files: string[]): Promise<ValidationResult> {
  const errors: ValidationError[] = [];
  
  for (const file of files) {
    try {
      await this.validateFile(file);
    } catch (error) {
      if (error instanceof ValidationError) {
        errors.push(error);
      } else {
        errors.push(
          new ValidationError(
            `Unexpected error validating ${file}`,
            'file',
            file,
            'valid'
          )
        );
      }
    }
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
}

// BAD: Fail on first error
async function validateFiles(files: string[]): Promise<void> {
  for (const file of files) {
    await this.validateFile(file); // Throws on first error
  }
}
```

### Pattern 6: Timeout Handling

```typescript
// GOOD: Proper timeout handling
async function fetchWithTimeout(
  url: string,
  timeoutMs: number,
  signal?: AbortSignal
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  
  try {
    const response = await fetch(url, {
      signal: signal || controller.signal,
    });
    
    return response;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new TimeoutError(
        `Request timed out after ${timeoutMs}ms`,
        'fetch',
        timeoutMs
      );
    }
    
    throw new ProviderError(
      `Failed to fetch: ${error instanceof Error ? error.message : String(error)}`,
      'http',
      url,
      error instanceof Error ? error : undefined
    );
  } finally {
    clearTimeout(timeoutId);
  }
}

// BAD: No timeout handling
async function fetch(url: string): Promise<Response> {
  return await fetch(url); // Can hang forever
}
```

### Pattern 7: Abort Signal Handling

```typescript
// GOOD: Check abort signal
async function processLargeFile(
  path: string,
  signal?: AbortSignal
): Promise<void> {
  const chunks = await this.readChunks(path);
  
  for (const chunk of chunks) {
    // Check if aborted
    if (signal?.aborted) {
      throw new AbortError(
        'Operation cancelled by user',
        'processLargeFile'
      );
    }
    
    await this.processChunk(chunk);
  }
}

// BAD: Ignore abort signal
async function processLargeFile(path: string): Promise<void> {
  const chunks = await this.readChunks(path);
  
  for (const chunk of chunks) {
    await this.processChunk(chunk); // Can't be cancelled
  }
}
```

## Error Message Guidelines

### Message Format

```
[Context] Action failed: Reason

Examples:
- File write failed: Permission denied for /path/to/file
- Provider connection failed: Cannot connect to http://localhost:11434
- Model load failed: Model "llama3.2" not found
- Config validation failed: Invalid value for "timeout" (expected number, got string)
```

### Message Components

1. **Context**: What was being done (optional but helpful)
2. **Action**: What failed
3. **Reason**: Why it failed
4. **Suggestion**: How to fix it (in error context or separate field)

### Examples

```typescript
// GOOD: Clear, actionable error messages
throw new FileSystemError(
  'File write failed: Permission denied. Check file permissions and try again.',
  'write',
  path
);

throw new ProviderError(
  'Provider connection failed: Cannot connect to http://localhost:11434. ' +
  'Ensure Ollama is running with "ollama serve".',
  'ollama',
  'http://localhost:11434'
);

throw new ValidationError(
  'Config validation failed: "timeout" must be a positive number, got "30s"',
  'timeout',
  '30s',
  'positive number'
);

// BAD: Vague error messages
throw new Error('Failed');
throw new Error('Error in file');
throw new Error('Something went wrong');
```

## Logging Patterns

### Log Levels

- **error**: Unrecoverable errors that require user intervention
- **warn**: Recoverable errors or unexpected conditions
- **info**: Important state changes or operations
- **debug**: Detailed diagnostic information

### Logging with Errors

```typescript
// GOOD: Log with context
try {
  await this.saveFile(path, content);
} catch (error) {
  logger.error('Failed to save file', {
    path,
    operation: 'save',
    error: error instanceof Error ? error.message : String(error),
    stack: error instanceof Error ? error.stack : undefined,
  });
  
  throw new FileSystemError(
    `Failed to save file: ${error instanceof Error ? error.message : String(error)}`,
    'write',
    path,
    error instanceof Error ? error : undefined
  );
}

// BAD: Log without context
try {
  await this.saveFile(path, content);
} catch (error) {
  console.error(error); // No context
  throw error;
}
```

## Testing Error Handling

### Unit Tests

```typescript
describe('FileSystemError', () => {
  it('should include operation and path in context', () => {
    const error = new FileSystemError(
      'Failed to write file',
      'write',
      '/path/to/file'
    );
    
    expect(error.message).toBe('Failed to write file');
    expect(error.code).toBe('FILE_SYSTEM_ERROR');
    expect(error.operation).toBe('write');
    expect(error.path).toBe('/path/to/file');
    expect(error.context).toEqual({
      operation: 'write',
      path: '/path/to/file',
      originalError: undefined,
    });
  });
  
  it('should preserve original error', () => {
    const originalError = new Error('ENOENT: no such file');
    const error = new FileSystemError(
      'Failed to read file',
      'read',
      '/path/to/file',
      originalError
    );
    
    expect(error.originalError).toBe(originalError);
    expect(error.context?.originalError).toBe('ENOENT: no such file');
  });
});
```

### Integration Tests

```typescript
describe('loadConfig', () => {
  it('should throw ConfigError when file not found', async () => {
    await expect(loadConfig('/nonexistent/config.yaml'))
      .rejects
      .toThrow(ConfigError);
    
    await expect(loadConfig('/nonexistent/config.yaml'))
      .rejects
      .toThrow('Config file not found');
  });
  
  it('should throw ConfigError when JSON is invalid', async () => {
    await fs.writeFile('/tmp/invalid.json', '{ invalid json }');
    
    await expect(loadConfig('/tmp/invalid.json'))
      .rejects
      .toThrow(ConfigError);
    
    await expect(loadConfig('/tmp/invalid.json'))
      .rejects
      .toThrow('Invalid JSON');
  });
});
```

## Migration Checklist

- [ ] Create custom error classes in `packages/core/src/errors/`
- [ ] Update all try-catch blocks to use custom errors
- [ ] Add type guards for error handling
- [ ] Handle Node.js error codes explicitly
- [ ] Add error recovery where appropriate
- [ ] Improve error messages with context
- [ ] Add logging with structured context
- [ ] Update tests to verify error handling
- [ ] Document error handling patterns in README

## Common Error Codes

| Code | Description | Example |
|------|-------------|---------|
| `FILE_SYSTEM_ERROR` | File system operation failed | Read, write, delete, stat |
| `CONFIG_ERROR` | Configuration error | Invalid config, missing file |
| `PROVIDER_ERROR` | Provider connection error | Cannot connect, timeout |
| `MODEL_ERROR` | Model operation error | Load, list, pull, remove |
| `WORKSPACE_BOUNDARY_ERROR` | Path outside workspace | Access denied |
| `TOOL_EXECUTION_ERROR` | Tool execution failed | Invalid args, runtime error |
| `VALIDATION_ERROR` | Validation failed | Invalid input, constraint violation |
| `TIMEOUT_ERROR` | Operation timed out | Request timeout, operation timeout |
| `ABORT_ERROR` | Operation aborted | User cancelled, signal aborted |

## References

- TypeScript Error Handling: https://www.typescriptlang.org/docs/handbook/2/narrowing.html#using-type-predicates
- Node.js Error Codes: https://nodejs.org/api/errors.html#nodejs-error-codes
- Error Handling Best Practices: https://www.joyent.com/node-js/production/design/errors

