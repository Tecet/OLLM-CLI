# Hooks Index Export Fix

## Issue
After commit d42c0aa (UI components cleanup), the application started showing the error:
```
Rendered more hooks than during the previous render.
```

## Root Cause
In commit d42c0aa, the `packages/cli/src/ui/hooks/index.ts` file was completely rewritten to export only the new shared hooks:
- `useTabNavigation`
- `useFocusedBorder` / `useFocusedState`
- `useScrollWindow`
- `useConfirmation`

However, the file previously exported these hooks which were **removed**:
- `useGlobalKeyboardShortcuts`
- `useTabEscapeHandler`
- `useMouse` / `MouseProvider`

Even though these hooks weren't being imported from the index file directly in the codebase, removing them from the index caused module resolution issues that led to the hooks error.

## Solution
Restored the missing exports to `packages/cli/src/ui/hooks/index.ts`:

```typescript
// Navigation hooks (existing)
export { useGlobalKeyboardShortcuts } from './useGlobalKeyboardShortcuts.js';
export { useTabEscapeHandler } from './useTabEscapeHandler.js';
export { useMouse, MouseProvider } from './useMouse.js';

// New shared hooks
export { useTabNavigation } from './useTabNavigation.js';
// ... etc
```

## Testing
- Build succeeded without errors
- Application should now run without the hooks error

## Next Steps
1. Test the application to confirm the fix
2. Re-apply the performance optimizations from commit 15f2ada
3. Commit both fixes together

## Lessons Learned
- When refactoring index files, always preserve existing exports unless you're certain they're not needed
- Module resolution issues can manifest as React hooks errors
- Always test after modifying barrel exports (index.ts files)
