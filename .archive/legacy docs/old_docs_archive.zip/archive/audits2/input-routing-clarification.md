# Input Routing - Clarification & Simplified Approach

**Date:** January 24, 2026  
**Status:** ✅ Clarified

## Key Principle: Preserve All Existing Functionality

**We are NOT changing how LLM chat works!**

We are ONLY adding the ability to switch where input goes.

---

## Current State (LLM Mode)

### Everything That Works Now
✅ Model selection on startup  
✅ `/model` command opens model picker  
✅ Up/Down arrows navigate model list  
✅ Enter selects model  
✅ `/help` shows commands  
✅ All slash commands work  
✅ Menu system works  
✅ History navigation (Up arrow for previous messages)  
✅ Multi-line input (Shift+Enter)  
✅ Streaming responses  
✅ Tool confirmations  

**All of this stays exactly the same!**

---

## What We're Adding

### 1. Visual Indicator
```
[●LLM | E | T1 | T2]  ← Shows where input goes
```

### 2. Mode Switching
```
Ctrl+Left/Right: Switch between LLM, Editor, Terminal1, Terminal2
```

### 3. Conditional Input Routing
```typescript
if (activeDestination === 'llm') {
  // Use EXISTING input handling
  // All current features work
  // Model selection, menus, commands, etc.
} else if (activeDestination === 'terminal1' || activeDestination === 'terminal2') {
  // NEW: Raw terminal input
  // Character-by-character to PTY
} else if (activeDestination === 'editor') {
  // Disabled (mockup)
}
```

---

## Implementation Strategy

### Step 1: Wrap Existing Logic
```typescript
// In ChatInputArea.tsx

useInput((input, key) => {
  const { activeDestination } = useInputRouting();
  
  // NEW: Check destination first
  if (activeDestination === 'terminal1' || activeDestination === 'terminal2') {
    // Route to terminal (raw mode)
    handleTerminalInput(input, key, activeDestination);
    return; // Exit early
  }
  
  // EXISTING: All current LLM input handling
  // This code stays exactly the same!
  
  // Model selection
  if (chatState.inputMode === 'menu') {
    // ... existing menu navigation
  }
  
  // Slash commands
  if (input.startsWith('/')) {
    // ... existing command handling
  }
  
  // Normal chat input
  // ... existing chat logic
});
```

### Step 2: Add Terminal Handler (New)
```typescript
const handleTerminalInput = (input: string, key: Key, dest: 'terminal1' | 'terminal2') => {
  const terminal = dest === 'terminal1' ? terminal1 : terminal2;
  
  // Raw mode: send immediately
  if (key.return) {
    terminal.sendRawInput('\r');
  } else if (key.backspace) {
    terminal.sendRawInput('\x7f');
  } else if (input) {
    terminal.sendRawInput(input);
  }
};
```

---

## User Experience

### Scenario 1: Normal LLM Chat (Default)
```
Indicator: [●LLM | E | T1 | T2]
User types: /model
Result: Model picker opens (existing behavior)
User presses: Up/Down
Result: Navigate models (existing behavior)
User presses: Enter
Result: Select model (existing behavior)
```

**Nothing changes!**

### Scenario 2: Switch to Terminal
```
User presses: Ctrl+Right
Indicator: [LLM | E | ●T1 | T2]
User types: gemini
Result: Characters go to terminal immediately
User presses: Enter
Result: \r sent to terminal, Gemini starts
User types: /model
Result: Goes to Gemini CLI (not our model picker!)
```

**Terminal gets raw input**

### Scenario 3: Switch Back to LLM
```
User presses: Ctrl+Left twice
Indicator: [●LLM | E | T1 | T2]
User types: /model
Result: Our model picker opens again
```

**Back to normal LLM mode**

---

## Code Changes Required

### Minimal Changes

**File 1: Create InputRoutingContext**
- New file
- Manages `activeDestination` state
- Provides cycling function

**File 2: Create InputRoutingIndicator**
- New file
- Displays `[LLM | E | T1 | T2]`
- Shows active destination

**File 3: Modify ChatInputArea**
- Add ONE check at the start of `useInput`
- If terminal mode, route to terminal
- Otherwise, use ALL existing logic unchanged

**File 4: Update TerminalContext**
- Add `sendRawInput(char)` method
- Expose in context

**That's it!**

---

## What Stays The Same

### LLM Chat Features (100% Preserved)
- ✅ Model selection UI
- ✅ `/model` command
- ✅ All slash commands
- ✅ Menu navigation
- ✅ History navigation
- ✅ Multi-line input
- ✅ Streaming responses
- ✅ Tool confirmations
- ✅ Input validation
- ✅ Error handling

### Input Box Behavior (When in LLM Mode)
- ✅ Line buffering
- ✅ Edit before send
- ✅ Up arrow for history
- ✅ Shift+Enter for newline
- ✅ Tab completion (if implemented)
- ✅ All existing keyboard shortcuts

---

## What Changes

### Only When Switched to Terminal
- ❌ No line buffering
- ❌ No edit before send
- ❌ No history navigation
- ❌ No slash commands
- ✅ Raw character input
- ✅ Immediate PTY streaming

### Visual Changes
- ➕ Input routing indicator added
- ➕ Ctrl+Left/Right switches mode
- ➕ Status message shows mode

---

## Implementation Checklist

### Phase 1: Add Mode Switching (No Breaking Changes)
- [ ] Create InputRoutingContext
- [ ] Create InputRoutingIndicator
- [ ] Add indicator to UI
- [ ] Add Ctrl+Left/Right handling
- [ ] Test: Switching modes works
- [ ] Test: LLM mode still works exactly as before

### Phase 2: Add Terminal Raw Input
- [ ] Add terminal input handler
- [ ] Add early return in useInput when terminal mode
- [ ] Test: Terminal receives raw input
- [ ] Test: LLM mode still unaffected

### Phase 3: Polish
- [ ] Add visual feedback
- [ ] Update status messages
- [ ] Add keyboard shortcuts
- [ ] Test all scenarios

---

## Testing Strategy

### Test 1: LLM Mode Unchanged
```
1. Start app (default: LLM mode)
2. Type /model
3. Verify: Model picker opens
4. Press Up/Down
5. Verify: Navigate models
6. Press Enter
7. Verify: Model selected
8. Type message
9. Verify: Sends to LLM
```

**Expected: Everything works as before**

### Test 2: Terminal Mode Works
```
1. Press Ctrl+Right (switch to T1)
2. Verify: Indicator shows [LLM | E | ●T1 | T2]
3. Type gemini
4. Verify: Characters appear in terminal
5. Press Enter
6. Verify: Gemini starts
7. Type /model
8. Verify: Goes to Gemini CLI (not our picker)
```

**Expected: Raw input to terminal**

### Test 3: Switch Back
```
1. Press Ctrl+Left twice (back to LLM)
2. Verify: Indicator shows [●LLM | E | T1 | T2]
3. Type /model
4. Verify: Our model picker opens
```

**Expected: LLM mode restored**

---

## Risk Mitigation

### Risk: Breaking Existing LLM Features
**Mitigation:** 
- Add terminal check BEFORE existing logic
- Early return if terminal mode
- Don't modify existing LLM code

### Risk: Input Conflicts
**Mitigation:**
- Ctrl+Left/Right only in input box
- Clear visual indicator
- Status message shows mode

### Risk: User Confusion
**Mitigation:**
- Default to LLM mode
- Clear indicator always visible
- Status message describes mode

---

## Summary

**What we're doing:**
- Adding a mode switcher
- When in LLM mode: Everything works as now
- When in Terminal mode: Raw input to PTY

**What we're NOT doing:**
- Changing LLM chat behavior
- Removing any features
- Breaking existing functionality

**The key:**
```typescript
if (terminalMode) {
  // NEW: Raw input
} else {
  // EXISTING: All current features
}
```

Simple, clean, no breaking changes!
