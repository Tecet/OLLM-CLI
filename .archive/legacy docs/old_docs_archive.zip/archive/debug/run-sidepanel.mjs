import process from 'process';
import { render } from '../../packages/cli/src/test/ink-testing.js';
import { SidePanel } from '../../packages/cli/src/ui/components/layout/SidePanel.js';
import { UIProvider } from '../../packages/cli/src/features/context/UIContext.js';
import { FocusProvider } from '../../packages/cli/src/features/context/FocusContext.js';

(async function run(){
  try{
    const { lastFrame } = render(
      UIProvider ? (
        <UIProvider>
          <FocusProvider>
            <SidePanel
              visible={true}
              connection={{ status: 'connected', provider: 'ollama' }}
              model="test-model"
              gpu={{ available: false }}
              theme={{ text: { primary: '#d4d4d4' }, bg: { primary: '#1e1e1e' }, border: { primary: '#3e3e42' } }}
            />
          </FocusProvider>
        </UIProvider>
      ) : (
        <SidePanel
          visible={true}
          connection={{ status: 'connected', provider: 'ollama' }}
          model="test-model"
          gpu={{ available: false }}
          theme={{ text: { primary: '#d4d4d4' }, bg: { primary: '#1e1e1e' }, border: { primary: '#3e3e42' } }}
        />
      )
    );

    console.log('=== SIDE PANEL RAW OUTPUT START ===');
    console.log(lastFrame());
    console.log('=== SIDE PANEL RAW OUTPUT END ===');
  }catch(e){
    console.error('Run script error:');
    console.error(e && e.stack ? e.stack : e);
    process.exitCode = 1;
  }
})();
