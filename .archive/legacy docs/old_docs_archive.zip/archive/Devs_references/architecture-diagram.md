# Dynamic Prompt System - Architecture Diagram

## System Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         OLLM CLI - Dynamic Prompt System                     │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              USER INTERFACE                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │ Chat Input   │  │ Right Panel  │  │ Mode Display │  │ Confidence   │   │
│  │              │  │              │  │              │  │ Bars         │   │
│  │ /mode debug  │  │ 🐛 Debugger  │  │ Icon + Color │  │ ████████░░   │   │
│  │ /workflow    │  │ Persona      │  │ Duration     │  │ 0.85         │   │
│  └──────────────┘  │ Allowed Tools│  │ Suggestions  │  └──────────────┘   │
│                    └──────────────┘  └──────────────┘                       │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          MODE MANAGEMENT LAYER                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                      Prompt Mode Manager                            │    │
│  │                  (Central Orchestration)                            │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │  • Current Mode Tracking                                            │    │
│  │  • Mode Transition Logic                                            │    │
│  │  • Prompt Building                                                  │    │
│  │  • Tool Filtering                                                   │    │
│  │  • Event Emission                                                   │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Context     │  │  Workflow    │  │  Focus Mode  │  │  Hybrid Mode │   │
│  │  Analyzer    │  │  Manager     │  │  Manager     │  │  Manager     │   │
│  │              │  │              │  │              │  │              │   │
│  │ • Keywords   │  │ • Sequences  │  │ • Lock Mode  │  │ • Combine    │   │
│  │ • Confidence │  │ • Progress   │  │ • Timer      │  │ • Merge      │   │
│  │ • Suggest    │  │ • Steps      │  │ • Prevent    │  │ • Tools      │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Snapshot    │  │  Metrics     │  │  Mode Memory │  │  Transition  │   │
│  │  Manager     │  │  Tracker     │  │  (Project)   │  │  Suggester   │   │
│  │              │  │              │  │              │  │              │   │
│  │ • JSON       │  │ • Usage      │  │ • Prefs      │  │ • Reasons    │   │
│  │ • XML        │  │ • Stats      │  │ • Thresholds │  │ • Auto/Ask   │   │
│  │ • Findings   │  │ • Display    │  │ • Disabled   │  │ • Confidence │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              10 OPERATIONAL MODES                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         CORE MODES                                   │   │
│  ├─────────────────────────────────────────────────────────────────────┤   │
│  │  💬 Assistant    │ General conversation, no tools                    │   │
│  │  📋 Planning     │ Research & design, read-only + docs writing       │   │
│  │  👨‍💻 Developer    │ Full implementation, all tools                   │   │
│  │  🔧 Tool         │ Enhanced tool usage with guidance                 │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      SPECIALIZED MODES                               │   │
│  ├─────────────────────────────────────────────────────────────────────┤   │
│  │  🐛 Debugger     │ Systematic debugging, error analysis              │   │
│  │  🔒 Security     │ Security audits, vulnerability detection          │   │
│  │  👀 Reviewer     │ Code review, quality assessment                   │   │
│  │  ⚡ Performance  │ Performance analysis, optimization                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       EXTENDED MODES                                 │   │
│  ├─────────────────────────────────────────────────────────────────────┤   │
│  │  ⚡🔬 Prototype   │ Quick experiments, proof-of-concepts              │   │
│  │  👨‍🏫 Teacher     │ Education, concept explanation                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          INTEGRATION LAYER                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  Context     │  │  HotSwap     │  │  Compression │  │  Tool        │   │
│  │  Manager     │  │  Service     │  │  Service     │  │  Registry    │   │
│  │              │  │              │  │              │  │              │   │
│  │ • Messages   │  │ • Skills     │  │ • XML        │  │ • Filter     │   │
│  │ • System     │  │ • Snapshot   │  │ • Snapshot   │  │ • Execute    │   │
│  │ • Prompt     │  │ • Reseed     │  │ • Preserve   │  │ • Policy     │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          RAG INTEGRATION (FUTURE)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                         LanceDB Vector Store                        │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │  • Codebase Index                                                   │    │
│  │  • Documentation Index                                              │    │
│  │  • Conversation Memory                                              │    │
│  │  • Mode-Specific Knowledge Bases:                                  │    │
│  │    - Debugger (bugs, solutions)                                     │    │
│  │    - Security (vulnerabilities, fixes)                              │    │
│  │    - Performance (optimizations)                                    │    │
│  │    - Planning (design patterns)                                     │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │  Embedding   │  │  RAG         │  │  Context     │                      │
│  │  Service     │  │  Integration │  │  Injection   │                      │
│  │              │  │              │  │              │                      │
│  │ • Local      │  │ • Search     │  │ • On Entry   │                      │
│  │ • 384-dim    │  │ • Rank       │  │ • On Exit    │                      │
│  │ • Batch      │  │ • Index      │  │ • Findings   │                      │
│  └──────────────┘  └──────────────┘  └──────────────┘                      │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Mode Transition Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MODE TRANSITION FLOW                                 │
└─────────────────────────────────────────────────────────────────────────────┘

User Message
     │
     ▼
┌─────────────────┐
│ Context Analyzer│
│ • Detect        │
│   Keywords      │
│ • Calculate     │
│   Confidence    │
│ • Recommend     │
│   Mode          │
└────────┬────────┘
         │
         ▼
┌─────────────────┐      ┌──────────────────┐
│ Should Switch?  │─NO──▶│ Continue Current │
│ • Confidence    │      │ Mode             │
│ • Hysteresis    │      └──────────────────┘
│ • Cooldown      │
└────────┬────────┘
         │ YES
         ▼
┌─────────────────┐
│ Create Snapshot │
│ • JSON (quick)  │
│ • Recent msgs   │
│ • Active state  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Switch Mode     │
│ • Update state  │
│ • Emit event    │
│ • Log history   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Build Prompt    │
│ • Mode template │
│ • Skills        │
│ • Tools         │
│ • Workspace     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Filter Tools    │
│ • Check allowed │
│ • Check denied  │
│ • Validate      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Update UI       │
│ • Mode display  │
│ • Confidence    │
│ • Tools list    │
│ • Animation     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Continue Chat   │
└─────────────────┘
```

## Workflow Execution Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         WORKFLOW EXECUTION FLOW                              │
└─────────────────────────────────────────────────────────────────────────────┘

User: /workflow feature_development
     │
     ▼
┌─────────────────┐
│ Load Workflow   │
│ • Steps         │
│ • Modes         │
│ • Criteria      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Step 1:         │
│ Planning Mode   │
│ • Research      │
│ • Design        │
│ • Write docs    │
└────────┬────────┘
         │
         ▼ (Exit criteria met)
┌─────────────────┐
│ Step 2:         │
│ Developer Mode  │
│ • Implement     │
│ • Test          │
│ • Commit        │
└────────┬────────┘
         │
         ▼ (Exit criteria met)
┌─────────────────┐
│ Step 3:         │
│ Reviewer Mode   │
│ • Review code   │
│ • Find issues   │
│ • Suggest fixes │
└────────┬────────┘
         │
         ▼ (Exit criteria met)
┌─────────────────┐
│ Step 4:         │
│ Developer Mode  │
│ • Apply fixes   │
│ • Re-test       │
│ • Final commit  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Workflow        │
│ Complete!       │
└─────────────────┘
```

## RAG Integration Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         RAG INTEGRATION FLOW                                 │
└─────────────────────────────────────────────────────────────────────────────┘

Mode Entry (e.g., Debugger)
     │
     ▼
┌─────────────────┐
│ Extract Query   │
│ • Error message │
│ • Stack trace   │
│ • Context       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Generate        │
│ Embedding       │
│ • 384-dim       │
│ • Local model   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Search LanceDB  │
│ • Debugger KB   │
│ • Vector search │
│ • Top 5 results │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Rank Results    │
│ • Similarity    │
│ • Relevance     │
│ • Recency       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Inject Context  │
│ • Add to prompt │
│ • Format nicely │
│ • Cite sources  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ LLM Processing  │
│ • With context  │
│ • Better answer │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Mode Exit       │
│ • Extract       │
│   findings      │
│ • Generate      │
│   embedding     │
│ • Index in KB   │
└─────────────────┘
```

## Storage Structure

```
~/.ollm/
├── mode-preferences.json          # Project mode preferences
├── snapshots/
│   └── session-{id}/
│       ├── transition-*.json      # Lightweight snapshots
│       └── full-*.xml             # Full snapshots
├── metrics/
│   └── mode-metrics.json          # Mode usage metrics
└── rag/
    ├── codebase.lance/            # Codebase index
    ├── docs.lance/                # Documentation index
    ├── memory.lance/              # Conversation memory
    └── knowledge/
        ├── debugger.lance/        # Debugger knowledge
        ├── security.lance/        # Security knowledge
        ├── performance.lance/     # Performance knowledge
        └── planning.lance/        # Planning knowledge
```

---

**Architecture Complete:** ✅  
**All Components Defined:** ✅  
**Integration Points Clear:** ✅
