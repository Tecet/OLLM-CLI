# Code Editor Audit Summary

**Date**: January 22, 2026  
**Status**: ✅ Complete

## Audit Findings

### What Exists

#### ✅ SyntaxViewer (Read-only Viewer)
- **Location**: `packages/cli/src/ui/components/file-explorer/SyntaxViewer.tsx`
- **Status**: Fully implemented (Task 15 in File Explorer spec)
- **Features**:
  - Syntax highlighting using `shiki`
  - 50+ programming languages supported
  - Line numbers
  - Scrolling
  - Read-only viewing
- **Usage**: Press 'v' in File Explorer to view files

#### ✅ EditorIntegration (External Editors)
- **Location**: `packages/cli/src/ui/components/file-explorer/EditorIntegration.ts`
- **Status**: Fully implemented (Task 16 in File Explorer spec)
- **Features**:
  - Spawns $EDITOR (nano, vim, notepad, etc.)
  - Waits for editor to close
  - Reloads file after editing
  - Fallback to platform defaults
- **Usage**: Press 'e' in File Explorer to edit in external editor

#### ✅ Window System (3 Windows)
- **Location**: `packages/cli/src/ui/contexts/WindowContext.tsx`
- **Windows**: `'chat' | 'terminal' | 'editor'`
- **Status**: Editor window type defined but not implemented
- **Current State**: Shows "Editor - Coming Soon" placeholder

### What's Missing

#### ❌ Built-in Code Editor
- No in-terminal editing capability
- Cannot make quick edits without leaving OLLM CLI
- Editor window is just a placeholder

#### ❌ Prettier Integration
- Mentioned in ContextAnalyzer.ts but not integrated
- No auto-formatting on save
- No format command

## Recommendations

### Primary Recommendation: Build Lightweight Terminal Editor

**Why**:
1. Quick edits without context switching
2. Stays within OLLM CLI workflow
3. Integrates with File Explorer and Focus System
4. Can leverage existing SyntaxViewer code

**What to Build**:
- Line-based text editor using Ink components
- Basic operations: insert, delete, save, undo
- Syntax highlighting (reuse SyntaxViewer's shiki)
- Line numbers and cursor navigation
- File dirty state tracking
- Integration with File Explorer

**Timeline**: 7-10 days
- MVP (basic editing): 3-4 days
- Enhanced (undo/redo, find): 2-3 days
- Polish (syntax highlighting, prettier): 2-3 days

### Alternative Options

**Option B**: Embed existing terminal editor (nano, micro, helix)
- Pros: Full-featured, proven
- Cons: External dependency, integration challenges

**Option C**: Enhance SyntaxViewer with edit mode
- Pros: Reuses existing code
- Cons: Limited capabilities, complicates viewer

## File Explorer Spec Status

### Viewer Tasks (Completed)
- ✅ Task 15: SyntaxViewer with syntax highlighting
- ✅ Task 16: EditorIntegration for external editors
- ✅ Task 17: Keyboard shortcuts for viewer and editor

### What's in the Spec
The File Explorer spec (`.kiro/specs/v0.3.0 File Explorer/`) includes:
- **Requirement 5**: Editor Integration
  - 5.1: Spawn external editor
  - 5.2: Fallback to nano/notepad
  - 5.3: Reload after editing
  - 5.4: Syntax-highlighted viewer
  - 5.5: Support common languages

All requirements are **fully implemented** ✅

### What's NOT in the Spec
- Built-in terminal-based editor
- Prettier integration
- Auto-formatting
- Multi-file editing

## Prettier Status

### Current State
- **Mentioned**: In `packages/core/src/prompts/ContextAnalyzer.ts` as a keyword for "reviewer" mode
- **Not Integrated**: No actual prettier integration exists
- **Not in Spec**: Not mentioned in File Explorer requirements or design

### Potential Integration Points
1. **Format on Save**: Auto-format when saving in built-in editor
2. **Manual Command**: Ctrl+Shift+F to format current file
3. **Pre-commit Hook**: Format files before git commit
4. **LLM Tool**: Add prettier as a tool the LLM can invoke

## Next Steps

### If Building Code Editor

1. **Create New Spec**
   - Directory: `.kiro/specs/v0.4.0 Code Editor/`
   - Files: `requirements.md`, `design.md`, `tasks.md`

2. **Define Requirements**
   - User stories for editing workflows
   - Acceptance criteria for each feature
   - Integration points with File Explorer

3. **Design Components**
   - EditorBuffer (text management)
   - EditorCursor (cursor movement)
   - EditorHistory (undo/redo)
   - CodeEditor (main component)

4. **Implement MVP**
   - Basic text editing
   - Save functionality
   - Cursor navigation
   - Line numbers

5. **Enhance Incrementally**
   - Undo/redo
   - Find/replace
   - Syntax highlighting
   - Prettier integration

### If Enhancing Existing

1. **Add Edit Mode to SyntaxViewer**
   - Toggle between view and edit modes
   - Basic text insertion/deletion
   - Save changes

2. **Integrate Prettier**
   - Add prettier dependency
   - Implement format-on-save
   - Add manual format command

## Documentation Created

1. **CODE-EDITOR-PROPOSAL.md** - Comprehensive proposal with:
   - Current state audit
   - Three implementation options
   - Recommended approach (Lightweight Terminal Editor)
   - Architecture and component design
   - Implementation plan with phases
   - Integration points
   - Testing strategy
   - Timeline and dependencies

2. **CODE-EDITOR-AUDIT-SUMMARY.md** (this file) - Quick reference:
   - What exists
   - What's missing
   - Recommendations
   - Next steps

## Key Insights

1. **Viewer is Complete**: SyntaxViewer provides excellent read-only viewing
2. **External Editor Works**: EditorIntegration handles heavy editing well
3. **Gap Identified**: No quick-edit capability for small changes
4. **Window Ready**: Editor window type exists, just needs implementation
5. **Prettier Opportunity**: Not integrated anywhere, good enhancement opportunity

## Conclusion

The File Explorer has excellent viewing and external editing capabilities, but lacks a built-in editor for quick edits. Building a lightweight terminal editor would fill this gap and provide a seamless editing experience within OLLM CLI.

**Recommendation**: Proceed with building the Lightweight Terminal Editor as outlined in CODE-EDITOR-PROPOSAL.md.
