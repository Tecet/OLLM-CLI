# Context Management System - Documentation

**Version:** 2.0  
**Date:** January 20, 2026  
**Status:** Complete

---

## Overview

The Adaptive Context Compression System is an intelligent context management solution that dynamically adjusts compression strategies, system prompts, and preservation rules based on:

1. **Context Window Size** - Automatically detects and adapts to 5 tiers (2-4K, 4-8K, 8-32K, 32-64K, 64K+)
2. **Operational Mode** - Applies mode-specific preservation (Developer, Planning, Assistant, Debugger)
3. **Hardware Capability** - Locks prompt tier to hardware capacity when auto-sizing enabled
4. **85% Context Cap** - Sends 85% of user's selected context to Ollama for natural stops ⭐ NEW

The system prevents concept drift in long conversations while optimizing token usage across different context sizes, from small 2K contexts to massive 128K+ contexts. The 85% cap ensures Ollama stops naturally before overflow, triggering compression at predictable points.

---

## Core Documentation

### 📘 Main Architecture

**[Context-Architecture.md](./Context-Architecture.md)** - Complete system design
- 5-tier adaptive compression architecture (2-4K, 4-8K, 8-32K, 32-64K, 64K+)
- Mode-specific profiles with never-compressed sections
- LLM erosion prevention strategies
- Compression strategies per tier
- Token budget examples for all tiers
- Migration path from Phase 1 to Phase 2

**Key Sections:**
- Context Size Tiers - Detailed breakdown of all 5 tiers
- Mode-Specific Profiles - Developer, Planning, Assistant, Debugger
- Compression Strategies - Rollover, Smart, Progressive, Structured
- Implementation Details - Phase 1 (complete), Phase 2 (next), Phase 3 (future)

---

### 🎯 Adaptive System Prompts

**[Adaptive_system_Prompts.md](./Adaptive_system_Prompts.md)** - System prompts that scale with context
- 20 prompt templates (5 tiers × 4 modes)
- Token budgets: ~200, ~500, ~1000, ~1500, ~1500 tokens
- Complete prompt examples for all tiers and modes
- Quality scaling from essential to expert-level
- Automatic prompt selection and switching

**Key Sections:**
- Token Budget Strategy - Revised allocations per tier
- Prompt Examples - Complete examples for Tier 1-5
- Benefits - Quality scaling, token efficiency, automatic adaptation
- Implementation Notes - Prompt storage, selection logic, automatic updates

---

### 🔀 Prompt Routing & Hardware-Aware Selection

**[Prompts-Routing.md](./Prompts-Routing.md)** - Visual routing and switching logic
- Prompt selection matrix (5 tiers × 4 modes = 20 templates)
- Hardware-aware prompt selection ⭐ NEW
- Automatic tier and mode switching
- Visual mermaid diagrams for all flows
- UI integration examples

**Key Sections:**
- Prompt Selection Matrix - How prompts are chosen
- Hardware-Aware Prompt Selection - Locks prompt tier to hardware capability
- Automatic Tier Switching - Model changes trigger prompt updates
- Automatic Mode Switching - User mode changes update prompts
- Token Budget Flow - How budgets scale with tiers

**Hardware-Aware Feature:**
When auto-sizing is enabled, the system locks the prompt tier to hardware capability (detected at startup) to prevent mid-conversation prompt changes that could confuse the LLM. This ensures stable, consistent behavior throughout the session.

---

### 📊 Checkpoint Flow Diagrams

**[Checkpoint_Flow-Diagram.md](./Checkpoint_Flow-Diagram.md)** - Visual flow diagrams
- System overview with tier detection
- Tier-specific compression flows
- Checkpoint lifecycle and aging
- Token budget over time
- Comparison: old vs new approach

**Key Sections:**
- Tier-Specific Compression - Visual flow for each tier
- Checkpoint Lifecycle - How checkpoints age and compress
- Token Budget Over Time - Usage across multiple compressions
- Decision Flow - When to compress checkpoints
- Event Timeline - Sequence of compression events

---

## Quick Reference

### Context Size Tiers

| Tier | Context Size | Strategy | Checkpoints | System Prompt | Target Users |
|------|--------------|----------|-------------|---------------|--------------|
| **1** | 2-4K | Rollover | 0 | ~200 tokens | Casual |
| **2** | 4-8K | Smart | 1 | ~500 tokens | Entry-level |
| **3** ⭐ | 8-32K | Progressive | 5 | ~1000 tokens | **90% of users** |
| **4** | 32-64K | Structured | 10 | ~1500 tokens | Premium |
| **5** | 64K+ | Structured | 15 | ~1500 tokens | Enterprise |

⭐ = Primary development focus

### Mode Profiles

| Mode | Focus | Never Compress | System Prompt Focus |
|------|-------|----------------|---------------------|
| **Developer** | Code quality | Architecture, APIs, Data models | SOLID principles, patterns, testing |
| **Planning** | Task organization | Goals, Requirements, Constraints | Task breakdown, dependencies, estimation |
| **Assistant** | Conversation | User preferences, Context | Clear communication, examples |
| **Debugger** | Error diagnosis | Stack traces, Reproduction steps | Root cause analysis, systematic debugging |

### Token Budget Breakdown (Tier 3 - 32K Context)

```
Total Context: 32,000 tokens

Breakdown:
├─ System Prompt:     1,000 tokens (3.1%)  ← Adaptive (Tier 3)
├─ Task Definition:     400 tokens (1.2%)  ← Never-compressed
├─ Architecture:      1,200 tokens (3.8%)  ← Never-compressed (6 decisions)
├─ Checkpoints:       2,100 tokens (6.6%)  ← Compressed (3 levels)
│  ├─ Checkpoint 1:     300 tokens         ← Compact (ancient)
│  ├─ Checkpoint 2:     600 tokens         ← Moderate (old)
│  └─ Checkpoint 3:   1,200 tokens         ← Detailed (recent)
└─ Work Space:       27,300 tokens (85.3%) ← Active work

Compression Trigger: 70% (22,400 tokens)
Never Lost: Task definition + 6 architecture decisions
```

---

## Hardware-Aware Prompt Selection ⭐

### The Problem

When auto-context sizing is enabled, the context window dynamically adjusts based on available VRAM. If we change the system prompt every time the context size changes, it can confuse the LLM mid-conversation.

### The Solution

Lock the prompt tier to **hardware capability** (detected at startup) when auto-sizing is enabled.

### How It Works

1. **At Startup:**
   - VRAM Monitor detects available VRAM
   - Context Pool calculates maximum possible context size
   - Accounts for: model size in VRAM, KV cache, safety buffer
   - Maps to Hardware Capability Tier (e.g., Tier 3 for 32K max)

2. **During Session:**
   - **Auto-sizing enabled:** Prompt tier LOCKED to hardware capability
   - **Manual sizing:** Prompt tier uses higher of hardware or actual
   - Context window can resize freely without changing prompts

3. **Benefits:**
   - ✅ Stable prompts throughout conversation
   - ✅ No mid-conversation LLM confusion
   - ✅ Optimal quality for hardware capability
   - ✅ Fully automatic, no user configuration

### Example Scenario

```
Hardware: 24GB VRAM, 13B model
├─ Hardware Capability: 32K context possible
├─ Hardware Capability Tier: Tier 3 (8-32K)
└─ Effective Prompt Tier: Tier 3 (LOCKED)

User Selection: 16K context
├─ Actual Context Tier: Tier 3 (8-32K)
└─ Context Window: 16K tokens

During Conversation:
├─ Auto-sizing adjusts: 16K → 20K → 18K → 22K
├─ Actual Context Tier: Stays Tier 3
├─ Effective Prompt Tier: Stays Tier 3 (LOCKED)
└─ System Prompt: NEVER CHANGES ✅

Result: Stable, consistent LLM behavior
```

---

## Key Features

### 1. Adaptive Compression ✅

- **Tier 1 (2-4K):** Rollover with snapshots - no checkpoints
- **Tier 2 (4-8K):** Smart compression - 1 checkpoint
- **Tier 3 (8-32K):** Progressive checkpoints - 5 checkpoints ⭐
- **Tier 4 (32-64K):** Structured checkpoints - 10 checkpoints
- **Tier 5 (64K+):** Pristine checkpoints - 15 checkpoints

### 2. Mode-Specific Preservation ✅

- **Developer Mode:** Preserves architecture, APIs, data models
- **Planning Mode:** Preserves goals, requirements, constraints
- **Assistant Mode:** Preserves user preferences, conversation context
- **Debugger Mode:** Preserves stack traces, reproduction steps

### 3. Adaptive System Prompts ✅

- **Tier 1:** ~200 tokens - Essential behavior + basic guardrails
- **Tier 2:** ~500 tokens - Detailed guidance + examples
- **Tier 3:** ~1000 tokens - Comprehensive methodology + frameworks ⭐
- **Tier 4:** ~1500 tokens - Expert-level detail + sophistication
- **Tier 5:** ~1500 tokens - Maximum sophistication

### 4. Hardware-Aware Selection ✅

- Detects hardware capability at startup
- Locks prompt tier when auto-sizing enabled
- Prevents mid-conversation prompt changes
- Ensures stable LLM behavior

### 5. LLM Erosion Prevention ✅

- Monitors context utilization (target: 70-75%)
- Detects quality degradation
- Triggers compression before issues occur
- Preserves critical information

### 6. 85% Context Cap Strategy ✅ NEW

- **User Experience:** User selects 4K, sees "4096 tokens" in UI
- **Behind the Scenes:** App sends `num_ctx: 3482` (85%) to Ollama
- **Natural Stops:** Ollama stops at 85% with `done_reason: 'length'`
- **Compression Trigger:** Natural stop triggers compression flow
- **Benefits:** Predictable behavior, clean stops, no overflow

**How It Works:**
```
User selects: 4K context (4096 tokens)
UI displays: "Context: 4096 tokens"
App sends to Ollama: num_ctx: 3482 (85%)
Ollama streams until: 3482 tokens reached
Ollama returns: done_reason: 'length'
App triggers: Compression + session save
User continues: Types "continue" to resume
```

**Pre-Calculated Values:**
- 4K → 3482 tokens (85%)
- 8K → 6963 tokens (85%)
- 16K → 13926 tokens (85%)
- 32K → 27853 tokens (85%)
- 64K → 55706 tokens (85%)
- 128K → 111411 tokens (85%)

Stored in `LLM_profiles.json` as `ollama_context_size` field.

---

## File Locations

### Source Code

- **Context Manager:** `packages/core/src/context/contextManager.ts`
- **Types & Prompts:** `packages/core/src/context/types.ts`
- **Compression Service:** `packages/core/src/services/chatCompressionService.ts`
- **Token Counter:** `packages/core/src/context/tokenCounter.ts`
- **VRAM Monitor:** `packages/core/src/context/vramMonitor.ts`
- **Context Pool:** `packages/core/src/context/contextPool.ts`

### Tests

- **Adaptive Context:** `packages/core/src/context/__tests__/adaptive-context.test.ts`
- **Progressive Checkpoints:** `packages/core/src/context/__tests__/progressive-checkpoints.test.ts`

### User Documentation

- **Context Management:** `docs/Context/README.md`
- **Progressive Checkpoints:** `docs/Context/management/progressive-checkpoints.md`
- **Compression Service:** `docs/Context/api/compression-service.md`
- **Context Manager API:** `docs/Context/api/context-manager.md`

---

## Development Status

### Phase 1: Foundation ✅ Complete

- Basic checkpoint system
- Hierarchical compression (3 levels)
- Additive checkpoint history
- Checkpoint aging and merging
- All 93 tests passing

### Phase 2: Adaptive System 🚧 Next

**Priority:** HIGH  
**Target:** Tier 3 (8-32K) - 90% of users

**Components to Add:**
1. Context size detection and tier mapping
2. Mode profile system with preservation rules
3. Rollover mechanism for Tier 1
4. Smart compression for Tier 2
5. Never-compressed sections
6. Integration testing

**Effort:** 15-20 hours  
**Impact:** Covers 90% of use cases

### Phase 3: Intelligence Layer 📋 Future

**Priority:** MEDIUM  
**Target:** Tier 4/5 (32K+) - Premium users

**Components to Add:**
1. Semantic extraction with LLM analysis
2. Quality monitoring and erosion detection
3. Predictive compression
4. Rich metadata tracking

**Effort:** 25-30 hours  
**Impact:** Premium experience for high-end users

---

## Getting Started

### For Users

Progressive checkpoints and adaptive compression are automatically enabled. No configuration needed!

The system will:
- Detect your context size and select the appropriate tier
- Apply mode-specific preservation rules
- Scale system prompts to your context capacity
- Lock prompt tier to hardware capability (when auto-sizing enabled)
- Compress intelligently to prevent LLM erosion

### For Developers

1. **Read the Architecture:** Start with [Context-Architecture.md](./Context-Architecture.md)
2. **Understand Prompts:** Review [Adaptive_system_Prompts.md](./Adaptive_system_Prompts.md)
3. **See the Flow:** Check [Checkpoint_Flow-Diagram.md](./Checkpoint_Flow-Diagram.md)
4. **Explore Routing:** Study [Prompts-Routing.md](./Prompts-Routing.md)
5. **Review Code:** Examine `packages/core/src/context/contextManager.ts`
6. **Run Tests:** Execute `npm test -- adaptive-context`

---

## Additional Resources

### Development Documentation

Located in `development/` subdirectory:
- Implementation plans and task breakdowns
- Progress tracking and status updates
- Code audits and alignment analysis
- Completion reports and summaries
- Prompt examples and token budget analysis

### Legacy Documentation

Located in `old/` subdirectory:
- Archived documentation from previous iterations
- Historical implementation plans
- Migration guides

---

## Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| **Context Utilization** | 70-75% | Token usage monitoring |
| **LLM Quality** | > 0.8 coherence | Output quality scoring |
| **Concept Drift** | < 5% deviation | Decision consistency |
| **User Satisfaction** | > 90% | Task completion rate |
| **Performance** | < 100ms overhead | Compression timing |
| **Prompt Stability** | 100% (auto-sizing) | No mid-conversation changes |

---

## Changelog

### Version 2.1 (January 21, 2026)

**Added:**
- ✅ **85% Context Cap Strategy** - Transparent UX with natural stops
  - User sees full context size (e.g., 4K = 4096 tokens) in UI
  - App sends 85% to Ollama via `num_ctx` parameter (e.g., 3482 tokens)
  - Ollama stops naturally at cap with `done_reason: 'length'`
  - Predictable compression triggers at same point every time
  - 15% buffer (e.g., 614 tokens for 4K) gives Ollama room to complete thoughts
  - Pre-calculated values in `LLM_profiles.json` (no runtime math)
  - Added `ollama_context_size` field to all context profiles
  - Updated `ChatOptions` interface with `contextSize` and `ollamaContextSize`
  - Wired up in `ModelContext.tsx` to pass `num_ctx` to Ollama

**Benefits:**
- No context overflow errors
- Natural, clean stops without abrupt cutoffs
- Predictable behavior for compression triggers
- Transparent to user (no technical knowledge required)
- Better compression timing and quality

**Documentation:**
- Added [85% Cap Implementation Guide](./85-PERCENT-CAP-IMPLEMENTATION.md)
- Updated Context-Architecture.md with 85% cap section
- Updated Adaptive_system_Prompts.md with token budget notes
- Updated Checkpoint_Flow-Diagram.md with cap explanation
- Updated Prompts-Routing.md with cap notes

**See Also:** [85% Cap Implementation Guide](./85-PERCENT-CAP-IMPLEMENTATION.md)
- 85% Context Cap Strategy ⭐ NEW
  - Pre-calculated `ollama_context_size` values in LLM_profiles.json
  - Transparent to user (sees full context, we send 85%)
  - Natural stops at predictable points
  - Triggers compression via `done_reason: 'length'`
- Implementation in ModelContext.tsx
- Profile lookup for ollama_context_size
- Fallback calculation (85%) if profile missing

**Benefits:**
- No runtime math - pre-calculated values
- Predictable compression triggers
- Clean natural stops from Ollama
- Prevents context overflow
- User-friendly (transparent operation)

### Version 2.0 (January 20, 2026)

**Added:**
- Complete 5-tier architecture (2-4K, 4-8K, 8-32K, 32-64K, 64K+)
- Hardware-aware prompt selection ⭐ NEW
- 20 adaptive system prompts (5 tiers × 4 modes)
- Mode-specific profiles with never-compressed sections
- Rollover mechanism for Tier 1
- Smart compression for Tier 2
- Comprehensive documentation with mermaid diagrams

**Changed:**
- Refocused on Tier 3 (8-32K) as primary target
- Updated token budgets: ~200, ~500, ~1000, ~1500, ~1500
- Revised compression strategies per tier
- Enhanced mode profile definitions

**Clarified:**
- Tier 1 needs rollover, not just truncation
- Tier 2 is entry-level for serious work
- Tier 3 is where 90% of users operate
- Tier 4/5 are premium/enterprise tiers

### Version 1.0 (January 19, 2026)

**Initial Release:**
- Basic progressive checkpoint system
- 3-level hierarchical compression
- Additive checkpoint history
- Checkpoint aging and merging
- Test suite and documentation

---

## Contact & Contributions

For questions, issues, or contributions:
- **Documentation:** `.dev/docs/Context/`
- **Implementation:** `packages/core/src/context/`
- **Tests:** `packages/core/src/context/__tests__/`
- **Issues:** Project issue tracker

---

**Document Status:** ✅ Complete  
**Last Updated:** January 20, 2026  
**Next Review:** After Phase 2 implementation
