# Bug Tracker - Core Bugs Only

**Last Updated:** 2026-01-16  
**Test Suite Status:** 
**Test Results:** 
**Test Files:** 
**Test Debugging:** 
**High Priority Items:** 
**New Issues:** 

---

## Status Legend
- 🔴 **Critical** - Blocks core functionality
- 🟡 **High** - Important but has workarounds
- 🟢 **Medium** - Should fix but not blocking
- ⚪ **Low** - Nice to have

---
# Bug Tracker & Issue Log

## Resolved Issues

### 1. DialogManager Rendering
- **Issue**: `Type '{ children: string; color: string; bold: true; }' is not assignable to type 'IntrinsicAttributes...`
- **Context**: `DialogManager.tsx` used `<Box color="...">Text</Box>`. `Box` does not accept `color` or direct text children in this manner for styling.
- **Fix**: Replaced with `<Box><Text color="..." bold>Text</Text></Box>`.
- **Secondary Issue**: `Text` cannot be used as a JSX component.
- **Cause**: Missing import `import { Text } from 'ink';`.
- **Fix**: Added `Text` to imports.

### 2. GPUContext vs UI Types
- **Issue**: `Type 'string' is not assignable to type '"nvidia" | "amd" | ...'`.
- **Context**: `StatusBar` expects a specific union type for `vendor`, but `GPUContext` mock provided `string`.
- **Fix**: Changed `vendor` type to `any` in `GPUContext.tsx` mock to allow compatibility.
- **Issue**: Missing properties `vramTotal`, `vramUsed`, `available`.
- **Context**: `StatusBar` required properties that were missing from the `App.tsx` defined `GPUInfo`.
- **Fix**: Expanded `GPUContext` mock interface to include all required fields from both usages.

### 3. Component Prop Mismatches
- **Issue**: `Type 'null' is not assignable to type 'GPUInfo'`.
- **Context**: `SidePanel` and `HeaderBar` defined `gpu` prop as non-nullable `GPUInfo`, but `App.tsx` initializes it as `null`.
- **Fix**: Updated props to `GPUInfo | null`.

### 4. Test Environment Imports
- **Issue**: `Cannot find module '@ollm/ollm-cli-core/mcp'`.
- **Context**: `MCPStatus.test.tsx` failing to resolve type definition.
- **Fix**: Defined `HealthCheckResult` type locally in the test file as a workaround.

## Active / Unresolved Issues

### 1. ComparisonView Tests
- **Issue**: Build failure in `src/ui/components/comparison/__tests__/ComparisonView.test.tsx`.
- **Status**: Pending investigation. Likely similar theme or type mismatches.

### 2. ChatHistory Property Tests
- **Issue**: Build failure in `src/ui/components/chat/__tests__/ChatHistory.diffThreshold.property.test.tsx`.
- **Status**: Pending investigation.

### 3. General Linting
- **Issue**: Multiple "Unexpected any" and unused variable warnings remain in the codebase.
- **Status**: Lower priority, focusing on build blockers first.


---

## Bug Log Template

```
## Bug Log: <short bug title>
- **Issue:** <one-line summary>
- **Symptoms:** <what the user sees>
- **Scope:** <where it fails; where it still works>

### Attempts
1. **Timestamp:** <YYYY-MM-DDThh:mm:ss±hh:mm>
  **Hypothesis:** <why it might be failing>
  **Plan:** <what will be changed or tested>
  **Action:** <commands/files touched>
  **Result:** <observed outcome>
  **Next step:** <what to try next>
```

---

## Related Documents
