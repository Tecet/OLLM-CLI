# System Prompt Audit - Executive Summary

**Date:** January 18, 2026  
**Auditor:** AI Assistant  
**Status:** ✅ COMPLETE

---

## TL;DR

**Critical Finding:** OLLM CLI starts with **NO system prompt**, meaning the model has no instructions about its role, behavior, or capabilities.

**Impact:** Unpredictable model behavior, no consistency, no identity.

**Solution:** Implement 3 quick fixes (1-2 hours of work).

---

## What We Found

### ✅ Good News: Infrastructure Exists

The prompt building system is **fully implemented** and ready to use:

1. **SystemPromptBuilder** - Modular prompt composition ✅
2. **PromptRegistry** - Multi-source prompt management ✅
3. **Core Templates** - Identity, mandates, sanity checks ✅

### ❌ Bad News: Not Being Used

Despite having all the infrastructure, **it's never called**:

1. App starts with empty system prompt
2. SystemPromptBuilder is only used in HotSwapService (edge case)
3. No integration with main chat flow

---

## The 3 Critical Issues

### 🔴 Issue 1: No Initial System Prompt

**What happens now:**
```typescript
// App starts with this:
systemPrompt: {
  content: '',  // ← EMPTY!
}
```

**What should happen:**
```typescript
// App should start with this:
systemPrompt: {
  content: `You are an interactive CLI agent specializing in software engineering tasks...

# Core Mandates
- Rigorously adhere to existing project conventions
- NEVER assume a library/framework is available
- Ensure changes integrate naturally
...`
}
```

**Fix:** Call SystemPromptBuilder on app start (5 lines of code)

### ⚠️ Issue 2: System Prompt Cleared on Chat Clear

**What happens now:**
```typescript
const clearChat = () => {
  contextActions.clear();
  contextActions.setSystemPrompt(''); // ← Clears it!
};
```

**What should happen:**
```typescript
const clearChat = () => {
  contextActions.clear(); // Already preserves system prompt
  // Don't clear it!
};
```

**Fix:** Remove 1 line of code

### 🔴 Issue 3: SystemPromptBuilder Not Integrated

**What happens now:**
- SystemPromptBuilder exists but is never used
- All the prompt infrastructure is wasted
- No modular composition
- No skill integration

**What should happen:**
- Use SystemPromptBuilder on app start
- Rebuild prompt when skills change
- Rebuild prompt when tools change
- Rebuild prompt when MCP servers change

**Fix:** Integrate into ContextManagerProvider (20 lines of code)

---

## Current Prompt Templates

### Identity Prompt
```
You are an interactive CLI agent specializing in software engineering tasks. 
Your primary goal is to help users safely and efficiently, adhering strictly 
to the following instructions and utilizing your available tools.
```

### Mandates Prompt
```
# Core Mandates

- **Conventions:** Rigorously adhere to existing project conventions
- **Verification:** NEVER assume a library/framework is available
- **Idiomatic Changes:** Ensure changes integrate naturally
- **Comments:** Add comments sparingly and only for "why", not "what"
- **Proactiveness:** Fulfill the request thoroughly
- **Ambiguity:** Do not take significant actions beyond clear scope
- **Output:** Be professional and concise
```

### Sanity Check Prompt (Optional)
```
# Reality Check Protocol

- **Pre-Flight:** Before editing any file, you MUST read it first
- **Reproduction:** Before fixing a bug, you MUST reproduce it
- **Confusion Protocol:** If confused, use write_memory_dump tool
```

---

## Quick Fix Implementation

### Fix 1: Set Initial System Prompt (5 minutes)

**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

**Add after manager creation:**
```typescript
// BUILD AND SET INITIAL SYSTEM PROMPT
const promptRegistry = new PromptRegistry();
const promptBuilder = new SystemPromptBuilder(promptRegistry);

const initialPrompt = promptBuilder.build({
  interactive: true,
  useSanityChecks: false,
  skills: []
});

manager.setSystemPrompt(initialPrompt);
```

### Fix 2: Preserve System Prompt on Clear (1 minute)

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Remove this line:**
```typescript
contextActions.setSystemPrompt(''); // ← DELETE THIS
```

### Fix 3: Export Required Classes (2 minutes)

**File:** `packages/core/src/index.ts`

**Add exports:**
```typescript
export { SystemPromptBuilder } from './context/SystemPromptBuilder.js';
export { PromptRegistry } from './prompts/PromptRegistry.js';
```

---

## Testing

### Test 1: Verify Initial Prompt
```bash
1. Start OLLM CLI
2. Send message: "What are you?"
3. Model should respond with awareness of being a CLI agent
4. Check Ollama logs to see system prompt
```

### Test 2: Verify Prompt Persistence
```bash
1. Start OLLM CLI
2. Send message
3. Run /clear command
4. Send another message
5. Model should still have context about being a CLI agent
```

### Test 3: Verify Prompt Content
```bash
1. Start OLLM CLI
2. Check Ollama API logs
3. Verify system prompt includes:
   - Identity: "CLI agent specializing in software engineering"
   - Mandates: "Rigorously adhere to existing project conventions"
   - No sanity checks (disabled by default)
```

---

## Impact Analysis

### Before Fix
- ❌ No system prompt
- ❌ Model has no identity
- ❌ No behavioral guidelines
- ❌ Unpredictable responses
- ❌ No consistency across sessions

### After Fix
- ✅ Clear identity as CLI agent
- ✅ Behavioral guidelines (mandates)
- ✅ Consistent behavior
- ✅ Professional output
- ✅ Proper tool usage

---

## Future Enhancements

### Phase 2: Dynamic Updates (2-3 hours)
- Update prompt when skills change
- Update prompt when tools change
- Update prompt when MCP servers change

### Phase 3: User Configuration (3-4 hours)
- Add settings UI for system prompt
- Persist custom prompts
- Allow editing

### Phase 4: Prompt Router (Future)
- Profile-based prompts (coding, creative, general)
- Task-specific prompts (debugging, refactoring)
- Context-aware selection

---

## Recommendation

**Priority:** 🔴 CRITICAL - Implement immediately

**Effort:** 10 minutes of coding + 5 minutes of testing

**Impact:** Massive improvement in model behavior and consistency

**Risk:** Very low - only adding missing initialization

---

## Files to Modify

1. `packages/core/src/index.ts` - Export SystemPromptBuilder and PromptRegistry
2. `packages/cli/src/features/context/ContextManagerContext.tsx` - Add initial prompt
3. `packages/cli/src/features/context/ChatContext.tsx` - Remove prompt clearing

---

## Summary

We have a **fully functional prompt building system** that's just not being used. Three simple fixes will:

1. Give the model a clear identity
2. Establish behavioral guidelines
3. Ensure consistency across sessions

This is a **high-impact, low-effort** fix that should be implemented immediately.

---

**Next Steps:**
1. Review this summary
2. Implement the 3 fixes
3. Test with DeepSeek-R1
4. Commit changes

**Estimated Time:** 15 minutes total
