# System Prompt Implementation Plan

**Date:** January 18, 2026  
**Status:** 📋 READY FOR IMPLEMENTATION

---

## Context

After reviewing:
1. `.dev/reference/PromptsDraft.md` - Research from Gemini CLI analysis
2. `.dev/reference/systemPrompts.md` - Original architecture plan
3. `.kiro/specs/stage-04b-context-management/design.md` - Context management spec
4. Gemini CLI's actual implementation (via web research)

**Key Finding:** We have a well-researched, well-designed system that's **90% implemented** but **0% integrated**.

---

## What Gemini CLI Does (Our Reference)

### 1. Environment Variable System Prompt
```bash
export GEMINI_SYSTEM_MD=/path/to/prompt.md
gemini
```

**How it works:**
- Single environment variable points to markdown file
- File content becomes system prompt
- No config files, no SDK, just a file
- Can be project-specific or global

### 2. Modular Prompt Architecture

**From Gemini CLI source:**
```typescript
// packages/core/src/core/prompts.ts
function getCoreSystemPrompt(config) {
  const sections = [];
  
  // 1. Identity (always)
  sections.push(getIdentityPrompt(config.interactive));
  
  // 2. Core Mandates (always)
  sections.push(getCoreMandates());
  
  // 3. Workflows (conditional)
  if (config.hasCodebaseInvestigator) {
    sections.push(getInvestigatorWorkflow());
  } else {
    sections.push(getStandardWorkflow());
  }
  
  // 4. Environment Context (dynamic)
  if (config.hasGit) sections.push(getGitInstructions());
  if (config.sandbox) sections.push(getSandboxInstructions());
  
  // 5. MCP Prompts (from registry)
  sections.push(...getMCPServerPrompts());
  
  return sections.join('\n\n');
}
```

### 3. State Snapshot for Compression

**XML-based structured compression:**
```xml
<state_snapshot>
    <overall_goal>Refactor auth service to use BetterAuth</overall_goal>
    <key_knowledge>
        - API Key is in .env (verified)
        - Tests for auth are in src/tests/auth/
    </key_knowledge>
    <file_system_state>
        - MODIFIED: src/auth.ts (Swapped imports)
        - CREATED: src/better-auth-adapter.ts
    </file_system_state>
    <current_plan>
        1. [DONE] Install dependencies
        2. [IN PROGRESS] Implement adapter
        3. [TODO] Update tests
    </current_plan>
</state_snapshot>
```

---

## What We Have (Already Implemented)

### ✅ Core Infrastructure

1. **SystemPromptBuilder** (`packages/core/src/context/SystemPromptBuilder.ts`)
   - Modular prompt composition
   - Template variable substitution
   - Skill integration
   - Sanity checks

2. **PromptRegistry** (`packages/core/src/prompts/PromptRegistry.ts`)
   - Multi-source prompt management
   - Tag-based filtering
   - MCP integration

3. **Core Templates** (`packages/core/src/prompts/templates/`)
   - `identity.ts` - Agent identity
   - `mandates.ts` - Behavioral rules
   - `sanity.ts` - Reality checks
   - `stateSnapshot.ts` - Compression template

4. **ContextManager** (`packages/core/src/context/contextManager.ts`)
   - System prompt storage
   - `getSystemPrompt()` / `setSystemPrompt()`
   - Context management

5. **HotSwapService** (`packages/core/src/context/HotSwapService.ts`)
   - Uses SystemPromptBuilder
   - XML state snapshots
   - Context reseeding

### ❌ What's Missing

1. **Initial prompt not set** - App starts with empty prompt
2. **No integration** - SystemPromptBuilder never called in main flow
3. **No environment variable support** - Can't use `OLLM_SYSTEM_MD`
4. **No dynamic updates** - Prompt doesn't update when skills/tools change
5. **No project-specific prompts** - Can't have `.ollm/system-prompt.md`

---

## Implementation Plan

### Phase 1: Core Integration (1-2 hours)

#### Task 1.1: Export Required Classes
**File:** `packages/core/src/index.ts`

```typescript
// Add exports
export { SystemPromptBuilder } from './context/SystemPromptBuilder.js';
export { PromptRegistry } from './prompts/PromptRegistry.js';
export type { SystemPromptConfig } from './context/SystemPromptBuilder.js';
```

#### Task 1.2: Set Initial System Prompt
**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

```typescript
import { SystemPromptBuilder, PromptRegistry } from '@ollm/core';

// In ContextManagerProvider initialization
useEffect(() => {
  const initManager = async () => {
    try {
      const manager = createContextManager(sessionId, modelInfo, config);
      managerRef.current = manager;
      
      await manager.start();
      
      // BUILD INITIAL SYSTEM PROMPT
      const promptRegistry = new PromptRegistry();
      const promptBuilder = new SystemPromptBuilder(promptRegistry);
      
      const initialPrompt = promptBuilder.build({
        interactive: true,
        useSanityChecks: false,
        skills: [],
        agentName: 'OLLM CLI'
      });
      
      manager.setSystemPrompt(initialPrompt);
      
      setActive(true);
      setUsage(manager.getUsage());
      setError(null);
    } catch (err) {
      // ...
    }
  };
  
  initManager();
}, [sessionId, modelInfo, config]);
```

#### Task 1.3: Preserve System Prompt on Clear
**File:** `packages/cli/src/features/context/ChatContext.tsx`

```typescript
const clearChat = useCallback(() => {
  setMessages([]);
  setCurrentInput('');
  setStreaming(false);
  setWaitingForResponse(false);
  if (contextActions) {
    contextActions.clear().catch(console.error);
    // DON'T clear system prompt - it's preserved by clear()
    // REMOVE THIS LINE: contextActions.setSystemPrompt('');
  }
}, [contextActions]);
```

### Phase 2: Environment Variable Support (1 hour)

#### Task 2.1: Add Environment Variable Loading
**File:** `packages/cli/src/config/settingsService.ts`

```typescript
import { readFileSync, existsSync } from 'fs';
import { resolve } from 'path';

export class SettingsService {
  // ...
  
  /**
   * Load system prompt from environment variable or file
   * Priority: OLLM_SYSTEM_MD > .ollm/system-prompt.md > default
   */
  public getSystemPromptSource(): string | null {
    // 1. Check environment variable
    const envPath = process.env.OLLM_SYSTEM_MD;
    if (envPath && existsSync(envPath)) {
      try {
        return readFileSync(envPath, 'utf-8');
      } catch (error) {
        console.warn(`Failed to load system prompt from ${envPath}:`, error);
      }
    }
    
    // 2. Check workspace .ollm/system-prompt.md
    const workspacePath = resolve(process.cwd(), '.ollm', 'system-prompt.md');
    if (existsSync(workspacePath)) {
      try {
        return readFileSync(workspacePath, 'utf-8');
      } catch (error) {
        console.warn(`Failed to load system prompt from ${workspacePath}:`, error);
      }
    }
    
    // 3. Check global ~/.ollm/system-prompt.md
    const globalPath = resolve(homedir(), '.ollm', 'system-prompt.md');
    if (existsSync(globalPath)) {
      try {
        return readFileSync(globalPath, 'utf-8');
      } catch (error) {
        console.warn(`Failed to load system prompt from ${globalPath}:`, error);
      }
    }
    
    return null;
  }
}
```

#### Task 2.2: Use Custom Prompt if Available
**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

```typescript
// In initialization
const settingsService = SettingsService.getInstance();
const customPrompt = settingsService.getSystemPromptSource();

let initialPrompt: string;

if (customPrompt) {
  // Use custom prompt from file
  initialPrompt = customPrompt;
} else {
  // Build default prompt
  const promptRegistry = new PromptRegistry();
  const promptBuilder = new SystemPromptBuilder(promptRegistry);
  
  initialPrompt = promptBuilder.build({
    interactive: true,
    useSanityChecks: false,
    skills: [],
    agentName: 'OLLM CLI'
  });
}

manager.setSystemPrompt(initialPrompt);
```

### Phase 3: Dynamic Prompt Updates (2-3 hours)

#### Task 3.1: Track Active Components
**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

```typescript
// Add state for tracking active components
const [activeSkills, setActiveSkills] = useState<string[]>([]);
const [activeTools, setActiveTools] = useState<string[]>([]);
const [activeMcpServers, setActiveMcpServers] = useState<string[]>([]);

// Store prompt builder and registry in refs
const promptRegistryRef = useRef<PromptRegistry | null>(null);
const promptBuilderRef = useRef<SystemPromptBuilder | null>(null);
```

#### Task 3.2: Rebuild Prompt Function
**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

```typescript
const rebuildSystemPrompt = useCallback(async () => {
  if (!managerRef.current || !promptBuilderRef.current) return;
  
  // Check for custom prompt first
  const settingsService = SettingsService.getInstance();
  const customPrompt = settingsService.getSystemPromptSource();
  
  if (customPrompt) {
    // Use custom prompt, don't rebuild
    managerRef.current.setSystemPrompt(customPrompt);
    return;
  }
  
  // Build dynamic prompt
  const newPrompt = promptBuilderRef.current.build({
    interactive: true,
    useSanityChecks: false,
    skills: activeSkills,
    agentName: 'OLLM CLI',
    additionalInstructions: buildAdditionalInstructions()
  });
  
  managerRef.current.setSystemPrompt(newPrompt);
}, [activeSkills, activeTools, activeMcpServers]);

function buildAdditionalInstructions(): string {
  const sections: string[] = [];
  
  // Add tool information
  if (activeTools.length > 0) {
    sections.push(`## Available Tools\n${activeTools.join(', ')}`);
  }
  
  // Add MCP server information
  if (activeMcpServers.length > 0) {
    sections.push(`## Active MCP Servers\n${activeMcpServers.join(', ')}`);
  }
  
  return sections.join('\n\n');
}
```

#### Task 3.3: Listen to Context Manager Events
**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

```typescript
useEffect(() => {
  if (!managerRef.current) return;
  
  const manager = managerRef.current;
  
  // Listen for skill changes
  manager.on('active-skills-updated', ({ skills }) => {
    setActiveSkills(skills);
  });
  
  // Listen for tool changes
  manager.on('active-tools-updated', ({ tools }) => {
    setActiveTools(tools);
  });
  
  // Listen for MCP changes
  manager.on('active-mcp-updated', ({ servers }) => {
    setActiveMcpServers(servers);
  });
  
  return () => {
    manager.removeAllListeners('active-skills-updated');
    manager.removeAllListeners('active-tools-updated');
    manager.removeAllListeners('active-mcp-updated');
  };
}, []);

// Rebuild prompt when components change
useEffect(() => {
  rebuildSystemPrompt();
}, [activeSkills, activeTools, activeMcpServers, rebuildSystemPrompt]);
```

### Phase 4: XML State Snapshots (1-2 hours)

#### Task 4.1: Update Compression Service
**File:** `packages/core/src/services/chatCompressionService.ts`

```typescript
import { STATE_SNAPSHOT_PROMPT } from '../prompts/templates/stateSnapshot.js';

async compress(
  messages: SessionMessage[],
  strategy: CompressionStrategy
): Promise<CompressedContext> {
  if (strategy.type === 'summarize' || strategy.type === 'hybrid') {
    // Use XML state snapshot prompt instead of generic summary
    const summaryPrompt = STATE_SNAPSHOT_PROMPT.content;
    
    // Build context for summarization
    const contextToSummarize = messages
      .slice(0, -strategy.preserveRecent)
      .map(m => `${m.role}: ${m.parts[0].text}`)
      .join('\n\n');
    
    // Request structured snapshot
    const summary = await this.generateSummary(
      contextToSummarize,
      summaryPrompt
    );
    
    // Parse and validate XML structure
    const isValidSnapshot = this.validateStateSnapshot(summary);
    if (!isValidSnapshot) {
      console.warn('Generated summary is not valid XML state snapshot, using anyway');
    }
    
    // ...
  }
}

private validateStateSnapshot(content: string): boolean {
  // Check for required XML tags
  const requiredTags = [
    '<state_snapshot>',
    '<overall_goal>',
    '<key_knowledge>',
    '<file_system_state>',
    '<current_plan>',
    '</state_snapshot>'
  ];
  
  return requiredTags.every(tag => content.includes(tag));
}
```

#### Task 4.2: Create State Snapshot Template
**File:** `packages/core/src/prompts/templates/stateSnapshot.ts`

```typescript
import { PromptDefinition } from '../types.js';

export const STATE_SNAPSHOT_PROMPT: PromptDefinition = {
  id: 'compression-state-snapshot',
  name: 'State Snapshot Compression',
  content: `Create a structured state snapshot of the conversation above. Use this exact XML format:

<state_snapshot>
    <overall_goal>
        [What is the user trying to accomplish? Be specific.]
    </overall_goal>

    <key_knowledge>
        - [Important facts discovered]
        - [User preferences or constraints]
        - [Technical details that matter]
    </key_knowledge>

    <file_system_state>
        - MODIFIED: [file path] ([what changed])
        - CREATED: [file path] ([purpose])
        - DELETED: [file path] ([reason])
    </file_system_state>

    <current_plan>
        1. [DONE] [completed step]
        2. [IN PROGRESS] [current step]
        3. [TODO] [next step]
    </current_plan>
</state_snapshot>

Be concise but preserve all critical information. This snapshot will be used to restore context later.`,
  description: 'Structured XML format for context compression',
  source: 'static',
  tags: ['compression', 'snapshot'],
};
```

### Phase 5: UI and Commands (2-3 hours)

#### Task 5.1: Add System Prompt Commands
**File:** `packages/cli/src/commands/contextCommands.ts`

```typescript
// Add new commands
registry.register({
  name: '/prompt',
  description: 'Manage system prompt',
  subcommands: [
    {
      name: 'show',
      description: 'Show current system prompt',
      execute: async () => {
        const manager = getGlobalContextManager();
        if (!manager) return { success: false, message: 'Context manager not initialized' };
        
        const prompt = manager.getSystemPrompt();
        return { success: true, message: prompt };
      }
    },
    {
      name: 'reload',
      description: 'Reload system prompt from file',
      execute: async () => {
        // Trigger prompt rebuild
        // ...
      }
    },
    {
      name: 'reset',
      description: 'Reset to default system prompt',
      execute: async () => {
        // Clear custom prompt, rebuild default
        // ...
      }
    }
  ]
});
```

#### Task 5.2: Add Settings UI for System Prompt
**File:** `packages/cli/src/ui/components/settings/PromptSettings.tsx` (new)

```typescript
import React, { useState } from 'react';
import { Box, Text } from 'ink';
import { SettingsService } from '../../../config/settingsService.js';

export function PromptSettings() {
  const [customPromptPath, setCustomPromptPath] = useState<string>('');
  
  return (
    <Box flexDirection="column">
      <Text bold>System Prompt Settings</Text>
      
      <Box marginTop={1}>
        <Text>Custom Prompt File: </Text>
        <Text color="cyan">{customPromptPath || 'Using default'}</Text>
      </Box>
      
      <Box marginTop={1}>
        <Text dimColor>
          Set OLLM_SYSTEM_MD environment variable to use a custom prompt file
        </Text>
      </Box>
      
      <Box marginTop={1}>
        <Text dimColor>
          Or create .ollm/system-prompt.md in your project directory
        </Text>
      </Box>
    </Box>
  );
}
```

---

## Testing Plan

### Test 1: Initial System Prompt
```bash
1. Start OLLM CLI
2. Send message: "What are you?"
3. Verify response mentions being a CLI agent
4. Check Ollama logs for system prompt
5. Verify identity and mandates are present
```

### Test 2: Custom Prompt via Environment Variable
```bash
1. Create custom-prompt.md with "You are a pirate assistant"
2. export OLLM_SYSTEM_MD=./custom-prompt.md
3. Start OLLM CLI
4. Send message: "Hello"
5. Verify pirate-themed response
```

### Test 3: Project-Specific Prompt
```bash
1. Create .ollm/system-prompt.md in project
2. Add project-specific instructions
3. Start OLLM CLI
4. Verify project instructions are used
```

### Test 4: System Prompt Persistence
```bash
1. Start OLLM CLI
2. Send message
3. Run /clear
4. Send another message
5. Verify system prompt still present
```

### Test 5: Dynamic Prompt Updates
```bash
1. Start OLLM CLI
2. Activate a skill
3. Verify prompt includes skill instructions
4. Deactivate skill
5. Verify prompt removes skill instructions
```

### Test 6: XML State Snapshot
```bash
1. Have long conversation
2. Trigger compression
3. Verify compressed context uses XML format
4. Verify all required tags present
5. Verify information preserved
```

---

## Documentation Updates

### User Documentation

**File:** `docs/configuration.md`

Add section:
```markdown
## System Prompts

OLLM CLI uses system prompts to define the assistant's behavior and capabilities.

### Default Prompt

By default, OLLM CLI uses a carefully crafted system prompt that:
- Defines the assistant as a CLI agent specializing in software engineering
- Establishes core behavioral rules (conventions, safety, transparency)
- Provides context about available tools and capabilities

### Custom Prompts

You can customize the system prompt in three ways:

1. **Environment Variable** (highest priority)
   ```bash
   export OLLM_SYSTEM_MD=/path/to/your/prompt.md
   ollm
   ```

2. **Project-Specific** (medium priority)
   Create `.ollm/system-prompt.md` in your project directory

3. **Global** (lowest priority)
   Create `~/.ollm/system-prompt.md` in your home directory

### Prompt Commands

- `/prompt show` - Display current system prompt
- `/prompt reload` - Reload prompt from file
- `/prompt reset` - Reset to default prompt

### Example Custom Prompts

**Coding Assistant:**
```markdown
You are a senior software engineer assistant. Focus on:
- Writing clean, maintainable code
- Following project conventions
- Explaining complex concepts clearly
- Suggesting best practices
```

**Debugging Assistant:**
```markdown
You are a debugging specialist. Your approach:
1. Reproduce the issue first
2. Analyze root causes systematically
3. Suggest fixes with explanations
4. Verify fixes work
```
```

### Developer Documentation

**File:** `docs/Context/api/system-prompt-builder.md` (new)

```markdown
# SystemPromptBuilder API

## Overview

The SystemPromptBuilder provides a modular way to construct system prompts from reusable components.

## Usage

```typescript
import { SystemPromptBuilder, PromptRegistry } from '@ollm/core';

const registry = new PromptRegistry();
const builder = new SystemPromptBuilder(registry);

const prompt = builder.build({
  interactive: true,
  useSanityChecks: false,
  skills: ['debugging', 'refactoring'],
  agentName: 'OLLM CLI',
  additionalInstructions: 'Focus on TypeScript best practices'
});
```

## Configuration

### SystemPromptConfig

- `interactive: boolean` - Whether running in interactive mode
- `useSanityChecks?: boolean` - Include reality check protocols
- `agentName?: string` - Name of the agent
- `additionalInstructions?: string` - Custom instructions to append
- `skills?: string[]` - Active skills to include

## Prompt Structure

Prompts are built in this order:

1. **Identity** (Tier 1) - Agent persona and role
2. **Mandates** (Tier 1) - Core behavioral rules
3. **Skills** (Tier 2) - Active skill instructions
4. **Sanity Checks** (Tier 2/3) - Reality check protocols
5. **Additional Instructions** (Tier 3) - Custom instructions

## Extending

Register custom prompts:

```typescript
registry.register({
  id: 'my-custom-prompt',
  name: 'Custom Instructions',
  content: 'Your instructions here...',
  source: 'config',
  tags: ['custom']
});
```
```

---

## Migration Path

### For Existing Users

1. **No Breaking Changes** - Default behavior improves automatically
2. **Opt-In Customization** - Users can add custom prompts when ready
3. **Backward Compatible** - Existing sessions continue working

### Rollout Plan

1. **Phase 1** (Week 1): Core integration, default prompts
2. **Phase 2** (Week 2): Environment variable support
3. **Phase 3** (Week 3): Dynamic updates
4. **Phase 4** (Week 4): XML snapshots
5. **Phase 5** (Week 5): UI and documentation

---

## Success Criteria

### Must Have
- ✅ Initial system prompt set on app start
- ✅ System prompt preserved on chat clear
- ✅ Environment variable support (OLLM_SYSTEM_MD)
- ✅ Project-specific prompts (.ollm/system-prompt.md)

### Should Have
- ✅ Dynamic prompt updates when skills/tools change
- ✅ XML state snapshots for compression
- ✅ Prompt management commands (/prompt show, reload, reset)

### Nice to Have
- ⏳ Settings UI for prompt configuration
- ⏳ Prompt templates library
- ⏳ Prompt effectiveness analytics

---

## Summary

**Current State:** Infrastructure 90% complete, integration 0%

**Effort Required:** 8-12 hours total

**Impact:** Massive improvement in model behavior and consistency

**Risk:** Very low - additive changes only

**Next Step:** Implement Phase 1 (Core Integration) - 1-2 hours

---

**Status:** Ready for implementation
**Priority:** 🔴 CRITICAL
**Estimated Completion:** 1-2 weeks (if done incrementally)
