# System Prompt & Prompt Builder Audit

**Date:** January 18, 2026  
**Status:** 🔍 IN PROGRESS

## Executive Summary

This audit examines:
1. System prompt behavior at app start and chat clearing
2. Prompt builder/router architecture (planned vs implemented)
3. Current implementation status and gaps

---

## Part 1: System Prompt Behavior

### Current Implementation

#### System Prompt Storage
- **Location:** `ContextManager` in `@ollm/core`
- **Structure:** Stored as a `Message` object with role='system'
- **Access:** Via `getSystemPrompt()` and `setSystemPrompt(content)`

```typescript
// packages/core/src/context/contextManager.ts
setSystemPrompt(content: string): void {
  const systemPrompt: Message = {
    id: `system-${Date.now()}`,
    role: 'system',
    content,
    timestamp: new Date(),
    tokenCount: this.tokenCounter.countTokensCached(...)
  };
  
  // Remove old system prompt
  this.currentContext.messages = this.currentContext.messages.filter(
    m => m.role !== 'system'
  );
  
  // Add new at beginning
  this.currentContext.messages.unshift(systemPrompt);
  this.currentContext.systemPrompt = systemPrompt;
}
```

#### System Prompt at App Start

**Finding:** ❌ **NO INITIAL SYSTEM PROMPT IS SET**

```typescript
// packages/core/src/context/contextManager.ts - Constructor
this.currentContext = {
  sessionId,
  messages: [],
  systemPrompt: {
    id: `system-${Date.now()}`,
    role: 'system',
    content: '',  // ← EMPTY STRING!
    timestamp: new Date()
  },
  tokenCount: 0,
  maxTokens: this.contextPool.currentSize,
  metadata: { ... }
};
```

**Impact:**
- App starts with NO system prompt
- Model has no identity, mandates, or instructions
- First message sent has no context about what the assistant should do

#### System Prompt on Chat Clear

**Current Behavior:** ✅ **CORRECTLY PRESERVED**

```typescript
// packages/cli/src/features/context/ChatContext.tsx
const clearChat = useCallback(() => {
  setMessages([]);
  setCurrentInput('');
  setStreaming(false);
  setWaitingForResponse(false);
  if (contextActions) {
    contextActions.clear().catch(console.error);
    contextActions.setSystemPrompt(''); // ← Clears system prompt
  }
}, [contextActions]);
```

**Finding:** ⚠️ **SYSTEM PROMPT IS CLEARED**

The `clear()` method in ContextManager preserves system prompt:
```typescript
async clear(): Promise<void> {
  const systemPrompt = this.currentContext.messages.find(
    m => m.role === 'system'
  );
  
  this.currentContext.messages = systemPrompt ? [systemPrompt] : [];
  this.currentContext.tokenCount = systemPrompt?.tokenCount || 0;
  // ...
}
```

But ChatContext explicitly clears it with `setSystemPrompt('')`.

**Impact:**
- After clearing chat, system prompt is lost
- Next conversation has no context
- User must restart app to get system prompt back (if it existed)

---

## Part 2: Prompt Builder Architecture

### Planned Architecture

#### SystemPromptBuilder (Implemented ✅)

**Location:** `packages/core/src/context/SystemPromptBuilder.ts`

**Purpose:** Build system prompts from modular components

**Features:**
- ✅ Tier-based prompt composition
- ✅ Template variable substitution
- ✅ Skill integration
- ✅ Sanity checks (optional)
- ✅ Custom instructions

**Structure:**
```typescript
export class SystemPromptBuilder {
  constructor(private registry: PromptRegistry) {
    // Register core prompts
    this.registry.register(IDENTITY_PROMPT);
    this.registry.register(MANDATES_PROMPT);
    this.registry.register(REALITY_CHECK_PROMPT);
  }

  build(config: SystemPromptConfig): string {
    const sections: string[] = [];
    
    // 1. Identity (Tier 1)
    // 2. Mandates (Tier 1)
    // 3. Active Skills (Tier 2)
    // 4. Sanity Checks (Tier 2/3 - Optional)
    // 5. Custom/Additional Instructions
    
    return sections.join('\n\n');
  }
}
```

**Config Interface:**
```typescript
export interface SystemPromptConfig {
  interactive: boolean;
  useSanityChecks?: boolean;
  agentName?: string;
  additionalInstructions?: string;
  skills?: string[];
}
```

#### PromptRegistry (Implemented ✅)

**Location:** `packages/core/src/prompts/PromptRegistry.ts`

**Purpose:** Manage prompts from multiple sources

**Features:**
- ✅ Register/unregister prompts
- ✅ Get by ID, tag, or source
- ✅ MCP server integration
- ✅ Clear MCP prompts on disconnect

**Sources:**
- `static`: Built-in prompts (identity, mandates, sanity)
- `mcp`: Prompts from MCP servers
- `config`: User-defined prompts

#### Core Prompt Templates (Implemented ✅)

**Location:** `packages/core/src/prompts/templates/`

1. **identity.ts** - Agent identity and role
2. **mandates.ts** - Core behavioral rules
3. **sanity.ts** - Reality checks and safety

---

## Part 3: Current Implementation Status

### What's Implemented ✅

1. **SystemPromptBuilder** - Full implementation
   - Modular prompt composition
   - Template variable substitution
   - Skill integration
   - Sanity checks

2. **PromptRegistry** - Full implementation
   - Multi-source prompt management
   - Tag-based filtering
   - MCP integration

3. **Core Templates** - Full implementation
   - Identity prompt
   - Mandates prompt
   - Reality check prompt

4. **ContextManager Integration** - Partial
   - ✅ System prompt storage
   - ✅ System prompt get/set
   - ❌ No automatic prompt building
   - ❌ No initial prompt set

### What's Missing ❌

1. **Initial System Prompt Generation**
   - SystemPromptBuilder is never called at app start
   - ContextManager starts with empty system prompt
   - No default identity or mandates

2. **Prompt Builder Integration**
   - SystemPromptBuilder exists but is not used
   - Only used in HotSwapService (tool swapping)
   - Not integrated with main chat flow

3. **Dynamic Prompt Updates**
   - No mechanism to update prompt when skills change
   - No mechanism to update prompt when tools change
   - No mechanism to update prompt when MCP servers connect/disconnect

4. **Prompt Router** (Planned but Not Implemented)
   - No routing logic for different contexts
   - No profile-based prompt selection
   - No task-specific prompt adaptation

5. **User-Configurable Prompts**
   - No UI for editing system prompt
   - No persistence of custom prompts
   - No prompt templates for users

---

## Part 4: Critical Issues

### Issue 1: No Initial System Prompt 🔴

**Severity:** CRITICAL

**Problem:**
- App starts with empty system prompt
- Model has no instructions about its role
- No behavioral guidelines
- No identity

**Impact:**
- Model behavior is unpredictable
- No consistency across sessions
- Users must manually set context every time

**Solution:**
```typescript
// In ContextManagerProvider initialization
useEffect(() => {
  const initManager = async () => {
    try {
      const manager = createContextManager(sessionId, modelInfo, config);
      managerRef.current = manager;
      
      await manager.start();
      
      // BUILD AND SET INITIAL SYSTEM PROMPT
      const promptRegistry = new PromptRegistry();
      const promptBuilder = new SystemPromptBuilder(promptRegistry);
      
      const initialPrompt = promptBuilder.build({
        interactive: true,
        useSanityChecks: false,
        skills: []
      });
      
      manager.setSystemPrompt(initialPrompt);
      
      setActive(true);
      setUsage(manager.getUsage());
      setError(null);
    } catch (err) {
      // ...
    }
  };
  
  initManager();
}, [sessionId, modelInfo, config]);
```

### Issue 2: System Prompt Cleared on Chat Clear ⚠️

**Severity:** MEDIUM

**Problem:**
- `clearChat()` explicitly calls `setSystemPrompt('')`
- Loses all context on clear
- User must restart to get prompt back

**Current Code:**
```typescript
const clearChat = useCallback(() => {
  // ...
  if (contextActions) {
    contextActions.clear().catch(console.error);
    contextActions.setSystemPrompt(''); // ← PROBLEM
  }
}, [contextActions]);
```

**Solution:**
```typescript
const clearChat = useCallback(() => {
  // ...
  if (contextActions) {
    contextActions.clear().catch(console.error);
    // DON'T clear system prompt - it's preserved by clear()
  }
}, [contextActions]);
```

### Issue 3: SystemPromptBuilder Not Used 🔴

**Severity:** HIGH

**Problem:**
- SystemPromptBuilder is fully implemented
- But never called in main chat flow
- Only used in HotSwapService (edge case)

**Impact:**
- All the prompt building infrastructure is wasted
- No modular prompt composition
- No skill integration
- No dynamic updates

**Solution:**
Integrate SystemPromptBuilder into:
1. App initialization (set initial prompt)
2. Skill activation (update prompt with skills)
3. Tool changes (update prompt with tool info)
4. MCP server connect/disconnect (update prompt with MCP tools)

### Issue 4: No Prompt Router 🟡

**Severity:** LOW (Future Enhancement)

**Problem:**
- No routing logic for different contexts
- Same prompt for all tasks
- No adaptation to user intent

**Planned Features:**
- Profile-based prompts (coding, creative, general)
- Task-specific prompts (debugging, refactoring, explaining)
- Context-aware prompt selection

**Status:** Not implemented, not blocking

---

## Part 5: Recommendations

### Immediate Fixes (Critical)

1. **Set Initial System Prompt**
   - Call SystemPromptBuilder on app start
   - Set default identity and mandates
   - Ensure consistent behavior

2. **Don't Clear System Prompt on Chat Clear**
   - Remove `setSystemPrompt('')` call
   - Let ContextManager preserve it
   - Maintain context across clears

3. **Integrate SystemPromptBuilder**
   - Use in main chat flow
   - Update on skill changes
   - Update on tool changes

### Short-Term Improvements (High Priority)

1. **Dynamic Prompt Updates**
   - Rebuild prompt when skills change
   - Rebuild prompt when tools change
   - Rebuild prompt when MCP servers change

2. **Prompt Persistence**
   - Save custom prompts to settings
   - Load on app start
   - Allow user overrides

3. **Prompt UI**
   - Add settings tab for system prompt
   - Show current prompt
   - Allow editing

### Long-Term Enhancements (Medium Priority)

1. **Prompt Router**
   - Implement routing logic
   - Profile-based selection
   - Task-specific adaptation

2. **Prompt Templates**
   - User-defined templates
   - Template marketplace
   - Import/export

3. **Prompt Analytics**
   - Track prompt effectiveness
   - A/B testing
   - Optimization suggestions

---

## Part 6: Implementation Plan

### Phase 1: Fix Critical Issues (1-2 hours)

**Task 1.1: Set Initial System Prompt**
- File: `packages/cli/src/features/context/ContextManagerContext.tsx`
- Action: Add SystemPromptBuilder call in initialization
- Test: Verify prompt is set on app start

**Task 1.2: Preserve System Prompt on Clear**
- File: `packages/cli/src/features/context/ChatContext.tsx`
- Action: Remove `setSystemPrompt('')` call
- Test: Verify prompt persists after clear

**Task 1.3: Export SystemPromptBuilder**
- File: `packages/core/src/index.ts`
- Action: Export SystemPromptBuilder and PromptRegistry
- Test: Verify imports work in CLI

### Phase 2: Dynamic Updates (2-3 hours)

**Task 2.1: Update Prompt on Skill Changes**
- File: `packages/cli/src/features/context/ContextManagerContext.tsx`
- Action: Rebuild prompt when activeSkills changes
- Test: Verify prompt updates when skills added/removed

**Task 2.2: Update Prompt on Tool Changes**
- File: `packages/cli/src/features/context/ContextManagerContext.tsx`
- Action: Rebuild prompt when activeTools changes
- Test: Verify prompt updates when tools enabled/disabled

**Task 2.3: Update Prompt on MCP Changes**
- File: `packages/cli/src/features/context/ContextManagerContext.tsx`
- Action: Rebuild prompt when MCP servers connect/disconnect
- Test: Verify prompt updates on MCP events

### Phase 3: User Configuration (3-4 hours)

**Task 3.1: Add Prompt Settings UI**
- File: `packages/cli/src/ui/components/settings/PromptSettings.tsx` (new)
- Action: Create settings panel for system prompt
- Test: Verify UI shows current prompt

**Task 3.2: Persist Custom Prompts**
- File: `packages/cli/src/config/settingsService.ts`
- Action: Add prompt storage to settings
- Test: Verify prompts persist across restarts

**Task 3.3: Allow Prompt Editing**
- File: `packages/cli/src/ui/components/settings/PromptSettings.tsx`
- Action: Add edit functionality
- Test: Verify edits are saved and applied

---

## Part 7: Testing Plan

### Test 1: Initial System Prompt
```bash
1. Start OLLM CLI
2. Send first message
3. Check Ollama logs for system prompt
4. Verify identity and mandates are present
```

### Test 2: System Prompt Persistence
```bash
1. Start OLLM CLI
2. Send message
3. Clear chat with /clear
4. Send another message
5. Verify system prompt is still present
```

### Test 3: Dynamic Prompt Updates
```bash
1. Start OLLM CLI
2. Check initial prompt (no skills)
3. Activate a skill
4. Verify prompt includes skill instructions
5. Deactivate skill
6. Verify prompt removes skill instructions
```

### Test 4: Custom Prompts
```bash
1. Open settings
2. Edit system prompt
3. Save changes
4. Restart OLLM CLI
5. Verify custom prompt is loaded
```

---

## Part 8: Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         App Start                            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              ContextManagerProvider Init                     │
│  ┌────────────────────────────────────────────────────┐    │
│  │ 1. Create ContextManager                           │    │
│  │ 2. Create PromptRegistry                           │    │
│  │ 3. Create SystemPromptBuilder                      │    │
│  │ 4. Build initial prompt                            │    │
│  │ 5. Set system prompt                               │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    SystemPromptBuilder                       │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Tier 1: Identity + Mandates                        │    │
│  │ Tier 2: Skills + Sanity Checks                     │    │
│  │ Tier 3: Custom Instructions                        │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      PromptRegistry                          │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Static Prompts: identity, mandates, sanity         │    │
│  │ MCP Prompts: from connected servers                │    │
│  │ Config Prompts: user-defined                       │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     ContextManager                           │
│  ┌────────────────────────────────────────────────────┐    │
│  │ systemPrompt: Message                              │    │
│  │ messages: Message[]                                │    │
│  │ tokenCount: number                                 │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Chat Flow                               │
│  ┌────────────────────────────────────────────────────┐    │
│  │ 1. User sends message                              │    │
│  │ 2. Get system prompt from ContextManager           │    │
│  │ 3. Build history with system prompt                │    │
│  │ 4. Send to LLM                                     │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

## Summary

### Current State
- ✅ SystemPromptBuilder: Fully implemented
- ✅ PromptRegistry: Fully implemented
- ✅ Core Templates: Fully implemented
- ❌ Initial prompt: Not set
- ❌ Integration: Not used in main flow
- ❌ Dynamic updates: Not implemented
- ❌ User configuration: Not implemented
- ❌ Prompt router: Not implemented

### Critical Issues
1. 🔴 No initial system prompt set
2. ⚠️ System prompt cleared on chat clear
3. 🔴 SystemPromptBuilder not used in main flow

### Next Steps
1. Set initial system prompt on app start
2. Preserve system prompt on chat clear
3. Integrate SystemPromptBuilder into main flow
4. Add dynamic prompt updates
5. Add user configuration UI

---

**Status:** Audit complete, ready for implementation
