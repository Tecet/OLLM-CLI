# Unified Prompt System - Implementation Plan

**Date:** January 18, 2026  
**Status:** 📋 READY FOR IMPLEMENTATION  
**Priority:** 🔴 CRITICAL

---

## Overview

This plan unifies three related features:

1. **System Prompt Integration** - Fix missing initial prompt
2. **Dynamic Mode Switching** - Context-aware persona changes
3. **UI Display** - Show current mode/persona in right panel

**Goal:** Create an intelligent prompt system that adapts to conversation context and displays current state to the user.

---

## Architecture

### Three-Layer System

```
┌─────────────────────────────────────────────────────────────┐
│                    Layer 1: Mode Detection                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ ContextAnalyzer                                     │    │
│  │ - Analyzes conversation for coding keywords        │    │
│  │ - Detects tool usage patterns                      │    │
│  │ - Calculates confidence scores                     │    │
│  │ - Recommends mode: assistant | developer | tool    │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  Layer 2: Prompt Composition                 │
│  ┌────────────────────────────────────────────────────┐    │
│  │ DynamicPromptComposer                              │    │
│  │ - Loads base template for current mode            │    │
│  │ - Injects tool schemas                             │    │
│  │ - Adds workspace context                           │    │
│  │ - Includes active skills/hooks/MCP                 │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Layer 3: State Management                  │
│  ┌────────────────────────────────────────────────────┐    │
│  │ PromptModeManager                                  │    │
│  │ - Tracks current mode                              │    │
│  │ - Manages mode transitions                         │    │
│  │ - Updates UI state                                 │    │
│  │ - Emits mode change events                         │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

## Mode Definitions

### 1. Assistant Mode (Default)

**Persona:** "Helpful AI Assistant"

**Icon:** 💬

**When Active:**
- App start (default)
- General questions
- No coding keywords in recent messages
- No tool usage

**Allowed Tools:** None (pure conversation)

**Prompt Template:**
```markdown
You are a helpful AI assistant. You can answer questions, explain concepts,
and have natural conversations about any topic.

When users ask about technical or coding topics, you can provide detailed
explanations and guidance. However, you should NOT write code or modify files
directly in this mode.

If the user wants to implement something, suggest switching to Developer mode
or Planning mode first.

Keep responses friendly, clear, and accessible.
```

### 2. Planning Mode

**Persona:** "Technical Architect & Planner"

**Icon:** 📋

**When Active:**
- Keywords: plan, design, architecture, research, investigate, explore
- User asks "how should I", "what's the best way", "help me plan"
- Before starting implementation
- Research phase

**Allowed Tools:**
- ✅ web_search - Research technologies, patterns, best practices
- ✅ web_fetch - Read documentation, articles, examples
- ✅ read_file - Understand existing code (read-only)
- ✅ grep_search - Find patterns in codebase (read-only)
- ✅ list_directory - Explore project structure (read-only)
- ❌ write_file - NO writing
- ❌ str_replace - NO editing
- ❌ shell - NO execution
- ❌ git_* - NO git operations

**Prompt Template:**
```markdown
You are a technical architect and planning specialist. Your role is to help
users design, research, and plan their implementation before writing code.

# Core Responsibilities
- Research best practices and technologies
- Design system architecture
- Create implementation plans
- Identify potential issues and risks
- Recommend tools, libraries, and patterns
- Break down complex tasks into steps

# Planning Approach
1. Understand the goal and constraints
2. Research relevant technologies and patterns
3. Analyze existing codebase (read-only)
4. Design the solution architecture
5. Create step-by-step implementation plan
6. Identify dependencies and risks
7. Recommend testing strategy

# Restrictions
- You CANNOT write or modify code in this mode
- You CANNOT execute commands or scripts
- You CANNOT make git commits
- You CAN read files and search the codebase
- You CAN research using web search
- You CAN create detailed plans and designs

# Available Research Tools
- web_search: Find information, documentation, examples
- web_fetch: Read articles, docs, tutorials
- read_file: Understand existing code
- grep_search: Find patterns in codebase
- list_directory: Explore project structure

When planning is complete, suggest switching to Developer mode for implementation.

# Output Format
Provide plans in this structure:
1. **Goal**: What we're trying to achieve
2. **Research**: Technologies, patterns, best practices
3. **Architecture**: High-level design
4. **Implementation Steps**: Detailed breakdown
5. **Dependencies**: What's needed
6. **Risks**: Potential issues
7. **Testing Strategy**: How to verify
```

### 3. Developer Mode

**Persona:** "Senior Software Engineer"

**Icon:** 👨‍💻

**When Active:**
- Coding keywords detected (implement, refactor, debug, function, class, etc.)
- File operations requested
- User says "let's implement", "write the code", "fix this bug"
- After planning phase

**Allowed Tools:** All tools (full access)

**Prompt Template:**
```markdown
You are a senior software engineer and CLI agent specializing in software
development tasks.

# Core Mandates
- Rigorously adhere to existing project conventions
- NEVER assume a library/framework is available without verification
- Ensure changes integrate naturally with existing code
- Add comments sparingly, only for "why" not "what"
- Be proactive but stay within clear scope
- Output should be professional and concise

# Current Project Context
- Tech Stack: {detected from workspace}
- Available Tools: {tool list}
- Active Skills: {skill list}

# Development Workflow
1. Read files before modifying
2. Understand existing patterns
3. Make minimal, focused changes
4. Test your changes
5. Explain your reasoning

When writing code:
- Follow existing patterns
- Consider edge cases
- Explain architectural decisions
- Test critical functionality

# Available Tools
You have full access to all tools including:
- File operations (read, write, edit)
- Shell commands
- Git operations
- Search and exploration
```

### 4. Tool Mode (Enhanced)

**Persona:** "Senior Software Engineer + Tool Expert"

**Icon:** 🔧

**When Active:**
- Tool just executed
- User explicitly requests tool usage
- Multi-step task requiring tools
- Complex tool chaining needed

**Allowed Tools:** All tools (full access)

**Prompt Template:**
```markdown
{Developer Mode Base}

# Tool Usage Guidelines

## Available Tools
{Full tool schemas with descriptions}

## Tool Selection Strategy
- read_file: Read single files when path is known
- grep_search: Search across files for patterns
- file_search: Find files by name
- list_directory: Explore directory structure
- shell: Run commands, tests, builds
- git_*: Version control operations
- web_search: Research when needed
- web_fetch: Read documentation

## Tool Chaining Patterns
1. Explore → Analyze → Modify → Verify
   - list_directory → read_file → str_replace → shell (test)

2. Search → Read → Understand
   - grep_search → read_file → analyze

3. Git Workflow
   - git_status → git_diff → git_commit

4. Research → Implement
   - web_search → web_fetch → read_file → write_file

## Best Practices
- Always read files before modifying
- Use grep_search for finding patterns
- Verify changes with tests when possible
- Commit logical units of work
```

---

## Implementation

### Phase 1: Core Infrastructure (2-3 hours)

#### Step 1.1: Create ContextAnalyzer

**File:** `packages/core/src/context/ContextAnalyzer.ts` (new)


---

## Mode Transition Logic

### Keyword Detection

```typescript
const MODE_KEYWORDS = {
  planning: [
    // Planning keywords
    'plan', 'design', 'architecture', 'architect', 'strategy',
    'research', 'investigate', 'explore', 'analyze', 'study',
    'how should i', 'what\'s the best way', 'help me plan',
    'before we start', 'let\'s think about', 'approach',
    'pros and cons', 'compare', 'evaluate', 'consider',
    'roadmap', 'outline', 'structure', 'organize'
  ],
  
  developer: [
    // Implementation keywords
    'implement', 'write', 'create', 'build', 'code',
    'refactor', 'fix', 'debug', 'modify', 'update',
    'function', 'class', 'method', 'component',
    'let\'s implement', 'write the code', 'fix this bug',
    'add feature', 'change', 'edit', 'delete',
    
    // File operations
    'file', 'directory', 'folder', 'import', 'export',
    
    // Git operations
    'commit', 'push', 'pull', 'merge', 'branch'
  ],
  
  assistant: [
    // General conversation
    'what', 'why', 'how', 'when', 'where', 'who',
    'explain', 'describe', 'tell me', 'help me understand',
    'question', 'curious', 'wondering', 'interested'
  ]
};
```

### Mode Transition Rules

```typescript
interface ModeTransition {
  from: Mode;
  to: Mode;
  confidence: number;
  triggers: string[];
}

const TRANSITION_RULES: ModeTransition[] = [
  // Assistant → Planning
  {
    from: 'assistant',
    to: 'planning',
    confidence: 0.7,
    triggers: ['plan', 'design', 'research', 'how should']
  },
  
  // Planning → Developer
  {
    from: 'planning',
    to: 'developer',
    confidence: 0.8,
    triggers: ['implement', 'let\'s code', 'write', 'create']
  },
  
  // Developer → Planning (step back)
  {
    from: 'developer',
    to: 'planning',
    confidence: 0.6,
    triggers: ['wait', 'hold on', 'let\'s plan', 'rethink']
  },
  
  // Any → Assistant (reset)
  {
    from: '*',
    to: 'assistant',
    confidence: 0.5,
    triggers: ['chat', 'talk', 'discuss', 'explain']
  },
  
  // Any → Tool (explicit tool usage)
  {
    from: '*',
    to: 'tool',
    confidence: 0.9,
    triggers: ['<tool_call>', 'use tool', 'run command']
  }
];
```

### Confidence Scoring

```typescript
function calculateModeConfidence(
  messages: Message[],
  mode: Mode
): number {
  let score = 0;
  const recentMessages = messages.slice(-5);
  const keywords = MODE_KEYWORDS[mode];
  
  for (const msg of recentMessages) {
    const text = msg.content.toLowerCase();
    
    // Count keyword matches
    const matches = keywords.filter(kw => text.includes(kw)).length;
    score += matches * 0.15;
    
    // Boost for explicit mode requests
    if (text.includes(`switch to ${mode}`)) score += 0.5;
    if (text.includes(`${mode} mode`)) score += 0.4;
    
    // Check for code blocks (developer mode indicator)
    if (mode === 'developer' && text.includes('```')) score += 0.2;
    
    // Check for questions (assistant mode indicator)
    if (mode === 'assistant' && text.includes('?')) score += 0.1;
    
    // Check for tool usage (tool mode indicator)
    if (mode === 'tool' && text.includes('tool')) score += 0.3;
  }
  
  return Math.min(score, 1.0);
}
```

---

## Tool Filtering by Mode

### Tool Access Control

```typescript
interface ToolAccess {
  mode: Mode;
  allowedTools: string[];
  deniedTools: string[];
  readOnly: boolean;
}

const TOOL_ACCESS: Record<Mode, ToolAccess> = {
  assistant: {
    mode: 'assistant',
    allowedTools: [],
    deniedTools: ['*'], // No tools in assistant mode
    readOnly: true
  },
  
  planning: {
    mode: 'planning',
    allowedTools: [
      // Research tools
      'web_search',
      'web_fetch',
      
      // Read-only exploration
      'read_file',
      'read_multiple_files',
      'grep_search',
      'file_search',
      'list_directory',
      
      // Analysis tools
      'get_diagnostics'
    ],
    deniedTools: [
      // No writing
      'write_file',
      'fs_append',
      'str_replace',
      'delete_file',
      
      // No execution
      'execute_pwsh',
      'control_pwsh_process',
      
      // No git operations
      'git_*'
    ],
    readOnly: true
  },
  
  developer: {
    mode: 'developer',
    allowedTools: ['*'], // All tools
    deniedTools: [],
    readOnly: false
  },
  
  tool: {
    mode: 'tool',
    allowedTools: ['*'], // All tools
    deniedTools: [],
    readOnly: false
  }
};

function filterToolsForMode(
  tools: Tool[],
  mode: Mode
): Tool[] {
  const access = TOOL_ACCESS[mode];
  
  if (access.allowedTools.includes('*')) {
    return tools; // All tools allowed
  }
  
  return tools.filter(tool => {
    // Check if tool is explicitly allowed
    if (access.allowedTools.includes(tool.name)) {
      return true;
    }
    
    // Check if tool matches pattern (e.g., 'git_*')
    for (const pattern of access.allowedTools) {
      if (pattern.endsWith('*')) {
        const prefix = pattern.slice(0, -1);
        if (tool.name.startsWith(prefix)) {
          return true;
        }
      }
    }
    
    // Check if tool is explicitly denied
    if (access.deniedTools.includes(tool.name)) {
      return false;
    }
    
    // Check denied patterns
    for (const pattern of access.deniedTools) {
      if (pattern === '*') return false;
      if (pattern.endsWith('*')) {
        const prefix = pattern.slice(0, -1);
        if (tool.name.startsWith(prefix)) {
          return false;
        }
      }
    }
    
    return false;
  });
}
```

---

## UI Integration

### Update ActiveContextState

**File:** `packages/cli/src/features/context/ActiveContextState.tsx`

```typescript
interface ActiveContextState {
  activeSkills: string[];
  activeTools: string[];
  activeHooks: string[];
  activeMcpServers: string[];
  activePrompts: string[];
  currentPersona: string;
  currentMode: 'assistant' | 'planning' | 'developer' | 'tool'; // NEW
  contextStrategy: 'Standard' | 'Hot Swap';
}
```

### Update ContextSection Display

**File:** `packages/cli/src/ui/components/layout/ContextSection.tsx`

```typescript
export function ContextSection() {
  const { 
    currentPersona,
    currentMode, // NEW
    activeSkills, 
    activeTools, 
    activeHooks,
    activeMcpServers,
    activePrompts,
  } = useActiveContext();
  
  // Mode icons and colors
  const modeDisplay = {
    assistant: { icon: '💬', color: 'blue', label: 'Assistant' },
    planning: { icon: '📋', color: 'yellow', label: 'Planning' },
    developer: { icon: '👨‍💻', color: 'green', label: 'Developer' },
    tool: { icon: '🔧', color: 'cyan', label: 'Tool Expert' }
  };
  
  const mode = modeDisplay[currentMode] || modeDisplay.assistant;

  return (
    <Box flexDirection="row" width="100%">
      {/* Left Column */}
      <Box flexDirection="column" flexGrow={1} width="50%" paddingRight={1}>
        {/* Mode (NEW) */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="magenta" bold>Active Mode:</Text>
          <Text color={mode.color}>
            {mode.icon} {mode.label}
          </Text>
        </Box>
        
        {/* Persona */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="blue" bold>Persona:</Text>
          <Text>{currentPersona}</Text>
        </Box>

        {/* Prompts */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="red" bold>Active Prompts:</Text>
          {activePrompts.length === 0 ? (
            <Text dimColor>None</Text>
          ) : (
            activePrompts.map((prompt: string) => (
              <Text key={prompt}>- {prompt}</Text>
            ))
          )}
        </Box>

        {/* Skills */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="green" bold>Active Skills:</Text>
          {activeSkills.length === 0 ? (
            <Text dimColor>None</Text>
          ) : (
            activeSkills.map((skill: string) => (
              <Text key={skill}>- {skill}</Text>
            ))
          )}
        </Box>
      </Box>

      {/* Right Column */}
      <Box flexDirection="column" flexGrow={1} width="50%" paddingLeft={1}>
        {/* MCP */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="magenta" bold>MCP Servers:</Text>
          {activeMcpServers.length === 0 ? (
            <Text dimColor>None</Text>
          ) : (
            activeMcpServers.map((server: string) => (
              <Text key={server}>- {server}</Text>
            ))
          )}
        </Box>

        {/* Hooks */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="cyan" bold>Active Hooks:</Text>
          {activeHooks.length === 0 ? (
            <Text dimColor>None</Text>
          ) : (
            activeHooks.map((hook: string) => (
              <Text key={hook}>- {hook}</Text>
            ))
          )}
        </Box>

        {/* Tools */}
        <Box marginBottom={1} flexDirection="column">
          <Text color="yellow" bold>Active Tools:</Text>
          {activeTools.length === 0 ? (
            <Text dimColor>None</Text>
          ) : (
            activeTools.map((tool: string) => (
              <Text key={tool}>- {tool}</Text>
            ))
          )}
        </Box>
      </Box>
    </Box>
  );
}
```

---

## Manual Mode Switching

### Add /mode Command

**File:** `packages/cli/src/commands/contextCommands.ts`

```typescript
registry.register({
  name: '/mode',
  description: 'Switch prompt mode',
  subcommands: [
    {
      name: 'assistant',
      description: 'Switch to Assistant mode (general conversation)',
      execute: async () => {
        const modeManager = getGlobalModeManager();
        modeManager.forceMode('assistant');
        return { 
          success: true, 
          message: '💬 Switched to Assistant mode - General conversation' 
        };
      }
    },
    {
      name: 'planning',
      description: 'Switch to Planning mode (research & design, no coding)',
      execute: async () => {
        const modeManager = getGlobalModeManager();
        modeManager.forceMode('planning');
        return { 
          success: true, 
          message: '📋 Switched to Planning mode - Research & design (read-only)' 
        };
      }
    },
    {
      name: 'developer',
      description: 'Switch to Developer mode (full coding access)',
      execute: async () => {
        const modeManager = getGlobalModeManager();
        modeManager.forceMode('developer');
        return { 
          success: true, 
          message: '👨‍💻 Switched to Developer mode - Full coding access' 
        };
      }
    },
    {
      name: 'auto',
      description: 'Enable automatic mode switching (default)',
      execute: async () => {
        const modeManager = getGlobalModeManager();
        modeManager.enableAutoSwitch();
        return { 
          success: true, 
          message: '🔄 Automatic mode switching enabled' 
        };
      }
    },
    {
      name: 'status',
      description: 'Show current mode',
      execute: async () => {
        const modeManager = getGlobalModeManager();
        const mode = modeManager.getCurrentMode();
        const auto = modeManager.isAutoSwitchEnabled();
        
        const modeInfo = {
          assistant: '💬 Assistant - General conversation',
          planning: '📋 Planning - Research & design (read-only)',
          developer: '👨‍💻 Developer - Full coding access',
          tool: '🔧 Tool Expert - Enhanced tool usage'
        };
        
        return {
          success: true,
          message: `Current mode: ${modeInfo[mode]}\nAuto-switch: ${auto ? 'Enabled' : 'Disabled'}`
        };
      }
    }
  ]
});
```

---

## Example Workflows

### Workflow 1: Research → Plan → Implement

```
User: "I want to add authentication to my app"
→ Assistant Mode (default)

User: "Help me plan the authentication system"
→ Planning Mode (keyword: "plan")
→ Can use: web_search, read_file, grep_search
→ Cannot: write_file, shell, git

AI: [Researches auth patterns, reads existing code, creates plan]

User: "Great! Let's implement it"
→ Developer Mode (keyword: "implement")
→ Can use: All tools

AI: [Writes code, runs tests, commits changes]
```

### Workflow 2: Quick Question

```
User: "What's the difference between JWT and sessions?"
→ Assistant Mode (general question)
→ No tools needed

AI: [Explains concepts clearly]

User: "Which should I use for my API?"
→ Still Assistant Mode (discussion)

AI: [Provides guidance]
```

### Workflow 3: Debug Issue

```
User: "My tests are failing"
→ Developer Mode (problem-solving)

AI: [Reads test files, analyzes errors]

User: "Let's plan how to fix this systematically"
→ Planning Mode (keyword: "plan")

AI: [Creates debugging strategy, identifies root causes]

User: "Okay, fix it"
→ Developer Mode (keyword: "fix")

AI: [Implements fixes, runs tests]
```

---

## Summary

### Four Modes

1. **💬 Assistant** - General conversation, no tools
2. **📋 Planning** - Research & design, read-only tools
3. **👨‍💻 Developer** - Full implementation, all tools
4. **🔧 Tool Expert** - Enhanced tool usage, all tools

### Key Features

- ✅ Automatic mode detection based on keywords
- ✅ Manual mode switching with `/mode` command
- ✅ Tool filtering per mode (Planning = read-only)
- ✅ UI display of current mode in right panel
- ✅ Smooth transitions between modes
- ✅ Hysteresis to prevent rapid switching

### Benefits

- **Planning Mode** prevents premature coding
- **Tool restrictions** enforce proper workflow
- **Clear visual feedback** shows current mode
- **Flexible switching** (auto or manual)
- **Better AI behavior** with context-appropriate prompts

---

**Next Step:** Implement Phase 1 - Core infrastructure (ContextAnalyzer, DynamicPromptComposer, PromptModeManager)
