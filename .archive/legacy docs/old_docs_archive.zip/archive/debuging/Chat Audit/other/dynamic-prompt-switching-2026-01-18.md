# Dynamic Prompt Switching - Design Document

**Date:** January 18, 2026  
**Status:** Design Phase  
**Priority:** High

## Overview

Implement context-aware system prompt switching that adapts the AI's persona and capabilities based on conversation context:

- **Assistant Mode** (Default): General conversational AI for questions, explanations, discussions
- **Developer Mode**: Senior software engineer for coding tasks, architecture, debugging
- **Tool Mode**: Enhanced tool awareness when tools are actively being used

## Design Principles

1. **Seamless Transitions**: Switch modes automatically based on context
2. **No User Friction**: User doesn't need to manually switch modes
3. **Context Preservation**: Mode switches don't lose conversation history
4. **Tool Awareness**: Always inject tool schemas when tools are available

## Mode Definitions

### 1. Assistant Mode (Default)

**Trigger Conditions:**
- Initial conversation start
- User asks general questions (not code-related)
- No coding keywords detected in recent messages
- No tool calls in last N turns

**Prompt Components:**
```
[Identity: Helpful AI Assistant]
[Capabilities: General knowledge, explanations, discussions]
[Tone: Friendly, conversational, educational]
[Tools: Available but not emphasized]
```

**Example Prompt:**
```markdown
You are a helpful AI assistant. You can answer questions, explain concepts, 
and have natural conversations. You have access to tools when needed, but 
focus on being conversational and helpful.

When the user asks about coding, software development, or technical topics,
you can provide detailed technical assistance.
```

### 2. Developer Mode

**Trigger Conditions:**
- User mentions: code, function, class, bug, error, implement, refactor, debug
- User asks to create/modify files
- User discusses architecture, design patterns, algorithms
- Tool calls related to file operations, git, shell

**Prompt Components:**
```
[Identity: Senior Software Engineer]
[Capabilities: Code review, architecture, debugging, best practices]
[Tone: Professional, precise, technical]
[Tools: Emphasized for file ops, git, shell, search]
[Context: Project structure, tech stack, coding standards]
```

**Example Prompt:**
```markdown
You are a senior software engineer and architect. You write clean, maintainable,
well-tested code following best practices. You understand the full stack and
can work across languages and frameworks.

Current Project Context:
- Tech Stack: {detected from workspace}
- Available Tools: {file ops, git, shell, search}
- Coding Standards: {from workspace config}

When writing code:
- Follow the project's existing patterns
- Write tests when appropriate
- Consider edge cases and error handling
- Explain your reasoning for architectural decisions
```

### 3. Tool Mode (Enhanced)

**Trigger Conditions:**
- Tool call just executed
- User explicitly requests tool usage
- Complex multi-step task requiring tools

**Prompt Components:**
```
[Identity: Current mode + Tool Expert]
[Tool Schemas: Full tool definitions]
[Tool Usage: Best practices, when to use each tool]
[Tool Chaining: How to combine tools effectively]
```

**Example Prompt:**
```markdown
{Base mode prompt}

TOOL USAGE GUIDELINES:

Available Tools:
{Full tool schemas with descriptions}

Tool Selection:
- Use read_file for reading single files
- Use grep_search for finding patterns across files
- Use shell for running commands
- Always confirm destructive operations

Tool Chaining:
- Search → Read → Analyze → Modify → Test
- Git status → Review changes → Commit
```

## Implementation Architecture

### 1. Context Analyzer

```typescript
interface ContextAnalysis {
  mode: 'assistant' | 'developer' | 'tool';
  confidence: number;
  triggers: string[];
  metadata: {
    codingKeywords: string[];
    toolsUsed: string[];
    recentTopics: string[];
  };
}

class ContextAnalyzer {
  analyzeConversation(messages: Message[]): ContextAnalysis {
    // Analyze last N messages for context
    // Detect coding keywords, tool usage, topics
    // Return recommended mode
  }
  
  shouldSwitchMode(
    currentMode: string,
    analysis: ContextAnalysis
  ): boolean {
    // Hysteresis: require confidence threshold to switch
    // Avoid rapid mode switching
  }
}
```

### 2. Prompt Composer

```typescript
interface PromptTemplate {
  mode: string;
  identity: string;
  capabilities: string;
  tone: string;
  tools?: string;
  context?: string;
}

class DynamicPromptComposer {
  private templates: Map<string, PromptTemplate>;
  private contextAnalyzer: ContextAnalyzer;
  
  composePrompt(
    mode: string,
    tools: Tool[],
    workspaceContext: WorkspaceContext
  ): string {
    const template = this.templates.get(mode);
    
    // Compose prompt from template
    let prompt = this.renderTemplate(template);
    
    // Add tool schemas if tools available
    if (tools.length > 0) {
      prompt += this.renderToolSchemas(tools);
    }
    
    // Add workspace context
    if (workspaceContext) {
      prompt += this.renderWorkspaceContext(workspaceContext);
    }
    
    return prompt;
  }
  
  private renderTemplate(template: PromptTemplate): string {
    // Render template with variables
  }
  
  private renderToolSchemas(tools: Tool[]): string {
    // Format tool schemas for prompt
  }
  
  private renderWorkspaceContext(context: WorkspaceContext): string {
    // Add project-specific context
  }
}
```

### 3. Mode Manager

```typescript
class PromptModeManager {
  private currentMode: string = 'assistant';
  private analyzer: ContextAnalyzer;
  private composer: DynamicPromptComposer;
  private modeHistory: Array<{mode: string; timestamp: number}> = [];
  
  async updatePrompt(
    messages: Message[],
    tools: Tool[],
    workspace: WorkspaceContext
  ): Promise<{prompt: string; modeChanged: boolean}> {
    // Analyze conversation context
    const analysis = this.analyzer.analyzeConversation(messages);
    
    // Check if mode should switch
    const shouldSwitch = this.analyzer.shouldSwitchMode(
      this.currentMode,
      analysis
    );
    
    let modeChanged = false;
    if (shouldSwitch) {
      this.currentMode = analysis.mode;
      this.modeHistory.push({
        mode: analysis.mode,
        timestamp: Date.now()
      });
      modeChanged = true;
    }
    
    // Compose prompt for current mode
    const prompt = this.composer.composePrompt(
      this.currentMode,
      tools,
      workspace
    );
    
    return {prompt, modeChanged};
  }
  
  getCurrentMode(): string {
    return this.currentMode;
  }
  
  forceMode(mode: string): void {
    this.currentMode = mode;
  }
}
```

## Keyword Detection

### Coding Keywords (Trigger Developer Mode)

```typescript
const CODING_KEYWORDS = [
  // Actions
  'implement', 'refactor', 'debug', 'fix', 'optimize', 'test',
  'create', 'modify', 'update', 'delete', 'write', 'read',
  
  // Concepts
  'function', 'class', 'method', 'variable', 'constant',
  'interface', 'type', 'enum', 'struct',
  'algorithm', 'pattern', 'architecture',
  
  // Problems
  'bug', 'error', 'exception', 'crash', 'issue',
  'warning', 'lint', 'compile', 'build',
  
  // Tools
  'git', 'commit', 'branch', 'merge', 'pull', 'push',
  'npm', 'yarn', 'pip', 'cargo', 'maven',
  
  // Languages
  'typescript', 'javascript', 'python', 'rust', 'go',
  'java', 'c++', 'c#', 'ruby', 'php',
  
  // File operations
  'file', 'directory', 'folder', 'path', 'import', 'export'
];
```

### General Keywords (Keep Assistant Mode)

```typescript
const GENERAL_KEYWORDS = [
  'what', 'why', 'how', 'when', 'where', 'who',
  'explain', 'describe', 'tell me', 'help me understand',
  'question', 'curious', 'wondering', 'interested'
];
```

## Mode Switching Logic

### Hysteresis (Prevent Rapid Switching)

```typescript
interface ModeSwitchConfig {
  minConfidence: number;      // 0.7 = 70% confidence required
  minDuration: number;         // Stay in mode for at least 30s
  lookbackWindow: number;      // Analyze last 5 messages
  cooldownPeriod: number;      // Wait 10s between switches
}

const DEFAULT_CONFIG: ModeSwitchConfig = {
  minConfidence: 0.7,
  minDuration: 30000,  // 30 seconds
  lookbackWindow: 5,
  cooldownPeriod: 10000  // 10 seconds
};
```

### Confidence Scoring

```typescript
function calculateModeConfidence(
  messages: Message[],
  mode: 'assistant' | 'developer'
): number {
  let score = 0;
  const recentMessages = messages.slice(-5);
  
  for (const msg of recentMessages) {
    const text = msg.content.toLowerCase();
    
    if (mode === 'developer') {
      // Count coding keywords
      const codingMatches = CODING_KEYWORDS.filter(kw => 
        text.includes(kw)
      ).length;
      score += codingMatches * 0.2;
      
      // Check for code blocks
      if (text.includes('```')) score += 0.3;
      
      // Check for file paths
      if (/\.(ts|js|py|rs|go|java)/.test(text)) score += 0.2;
      
    } else {
      // Count general keywords
      const generalMatches = GENERAL_KEYWORDS.filter(kw =>
        text.includes(kw)
      ).length;
      score += generalMatches * 0.2;
      
      // No code blocks
      if (!text.includes('```')) score += 0.1;
    }
  }
  
  return Math.min(score, 1.0);
}
```

## Integration Points

### 1. ChatClient Integration

```typescript
// packages/core/src/core/chatClient.ts

class ChatClient {
  private modeManager: PromptModeManager;
  
  async sendMessage(message: string): Promise<void> {
    // Update system prompt based on context
    const {prompt, modeChanged} = await this.modeManager.updatePrompt(
      this.messages,
      this.tools,
      this.workspaceContext
    );
    
    // Show mode change indicator
    if (modeChanged) {
      this.emit('mode-changed', this.modeManager.getCurrentMode());
    }
    
    // Send to provider with updated prompt
    const response = await this.provider.chat({
      systemPrompt: prompt,
      messages: this.messages,
      tools: this.tools
    });
  }
}
```

### 2. UI Integration

```typescript
// packages/cli/src/ui/components/StatusBar.tsx

function StatusBar() {
  const {currentMode} = useChatContext();
  
  return (
    <Box>
      <Text>Mode: </Text>
      <Text color={getModeColor(currentMode)}>
        {currentMode === 'assistant' ? '💬' : '👨‍💻'} {currentMode}
      </Text>
    </Box>
  );
}
```

### 3. Command Integration

```typescript
// Allow manual mode switching
/mode assistant   // Switch to assistant mode
/mode developer   // Switch to developer mode
/mode auto        // Enable automatic switching (default)
```

## Prompt Templates

### Assistant Template

```markdown
You are a helpful AI assistant. You can:
- Answer questions about any topic
- Explain concepts clearly
- Have natural conversations
- Help with research and learning

You have access to tools when needed, but your primary focus is being 
conversational and helpful. When users ask about technical topics, you 
can provide detailed assistance.

Keep responses friendly and accessible.
```

### Developer Template

```markdown
You are a senior software engineer with expertise across the full stack.

IDENTITY:
- Expert in software architecture and design patterns
- Proficient in multiple programming languages
- Focused on code quality, testing, and maintainability
- Pragmatic problem solver

CURRENT PROJECT:
- Tech Stack: {workspace.techStack}
- Languages: {workspace.languages}
- Frameworks: {workspace.frameworks}

CODING PRINCIPLES:
- Write clean, readable, well-documented code
- Follow existing project patterns and conventions
- Consider edge cases and error handling
- Test critical functionality
- Explain architectural decisions

AVAILABLE TOOLS:
{tool_schemas}

When working with code:
1. Understand the context before making changes
2. Use tools to explore the codebase
3. Make minimal, focused changes
4. Test your changes
5. Explain your reasoning
```

### Tool-Enhanced Template

```markdown
{base_mode_template}

TOOL USAGE GUIDELINES:

Available Tools:
{detailed_tool_schemas}

Tool Selection Strategy:
- read_file: Read single files when you know the path
- grep_search: Search across files for patterns
- file_search: Find files by name
- list_directory: Explore directory structure
- shell: Run commands, tests, builds
- git_*: Version control operations

Tool Chaining Patterns:
1. Explore → Analyze → Modify → Verify
   - list_directory → read_file → str_replace → shell (test)

2. Search → Read → Understand
   - grep_search → read_file → analyze

3. Git Workflow
   - git_status → git_diff → git_commit

Best Practices:
- Always read files before modifying
- Use grep_search for finding code patterns
- Verify changes with tests when possible
- Commit logical units of work
```

## Configuration

### User Configuration

```yaml
# .ollm/config.yaml

prompt:
  mode: auto  # auto | assistant | developer
  
  switching:
    enabled: true
    confidence_threshold: 0.7
    min_duration: 30000
    cooldown: 10000
  
  templates:
    assistant: ~/.ollm/prompts/assistant.md
    developer: ~/.ollm/prompts/developer.md
  
  context:
    include_workspace: true
    include_git_status: true
    include_tech_stack: true
```

## Implementation Phases

### Phase 1: Core Infrastructure (2-3 hours)
- [ ] Create ContextAnalyzer class
- [ ] Create DynamicPromptComposer class
- [ ] Create PromptModeManager class
- [ ] Define keyword lists
- [ ] Implement confidence scoring

### Phase 2: Prompt Templates (1-2 hours)
- [ ] Create assistant template
- [ ] Create developer template
- [ ] Create tool-enhanced template
- [ ] Add template variables
- [ ] Test template rendering

### Phase 3: Integration (2-3 hours)
- [ ] Integrate with ChatClient
- [ ] Add mode change events
- [ ] Update UI to show current mode
- [ ] Add /mode command
- [ ] Test mode switching

### Phase 4: Configuration (1 hour)
- [ ] Add config schema
- [ ] Load user templates
- [ ] Support custom keywords
- [ ] Add mode switching settings

### Phase 5: Testing & Refinement (2-3 hours)
- [ ] Test mode detection accuracy
- [ ] Tune confidence thresholds
- [ ] Test hysteresis logic
- [ ] User testing and feedback
- [ ] Documentation

## Success Metrics

1. **Mode Detection Accuracy**: >90% correct mode for conversation type
2. **Switch Frequency**: <1 switch per 5 minutes (avoid thrashing)
3. **User Satisfaction**: Users don't notice/need to manually switch
4. **Tool Usage**: Appropriate tool usage in developer mode

## Future Enhancements

1. **More Modes**:
   - Reviewer mode (code review focus)
   - Debugger mode (debugging focus)
   - Architect mode (high-level design)

2. **ML-Based Detection**:
   - Train classifier on conversation patterns
   - Learn from user corrections
   - Personalized mode preferences

3. **Context Memory**:
   - Remember user's typical workflow
   - Predict mode based on time of day
   - Learn project-specific patterns

4. **Workspace Profiles**:
   - Different modes per project type
   - Custom templates per workspace
   - Team-shared prompt configurations

## References

- Gemini CLI system prompt architecture
- SystemPromptBuilder implementation
- PromptRegistry design
- Tool schema documentation

---

**Next Steps:**
1. Review and approve design
2. Implement Phase 1 (core infrastructure)
3. Create prompt templates
4. Test with real conversations
