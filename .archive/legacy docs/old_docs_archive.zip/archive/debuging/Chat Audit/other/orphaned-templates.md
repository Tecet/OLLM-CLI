# Orphaned Template Files - Cleanup Recommendation

**Date:** 2026-01-18  
**Context:** Test cleanup revealed unused template files

---

## Orphaned Files Found

The following template files exist in `packages/core/src/prompts/templates/modes/` but are **NOT exported** in `index.ts` and **NOT in the ModeType** union:

1. `tool.ts` - Tool mode template (merged into developer)
2. `security.ts` - Security mode template (merged into reviewer)
3. `performance.ts` - Performance mode template (merged into debugger)
4. `prototype.ts` - Prototype mode template (merged into developer)
5. `teacher.ts` - Teacher mode template (merged into assistant)

---

## Current State

**Active Modes (5):**
- `assistant.ts` ✅ Exported
- `planning.ts` ✅ Exported
- `developer.ts` ✅ Exported
- `debugger.ts` ✅ Exported
- `reviewer.ts` ✅ Exported

**Orphaned (5):**
- `tool.ts` ❌ Not exported, not in ModeType
- `security.ts` ❌ Not exported, not in ModeType
- `performance.ts` ❌ Not exported, not in ModeType
- `prototype.ts` ❌ Not exported, not in ModeType
- `teacher.ts` ❌ Not exported, not in ModeType

---

## Verification

**Source of Truth:**
```typescript
// packages/core/src/prompts/ContextAnalyzer.ts
export type ModeType =
  | 'assistant'
  | 'planning'
  | 'developer'
  | 'debugger'
  | 'reviewer';  // Only 5 modes
```

**Exports:**
```typescript
// packages/core/src/prompts/templates/modes/index.ts
export {
  ASSISTANT_MODE_TEMPLATE,
  PLANNING_MODE_TEMPLATE,
  DEVELOPER_MODE_TEMPLATE,
  DEBUGGER_MODE_TEMPLATE,
  REVIEWER_MODE_TEMPLATE
};  // Only 5 templates exported
```

---

## Recommendation

### Option 1: Delete Orphaned Files (Recommended)
**Pros:**
- Clean codebase
- No confusion about which modes exist
- Reduces maintenance burden

**Cons:**
- Lose historical templates (can recover from git)

**Action:**
```bash
# Delete orphaned template files
rm packages/core/src/prompts/templates/modes/tool.ts
rm packages/core/src/prompts/templates/modes/security.ts
rm packages/core/src/prompts/templates/modes/performance.ts
rm packages/core/src/prompts/templates/modes/prototype.ts
rm packages/core/src/prompts/templates/modes/teacher.ts
```

### Option 2: Keep for Reference
**Pros:**
- Preserve templates for potential future use
- Historical reference

**Cons:**
- Confusing - files exist but aren't used
- May cause future bugs if someone tries to use them

**Action:**
- Move to `.archive/` or `.deprecated/` folder
- Add README explaining they're deprecated

---

## Decision Needed

**Question for user:** Should we delete these 5 orphaned template files?

**My recommendation:** **Delete them**
- They're not in the type system
- They're not exported
- Git history preserves them if needed
- Cleaner codebase

---

## Impact

**If deleted:**
- ✅ Cleaner codebase
- ✅ No risk of accidental use
- ✅ Matches current 5-mode system
- ✅ Can always recover from git

**If kept:**
- ⚠️ Potential confusion
- ⚠️ May cause future bugs
- ⚠️ Maintenance burden
