# Tools and Hooks Comprehensive Audit

**Date:** January 19, 2026  
**Status:** Consolidated from 3 previous audits + fresh analysis  
**Scope:** Complete tools and hooks subsystems including registries, execution, UI integration, extensions, and MCP integration

---

## Executive Summary

The tools and hooks subsystems suffer from **severe architectural disconnects** between core services and UI components. Critical issues include:

1. **No central ToolRegistry in ServiceContainer** - Tools registered in isolated instances
2. **UI HooksProvider creates its own registry** - Disconnected from core HookService
3. **CLI bypasses ChatClient** - Tool execution logic in core is unused
4. **HookPlanner constructed incorrectly** - Missing required registry parameter
5. **Ephemeral ToolRegistry per message** - Fragile and racy

**Impact:** Tools and hooks appear to work in UI but don't execute in runtime. Extensions can't register tools/hooks properly. Users see tools that don't exist and hooks that never run.

**Recommendation:** Immediate architectural fixes required before system is functional. Estimated 2-3 weeks to establish proper service wiring.

---

## Architecture Overview

### Current (Broken) Flow
```
UI (HooksProvider) → Local HookRegistry (isolated)
UI (ToolsPanel) → Static Config (not dynamic registry)
CLI (ChatContext) → New ToolRegistry() per message (ephemeral)
Core (ServiceContainer) → No ToolRegistry getter
Extensions → ExtensionManager (no registries provided)
```

### Expected (Correct) Flow
```
ServiceContainer → Central ToolRegistry (singleton)
                → Central HookRegistry (singleton)
                ↓
UI (HooksProvider) → Uses central HookRegistry
UI (ToolsPanel) → Uses central ToolRegistry
CLI (ChatContext) → Uses central ToolRegistry
Extensions → ExtensionManager (receives registries)
```

---

## Critical Issues

### 1. ServiceContainer Missing ToolRegistry (CRITICAL)
**Location:** `packages/core/src/services/serviceContainer.ts`

**Issue:** No ToolRegistry initialization or getter method

**Evidence:**
```typescript
// ServiceContainer has these getters:
getModelManagementService()
getModelRouter()
getMemoryService()
getTemplateService()
getHookService()
getExtensionManager()
// But NO getToolRegistry()!
```

**Impact:**
- No central tool registry exists
- Each component creates its own isolated registry
- Tools registered in one place don't appear in another
- Extension tools can't be discovered
- MCP tools can't be integrated

**Severity:** CRITICAL - Blocks all tool functionality

**Recommendation:**
```typescript
// Add to ServiceContainer:
private _toolRegistry?: ToolRegistry;

getToolRegistry(): ToolRegistry {
  if (!this._toolRegistry) {
    const settingsService = SettingsService.getInstance();
    this._toolRegistry = new ToolRegistry(settingsService);
    
    // Register built-in tools
    registerBuiltInTools(this._toolRegistry);
  }
  return this._toolRegistry;
}
```

**Effort:** 1 day  
**Priority:** P0

---

### 2. UI HooksProvider Disconnected from Core (CRITICAL)
**Location:** `packages/cli/src/ui/contexts/HooksContext.tsx:95`

**Issue:** Creates its own HookRegistry instead of using HookService's registry

**Evidence:**
```typescript
export function HooksProvider({ children }: HooksProviderProps) {
  const hookRegistry = new HookRegistry(); // WRONG! Creates isolated registry
  // Should use: const hookRegistry = hookService.getRegistry();
  
  useEffect(() => {
    loadHooksFromFiles(hookRegistry); // Loads into isolated registry
  }, []);
}
```

**Impact:**
- Hooks shown in UI never execute in runtime
- HookService has different hooks than UI shows
- User-created hooks don't trigger on events
- Extension hooks invisible to UI

**Severity:** CRITICAL - Hooks don't work

**Recommendation:**
```typescript
export function HooksProvider({ children }: HooksProviderProps) {
  const serviceContext = useServiceContext();
  const hookService = serviceContext.getHookService();
  const hookRegistry = hookService.getRegistry(); // Use central registry
  
  useEffect(() => {
    loadHooksFromFiles(hookRegistry); // Loads into central registry
  }, [hookRegistry]);
}
```

**Effort:** 1 day  
**Priority:** P0

---

### 3. CLI Bypasses ChatClient (CRITICAL)
**Location:** `packages/cli/src/features/context/ModelContext.tsx:720`

**Issue:** Uses `provider.chatStream()` directly instead of ChatClient with tool support

**Evidence:**
```typescript
// ModelContext.sendToLLM() calls provider directly:
const stream = provider.chatStream({
  model: currentModel,
  messages: providerMessages,
  tools: tools && tools.length > 0 && modelSupportsTools(currentModel) ? tools : undefined,
  // ...
});

// ChatClient with tool execution logic is never used!
```

**Impact:**
- Tool execution logic in `packages/core/src/core/chatClient.ts` is dead code
- ~600 lines of unused tool handling code
- No event emission for hooks
- Tool calls handled manually in ChatContext

**Severity:** CRITICAL - Architecture mismatch

**Recommendation:**
- Refactor ModelContext to use ChatClient
- Or remove ChatClient if CLI pattern is preferred
- Document architectural decision

**Effort:** 3-5 days  
**Priority:** P0

---

### 4. HookPlanner Constructor Bug (CRITICAL)
**Location:** `packages/core/src/services/hookService.ts:59`

**Issue:** HookPlanner instantiated without required HookRegistry parameter

**Evidence:**
```typescript
// In HookService constructor:
this.planner = new HookPlanner(); // Missing registry parameter!

// HookPlanner constructor expects:
constructor(private registry: HookRegistry) { ... }
```

**Impact:**
- Runtime error when planner methods are called
- Planner operates with undefined registry
- Hook planning fails silently or crashes

**Severity:** CRITICAL - Runtime crash

**Recommendation:**
```typescript
// In HookService constructor:
this.planner = new HookPlanner(this.registry);
```

**Effort:** 5 minutes  
**Priority:** P0

---

### 5. Ephemeral ToolRegistry Per Message (HIGH)
**Location:** `packages/cli/src/features/context/ChatContext.tsx`

**Issue:** Creates new ToolRegistry for each message

**Evidence:**
```typescript
// In ChatContext.sendMessage():
const toolRegistry = new ToolRegistry(settingsService); // New instance!
toolRegistry.register(new HotSwapTool());
toolRegistry.register(new MemoryDumpTool());
const toolSchemas = toolRegistry.getFunctionSchemasForMode(...);
```

**Impact:**
- Tools vary per message
- No stable global registry
- Extension tools not included
- MCP tools not included
- Race conditions possible

**Severity:** HIGH - Fragile and incorrect

**Recommendation:**
```typescript
// Use central registry:
const toolRegistry = serviceContainer.getToolRegistry();
const toolSchemas = toolRegistry.getFunctionSchemasForMode(...);
```

**Effort:** 1 day  
**Priority:** P0

---

### 6. ToolsPanel Uses Static Config (HIGH)
**Location:** `packages/cli/src/ui/components/tools/ToolsPanel.tsx`

**Issue:** UI shows tools from static config, not dynamic registry

**Evidence:**
```typescript
// ToolsPanel uses:
import { getToolsByCategory } from '../../config/toolsConfig.js';

// Instead of:
const tools = toolRegistry.list();
```

**Impact:**
- UI shows hardcoded tool list
- Dynamic tools (MCP, extensions) don't appear
- UI and runtime tool lists differ
- Enable/disable state disconnected

**Severity:** HIGH - UI/runtime mismatch

**Recommendation:**
```typescript
// ToolsPanel should:
const toolRegistry = useServiceContext().getToolRegistry();
const tools = toolRegistry.list();
const enabledTools = toolRegistry.getEnabledTools();
```

**Effort:** 2 days  
**Priority:** P1

---

### 7. ExtensionManager Not Wired to Registries (HIGH)
**Location:** `packages/core/src/services/serviceContainer.ts:180-200`

**Issue:** ExtensionManager created without hook/tool registries

**Evidence:**
```typescript
getExtensionManager(): ExtensionManager {
  if (!this._extensionManager) {
    this._extensionManager = new ExtensionManager([
      userExtensionsDir,
      workspaceExtensionsDir,
    ]);
    // Missing: hookRegistry, toolRegistry, mcpToolWrapper parameters!
  }
  return this._extensionManager;
}
```

**Impact:**
- Extensions can't register hooks
- Extensions can't register tools
- Extension functionality broken
- MCP tools can't be wrapped

**Severity:** HIGH - Extensions don't work

**Recommendation:**
```typescript
getExtensionManager(): ExtensionManager {
  if (!this._extensionManager) {
    const hookRegistry = this.getHookService().getRegistry();
    const toolRegistry = this.getToolRegistry();
    const mcpToolWrapper = new MCPToolWrapper();
    
    this._extensionManager = new ExtensionManager(
      [userExtensionsDir, workspaceExtensionsDir],
      hookRegistry,
      toolRegistry,
      mcpToolWrapper
    );
  }
  return this._extensionManager;
}
```

**Effort:** 1 day  
**Priority:** P0

---

### 8. Built-in Tools Not Registered (HIGH)
**Location:** `packages/core/src/tools/index.ts`

**Issue:** `registerBuiltInTools()` function exists but never called

**Evidence:**
```typescript
// Function defined:
export function registerBuiltInTools(registry: ToolRegistry): void {
  registry.register(new ReadFileTool());
  registry.register(new WriteFileTool());
  // ... more tools
}

// But never called in ServiceContainer or anywhere!
```

**Impact:**
- No tools available in runtime
- Only tools registered per-message in ChatContext
- Built-in tools missing from UI

**Severity:** HIGH - No tools available

**Recommendation:**
```typescript
// Call in ServiceContainer.getToolRegistry():
getToolRegistry(): ToolRegistry {
  if (!this._toolRegistry) {
    this._toolRegistry = new ToolRegistry(settingsService);
    registerBuiltInTools(this._toolRegistry); // Add this!
  }
  return this._toolRegistry;
}
```

**Effort:** 5 minutes  
**Priority:** P0

---

### 9. Hook Events Not Emitted in CLI (HIGH)
**Location:** `packages/cli/src/features/context/ModelContext.tsx`

**Issue:** CLI doesn't emit hook events that core expects

**Evidence:**
```typescript
// ChatClient emits events like:
messageBus.emit('before_agent', { ... });
messageBus.emit('after_tool', { ... });

// But CLI uses provider directly, no event emission!
```

**Impact:**
- Hooks never execute
- HookService listens for events but they never come
- Hook system completely non-functional in CLI

**Severity:** HIGH - Hooks don't work

**Recommendation:**
- Emit events in ModelContext.sendToLLM()
- Or use ChatClient which emits events
- Document event emission requirements

**Effort:** 2-3 days  
**Priority:** P1

---

### 10. HookRunner Stream Error Handling (MEDIUM)
**Location:** `packages/core/src/hooks/hookRunner.ts:140-160`

**Issue:** Throws inside stream event handlers

**Evidence:**
```typescript
child.stdout?.on('data', (data) => {
  const chunk = data.toString();
  outputSize += chunk.length;
  
  if (outputSize > MAX_OUTPUT_SIZE) {
    child?.kill('SIGTERM');
    throw new Error(`Hook output exceeded ${MAX_OUTPUT_SIZE} bytes`); // WRONG!
  }
  
  stdout += chunk;
});
```

**Problems:**
- Throwing inside async event callbacks not caught by outer try/catch
- Can produce unhandled exceptions
- Process may not be cleaned up properly

**Impact:**
- Unhandled promise rejections
- Process leaks
- Inconsistent error handling

**Severity:** MEDIUM - Reliability issue

**Recommendation:**
```typescript
child.stdout?.on('data', (data) => {
  const chunk = data.toString();
  outputSize += chunk.length;
  
  if (outputSize > MAX_OUTPUT_SIZE) {
    child?.kill('SIGTERM');
    // Don't throw! Set error flag and handle in exit handler
    outputExceeded = true;
    return;
  }
  
  stdout += chunk;
});
```

**Effort:** 1 day  
**Priority:** P2

---

### 11. Command Whitelist Contains Invalid Entry (LOW)
**Location:** `packages/core/src/hooks/hookRunner.ts:117`

**Issue:** `"uvx"` in command whitelist appears to be typo

**Evidence:**
```typescript
private isWhitelistedCommand(command: string): boolean {
  const whitelist = ['node', 'python', 'python3', 'bash', 'sh', 'npx', 'uvx'];
  return whitelist.includes(command);
}
```

**Problems:**
- `uvx` is not a standard command
- Likely meant to be `uv` (Python package installer)
- No usage evidence in codebase

**Impact:**
- Potential security issue if `uvx` is malicious
- Confusion for developers

**Severity:** LOW - Security/clarity issue

**Recommendation:**
- Remove `uvx` or confirm intent
- Document whitelist rationale
- Consider making whitelist configurable

**Effort:** 5 minutes  
**Priority:** P3

---

### 12. TrustedHooks Path Validation Flawed (LOW)
**Location:** `packages/core/src/hooks/trustedHooks.ts:95`

**Issue:** Path validation logic has unclear precedence

**Evidence:**
```typescript
if (hook.sourcePath && hook.sourcePath.includes('/') || hook.sourcePath?.includes('\\'))
```

**Problems:**
- Operator precedence unclear
- Should be: `(hook.sourcePath && (hook.sourcePath.includes('/') || hook.sourcePath.includes('\\')))`
- Current logic: `(hook.sourcePath && hook.sourcePath.includes('/')) || hook.sourcePath?.includes('\\')`

**Impact:**
- Incorrect file reading decisions
- Potential security issue

**Severity:** LOW - Logic error

**Recommendation:**
```typescript
if (hook.sourcePath && (hook.sourcePath.includes('/') || hook.sourcePath.includes('\\')))
```

**Effort:** 5 minutes  
**Priority:** P3

---

### 13. MockMessageBus Type Mismatch in Tests (LOW)
**Location:** `packages/core/src/tools/__tests__/edit-file.test.ts`

**Issue:** Tests pass MockMessageBus where ToolContext expects MessageBus

**Evidence:**
- TypeScript errors show missing `messageBus` property
- Tests use `createToolContext()` inconsistently
- MockMessageBus implements MessageBus but lacks required ToolContext properties

**Impact:**
- Test compilation failures
- Tests may not catch real issues

**Severity:** LOW - Test quality issue

**Recommendation:**
- Update MockMessageBus to match ToolContext interface
- Use consistent test helper functions
- Fix TypeScript errors

**Effort:** 1 day  
**Priority:** P3

---

## Additional Findings

### 14. Hook Approval UX Missing
**Issue:** No UI for approving untrusted hooks

**Impact:**
- Hooks fail silently without approval
- No user feedback for trust decisions
- Workspace hooks don't work

**Severity:** MEDIUM

**Recommendation:**
- Add approval dialog in UI
- Show hook details before approval
- Persist approval decisions

**Effort:** 2-3 days  
**Priority:** P2

---

### 15. Tool State Persistence Disconnect
**Issue:** Tool enabled state in settings not connected to registry filtering

**Impact:**
- Inconsistent tool availability
- Settings changes don't affect runtime
- UI and runtime state diverge

**Severity:** MEDIUM

**Recommendation:**
- Connect SettingsService to ToolRegistry via ToolStateProvider
- Emit events on settings changes
- Update registry filtering in real-time

**Effort:** 1-2 days  
**Priority:** P2

---

### 16. Parallel Hook Execution Not Supported
**Issue:** Hooks execute sequentially, blocking chat responses

**Evidence:**
```typescript
parallel: false // in HookPlanner
```

**Impact:**
- Long-running hooks delay responses
- Poor user experience
- No concurrency

**Severity:** LOW

**Recommendation:**
- Implement async hook execution
- Add parallel execution mode
- Make configurable per hook

**Effort:** 3-4 days  
**Priority:** P3

---

### 17. Hook Debugger Not Integrated
**Issue:** Hook debugging infrastructure exists but not used

**Evidence:**
- `hookDebugger.ts` implements debugging
- No calls to debugger in hook execution
- May be leftover from development

**Impact:**
- Debugging hooks is difficult
- Dead code

**Severity:** LOW

**Recommendation:**
- Integrate debugger into hook execution
- Add debug mode configuration
- Or remove if not needed

**Effort:** 1 day  
**Priority:** P3

---

## Test Coverage Analysis

### Passing Tests
- HookRunner unit tests - execution, timeout, validation
- HookRegistry unit tests - registration, retrieval
- ToolRegistry unit tests - registration, schemas
- Extension loading tests (mocked)

### Failing Tests
- None currently failing (because integration is broken, tests are isolated)

### Missing Tests
- End-to-end tool execution flow
- Hook event emission and execution
- Extension tool/hook registration
- MCP tool integration
- UI ↔ core registry synchronization
- ServiceContainer initialization

---

## Performance Concerns

### 1. Ephemeral Registry Creation
- New ToolRegistry created per message
- Registration overhead on every message
- Memory allocation/deallocation

### 2. Hook Execution Blocking
- Sequential execution blocks responses
- No timeout aggregation
- Long-running hooks delay everything

### 3. Tool Schema Generation
- Schemas regenerated on every call
- No caching of schemas
- Filtering applied repeatedly

---

## Security Concerns

### 1. Command Validation Weak
- Only checks command name against whitelist
- Arguments not validated
- Could allow `node malicious.js`

### 2. Trust Model Incomplete
- Approval callback may be undefined
- Hooks may be silently skipped
- No default UI prompt

### 3. Hook Output Size Limits
- Enforced but throws in stream handler
- May not prevent DoS
- No rate limiting

---

## Recommendations by Priority

### P0 (Critical - Fix Immediately)
1. **Add ToolRegistry to ServiceContainer**
   - Create singleton with SettingsService integration
   - Register built-in tools
   - **Effort:** 1 day
   - **Impact:** Enables tool functionality

2. **Fix HookPlanner constructor**
   - Pass registry parameter
   - **Effort:** 5 minutes
   - **Impact:** Prevents runtime crash

3. **Wire ExtensionManager to registries**
   - Pass hook/tool registries to constructor
   - **Effort:** 1 day
   - **Impact:** Enables extension functionality

4. **Connect UI HooksProvider to core**
   - Use HookService's registry
   - **Effort:** 1 day
   - **Impact:** Makes hooks functional

5. **Fix ephemeral ToolRegistry in ChatContext**
   - Use central registry
   - **Effort:** 1 day
   - **Impact:** Fixes tool availability

### P1 (High - Fix Soon)
6. **Update ToolsPanel to use dynamic registry**
   - Read from central ToolRegistry
   - Subscribe to changes
   - **Effort:** 2 days
   - **Impact:** Shows correct tools in UI

7. **Emit hook events in CLI**
   - Add event emission to ModelContext
   - Or use ChatClient
   - **Effort:** 2-3 days
   - **Impact:** Makes hooks execute

8. **Add hook approval UI**
   - Create approval dialog
   - Persist decisions
   - **Effort:** 2-3 days
   - **Impact:** Enables workspace hooks

### P2 (Medium - Schedule for Next Sprint)
9. **Fix HookRunner stream error handling**
   - Don't throw in event handlers
   - **Effort:** 1 day
   - **Impact:** Improves reliability

10. **Connect tool state persistence**
    - Wire SettingsService to ToolRegistry
    - **Effort:** 1-2 days
    - **Impact:** Fixes settings integration

11. **Add integration tests**
    - Test full tool execution flow
    - Test hook event flow
    - **Effort:** 3-4 days
    - **Impact:** Catches integration bugs

### P3 (Low - Nice to Have)
12. **Clean up command whitelist**
    - Remove invalid entries
    - Document rationale
    - **Effort:** 5 minutes
    - **Impact:** Improves security

13. **Fix TrustedHooks path validation**
    - Correct operator precedence
    - **Effort:** 5 minutes
    - **Impact:** Fixes logic error

14. **Fix test type mismatches**
    - Update MockMessageBus
    - **Effort:** 1 day
    - **Impact:** Improves test quality

15. **Implement parallel hook execution**
    - Add async execution mode
    - **Effort:** 3-4 days
    - **Impact:** Improves performance

---

## Migration Path

### Phase 1 (Week 1): Critical Fixes
- Add ToolRegistry to ServiceContainer
- Fix HookPlanner constructor
- Wire ExtensionManager to registries
- Connect UI HooksProvider to core
- Fix ephemeral ToolRegistry

**Deliverable:** Tools and hooks functional in basic scenarios

### Phase 2 (Week 2): High Priority
- Update ToolsPanel to use dynamic registry
- Emit hook events in CLI
- Add hook approval UI

**Deliverable:** Full UI integration working

### Phase 3 (Week 3): Medium Priority
- Fix HookRunner stream error handling
- Connect tool state persistence
- Add integration tests

**Deliverable:** Robust and tested system

### Phase 4 (Week 4+): Low Priority
- Clean up command whitelist
- Fix path validation
- Fix test type mismatches
- Implement parallel execution

**Deliverable:** Polished and optimized system

---

## Detailed Fix Plan

### Fix 1: Add ToolRegistry to ServiceContainer

**Files to Change:**
- `packages/core/src/services/serviceContainer.ts`
- `packages/core/src/tools/index.ts`
- `packages/cli/src/features/context/ChatContext.tsx`

**Changes:**
```typescript
// In ServiceContainer:
private _toolRegistry?: ToolRegistry;

getToolRegistry(): ToolRegistry {
  if (!this._toolRegistry) {
    const settingsService = SettingsService.getInstance();
    this._toolRegistry = new ToolRegistry(settingsService);
    registerBuiltInTools(this._toolRegistry);
  }
  return this._toolRegistry;
}

// In initializeAll():
this.getToolRegistry(); // Initialize eagerly

// In ChatContext:
const toolRegistry = serviceContainer.getToolRegistry();
const toolSchemas = toolRegistry.getFunctionSchemasForMode(...);
```

**Tests:**
- Unit test: singleton behavior
- Unit test: SettingsService integration
- Integration test: tool registration and retrieval

---

### Fix 2: Connect UI HooksProvider to Core

**Files to Change:**
- `packages/cli/src/ui/contexts/HooksContext.tsx`
- `packages/cli/src/services/hookLoader.ts`

**Changes:**
```typescript
// In HooksProvider:
export function HooksProvider({ children }: HooksProviderProps) {
  const serviceContext = useServiceContext();
  const hookService = serviceContext.getHookService();
  const hookRegistry = hookService.getRegistry();
  
  useEffect(() => {
    loadHooksFromFiles(hookRegistry);
  }, [hookRegistry]);
  
  // Rest of component uses hookRegistry
}
```

**Tests:**
- Integration test: hooks loaded from files appear in core registry
- Integration test: UI changes reflected in core

---

### Fix 3: Wire ExtensionManager to Registries

**Files to Change:**
- `packages/core/src/services/serviceContainer.ts`
- `packages/core/src/extensions/extensionManager.ts`

**Changes:**
```typescript
// In ServiceContainer.getExtensionManager():
getExtensionManager(): ExtensionManager {
  if (!this._extensionManager) {
    const hookRegistry = this.getHookService().getRegistry();
    const toolRegistry = this.getToolRegistry();
    const mcpToolWrapper = new MCPToolWrapper();
    
    this._extensionManager = new ExtensionManager(
      [userExtensionsDir, workspaceExtensionsDir],
      hookRegistry,
      toolRegistry,
      mcpToolWrapper
    );
  }
  return this._extensionManager;
}
```

**Tests:**
- Integration test: extension registers hooks in core registry
- Integration test: extension registers tools in core registry

---

## Acceptance Criteria

### System is "Fixed" When:
1. ✅ Central ToolRegistry exists in ServiceContainer
2. ✅ Central HookRegistry used by UI and core
3. ✅ Built-in tools registered on startup
4. ✅ Extension tools/hooks appear in registries
5. ✅ UI shows dynamic tools from registry
6. ✅ Hooks execute when events are emitted
7. ✅ Tool enable/disable state works end-to-end
8. ✅ Integration tests pass for full flow

---

## Conclusion

The tools and hooks subsystems are **architecturally broken** due to missing service wiring. The components exist and work in isolation, but are not connected properly.

**Key Takeaways:**
- ServiceContainer missing ToolRegistry is root cause
- UI components create isolated registries
- Extensions can't integrate without registry access
- CLI bypasses core tool execution logic
- Fixes are straightforward but require careful coordination

**Next Steps:**
1. Add ToolRegistry to ServiceContainer (P0)
2. Fix HookPlanner constructor (P0)
3. Wire ExtensionManager (P0)
4. Connect UI to core registries (P0)
5. Add integration tests

**Estimated Effort:** 2-3 weeks for P0/P1, 4-5 weeks for all priorities

---

**Audit Completed:** January 19, 2026  
**Auditor:** AI Assistant (Consolidated from 3 previous audits + fresh code analysis)
