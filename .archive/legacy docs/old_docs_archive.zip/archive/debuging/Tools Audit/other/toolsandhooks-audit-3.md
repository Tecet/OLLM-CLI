# Tools and Hooks Audit - Phase 3 ✅

**Scope:** Deep investigation of the tools and hooks subsystems: implementation, UI integration, runtime wiring, extension/MCP integration, settings/state, and known race conditions. No code changes made — purely investigative notes and recommended next steps.

---

## Summary (TL;DR) ⚠️

- There are **several critical architectural disconnects** between the UI components (CLI), the core runtime services, and the extension/MCP systems. These disconnects cause hooks and tools to be registered and managed in multiple isolated registries, making the behavior inconsistent (UI vs runtime) and causing extensions and MCP tools to often not be executed where expected.
- I found **runtime bugs and race conditions** (e.g., missing dependency injection, incorrectly constructed components), **security-related validation oddities**, and repeated patterns of ephemeral registries and duplicated logic.

---

## Methodology 🔍

- Searched repo for occurrences of `hook`, `hooks`, `tool`, `tools`, `HookRegistry`, `ToolRegistry`, and related code (UI, core services, ExtensionManager, Chat/Context flows).
- Read core implementations (hook registry/runner/event handler/planner), UI contexts (`HooksContext`, `ToolsPanel`), service container, extension manager, and Chat context where tool schemas are assembled.
- Cross-referenced tests and `.dev` audit files to confirm prior findings and to find concrete examples.

Files inspected (non-exhaustive):
- `packages/core/src/hooks/*` (hookRegistry, hookRunner, hookPlanner, hookEventHandler)
- `packages/core/src/tools/tool-registry.ts`
- `packages/core/src/services/serviceContainer.ts`
- `packages/core/src/extensions/extensionManager.ts`
- `packages/cli/src/ui/contexts/HooksContext.tsx`
- `packages/cli/src/ui/components/tools/ToolsPanel.tsx`
- `packages/cli/src/features/context/ChatContext.tsx`
- `packages/cli/src/services/hookLoader.ts`
- `packages/cli/src/config/toolsConfig.ts`

---

## Key Findings & Evidence (detailed) 🧭

1) **UI Hooks provider uses its own `HookRegistry` (disconnect from core)** 🔗
- Evidence: `packages/cli/src/ui/contexts/HooksContext.tsx` creates a registry with `new HookRegistry()` when none is injected and then `loadHooksFromFiles(hookRegistry)` is called.
- Impact: Hooks shown/edited in UI may never be registered with the runtime `HookService` and therefore will not execute when events are emitted.
- Severity: High

2) **`HookService` constructs `HookPlanner` incorrectly (missing dependency)** ❗
- Evidence: `packages/core/src/services/hookService.ts` sets `this.planner = new HookPlanner();` but `HookPlanner` expects a `HookRegistry` in its constructor (`packages/core/src/hooks/hookPlanner.ts`).
- Impact: Either a runtime error will be thrown when planner methods are used or planner will operate with an undefined registry if used—unreliable behavior.
- Severity: High

3) **No central `ToolRegistry` in `ServiceContainer` (extensions/tools not integrated)** 🔌
- Evidence: `ServiceContainer.getExtensionManager()` creates `ExtensionManager` without passing `hookRegistry` or `toolRegistry`. `ExtensionManager` expects them (see constructor signature). `ExtensionManager.enableExtension()` registers tools to `this.toolRegistry` when present.
- Impact: Extensions can be loaded/enabled but their hooks/tools are not registered into the core/global registries, leading to ghost/partial extension behavior.
- Severity: High

4) **Tools UI (`ToolsPanel`) relies on a static `DEFAULT_TOOLS` config, not the runtime `ToolRegistry`** 🧾
- Evidence: `packages/cli/src/ui/components/tools/ToolsPanel.tsx` uses `getToolsByCategory()` from `packages/cli/src/config/toolsConfig.ts` (a static list) and `SettingsService` for enable/disable state.
- Impact: Dynamically discovered tools (MCP tools, extension-provided tools, or runtime-wrapped tools) won't appear in the Tools UI, causing mismatch between UI and runtime capabilities.
- Severity: High

5) **Ephemeral `ToolRegistry` is created per-message in `ChatContext` (fragile/racy)** ⏱️
- Evidence: In `packages/cli/src/features/context/ChatContext.tsx` the send flow constructs `new ToolRegistry(settingsService)` per message turn, registers a `HotSwapTool` and `MemoryDumpTool`, then uses `toolSchemas = toolRegistry.getFunctionSchemasForMode(...)` for prompt building.
- Impact: Tools and schemas vary per message and are not centralized; other subsystems cannot rely on a stable global registry. This also makes it hard for UI and extension system to remain synchronized.
- Severity: Medium-High

6) **`loadHooksFromFiles` vs core registry mismatch** ⚠️
- Evidence: `packages/cli/src/services/hookLoader.ts` registers file-based hooks into the passed registry; however, HooksProvider calls `loadHooksFromFiles(hookRegistry)` where `hookRegistry` may be a locally created one (UI-only). There's no guarantee the core `HookService` registry is populated.
- Impact: User/workspace hooks loaded by the UI can be invisible to core hook execution and `HookEventHandler`.
- Severity: High

7) **`ExtensionManager` usage assumes registries are provided but service wiring is missing** 🧩
- Evidence: `ExtensionManager.enableExtension()` registers hooks (`this.hookRegistry.registerHook(...)`) and MCP-wrapped tools (`this.toolRegistry.register(wrappedTool)`) only if the manager's registries were supplied.
- Impact: With `ServiceContainer` not supplying these, extensions won't fully integrate; tests may mock registries, which masks production problems.
- Severity: High

8) **Tool state provider support exists but inconsistent wiring** ⚙️
- Evidence: `ToolRegistry` accepts a `ToolStateProvider`. In production, some places instantiate it with `SettingsService` (e.g. ChatContext) but there is no single, shared `ToolRegistry` in the container that uses `SettingsService` centrally.
- Impact: Tool enable/disable filtering behavior is inconsistent across different `ToolRegistry` instances.
- Severity: Medium

9) **Potential security/typo in `HookRunner` whitelist** 🔐
- Evidence: `HookRunner.isWhitelistedCommand()` returns `['node', 'python', 'python3', 'bash', 'sh', 'npx', 'uvx']` — `uvx` looks suspicious (possible typo) and `validateCommand()` asserts absolute path or whitelist.
- Impact: Could cause unexpected acceptance/rejection of hook commands or open a vector if whitelist is incorrect.
- Severity: Medium

10) **Tests cover many unit scenarios but integration gaps remain** 🧪
- Evidence: Tests for HookRunner, HookRegistry, ToolRegistry and extension flows exist and pass (see `test-results.json` and tests under `packages/core/src/__tests__`). However, UI+core integration tests are limited and some UI tests report failures (e.g., `themeManager.property.test.ts` failing to load `uiSettings.js`).
- Impact: Unit tests mask higher-order integration problems between CLI UI and core services.
- Severity: Medium

---

## Additional Observations & Minor Issues 📝

- Several modules log user-facing initialization details (e.g., `SettingsService` writes path logs on family instantiation) that may clutter logs in some environments.
- There are TODOs and comments in code that indicate planned fixes (e.g., comments in `ChatContext` about model/tool support), suggesting the codebase is mid-refactor and some areas are intentionally provisional.
- Duplicate creation of `HookRegistry` in tests and UIs is understandable for isolation in tests, but the **runtime wiring must still be singular**.

---

## Recommendations & Next Steps (prioritized) ✅

1. **Create and expose shared `ToolRegistry` and `HookRegistry` in `ServiceContainer` (highest priority)** 🔧
   - Add getters (e.g., `getToolRegistry()`, `getHookRegistry()`) that instantiate singletons and wire them to `SettingsService` (ToolStateProvider) and to `HookService` respectively.
   - Rationale: centralization removes registry fragmentation and ensures extensions and UI share a single source of truth.

2. **Make UI providers use core registries (HooksProvider & Tools UI)** 🪝
   - `HooksProvider` should take the registry from the `HookService` (or accept the service via props/injection) rather than creating its own `new HookRegistry()`.
   - `ToolsPanel` should read from the central `ToolRegistry` (and subscribe to changes) instead of `DEFAULT_TOOLS` config.

3. **Fix `HookPlanner` instantiation in `HookService`** 🩺
   - Construct `HookPlanner` with a `HookRegistry` instance: `this.planner = new HookPlanner(this.registry);` and add a unit test for planner integration.

4. **Make `ExtensionManager` be instantiated by `ServiceContainer` with proper registries** 🔁
   - Provide `hookRegistry`, `toolRegistry`, `mcpToolWrapper` to the `ExtensionManager` via the service container so `enableExtension()` actually registers hooks/tools.

5. **Replace ephemeral per-message `ToolRegistry` usage with central registry or controlled ephemeral object** 🔁
   - If per-message filtering is required, do it by deriving schemas from the central registry (e.g., `toolRegistry.getFunctionSchemasForMode(...)`) rather than constructing a brand new registry each message.

6. **Audit `HookRunner` command validation and whitelist** 🔒
   - Verify the whitelist is correct (remove likely-typo `uvx`) and consider safer absolute path handling and better error messaging.

7. **Add integration tests for UI ↔ core hooks & tools path** 🧪
   - Tests should exercise the full flow: load extension → enable extension → extension registers hooks and tools → UI shows them → core executes hooks on events → tool call end-to-end.

8. **Add telemetry/logging and health alerts for missing wiring** 🚨
   - When the `ExtensionManager` loads an extension but `toolRegistry` or `hookRegistry` is not provided, log a warn/diagnostic that indicates incomplete wiring.

---

## Prioritized PR Plan (detailed) 🛠️

Below is a practical, ordered set of PRs to resolve the high-impact issues. Each item lists the goal, affected files, tests to add/update, approximate effort (engineer-days), and acceptance criteria.

1) PR-001 (Priority: P0) — "Add shared `ToolRegistry` & `HookRegistry` to `ServiceContainer`" (Est: 2-3d, Medium)
   - Goal: Provide singletons `getToolRegistry()` and `getHookRegistry()` on `ServiceContainer`, wire `ToolRegistry` with a `ToolStateProvider` backed by `SettingsService`, and ensure `initializeAll()` initializes registries as needed.
   - Files to change:
     - `packages/core/src/services/serviceContainer.ts` (add fields, getters, init in `initializeAll`)
     - `packages/core/src/services/index.ts` (exports)
     - `packages/core/src/tools/tool-registry.ts` (ensure ToolStateProvider interface is stable)
     - `packages/cli/src/features/context/ChatContext.tsx` (stop creating ephemeral `ToolRegistry` and use container-provided one)
     - `packages/cli/src/ui/contexts/HooksContext.tsx` (use HookService.getRegistry() where appropriate)
   - Tests:
     - Unit: singleton behavior + SettingsService-based filtering
     - Integration: start ServiceContainer, load an extension that registers tools, assert `toolRegistry.list()` contains them
   - Acceptance: Extension tools and UI show identical tool lists and Settings toggles are honored across the app.

2) PR-002 (Priority: P0) — "Make UI consume core registries (HooksProvider & ToolsPanel)" (Est: 1-2d, Medium)
   - Goal: Remove local registry creation in the UI; hook loader should register to the core registry and UI should read from the shared registries and listen for changes.
   - Files to change:
     - `packages/cli/src/ui/contexts/HooksContext.tsx` (replace `new HookRegistry()` fallback with `HookService.getRegistry()` or via props)
     - `packages/cli/src/services/hookLoader.ts` (ensure it is used to populate core registry during startup)
     - `packages/cli/src/ui/components/tools/ToolsPanel.tsx` (read from `ToolRegistry.getEnabledTools()` and subscribe)
     - `packages/cli/src/config/toolsConfig.ts` (keep as defaults; deprecate static reliance)
   - Tests:
     - Property tests: `HooksContext.property.test.tsx` and `ToolsTab.property.test.tsx` updated to use global registries
     - Integration test: loading hooks from files results in HookService registry populated
   - Acceptance: UI shows dynamic tools and hooks that are discoverable by the runtime; toggles in UI affect the same registry used by LLM tool filtering.

3) PR-003 (Priority: P1) — "Fix `HookPlanner` instantiation and add planner tests" (Est: 0.5-1d, Small)
   - Goal: Construct `HookPlanner` with the `HookRegistry` instance in `HookService` and add unit tests asserting ordering and plan results.
   - Files to change: `packages/core/src/services/hookService.ts`, add/modify `packages/core/src/hooks/__tests__/hookPlanner.test.ts`
   - Acceptance: `HookPlanner` receives a valid registry and unit tests pass.

4) PR-004 (Priority: P1) — "Ensure `ExtensionManager` receives registries from `ServiceContainer` + add health logging" (Est: 1-2d, Medium)
   - Goal: Update `ServiceContainer.getExtensionManager()` to pass `hookRegistry`, `toolRegistry` & `mcpToolWrapper` so extension registration is reliable; add warning logs if not available.
   - Files to change: `packages/core/src/services/serviceContainer.ts`, `packages/core/src/extensions/extensionManager.ts`
   - Tests: Integration tests where `ExtensionManager` loads an extension that registers hooks and tools; assert both registries are updated.
   - Acceptance: Extensions fully register hooks & tools in production wiring.

5) PR-005 (Priority: P2) — "Replace ephemeral `ToolRegistry` usage in `ChatContext` with central registry" (Est: 0.5-1d, Small)
   - Goal: Use the central `ToolRegistry` and call `getFunctionSchemasForMode()` for prompt building instead of creating a new registry per message.
   - Files to change: `packages/cli/src/features/context/ChatContext.tsx`
   - Acceptance: Prompt tool schemas come from central registry and tests ensure no functional regressions.

6) PR-006 (Priority: P2) — "`HookRunner` stream safety & whitelist audit" (Est: 1-2d, Medium)
   - Goal: Do not throw inside `child.stdout`/`child.stderr` callbacks — accumulate and abort gracefully with an error output; remove suspicious whitelist entry `uvx` and add tests for oversized output handling and for invalid commands.
   - Files to change: `packages/core/src/hooks/hookRunner.ts`, tests in `packages/core/src/hooks/__tests__/hookRunner.test.ts`
   - Acceptance: Oversized output triggers a clean hook error output (not an unhandled exception); command validation tests pass.

7) PR-007 (Priority: P3) — "MessageBus.filter lifecycle fix & leak tests" (Est: 0.5d, Small)
   - Goal: Make `MessageBus.filter()` return a proxy with `dispose()` or tie filter lifetime to a subscription so it can be cleaned up; add leak/regression test.
   - Files to change: `packages/core/src/hooks/messageBus.ts`, tests
   - Acceptance: No listener leak when proxies are disposed.


Merge & Rollout Plan 🧭
- Merge in order: PR-001 → PR-002 → PR-003 → PR-004 → PR-005 → PR-006 → PR-007
- Run full test suite and add integration tests after PR-002. Keep PR sizes small where possible to simplify review.
- For high-risk changes (PR-001/PR-002/PR-006), run a short staging/manual test: load existing extensions, enable/disable tools in UI, trigger a hook event, and validate hook execution and tool filtering.

---

## Concrete file/line references (for triage) 📌
- `packages/cli/src/ui/contexts/HooksContext.tsx` — creates `new HookRegistry()` and calls `loadHooksFromFiles()` into it.
- `packages/cli/src/services/hookLoader.ts` — `loadHooksFromFiles(registry)` registers hooks in passed registry.
- `packages/core/src/services/hookService.ts` — `this.planner = new HookPlanner();` (missing registry argument).
- `packages/core/src/hooks/hookPlanner.ts` — constructor signature expects `HookRegistry`.
- `packages/core/src/services/serviceContainer.ts` — `getExtensionManager()` does not pass registries to `ExtensionManager`.
- `packages/core/src/extensions/extensionManager.ts` — `enableExtension()` registers hooks/tools only if `this.hookRegistry`/`this.toolRegistry` are supplied.
- `packages/cli/src/features/context/ChatContext.tsx` — creates ephemeral `new ToolRegistry(settingsService)` and registers `HotSwapTool` and `MemoryDumpTool` per message.
- `packages/cli/src/config/toolsConfig.ts` and `packages/cli/src/ui/components/tools/ToolsPanel.tsx` — UI relies on static config rather than `ToolRegistry`.
- `packages/core/src/hooks/hookRunner.ts` — `isWhitelistedCommand()` includes `uvx` in whitelist (suspicious).

---

## Acceptance criteria for follow-up (what 'done' looks like) ✅
- Central `HookRegistry` and `ToolRegistry` exist, are singletons in `ServiceContainer`, and are used by core runtime, extension manager, and UI.
- Hooks loaded from files are registered into the core `HookService` registry; UI `HooksProvider` reads from that same registry.
- `HookPlanner` is constructed correctly and covered by tests.
- `ExtensionManager.enableExtension()` reliably registers hooks/tools in a production wiring (not just in tests).
- `ToolsPanel` displays dynamic tools (including MCP/extension-provided tools) and respects settings filtering through the shared `ToolRegistry` and `ToolStateProvider`.
- Integration tests validate UI ↔ core end-to-end flows for tools and hooks.

---

If you'd like, I can now produce a prioritized change list and implement a minimal PR that wires `ToolRegistry` into `ServiceContainer` and updates `ExtensionManager` and `ToolsPanel` to use it (I will not make changes until you confirm prioritization). 🔧


---

Generated on: 2026-01-18
Audit author: GitHub Copilot (using Raptor mini - Preview)

