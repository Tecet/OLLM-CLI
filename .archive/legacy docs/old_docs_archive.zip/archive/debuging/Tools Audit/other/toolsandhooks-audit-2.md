# Tools and Hooks Audit - Phase 2

**Date:** January 18, 2026  
**Auditor:** GitHub Copilot  
**Scope:** Deep investigation of tools and hooks implementation, UI integration, and core logic connections

## Executive Summary

The tools and hooks subsystems in OLLM CLI suffer from severe architectural disconnects and incomplete implementations. Core services are not properly initialized, UI components operate with isolated registries, and critical integration points are missing or broken. The system appears to be in a partially implemented state with major functionality gaps.

## Critical Architecture Issues

### 1. Service Container Missing Tool Registry
**Severity:** Critical  
**Location:** `packages/core/src/services/serviceContainer.ts`

**Issue:** The ServiceContainer does not provide or initialize a ToolRegistry, despite ChatClient requiring one.

**Evidence:**
- ChatClient constructor expects `ToolRegistry` parameter
- ServiceContainer has no `getToolRegistry()` method
- Built-in tools registration function exists but is never called
- CLI bypasses ChatClient entirely, using provider directly

**Impact:** Tools cannot be executed through the core chat system.

### 2. UI Hooks Registry Disconnected from Core
**Severity:** Critical  
**Location:** `packages/cli/src/ui/contexts/HooksContext.tsx`

**Issue:** HooksProvider creates its own HookRegistry instead of using the core HookService's registry.

**Evidence:**
- `new HookRegistry()` in HooksProvider (line 95)
- No integration with ServiceContext
- HookService initializes separately with its own registry
- UI hooks are not connected to runtime hook execution

**Impact:** UI shows hooks but they don't execute in the core system.

### 3. CLI Bypasses Core ChatClient
**Severity:** Critical  
**Location:** `packages/cli/src/features/context/ModelContext.tsx`

**Issue:** CLI uses provider.chatStream() directly instead of ChatClient with tool support.

**Evidence:**
- `sendToLLM` uses `provider.chatStream()` (line 720)
- No ToolRegistry integration in CLI
- ChatClient with tool execution logic is unused
- Tool calls handled manually in ChatContext

**Impact:** Tool execution logic in core is dead code.

### 4. HookPlanner Constructor Bug
**Severity:** High  
**Location:** `packages/core/src/services/hookService.ts:59`

**Issue:** HookPlanner instantiated without required HookRegistry parameter.

**Evidence:**
```typescript
this.planner = new HookPlanner(); // Missing registry parameter
```

**Impact:** HookPlanner will fail at runtime when trying to access registry.

### 5. MCP Tool Wrapper Schema Issues
**Severity:** High  
**Location:** `packages/core/src/mcp/mcpToolWrapper.ts`

**Issue:** MCP tools may not properly convert schemas for LLM consumption.

**Evidence:**
- Schema conversion logic exists but untested
- No validation of converted schemas
- Potential type mismatches between MCP and internal tool schemas

**Impact:** MCP tools may fail or behave incorrectly.

## Implementation Gaps

### 6. Built-in Tools Not Registered
**Severity:** High  
**Location:** `packages/core/src/tools/index.ts`

**Issue:** `registerBuiltInTools()` function exists but never called in core initialization.

**Evidence:**
- Function defined with proper tool registration
- No call in ServiceContainer or anywhere in core
- Tools only exist in tests

**Impact:** No tools available in runtime.

### 7. Hook Events Not Triggered in CLI
**Severity:** High  
**Location:** `packages/cli/src/features/context/ModelContext.tsx`

**Issue:** CLI doesn't emit hook events that core expects.

**Evidence:**
- ChatClient emits events like `before_agent`, `after_tool`
- CLI uses provider directly, no event emission
- HookService listens for events but they never come

**Impact:** Hooks never execute.

### 8. TrustedHooks Path Validation Flawed
**Severity:** Medium  
**Location:** `packages/core/src/hooks/trustedHooks.ts:95`

**Issue:** Path validation logic has unclear precedence.

**Evidence:**
```typescript
if (hook.sourcePath && hook.sourcePath.includes('/') || hook.sourcePath?.includes('\\'))
```

**Impact:** Potential incorrect file reading decisions.

### 9. MockMessageBus Type Mismatch in Tests
**Severity:** Medium  
**Location:** `packages/core/src/tools/__tests__/edit-file.test.ts`

**Issue:** Tests pass MockMessageBus where ToolContext expects MessageBus.

**Evidence:**
- TypeScript errors show missing `messageBus` property
- Tests use `createToolContext()` inconsistently
- MockMessageBus implements MessageBus but lacks required ToolContext properties

**Impact:** Test compilation failures.

### 10. Command Whitelist Contains Invalid Entry
**Severity:** Low  
**Location:** `packages/core/src/hooks/hookRunner.ts:117`

**Issue:** `"uvx"` in command whitelist appears to be a typo or legacy entry.

**Evidence:**
- `uvx` is not a standard command
- Likely meant to be `uv` (Python package installer)
- No usage evidence in codebase

**Impact:** Potential security or confusion.

## UI Integration Issues

### 11. ToolsPanel Uses Static Configuration
**Severity:** Medium  
**Location:** `packages/cli/src/ui/components/tools/ToolsPanel.tsx`

**Issue:** UI shows tools from static config, not dynamic registry.

**Evidence:**
- `getToolsByCategory()` uses hardcoded tool list
- No connection to actual ToolRegistry
- SettingsService used for enable/disable state

**Impact:** UI may show tools that don't exist in runtime.

### 12. Hook Categories Mapping Incomplete
**Severity:** Medium  
**Location:** `packages/cli/src/ui/contexts/HooksContext.tsx`

**Issue:** UI hook events don't map cleanly to core events.

**Evidence:**
- File events map to `before_tool`
- UI has more granular events than core supports
- Adapter converts UI hooks to core format

**Impact:** Hook functionality limited by core event types.

### 13. Extension Manager MCP Tool Registration
**Severity:** Medium  
**Location:** `packages/core/src/extensions/extensionManager.ts`

**Issue:** MCP tools registered but may conflict with built-in tools.

**Evidence:**
- `toolRegistry.register(wrappedTool)` in extension loading
- No duplicate name checking
- No priority system for tool conflicts

**Impact:** Tool name collisions possible.

## Security Concerns

### 14. Hook Command Validation Weak
**Severity:** Medium  
**Location:** `packages/core/src/hooks/hookRunner.ts`

**Issue:** Command validation allows arbitrary arguments to whitelisted commands.

**Evidence:**
- Only checks command name against whitelist
- Arguments not validated
- Could allow `node malicious.js`

**Impact:** Potential code execution vulnerabilities.

### 15. Trust Model Incomplete
**Severity:** Medium  
**Location:** `packages/core/src/hooks/trustedHooks.ts`

**Issue:** Approval callback may be undefined, causing silent hook skipping.

**Evidence:**
- `requestApproval()` returns false if no callback
- No default UI prompt in headless mode
- Workspace hooks may be silently ignored

**Impact:** Hooks don't work in CLI without approval UI.

## Dead Code and Legacy Issues

### 16. ChatClient Unused in CLI
**Severity:** High  
**Location:** `packages/core/src/core/chatClient.ts`

**Issue:** Full-featured ChatClient with tool support is not used.

**Evidence:**
- ChatClient handles tool calls, context, events
- CLI implements its own chat logic
- ~600 lines of unused code

**Impact:** Maintenance burden, feature inconsistency.

### 17. FileEdit Export Commented Out
**Severity:** Low  
**Location:** `packages/core/src/tools/index.ts:49`

**Issue:** `FileEdit` commented out in exports.

**Evidence:**
```typescript
export { EditFileTool, EditFileInvocation, type EditFileParams /*, type FileEdit */ } from './edit-file.js';
```

**Impact:** Potential API confusion.

### 18. Hook Debugger Not Integrated
**Severity:** Low  
**Location:** `packages/core/src/hooks/hookDebugger.ts`

**Issue:** Hook debugging infrastructure exists but not used.

**Evidence:**
- `hookDebugger.ts` implements debugging
- No calls to debugger in hook execution
- May be leftover from development

**Impact:** Debugging hooks is difficult.

## Test Coverage Gaps

### 19. Integration Tests Missing
**Severity:** High  
**Location:** Test files

**Issue:** No end-to-end tests for tools/hooks in CLI.

**Evidence:**
- Unit tests exist for components
- No integration tests for full tool execution
- No tests for hook event flow

**Impact:** Integration bugs not caught.

### 20. MCP Tool Testing Incomplete
**Severity:** Medium  
**Location:** `packages/core/src/mcp/__tests__/`

**Issue:** MCP tool wrapper tests don't cover schema conversion.

**Evidence:**
- Basic MCP client tests exist
- Tool wrapper has minimal test coverage
- Schema conversion untested

**Impact:** MCP integration reliability unknown.

## Performance Issues

### 21. Hook Execution Synchronous
**Severity:** Medium  
**Location:** `packages/core/src/hooks/hookRunner.ts`

**Issue:** Hooks execute sequentially, blocking chat responses.

**Evidence:**
- `parallel: false` in HookPlanner
- No async execution support
- Long-running hooks delay responses

**Impact:** Poor user experience with slow hooks.

### 22. Tool Registry Re-scans Categories
**Severity:** Low  
**Location:** `packages/cli/src/ui/components/tools/ToolsPanel.tsx`

**Issue:** Category data recalculated on every render.

**Evidence:**
- `useMemo` dependencies may cause unnecessary recalculations
- Static data computed dynamically

**Impact:** Minor performance impact.

## Configuration Issues

### 23. Hook Approval UX Missing
**Severity:** Medium  
**Location:** CLI UI

**Issue:** No UI for approving untrusted hooks.

**Evidence:**
- ApprovalCallback exists but no implementation
- Hooks may fail silently
- No user feedback for trust decisions

**Impact:** Hooks don't work for users.

### 24. Tool State Persistence Disconnect
**Severity:** Low  
**Location:** Settings vs Registry

**Issue:** Tool enabled state in settings not connected to registry filtering.

**Evidence:**
- SettingsService tracks enabled tools
- ToolRegistry has toolStateProvider but not used
- UI reads settings directly

**Impact:** Inconsistent tool availability.

## Recommendations

### Immediate Fixes (Blockers)
1. **Fix ServiceContainer**: Add ToolRegistry initialization and getter
2. **Connect UI Hooks**: Make HooksProvider use core HookService registry  
3. **Fix HookPlanner**: Pass registry to constructor
4. **Register Built-in Tools**: Call registerBuiltInTools in service initialization
5. **Use ChatClient in CLI**: Replace direct provider usage with ChatClient

### Short-term (Next Sprint)
6. **Implement Hook Approval UI**: Add dialog for approving hooks
7. **Fix Test Type Issues**: Update MockMessageBus to match ToolContext
8. **Add Integration Tests**: Test full tool execution flow
9. **Clean Command Whitelist**: Remove invalid entries

### Long-term (Architecture)
10. **Parallel Hook Execution**: Implement async hook running
11. **Dynamic Tool Discovery**: Connect UI to live ToolRegistry
12. **Complete MCP Testing**: Add comprehensive MCP integration tests
13. **Hook Debugging UI**: Integrate hook debugger into UI

## Files Requiring Attention

### Core Implementation
- `packages/core/src/services/serviceContainer.ts` - Add ToolRegistry
- `packages/core/src/services/hookService.ts` - Fix HookPlanner
- `packages/core/src/tools/index.ts` - Ensure tools registered
- `packages/core/src/hooks/trustedHooks.ts` - Fix path validation
- `packages/core/src/hooks/hookRunner.ts` - Improve command validation

### CLI Integration  
- `packages/cli/src/features/context/ModelContext.tsx` - Use ChatClient
- `packages/cli/src/ui/contexts/HooksContext.tsx` - Connect to core registry
- `packages/cli/src/ui/components/tools/ToolsPanel.tsx` - Use dynamic registry

### Tests
- `packages/core/src/tools/__tests__/edit-file.test.ts` - Fix MockMessageBus
- `packages/core/src/mcp/__tests__/` - Add tool wrapper tests
- Integration test files - Add end-to-end tests

### Configuration
- Hook approval dialog implementation
- Tool registry settings integration
- MCP server configuration validation

## Conclusion

The tools and hooks systems are fundamentally broken due to architectural disconnects between core services and CLI UI. Critical components exist but are not wired together, resulting in non-functional features. Immediate attention required to establish proper service initialization and component integration before features can work end-to-end.