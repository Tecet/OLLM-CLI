# Hooks System Audit
**Date:** January 17, 2026  
**Auditor:** System Analysis  
**Scope:** All hook system implementations in `packages/core/src/hooks/`

## Executive Summary

This audit reviews the hook system implementation for:
- Logic correctness and edge cases
- Security vulnerabilities
- Error handling completeness
- Performance issues
- Code quality and maintainability
- Missing features or improvements

### Overall Assessment
- **Critical Issues:** 1
- **High Priority Issues:** 4
- **Medium Priority Issues:** 6
- **Low Priority Issues:** 5
- **Recommendations:** 10

---

## 1. Hook Registry (hookRegistry.ts)

**Status:** ✅ Good with minor improvements needed

**Strengths:**
- Clean Map-based storage
- Dual indexing (by event and by ID)
- Proper array copying in getAllHooks()
- Good method coverage

**Issues:**

#### 🟢 LOW: No validation of hook ID uniqueness
**Location:** Line 29 `registerHook()`
**Issue:** Allows registering multiple hooks with the same ID
**Impact:** Could cause confusion and unexpected behavior
**Recommendation:**
```typescript
registerHook(event: HookEvent, hook: Hook): void {
  // Check if hook ID already exists
  if (this.hookById.has(hook.id)) {
    throw new Error(`Hook with ID '${hook.id}' is already registered`);
  }
  
  // Get or create the hooks array for this event
  const eventHooks = this.hooks.get(event) || [];
  eventHooks.push(hook);
  this.hooks.set(event, eventHooks);
  this.hookById.set(hook.id, hook);
}
```

#### 🟢 LOW: unregisterHook modifies array while iterating
**Location:** Lines 56-66
**Issue:** Modifies array in place which is fine but could be clearer
**Recommendation:** Use filter for clarity
```typescript
unregisterHook(hookId: string): boolean {
  const hook = this.hookById.get(hookId);
  if (!hook) {
    return false;
  }

  this.hookById.delete(hookId);

  // Remove from all event arrays using filter
  for (const [event, eventHooks] of this.hooks.entries()) {
    const filtered = eventHooks.filter((h) => h.id !== hookId);
    if (filtered.length !== eventHooks.length) {
      this.hooks.set(event, filtered);
    }
  }

  return true;
}
```

---

## 2. Hook Runner (hookRunner.ts)

**Status:** ⚠️ Needs attention

**Strengths:**
- Comprehensive timeout handling
- Good error isolation
- Trust verification integration
- Detailed execution metadata

**Issues:**

#### 🔴 CRITICAL: Shell injection vulnerability
**Location:** Line 96
```typescript
const child = spawn(hook.command, hook.args || [], {
  stdio: ['pipe', 'pipe', 'pipe'],
  shell: false,
});
```
**Issue:** While `shell: false` is set, there's no validation of `hook.command` or `hook.args`
**Impact:** Malicious hooks could execute arbitrary commands
**Fix:** Add command validation
```typescript
private validateCommand(command: string): void {
  // Ensure command doesn't contain shell metacharacters
  if (/[;&|`$(){}[\]<>]/.test(command)) {
    throw new Error(`Invalid characters in hook command: ${command}`);
  }
  
  // Ensure command is an absolute path or whitelisted command
  if (!path.isAbsolute(command) && !this.isWhitelistedCommand(command)) {
    throw new Error(`Hook command must be absolute path or whitelisted: ${command}`);
  }
}

private isWhitelistedCommand(command: string): boolean {
  const whitelist = ['node', 'python', 'python3', 'bash', 'sh'];
  return whitelist.includes(command);
}
```

#### 🟠 HIGH: No limit on hook output size
**Location:** Lines 103-109
**Issue:** Hooks can produce unlimited output, causing memory issues
**Impact:** Memory exhaustion from malicious or buggy hooks
**Fix:** Add output size limit
```typescript
const MAX_OUTPUT_SIZE = 1024 * 1024; // 1MB
let stdout = '';
let stderr = '';
let outputSize = 0;

child.stdout?.on('data', (data) => {
  const chunk = data.toString();
  outputSize += chunk.length;
  
  if (outputSize > MAX_OUTPUT_SIZE) {
    child.kill('SIGTERM');
    throw new Error(`Hook output exceeded ${MAX_OUTPUT_SIZE} bytes`);
  }
  
  stdout += chunk;
});
```

#### 🟠 HIGH: Duplicate trust checking code
**Location:** Lines 169-195, 217-243, 280-306, 348-374
**Issue:** Trust checking logic is duplicated in 4 methods
**Impact:** Maintenance burden, potential for inconsistencies
**Fix:** Extract to private method
```typescript
private async checkTrustAndApprove(hook: Hook): Promise<boolean> {
  if (!this.trustedHooks) {
    return true; // No trust system, allow execution
  }

  const isTrusted = await this.trustedHooks.isTrusted(hook);
  
  if (!isTrusted) {
    const approved = await this.trustedHooks.requestApproval(hook);
    
    if (approved) {
      const hash = await this.trustedHooks.computeHash(hook);
      await this.trustedHooks.storeApproval(hook, hash);
      return true;
    } else {
      console.warn(`Hook ${hook.name} was not approved and will be skipped`);
      return false;
    }
  }
  
  return true;
}

// Then use it:
async executeHook(hook: Hook, input: HookInput): Promise<HookOutput> {
  if (!this.config.enabled) {
    return { continue: true, error: 'Hooks are disabled in configuration' };
  }

  if (!(await this.checkTrustAndApprove(hook))) {
    return { continue: true, error: 'Hook not approved by user' };
  }

  return this.executeHookInternal(hook, input);
}
```

#### 🟡 MEDIUM: No resource cleanup on error
**Location:** Lines 96-145
**Issue:** If an error occurs, child process might not be properly cleaned up
**Fix:** Add try-finally for cleanup
```typescript
async executeHookInternal(hook: Hook, input: HookInput): Promise<HookOutput> {
  const startTime = Date.now();
  const hookDebugger = getHookDebugger();
  const traceId = hookDebugger.startTrace(hook, input.event, input);
  
  let child: ChildProcess | null = null;
  let timeoutId: NodeJS.Timeout | null = null;
  
  try {
    child = spawn(hook.command, hook.args || [], {
      stdio: ['pipe', 'pipe', 'pipe'],
      shell: false,
    });

    // ... rest of execution logic
  } finally {
    // Ensure cleanup
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    if (child && !child.killed) {
      child.kill('SIGTERM');
    }
  }
}
```

#### 🟡 MEDIUM: stdin write not error-handled
**Location:** Lines 112-113
**Issue:** Writing to stdin could fail but error is not caught
**Fix:**
```typescript
try {
  const inputJson = this.translator.serializeInput(input);
  child.stdin?.write(inputJson);
  child.stdin?.end();
} catch (error) {
  child.kill('SIGTERM');
  throw new Error(`Failed to write input to hook: ${error.message}`);
}
```

---

## 3. Hook Translator (hookTranslator.ts)

**Status:** ✅ Good

**Strengths:**
- Comprehensive validation
- Good error messages
- Event-specific data structuring
- Proper null/undefined handling

**Issues:**

#### 🟢 LOW: validateOutput allows null for optional fields
**Location:** Lines 54-72
**Issue:** Explicitly checks for null but could be simpler
**Recommendation:** Simplify validation
```typescript
validateOutput(output: unknown): boolean {
  if (typeof output !== 'object' || output === null) {
    return false;
  }

  const obj = output as Record<string, unknown>;

  // Must have 'continue' field as boolean
  if (typeof obj.continue !== 'boolean') {
    return false;
  }

  // Optional fields validation
  if (obj.systemMessage !== undefined && obj.systemMessage !== null && typeof obj.systemMessage !== 'string') {
    return false;
  }

  if (obj.data !== undefined && obj.data !== null) {
    if (typeof obj.data !== 'object' || Array.isArray(obj.data)) {
      return false;
    }
  }

  if (obj.error !== undefined && obj.error !== null && typeof obj.error !== 'string') {
    return false;
  }

  return true;
}
```

---

## 4. Trusted Hooks (trustedHooks.ts)

**Status:** ⚠️ Needs attention

**Strengths:**
- Good trust model (builtin > user > workspace > downloaded)
- Hash-based verification
- Approval workflow

**Issues:**

#### 🟠 HIGH: Hash computation is weak
**Location:** Lines 145-157
**Issue:** Hashes command+args instead of actual script content
**Impact:** Script changes won't be detected if command/args stay same
**Fix:** Read and hash actual script file
```typescript
async computeHash(hook: Hook): Promise<string> {
  try {
    // Try to read the actual script file
    const scriptPath = this.resolveScriptPath(hook);
    if (scriptPath) {
      const content = await readFile(scriptPath, 'utf-8');
      const hash = createHash('sha256');
      hash.update(content);
      return `sha256:${hash.digest('hex')}`;
    }
  } catch (error) {
    // Fall back to hashing command+args if file can't be read
    console.warn(`Could not read script file for hook '${hook.name}', using command hash`);
  }

  // Fallback: hash command and args
  const content = JSON.stringify({
    command: hook.command,
    args: hook.args || [],
  });

  const hash = createHash('sha256');
  hash.update(content);
  return `sha256:${hash.digest('hex')}`;
}

private resolveScriptPath(hook: Hook): string | null {
  // Logic to resolve actual script path from hook.command
  // This depends on how hooks are stored/referenced
  return null; // Placeholder
}
```

#### 🟡 MEDIUM: No approval expiration
**Location:** HookApproval interface
**Issue:** Approvals never expire, even if script changes
**Recommendation:** Add expiration
```typescript
export interface HookApproval {
  source: string;
  hash: string;
  approvedAt: string;
  approvedBy: string;
  expiresAt?: string; // Optional expiration
}

// In isTrusted():
private async isApproved(hook: Hook): Promise<boolean> {
  const sourcePath = this.getHookSourcePath(hook);
  const approval = this.approvals.get(sourcePath);
  
  if (!approval) {
    return false;
  }

  // Check expiration
  if (approval.expiresAt) {
    const expiresAt = new Date(approval.expiresAt);
    if (expiresAt < new Date()) {
      // Approval expired, remove it
      await this.removeApproval(sourcePath);
      return false;
    }
  }

  // Compute current hash and compare
  const currentHash = await this.computeHash(hook);
  return currentHash === approval.hash;
}
```

#### 🟡 MEDIUM: getHookSourcePath is a stub
**Location:** Lines 107-113
**Issue:** Uses command as source path, which is not unique
**Impact:** Multiple hooks with same command will share approval
**Fix:** Use actual file path or unique identifier
```typescript
private getHookSourcePath(hook: Hook): string {
  // Priority order for source path:
  // 1. Explicit source path if available
  if (hook.sourcePath) {
    return hook.sourcePath;
  }
  
  // 2. Extension name + hook ID for extension hooks
  if (hook.extensionName) {
    return `${hook.extensionName}:${hook.id}`;
  }
  
  // 3. Hook ID as fallback
  return hook.id;
}
```

---

## 5. Hook Planner (hookPlanner.ts)

**Status:** ✅ Excellent

**Strengths:**
- Clean priority-based ordering
- Stable sort preserves registration order
- Simple and focused

**No issues found.**

---

## 6. Hook Event Handler (hookEventHandler.ts)

**Status:** ✅ Good with minor improvements

**Strengths:**
- Clean event subscription
- Parallel and sequential execution modes
- Good error isolation
- Enable/disable functionality

**Issues:**

#### 🟢 LOW: Hardcoded event list
**Location:** Lines 48-61
**Issue:** Event list is hardcoded, needs manual updates
**Recommendation:** Generate from HookEvent type
```typescript
start(): void {
  if (!this.enabled) {
    this.enabled = true;
  }

  // Get all possible hook events from the type
  const events: HookEvent[] = this.getAllHookEvents();

  for (const event of events) {
    const listener: EventListener = async (evt, data) => {
      if (!this.enabled) return;
      await this.handleEvent(evt, data);
    };

    const listenerId = this.messageBus.on(event, listener);
    this.listenerIds.set(event, listenerId);
  }

  if (this.options.logging) {
    console.log('HookEventHandler started and listening for events');
  }
}

private getAllHookEvents(): HookEvent[] {
  // This would ideally be generated from the HookEvent type
  // For now, keep the list but make it a constant
  return [
    'session_start',
    'session_end',
    'before_agent',
    'after_agent',
    'before_model',
    'after_model',
    'before_tool_selection',
    'before_tool',
    'after_tool',
    'pre_compress',
    'post_compress',
    'notification',
  ];
}
```

---

## 7. Message Bus (messageBus.ts)

**Status:** ✅ Good

**Strengths:**
- Priority-based listeners
- Once listeners
- Wildcard support
- Event history
- Good async handling

**Issues:**

#### 🟡 MEDIUM: emitSync doesn't actually emit synchronously
**Location:** Lines 119-123
**Issue:** Name is misleading - it uses queueMicrotask which is async
**Impact:** Confusing API, potential race conditions
**Fix:** Rename or change behavior
```typescript
/**
 * Emit an event asynchronously without waiting for listeners
 * (Renamed from emitSync for clarity)
 */
emitAsync(event: HookEvent, data: any): void {
  queueMicrotask(() => {
    this.emit(event, data).catch((error) => {
      console.error(`Error in async emit for event '${event}':`, error);
    });
  });
}
```

#### 🟢 LOW: No max listeners warning
**Location:** MessageBus class
**Issue:** No warning when too many listeners are registered
**Recommendation:** Add max listeners check
```typescript
private maxListeners = 10;

on(event: HookEvent | '*', listener: EventListener, options?: ListenerOptions): string {
  const id = `listener-${this.idCounter++}`;
  this.listeners.set(id, {
    id,
    event,
    listener,
    priority: options?.priority ?? 0,
    once: false,
  });
  
  // Warn if too many listeners for this event
  const count = this.listenerCount(event);
  if (count > this.maxListeners) {
    console.warn(
      `Warning: ${count} listeners registered for event '${event}'. ` +
      `This may indicate a memory leak. Use setMaxListeners() to increase the limit.`
    );
  }
  
  return id;
}

setMaxListeners(n: number): void {
  this.maxListeners = n;
}
```

---

## 8. Hook Debugger (hookDebugger.ts)

**Status:** ✅ Excellent

**Strengths:**
- Comprehensive tracing
- Multiple output formats
- Statistics and summaries
- Data sanitization

**Issues:**

#### 🟢 LOW: No trace limit
**Location:** Line 67 `traces: HookTraceEntry[] = []`
**Issue:** Traces array can grow unbounded
**Recommendation:** Add limit like history
```typescript
private traces: HookTraceEntry[] = [];
private maxTraces = 1000;

endTrace(traceId: string, output?: unknown, error?: Error, exitCode?: number): void {
  // ... existing code ...
  
  this.traces.push(trace);
  
  // Limit trace history
  if (this.traces.length > this.maxTraces) {
    this.traces.shift();
  }
  
  this.activeTraces.delete(traceId);
  
  // ... rest of code ...
}

setMaxTraces(n: number): void {
  this.maxTraces = n;
}
```

---

## 9. Hook Config (config.ts)

**Status:** ✅ Excellent

**Strengths:**
- Zod validation
- Good defaults
- Merge function
- Type-safe

**No issues found.**

---

## 10. Hook Types (types.ts)

**Status:** ✅ Good with minor improvements

**Issues:**

#### 🟢 LOW: Hook interface missing optional fields
**Location:** Lines 24-36
**Issue:** No field for script source path or metadata
**Recommendation:** Add optional fields
```typescript
export interface Hook {
  /** Unique identifier for the hook */
  id: string;
  /** Human-readable name */
  name: string;
  /** Command to execute */
  command: string;
  /** Optional command arguments */
  args?: string[];
  /** Source of the hook (determines trust level) */
  source: HookSource;
  /** Extension name if hook comes from an extension */
  extensionName?: string;
  /** Optional source file path for hash verification */
  sourcePath?: string;
  /** Optional description */
  description?: string;
  /** Optional metadata */
  metadata?: Record<string, unknown>;
}
```

---

## Priority Issues Summary

### 🔴 Critical (Fix Immediately)

1. **hookRunner.ts:** Shell injection vulnerability
   - **Impact:** Arbitrary command execution
   - **Fix:** Add command validation and whitelist

### 🟠 High Priority (Fix Soon)

2. **hookRunner.ts:** No limit on hook output size
   - **Impact:** Memory exhaustion
   - **Fix:** Add 1MB output limit

3. **hookRunner.ts:** Duplicate trust checking code
   - **Impact:** Maintenance burden
   - **Fix:** Extract to private method

4. **trustedHooks.ts:** Hash computation is weak
   - **Impact:** Script changes not detected
   - **Fix:** Hash actual script content

5. **trustedHooks.ts:** getHookSourcePath is a stub
   - **Impact:** Multiple hooks share approval
   - **Fix:** Use unique identifier

### 🟡 Medium Priority (Address When Possible)

6. **hookRunner.ts:** No resource cleanup on error
7. **hookRunner.ts:** stdin write not error-handled
8. **trustedHooks.ts:** No approval expiration
9. **messageBus.ts:** emitSync doesn't emit synchronously

### 🟢 Low Priority (Nice to Have)

10-16. Various improvements for robustness and features

---

## Recommendations

### Security
1. ✅ Add command validation to prevent shell injection
2. ✅ Implement proper script content hashing
3. ✅ Add approval expiration mechanism
4. ✅ Validate hook output size limits
5. ✅ Add resource cleanup in error cases

### Performance
6. ✅ Add output size limits to prevent memory issues
7. ✅ Add trace history limits
8. ✅ Consider caching hash computations

### Reliability
9. ✅ Extract duplicate trust checking code
10. ✅ Add proper resource cleanup
11. ✅ Improve error handling for stdin writes
12. ✅ Add unique source path identification

### Maintainability
13. ✅ Remove hardcoded event lists
14. ✅ Rename misleading method names (emitSync)
15. ✅ Add max listeners warning
16. ✅ Improve hook interface with optional fields

---

## Testing Gaps

Components that need additional test coverage:
1. **hookRunner.ts** - Test command validation, output limits, resource cleanup
2. **trustedHooks.ts** - Test hash verification, approval expiration, source path resolution
3. **messageBus.ts** - Test emitSync behavior, max listeners warning
4. **hookEventHandler.ts** - Test parallel execution error handling

---

## Conclusion

Overall, the hook system is well-designed with good separation of concerns. However, there is **1 critical security issue** that needs immediate attention:

1. Shell injection vulnerability in hookRunner.ts

Additionally, there are **4 high-priority issues** related to security, performance, and maintainability:

2. No output size limits (memory exhaustion risk)
3. Duplicate trust checking code (maintenance burden)
4. Weak hash computation (security risk)
5. Stub source path implementation (functional issue)

The hook debugger and config modules are excellent. The message bus and event handler are solid with minor improvements needed.

**Next Steps:**
1. Fix critical shell injection vulnerability immediately
2. Address high-priority issues in next sprint
3. Add comprehensive test coverage for security features
4. Consider adding integration tests for hook execution flow
5. Document security model and trust levels

---

## Files Audited

1. `packages/core/src/hooks/types.ts` - Type definitions
2. `packages/core/src/hooks/hookRegistry.ts` - Hook registration
3. `packages/core/src/hooks/hookRunner.ts` - Hook execution
4. `packages/core/src/hooks/hookPlanner.ts` - Execution planning
5. `packages/core/src/hooks/hookEventHandler.ts` - Event handling
6. `packages/core/src/hooks/hookTranslator.ts` - Protocol translation
7. `packages/core/src/hooks/trustedHooks.ts` - Trust management
8. `packages/core/src/hooks/config.ts` - Configuration
9. `packages/core/src/hooks/messageBus.ts` - Event bus
10. `packages/core/src/hooks/hookDebugger.ts` - Debugging
