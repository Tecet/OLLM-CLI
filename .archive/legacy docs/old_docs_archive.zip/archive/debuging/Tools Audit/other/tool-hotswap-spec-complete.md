# Tool Hot-Swap Spec - Complete

**Date:** 2026-01-17  
**Status:** ✅ Spec Complete - Ready for Implementation

## Summary

Created comprehensive specification for fixing the "Tool hot-swap with models lacking tool calling" issue (Medium priority in bugtracker).

## Design Decisions Made

Through discussion with user, we finalized these key decisions:

1. **Filter Location:** C - Both layers (chat loop + provider) for defense in depth
2. **Tool Registry:** C - Conditional creation (only if model supports tools)
3. **System Prompt:** A - Add explicit note when tools disabled
4. **UI Feedback:** B - Warning message on model swap
5. **Detection:** C - Hybrid (proactive + reactive fallback)
6. **Unknown Models:** C - Ask user with auto-detect option
7. **Agent Loop:** A - Complete current turn gracefully
8. **Metadata Updates:** B - Auto-update on startup
9. **Runtime Learning:** C - Learn with user confirmation

## Rationale

**Key Insight:** Users can upload custom models not in our database, so we need:
- Multi-layer defense (chat loop + provider)
- User confirmation for unknown models
- Runtime learning with user approval
- Safe defaults (tool_support: false)

## Spec Documents Created

### 1. Requirements (.kiro/specs/tool-support-detection/requirements.md)
- 6 user stories with acceptance criteria
- Non-functional requirements (performance, reliability, usability)
- Data model enhancements
- Success metrics

### 2. Design (.kiro/specs/tool-support-detection/design.md)
- Architecture overview with data flow diagrams
- Component design for ModelContext, ChatContext, ProfileManager
- User prompt component design
- Error handling and testing strategy
- Correctness properties for property-based testing

### 3. Tasks (.kiro/specs/tool-support-detection/tasks.md)
- 8 implementation phases
- 60+ granular tasks
- Task dependencies
- Estimated effort: ~19 hours (2-3 days)
- Risk assessment

### 4. README (.kiro/specs/tool-support-detection/README.md)
- Quick reference and summary
- User flows and examples
- Success metrics
- Next steps

## Key Features

### Multi-Layer Defense
```
Layer 1: Chat Loop
  ↓ Check modelSupportsTools()
  ↓ Conditionally create ToolRegistry
  ↓ Add system prompt note

Layer 2: ModelContext
  ↓ Filter tools before provider
  ↓ Track runtime overrides

Layer 3: Provider (existing)
  ↓ Retry without tools on error
  ↓ Safety net
```

### Unknown Model Handling
```
Unknown Model Detected
  ↓
Prompt: "Does this model support tools? (y/n/auto-detect)"
  ↓
User Choice:
  - y: Save as tool_support: true
  - n: Save as tool_support: false
  - auto-detect: Send test request, learn from response
  ↓
Save to user_models.json with source tracking
```

### Runtime Learning
```
Tool Error Detected
  ↓
Check if user_confirmed (skip if yes)
  ↓
Prompt: "This model appears to not support tools. Update metadata? (y/n)"
  ↓
User Confirms:
  - y: Save to user_models.json (persistent)
  - n: Session-only override
```

## Data Model Changes

### user_models.json Enhancement
```json
{
  "id": "custom-model:latest",
  "tool_support": true,
  "tool_support_source": "user_confirmed",  // NEW: track how we learned
  "tool_support_confirmed_at": "2026-01-17T10:30:00Z"  // NEW: when confirmed
}
```

### Runtime Override Tracking
```typescript
toolSupportOverridesRef: Map<string, {
  supported: boolean;
  source: 'profile' | 'runtime_error' | 'user_confirmed' | 'auto_detected';
  timestamp: number;
}>
```

## Implementation Plan

### Phase 1: Data Model & Infrastructure (2h)
- Enhance user_models.json schema
- Create UserPromptContext for user interactions

### Phase 2: ModelContext Enhancements (4h)
- Enhanced override tracking
- Proactive detection on model swap
- Unknown model handling with prompts
- Auto-detect tool support
- Runtime learning with confirmation
- Metadata persistence

### Phase 3: ChatContext Enhancements (2h)
- Conditional tool registry creation
- System prompt modification
- Graceful agent loop handling

### Phase 4: ProfileManager Enhancements (2h)
- Startup metadata refresh (async, non-blocking)
- Enhanced updateUserModelsFromList()

### Phase 5: Provider Integration (1h)
- Enhanced error detection
- Error propagation to ModelContext

### Phase 6: UI Components (2h)
- UserPromptDialog component
- System messages

### Phase 7: Testing (4h)
- Unit tests
- Integration tests
- Property-based tests
- Manual testing

### Phase 8: Documentation & Cleanup (2h)
- Update documentation
- Code cleanup
- Update bugtracker

**Total: ~19 hours (2-3 days)**

## Testing Strategy

### Property-Based Tests
```typescript
// Property: Tools never sent to non-supporting models
fc.property(
  fc.record({ model: fc.string(), toolSupport: fc.boolean() }),
  ({ model, toolSupport }) => {
    setToolSupport(model, toolSupport);
    const filtered = filterTools(model, [testTool]);
    if (!toolSupport) expect(filtered).toBeUndefined();
  }
);

// Property: Unknown models always prompt or use safe default
fc.property(
  fc.string(),
  (unknownModel) => {
    const result = handleUnknownModel(unknownModel);
    expect(result.prompted || result.toolSupport === false).toBe(true);
  }
);
```

## Success Criteria

- ✅ Zero tool-related errors after model swap
- ✅ Unknown models prompt user or use safe default
- ✅ Runtime learning saves metadata with user confirmation
- ✅ All tests pass (unit, integration, property-based)
- ✅ No performance regression on model swap
- ✅ Documentation updated and complete

## Risk Assessment

- **Low Risk:** Data model changes (backward compatible)
- **Medium Risk:** ModelContext changes (well-isolated)
- **Low Risk:** ChatContext changes (conditional logic)
- **Low Risk:** ProfileManager changes (async, non-blocking)
- **Medium Risk:** User prompt flow (new UI pattern)

**Overall Risk:** Low-Medium

## Migration & Rollback

### Migration
1. New fields optional in user_models.json (backward compatible)
2. Existing overrides preserved
3. Gradual rollout by phase

### Rollback
If issues arise:
1. Disable startup refresh (config flag)
2. Disable runtime learning (config flag)
3. Revert to provider-level filtering only
4. User can manually edit user_models.json

## Documentation Updates

- ✅ Investigation document updated with model database architecture
- ✅ Spec created with requirements, design, and tasks
- ✅ Bugtracker updated with spec reference
- ⏳ User guide needs update (Phase 8)
- ⏳ Model database docs need update (Phase 8)

## Next Steps

1. ✅ Spec complete and reviewed
2. ⏳ Begin Phase 1 implementation (data model)
3. ⏳ Implement phases sequentially with testing
4. ⏳ Update documentation
5. ⏳ Deploy and monitor

## Related Documents

- **Spec:** `.kiro/specs/tool-support-detection/`
  - README (../../../.kiro/specs/tool-support-detection/README.md)
  - Requirements (../../../.kiro/specs/tool-support-detection/requirements.md)
  - Design (../../../.kiro/specs/tool-support-detection/design.md)
  - Tasks (../../../.kiro/specs/tool-support-detection/tasks.md)
- **Investigation:** `.dev/debuging/tool-hotswap-investigation.md`
- **Model DB:** `.dev/docs/Models/development/models_db.md`
- **Bugtracker:** `.dev/bugtracker.md`

---

**Status:** ✅ Ready for Implementation  
**Estimated Effort:** 2-3 days  
**Priority:** Medium  
**Risk:** Low-Medium
