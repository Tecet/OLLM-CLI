**Summary**
- **Scope**: Deep audit of hook and tool subsystems (implementation, runtime behavior, UI usage, and tests).
- **Goal**: Inventory relevant files, highlight defects, security and correctness risks, and list locations for follow-up work. No fixes applied.

**Inventory**
- **Hooks (core)**: `packages/core/src/hooks/` — files inspected: `hookRegistry.ts`, `hookEventHandler.ts`, `hookRunner.ts`, `hookTranslator.ts`, `trustedHooks.ts`, `messageBus.ts`, `types.ts`, `config.ts`, `hookDebugger.ts`.
- **Tools (core)**: `packages/core/src/tools/` — many tool modules and `__tests__` exercise full tool surface (read_file, write_file, glob, grep, shell, memory, etc.).
- **CLI UI usage**: `packages/cli/src/ui/...` and `packages/cli/src/hooks` — UI contexts and components register/display hooks and tools (e.g. HooksContext tests, ToolsTab, ToolsPanel).
- **Build/test artifacts**: `packages/core/typescript-errors.txt` and `test-results.json` used to surface compile/test failures and passing coverage.

**Test Summary (observed)**
- **Hook tests**: Broad set of hook unit/property/integration tests pass in `test-results.json` (many `hookEventHandler`, `hookRunner`, `hookConfiguration` tests passed).
- **Tool tests**: Most tool tests pass; notable failing items in prior runs: `packages/cli/src/__tests__/themeManager.property.test.ts` failing to load `../ui/uiSettings.js` and `packages/core/src/tools/__tests__/shell.test.ts` had failures in one run.
- **TypeScript errors**: See `packages/core/typescript-errors.txt` — many compile-time errors related to tools tests (mismatched types: `MockMessageBus` vs `ToolContext`) and a missing exported member `FileEdit` from `src/index.ts`.

**Key Findings (implementation & runtime risks)**
- **Unhandled throw inside stream listeners**: In `hookRunner.ts` (`executeHookInternal`) the `child.stdout` and `child.stderr` 'data' handlers throw when output size > MAX_OUTPUT_SIZE. Throwing inside async event callbacks is not caught by the outer try/catch and can produce unhandled exceptions. File: `packages/core/src/hooks/hookRunner.ts`.
- **Inconsistent error/log gating**: Code frequently checks `process.env.NODE_ENV !== 'test' && !process.env.VITEST` before logging. Tests use `VITEST` var in some places but not consistently — could hide logs during diagnostics depending on environment.
- **Potential race in timeout/kill handling**: The runner sets a timeout which calls `child.kill('SIGTERM')` and later checks `child.killed`. `child.killed` may not immediately reflect the state (kill is asynchronous). This can lead to ambiguous error messages vs behavior when processes are killed.
- **Validation regex / whitelist oddities**: `validateCommand` in `hookRunner.ts` rejects commands with metacharacters (good) but the whitelist includes `uvx` (likely a typo or legacy token) and lists commands by exact match — this may incorrectly reject valid invocations (or allow unintended ones). File: `packages/core/src/hooks/hookRunner.ts`.
- **Throwing from stream callbacks may crash process**: Related to the first point — throwing in stream handlers will not be turned into a returned HookOutput; instead it may bubble to the event loop and be logged/unhandled.
- **TrustedHooks: path check precedence and fallback**: In `trustedHooks.ts` the test for whether to read the script file uses a compound conditional: `if (hook.sourcePath && hook.sourcePath.includes('/') || hook.sourcePath?.includes('\'))`. Operator precedence makes this expression less clear; if `hook.sourcePath` is falsy the second part uses optional chaining but overall the condition is hard to reason about. File: `packages/core/src/hooks/trustedHooks.ts`.
- **MessageBus filter leaks listener**: `MessageBus.filter()` creates a proxy bus and registers a `this.on('*', ...)` listener on the parent but does not expose a way to remove that listener when the proxy is no longer used -> potential listener leak. File: `packages/core/src/hooks/messageBus.ts`.
- **MessageBus listener id/unsubscribe usage is consistent**: `HookEventHandler.start()` uses `messageBus.on(...)` and saves returned IDs, then calls `messageBus.off(listenerId)` in `stop()` — this matches `MessageBus` API (OK).
- **HookTranslator data shaping may be surprising**: `normalizeData()` wraps primitives/arrays into `{ value: data }`. Hooks that expect raw arrays/primitives might get unexpected shapes; check consumer contracts. File: `packages/core/src/hooks/hookTranslator.ts`.
- **Hook execution approvals default-deny without callback**: `TrustedHooks.requestApproval()` denies approval if no `approvalCallback` configured. That is secure, but in headless/test setups this can silently skip hooks; tests generally supply mocks but runtime installations may need a clear UX path. File: `packages/core/src/hooks/trustedHooks.ts`.
- **Duplicate/legacy symbol mismatch**: TypeScript errors show `Module './tools/index.js' has no exported member 'FileEdit'` and many tests treating `MockMessageBus` as a `ToolContext`. These indicate mismatches between tool public APIs and test/consumer expectations — likely caused by refactors leaving legacy names/types. File: `packages/core/typescript-errors.txt`.

**UI / Code-usage observations**
- `packages/cli` registers hooks into `HookRegistry` in many tests/components — UI tests rely on `HookRegistry` runtime shape; registry methods appear stable (`registerHook`, `getHooksForEvent`, `unregisterHook`).
- Some UI tests fail to load artifacts like `../ui/uiSettings.js` — indicates potential packaging/path drift between source and test harness. See failing test: `packages/cli/src/__tests__/themeManager.property.test.ts`.

**Security & Safety**
- **Command validation**: The current `validateCommand` approach rejects shell metacharacters but still allows whitelisted commands with arbitrary arguments. Consider stricter sanitization or canonical absolute path enforcement for workspace hooks.
- **Hook output size enforcement**: The runner attempts to enforce MAX_OUTPUT_SIZE but kills the child and throws inside the listener — this can lead to inconsistent state; streaming limits should be enforced without throwing from the listener (emit an error path and close streams gracefully).

**Places likely to contain legacy/unused code**
- The presence of `uvx` in command whitelist suggests leftover or misspelled legacy token — search repository for `uvx`.
- Missing export `FileEdit` suggests old API name changed; search for `FileEdit` and `edit-file` tool entry points to reconcile exports/consumers.
- Many TypeScript test errors that mention `MockMessageBus` vs `ToolContext` indicate type-shape drift between `tools` runtime API and test helpers.

**Recommended next steps (investigate-only, no fixes applied)**
- **1 — Stream error handling**: Review `executeHookInternal` stream handlers and replace `throw` inside `data` callbacks with an error path that resolves into a HookOutput/error so the outer flow handles it safely. Target: `packages/core/src/hooks/hookRunner.ts`.
- **2 — Validate/clean whitelist**: Audit whitelisted commands (remove `uvx` or confirm intent) and tighten `validateCommand` semantics. Target: `packages/core/src/hooks/hookRunner.ts`.
- **3 — TrustedHooks UX**: Document and/or provide a default approvalCallback or clear CLI prompt flow so workspace hooks are not silently denied in interactive installs. Target: `packages/core/src/hooks/trustedHooks.ts` and CLI UI.
- **4 — MessageBus.filter lifecycle**: Provide removal/unsubscribe path for proxy listeners or attach listener to proxy with forwarding that can be cleaned up. Target: `packages/core/src/hooks/messageBus.ts`.
- **5 — Type mismatches**: Investigate `packages/core/typescript-errors.txt` failures (missing `FileEdit`, `MockMessageBus` vs `ToolContext`) and reconcile exports/types; likely required for `tools` subsystem stability.
- **6 — Test path issues**: Fix test harness path resolution that failed to load `../ui/uiSettings.js` in `packages/cli` tests.

**References**
- Audit file (this): [.dev/toolsandhooks-audit-1.md](.dev/toolsandhooks-audit-1.md)
- Key files inspected:
  - `packages/core/src/hooks/hookRunner.ts`
  - `packages/core/src/hooks/hookEventHandler.ts`
  - `packages/core/src/hooks/hookRegistry.ts`
  - `packages/core/src/hooks/trustedHooks.ts`
  - `packages/core/src/hooks/hookTranslator.ts`
  - `packages/core/src/hooks/messageBus.ts`
  - `packages/core/src/tools/*` (tests show broad coverage)
  - `packages/core/typescript-errors.txt`
  - `test-results.json`

**Notes / Assumptions**
- I did not change any code — this is an investigation artifact only. The observations are based on reading source files and test results available in the repo snapshot.
- Some runtime behavior (race conditions, unhandled exceptions) are inferred from code patterns — recommended to reproduce with targeted tests or run-time instrumentation before applying fixes.
