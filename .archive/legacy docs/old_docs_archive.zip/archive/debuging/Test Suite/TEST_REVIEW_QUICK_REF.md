# Test Review Quick Reference
**For Agents Reviewing Tests**

---

## 🎯 YOUR TASK

Review and fix tests stage-by-stage following the plan in `TEST_REVIEW_PLAN.md`.

---

## 📋 QUICK WORKFLOW

### **1. Pick a Stage**
See `TEST_REVIEW_PLAN.md` for stage list. Start with:
- ✅ Stage 1.1: Context Management (DONE)
- 🔴 Stage 1.2: Provider System (NEXT)

### **2. For Each Test File in Stage:**

#### **A. AUDIT**
```bash
# Run the test
npm run test:unit -- <test-name>
```

**Ask:**
- ✅ Does test pass?
- ✅ Does tested code still exist?
- ✅ Are expectations current?
- ✅ Is this testing real bug or outdated code?
- ✅ Are new features missing tests?

**Classify:**
- 🟢 PASSING - Works correctly
- 🟡 OUTDATED - Needs updates
- 🔴 BROKEN - Real bug detected
- ⚪ MISSING - Coverage gaps
- 🟣 OBSOLETE - Feature removed

#### **B. FIX**

**If OUTDATED:**
1. Update test expectations
2. Fix timing/mocks
3. Verify passes

**If BROKEN:**
1. Investigate if real bug
2. Fix code OR mark as expected failure
3. Document bug

**If MISSING:**
1. Add new tests
2. Follow existing patterns
3. Verify coverage

**If OBSOLETE:**
1. Remove test
2. Document removal

#### **C. VERIFY**
```bash
# Run component tests together
npm run test:unit -- <component-name>
```

**Check:**
- ✅ All pass in isolation
- ✅ All pass together
- ✅ No test pollution
- ✅ Wired into suite

---

## 🔧 COMMON FIXES

### **Timing Issues**
```typescript
// BEFORE
await new Promise(resolve => setTimeout(resolve, 100));

// AFTER
await new Promise(resolve => setTimeout(resolve, 1000));
```

### **Floating-Point Comparison**
```typescript
// BEFORE
expect(value).toBe(0.8);

// AFTER
expect(Math.abs(value - 0.8)).toBeLessThan(0.0001);
```

### **Event-Based Tests**
```typescript
// BEFORE (unreliable)
expect(eventSpy).toHaveBeenCalled();

// AFTER (reliable)
const result = manager.getResult();
expect(result.value).toBe(expected);
```

### **Conditional Assertions**
```typescript
// When behavior depends on state
const usage = manager.getUsage();
if (usage.percentage >= 80) {
  expect(eventSpy).toHaveBeenCalled();
} else {
  console.log(`Only reached ${usage.percentage}%`);
}
```

---

## 📊 REPORT FORMAT

### **Per Test File:**
```markdown
## Test File: <filename>
**Status:** [PASSING/OUTDATED/BROKEN/MISSING/OBSOLETE]
**Tests:** [count]

**Issues Found:**
1. Issue description
2. Issue description

**Fixes Applied:**
1. Fix description
2. Fix description

**New Tests Added:**
1. Test description (X tests)

**Verification:**
- [x] Passes in isolation
- [x] Passes with component
- [x] Wired into suite
```

### **Per Stage:**
```markdown
## Stage X: <name>
**Status:** ✅ COMPLETE / 🟡 IN PROGRESS / 🔴 TODO
**Files:** X/Y complete
**Tests:** ~X,XXX

**Summary:**
- Reviewed: X files
- Fixed: X tests
- Added: X tests
- Removed: X tests

**Next:** Stage X.Y
```

---

## 🎯 STAGE CHECKLIST

Copy this for each stage:

### **Stage [X.Y]: [NAME]**
**Files:** [COUNT]  
**Tests:** ~[COUNT]  
**Status:** 🔴 TODO

**Test Files:**
- [ ] `path/to/test.test.ts`
  - Status: [PASSING/OUTDATED/BROKEN/MISSING/OBSOLETE]
  - Issues: [list]
  - Fixes: [list]
  - Verified: [yes/no]

**Summary:**
- Files reviewed: 0/[COUNT]
- Tests fixed: 0
- Tests added: 0
- Tests removed: 0

**Verification:**
- [ ] All tests pass in isolation
- [ ] All tests pass together
- [ ] Tests wired into suite
- [ ] No regressions

---

## 🚀 COMMANDS

### **Run Component Tests:**
```bash
npm run test:unit -- context
npm run test:unit -- mcp
npm run test:unit -- chat
npm run test:unit -- hooks
```

### **Run Specific Test:**
```bash
npm run test:unit -- <test-name>
```

### **Run Full Suite:**
```bash
npm run test
```

---

## ⚠️ IMPORTANT RULES

1. **One stage at a time** - Don't skip ahead
2. **Test in isolation first** - Before running with others
3. **Document everything** - Issues, fixes, decisions
4. **Verify wiring** - Ensure tests run with `npm run test`
5. **Check for pollution** - Tests must pass together
6. **Build before testing** - Run `npm run build` first
7. **Don't assume** - If unsure, ask or investigate

---

## 📄 EXAMPLE: Context Management (DONE)

### **What We Did:**
1. ✅ Audited 19 test files
2. ✅ Fixed 2 outdated tests
3. ✅ Removed 1 obsolete test
4. ✅ Added 3 new test files (27 tests)
5. ✅ Verified all pass
6. ✅ Confirmed wired into suite

### **Files Modified:**
- Updated: `memoryGuard.enforce-compress-signature.test.ts`
- Removed: `compression-api-mismatch.test.ts`
- Created: `autoSummary.test.ts` (5 tests)
- Created: `inflightTokens.test.ts` (9 tests)
- Created: `thresholdComparison.test.ts` (12 tests)

### **Result:**
✅ All 19 test files passing  
✅ 27 new tests added  
✅ Stage 1.1 COMPLETE

---

## 🎉 SUCCESS METRICS

### **Per Stage:**
- ✅ All files reviewed
- ✅ All issues fixed
- ✅ All tests passing
- ✅ Tests verified

### **Overall:**
- Progress: X/7 stages (X%)
- Tests reviewed: ~X,XXX/~4,500
- Tests passing: X%

---

**Use this as your quick reference while working through `TEST_REVIEW_PLAN.md`**
