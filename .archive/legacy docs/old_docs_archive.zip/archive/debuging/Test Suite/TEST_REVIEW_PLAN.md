# Test Suite Review & Repair Plan
**Date:** 2026-01-20  
**Total Tests:** ~4,500 tests across 67 test files  
**Status:** 🔴 Needs Systematic Review & Repair  
**Approach:** Stage-by-stage, component-by-component

---

## 🎯 OBJECTIVE

Systematically review and repair the entire test suite (~4.5k tests) by:
1. Identifying outdated tests
2. Finding missing test coverage
3. Detecting real bugs vs test bugs
4. Fixing tests component-by-component
5. Ensuring all tests are properly wired in
6. Verifying full suite passes

---

## 📋 REVIEW METHODOLOGY

### **For Each Test File:**

1. **Audit Phase:**
   - ✅ Read test file and understand what it's testing
   - ✅ Check if tested functions/methods still exist
   - ✅ Verify test expectations match current implementation
   - ✅ Identify if test is testing real bug vs outdated code
   - ✅ Check if new features are missing tests

2. **Classification:**
   - 🟢 **PASSING** - Test works correctly
   - 🟡 **OUTDATED** - Test needs updates for code changes
   - 🔴 **BROKEN** - Test detects real bug in code
   - ⚪ **MISSING** - New features not tested
   - 🟣 **OBSOLETE** - Test for removed feature

3. **Fix Phase:**
   - Update outdated tests
   - Add missing tests
   - Fix real bugs if found
   - Remove obsolete tests
   - Verify tests pass in isolation

4. **Integration Phase:**
   - Verify tests are wired into suite
   - Run component tests together
   - Check for interaction failures

---

## 🗂️ TEST ORGANIZATION BY STAGE/COMPONENT

### **Stage 1: Core Infrastructure** (Priority: 🔴 CRITICAL)
**Estimated Tests:** ~800 tests  
**Files:** 19 files

#### **1.1 Context Management** ✅ COMPLETE
- [x] `packages/core/src/context/__tests__/autoSummary.test.ts` (5 tests) ✅
- [x] `packages/core/src/context/__tests__/compressionService.test.ts`
- [x] `packages/core/src/context/__tests__/contextManager.test.ts`
- [x] `packages/core/src/context/__tests__/contextPool.test.ts`
- [x] `packages/core/src/context/__tests__/dynamicSizing.integration.test.ts`
- [x] `packages/core/src/context/__tests__/inflightTokens.test.ts` (9 tests) ✅
- [x] `packages/core/src/context/__tests__/integration.test.ts`
- [x] `packages/core/src/context/__tests__/jitDiscovery.test.ts`
- [x] `packages/core/src/context/__tests__/memoryGuard.enforce-compress-signature.test.ts` ✅
- [x] `packages/core/src/context/__tests__/memoryGuard.test.ts`
- [x] `packages/core/src/context/__tests__/memoryGuard.warning.test.ts`
- [x] `packages/core/src/context/__tests__/property-test-example.test.ts`
- [x] `packages/core/src/context/__tests__/snapshotManager.test.ts`
- [x] `packages/core/src/context/__tests__/snapshotStorage.test.ts`
- [x] `packages/core/src/context/__tests__/snapshotStorage.windows.test.ts`
- [x] `packages/core/src/context/__tests__/thresholdComparison.test.ts` (12 tests) ✅
- [x] `packages/core/src/context/__tests__/tokenCounter.test.ts`
- [x] `packages/core/src/context/__tests__/types.test.ts`
- [x] `packages/core/src/context/__tests__/vramMonitor.test.ts`

**Status:** ✅ COMPLETE (27 new tests added, 2 updated, 1 removed)

#### **1.2 Provider System** ✅ COMPLETE
**Estimated Tests:** ~200 tests  
**Files:** 3 files
- [x] `packages/core/src/provider/__tests__/ollamaProvider.test.ts`
- [x] `packages/core/src/provider/__tests__/providerFactory.test.ts`
- [x] `packages/core/src/provider/__tests__/providerRegistry.test.ts`

**Tasks:**
1. Verify provider interface matches implementation
2. Check if new providers are tested
3. Test error handling and retries
4. Verify streaming token reporting

#### **1.3 Prompt System** ✅ COMPLETE
**Estimated Tests:** ~150 tests  
**Files:** 2 files
- [x] `packages/core/src/prompts/__tests__/ContextAnalyzer-confidence.test.ts`
- [x] `packages/core/src/prompts/__tests__/ContextAnalyzer.test.ts`

**Tasks:**
1. Check if prompt modes match current implementation
2. Verify context analysis logic
3. Test mode switching
4. Check confidence scoring

#### **1.4 Services** ✅ COMPLETE
**Estimated Tests:** ~100 tests  
**Files:** 1 file
- [x] `packages/core/src/services/__tests__/contextManager.test.ts`

**Tasks:**
1. Verify service integration
2. Check dependency injection
3. Test lifecycle management

#### **1.5 Commands** ✅ COMPLETE
**Estimated Tests:** ~100 tests  
**Files:** 1 file
- [x] `packages/core/src/commands/__tests__/contextCommand.test.ts`

**Tasks:**
1. Verify command registration
2. Test command execution
3. Check error handling

#### **1.6 Core Chat** ✅ COMPLETE
**Estimated Tests:** ~250 tests  
**Files:** 2 files
- [x] `packages/core/src/core/__tests__/chatClient.test.ts`
- [x] `packages/core/src/core/__tests__/messageHistory.test.ts`

**Tasks:**
1. Verify chat client API
2. Test message history management
3. Check streaming behavior
4. Test tool calling integration

---

### **Stage 2: CLI Features** (Priority: 🟡 HIGH)
**Estimated Tests:** ~1,200 tests  
**Files:** 22 files

#### **2.1 Chat Context (CLI)** ✅ COMPLETE
**Estimated Tests:** ~200 tests  
**Files:** 6 files
- [x] `packages/cli/src/features/context/__tests__/ChatContext.test.tsx`
- [x] `packages/cli/src/features/context/__tests__/HooksContext.test.tsx`
- [x] `packages/cli/src/features/context/__tests__/ModelContext.test.tsx`
- [x] `packages/cli/src/features/context/__tests__/ToolSupportDetection.property.test.tsx`
- [x] `packages/cli/src/features/context/__tests__/ToolSupportMessages.test.ts`
- [x] `packages/cli/src/features/context/__tests__/UserPromptContext.test.tsx`

**Tasks:**
1. Verify React context providers work
2. Test hooks integration
3. Check model selection
4. Test tool support detection

#### **2.2 Commands (CLI)** ✅ COMPLETE
**Estimated Tests:** ~300 tests  
**Files:** 7 files
- [x] `packages/cli/src/commands/__tests__/commandRegistry.test.ts`
- [x] `packages/cli/src/commands/__tests__/commandSuggestions.property.test.ts`
- [x] `packages/cli/src/commands/__tests__/homeCommand.test.ts`
- [x] `packages/cli/src/commands/__tests__/missingArgumentHelp.property.test.ts`
- [x] `packages/cli/src/commands/__tests__/modeCommands-metrics.test.ts`
- [x] `packages/cli/src/commands/__tests__/modeShortcuts.test.ts`
- [x] `packages/cli/src/commands/__tests__/sessionCommands.property.test.ts`
- [x] `packages/cli/src/commands/__tests__/slashCommandParsing.test.ts`

**Tasks:**
1. Verify command registration
2. Test command suggestions
3. Check mode switching
4. Test session management

#### **2.3 Configuration** ✅ COMPLETE
**Estimated Tests:** ~150 tests  
**Files:** 4 files
- [x] `packages/cli/src/config/__tests__/configLoader.property.test.ts`
- [x] `packages/cli/src/config/__tests__/settingsService.property.test.ts`
- [x] `packages/cli/src/config/__tests__/settingsService.test.ts`
- [x] `packages/cli/src/config/__tests__/toolsConfig.test.ts`

**Tasks:**
1. Verify config loading
2. Test settings persistence
3. Check tools configuration
4. Test property-based config validation

Status: All Stage 2.3 configuration tests have been run and passed.

#### **2.4 Services (CLI)** ✅ COMPLETE
**Estimated Tests:** ~200 tests  
**Files:** 5 files
- [x] `packages/cli/src/services/__tests__/hookFileService.property.test.ts`  
- [x] `packages/cli/src/services/__tests__/hookFileService.test.ts`
- [x] `packages/cli/src/services/__tests__/mcpConfigService.test.ts`
- [x] `packages/cli/src/services/__tests__/mcpMarketplace.integration.test.ts`
- [x] `packages/cli/src/services/__tests__/mcpMarketplace.test.ts`

**Tasks:**
1. Test hook file service (property tests passed)
2. Verify MCP configuration
3. Test marketplace integration
4. Check service interactions

---

### **Stage 3: UI Components** (Priority: 🟡 HIGH)
**Estimated Tests:** ~1,800 tests  
**Status:** 🟡 IN PROGRESS — Running full test suite for Stage 3
**Files:** 31 files

#### **3.1 Chat Components** ✅ IN PROGRESS
**Estimated Tests:** ~600 tests  
**Files:** 12 files
- [x] `packages/cli/src/ui/components/chat/__tests__/ChatHistory.diffThreshold.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ChatHistory.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ChatHistory.statePreservation.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ChatHistory.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/Message.roleColors.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/MetricsDisplay.compact.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/MetricsDisplay.completeness.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/MetricsDisplay.ttft.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ProgressIndicator.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ReasoningBox.toggle.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/StreamingMessage.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ToolCall.completeness.property.test.tsx`
- [x] `packages/cli/src/ui/components/chat/__tests__/ToolCall.wrapping.property.test.tsx`

**Tasks:**
1. Test chat history rendering
2. Verify metrics display
3. Test streaming messages
4. Check tool call display
5. Test property-based UI invariants

#### **3.2 Dialog Components** ✅ COMPLETE
**Estimated Tests:** ~400 tests  
**Files:** 6 files
- [x] `packages/cli/src/ui/components/dialogs/__tests__/Dialog.test.tsx`
- [x] `packages/cli/src/ui/components/dialogs/__tests__/HealthMonitorDialog.test.tsx`
- [x] `packages/cli/src/ui/components/dialogs/__tests__/HelpOverlay.test.tsx`
- [x] `packages/cli/src/ui/components/dialogs/__tests__/HookApprovalDialog.test.tsx`
- [x] `packages/cli/src/ui/components/dialogs/__tests__/InstallServerDialog.test.tsx`
- [x] `packages/cli/src/ui/components/dialogs/__tests__/MarketplaceDialog.test.tsx`

**Summary of fixes & work:**
- Fixed test harness issues and mocks so dialogs run deterministically (added module-level `useServices` mocks where needed).
- Patched `MCPContext` to await async `mcpClient` calls and merge client-discovered servers with configured entries.
- Normalized test helper server status mappings and corrected `useMCP` mock shapes (`state.marketplace`).
- Added `Dialog.markEscHandled()` API and updated `MarketplaceDialog` to intercept Esc while search is focused.
- Removed unused code/imports flagged by ESLint and adjusted tests to use `mockReturnValueOnce` to avoid spy stacking.

**Outcome:** All dialog tests run and pass locally; ESLint and `tsc --noEmit` show no errors in the dialogs area.

**Tasks:**
1. Test dialog rendering
2. Verify user interactions
3. Test approval flows
4. Check marketplace integration

#### **3.3 Tab Components** ✅ COMPLETE
**Estimated Tests:** ~500 tests  
**Files:** 8 files
- [x] `packages/cli/src/ui/components/tabs/__tests__/DocsTab.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/FilesTab.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/HooksTab.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/MCPTab.integration.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/MCPTab.property.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/MCPTab.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/SettingsTab.test.tsx`
- [x] `packages/cli/src/ui/components/tabs/__tests__/ToolsTab.test.tsx`

**Notes:** Ran full Tab test group; all tests passed (88/88). ESLint across `packages/cli` & `packages/core` reported 12 errors and 14 warnings — triaged and recorded for follow-up.

Initial plan for Tab Components:
- Audit each test file for outdated mocks and hook/provider requirements.
- Decide mocking strategy (module-level mocks vs provider injection) and apply consistently.
- Run `tsc --noEmit` and `eslint` focused on `packages/cli/src/ui/components/tabs`.
- Run tab tests in isolation, triage failures, and apply minimal production patches only when tests reveal real bugs.

First immediate actions:
1. Run ESLint and TypeScript check for the tab components.
2. Run the tab test files via Vitest and collect failures.
3. Triage the top 3 failures and apply fixes/mocks.

#### **3.4 Other UI Components** ✅ COMPLETE

- Status: Verified and fixed; Stage 3.4 tests pass (6 files, 55 tests) — 2026-01-21
**Estimated Tests:** ~300 tests  
**Files:** 5 files
- [x] `packages/cli/src/ui/components/__tests__/ContextStatus.test.tsx`
- [x] `packages/cli/src/ui/components/comparison/__tests__/ComparisonView.test.tsx`
- [x] `packages/cli/src/ui/__tests__/minimal-ink.test.tsx`
- [x] `packages/cli/src/ui/contexts/__tests__/HooksContext.property.test.tsx`
- [x] `packages/cli/src/ui/contexts/__tests__/HooksContext.test.tsx`
- [x] `packages/cli/src/ui/contexts/__tests__/MCPContext.test.tsx`
- [x] `packages/cli/src/ui/contexts/__tests__/UICallbacksContext.test.tsx`

**Tasks:**
1. Test context status display
2. Verify comparison view
3. Test UI contexts
4. Check minimal Ink integration

---

### **Stage 4: Hooks System** (Priority: 🟡 MEDIUM)
**Estimated Tests:** ~200 tests  
**Files:** 2 files

- [x] `packages/cli/src/features/hooks/__tests__/adapter.test.ts`
- [x] `packages/cli/src/features/profiles/__tests__/ProfileManager.test.ts`

**Tasks:**
1. Test hook adapter
2. Verify hook execution
3. Test profile management
4. Check hook approval flow

---

### **Stage 5: Test Utilities** (Priority: 🟢 LOW)
**Estimated Tests:** ~300 tests  
**Files:** 6 files

- [ ] `packages/test-utils/src/__tests__/fixtures.test.ts`
- [ ] `packages/test-utils/src/__tests__/mockProviders.test.ts`
- [ ] `packages/test-utils/src/__tests__/performance.stage08.test.ts`
- [ ] `packages/test-utils/src/__tests__/testConfig.test.ts`
- [ ] `packages/test-utils/src/__tests__/testHelpers.test.ts`
- [ ] `packages/test-utils/src/__tests__/tsconfig-inheritance.test.ts`
- [ ] `packages/test-utils/src/__tests__/uiTestHelpers.test.ts`

**Tasks:**
1. Verify test utilities work
2. Test mock providers
3. Check performance tests
4. Verify test helpers

---

### **Stage 6: CLI Entry Points** (Priority: 🟡 MEDIUM)
**Estimated Tests:** ~100 tests  
**Files:** 3 files

- [ ] `packages/cli/src/__tests__/cli.test.ts`
- [ ] `packages/cli/src/__tests__/nonInteractive.property.test.ts`
- [ ] `packages/cli/src/__tests__/themeManager.property.test.ts`

**Tasks:**
1. Test CLI entry point
2. Verify non-interactive mode
3. Test theme management

---

### **Stage 7: Final Integration** (Priority: 🔴 CRITICAL)
**Estimated Tests:** All ~4,500 tests  
**Files:** All 67 files

**Tasks:**
1. Run full test suite
2. Identify tests that pass in isolation but fail in suite
3. Fix interaction issues
4. Verify no test pollution
5. Check test execution order dependencies
6. Final verification

---

## 📝 DETAILED WORKFLOW PER STAGE

### **Step 1: Audit Component Tests**
```bash
# Run tests for specific component
npm run test:unit -- <component-name>

# Example:
npm run test:unit -- contextManager
npm run test:unit -- MCPTab
npm run test:unit -- ChatHistory
```

**For each test file:**
1. Read the test file
2. Check implementation file
3. Document findings in checklist
4. Classify: PASSING, OUTDATED, BROKEN, MISSING, OBSOLETE

### **Step 2: Fix Component Tests**
For each classification:

**OUTDATED:**
- Update test expectations
- Fix timing issues
- Update mocks
- Verify passes

**BROKEN (Real Bug):**
- Document the bug
- Create bug report
- Fix the code OR mark test as expected failure
- Verify fix

**MISSING:**
- Add new tests
- Follow existing patterns
- Verify coverage

**OBSOLETE:**
- Remove test file
- Document removal

### **Step 3: Verify Component Integration**
```bash
# Run all tests for component group
npm run test:unit -- context
npm run test:unit -- mcp
npm run test:unit -- chat
```

**Check:**
- All tests pass together
- No test pollution
- No timing issues
- No race conditions

### **Step 4: Wire Into Suite**
**Verify:**
- Tests follow naming convention (`*.test.ts`, `*.test.tsx`)
- Tests in `__tests__` directory
- Tests discovered by Vitest
- Tests run with `npm run test`

---

## 🎯 EXECUTION PLAN

### **Week 1: Core Infrastructure**
- [ ] Day 1-2: Context Management ✅ DONE
- [ ] Day 3: Provider System
- [ ] Day 4: Prompt System
- [ ] Day 5: Services & Commands

### **Week 2: CLI Features**
- [ ] Day 1-2: Chat Context & Commands
- [ ] Day 3: Configuration
- [ ] Day 4-5: Services

### **Week 3: UI Components (Part 1)**
- [ ] Day 1-3: Chat Components
- [ ] Day 4-5: Dialog Components

### **Week 4: UI Components (Part 2) & Hooks**
- [ ] Day 1-3: Tab Components
- [ ] Day 4: Other UI Components
- [ ] Day 5: Hooks System

### **Week 5: Final Integration**
- [ ] Day 1-2: Test Utilities & CLI Entry Points
- [ ] Day 3-4: Full Suite Integration
- [ ] Day 5: Final Verification & Documentation

---

## 📊 PROGRESS TRACKING

### **Overall Progress:**
- **Total Stages:** 7
- **Completed:** 6 ✅ (Stages 1.1 - Context Management, 1.2 - Provider System, 1.4 - Services, 1.5 - Commands, 1.6 - Core Chat, 3.2 - Dialog Components)
- **In Progress:** 0
- **Remaining:** 2
- **Completion:** 86% (6/7 stages)

### **Test Count:**
- **Total Tests:** ~4,500
- **Reviewed:** ~800 (Context Management)
- **Fixed:** 27 new tests, 2 updated, 1 removed
- **Remaining:** ~3,700

---

## 🔧 TOOLS & COMMANDS

### **Run Specific Component Tests:**
```bash
# Context tests
npm run test:unit -- context

# MCP tests
npm run test:unit -- mcp

# Chat tests
npm run test:unit -- chat

# Hooks tests
npm run test:unit -- hooks

# UI tests
npm run test:unit -- ui
```

### **Run Specific Test File:**
```bash
npm run test:unit -- <filename>

# Example:
npm run test:unit -- autoSummary.test
npm run test:unit -- MCPTab.test
```

### **Run Full Suite:**
```bash
npm run test
```

### **Run with Coverage:**
```bash
npm run test -- --coverage
```

---

## 📋 CHECKLIST TEMPLATE

For each component/stage, create a checklist:

### **Component: [NAME]**
**Files:** [COUNT]  
**Estimated Tests:** [COUNT]  
**Status:** 🔴 TODO / 🟡 IN PROGRESS / ✅ COMPLETE

**Test Files:**
- [ ] `path/to/test1.test.ts` - Status: [PASSING/OUTDATED/BROKEN/MISSING/OBSOLETE]
- [ ] `path/to/test2.test.ts` - Status: [PASSING/OUTDATED/BROKEN/MISSING/OBSOLETE]

**Findings:**
- Issue 1: [Description]
- Issue 2: [Description]

**Fixes Applied:**
- Fix 1: [Description]
- Fix 2: [Description]

**Tests Added:**
- New test 1: [Description]
- New test 2: [Description]

**Verification:**
- [ ] All tests pass in isolation
- [ ] All tests pass together
- [ ] Tests wired into suite
- [ ] No regressions

---

## 🚨 COMMON ISSUES TO WATCH FOR

### **1. Timing Issues**
- Tests fail due to insufficient wait times
- **Fix:** Increase timeouts, use proper async/await

### **2. Mock Outdated**
- Mocks don't match current API
- **Fix:** Update mocks to match implementation

### **3. Missing Features**
- New features not tested
- **Fix:** Add tests for new features

### **4. Obsolete Tests**
- Tests for removed features
- **Fix:** Remove obsolete tests

### **5. Test Pollution**
- Tests pass in isolation but fail in suite
- **Fix:** Ensure proper cleanup, avoid shared state

### **6. Floating-Point Comparisons**
- Tests fail due to precision issues
- **Fix:** Use epsilon comparison

### **7. Event Timing**
- Events don't fire in test environment
- **Fix:** Test behavior, not events

### **8. Race Conditions**
- Tests fail intermittently
- **Fix:** Add proper synchronization

---

## 📄 DELIVERABLES

For each stage:
1. **Audit Report:** `STAGE_X_AUDIT.md`
2. **Fix Summary:** `STAGE_X_FIXES.md`
3. **Test Coverage:** `STAGE_X_COVERAGE.md`
4. **Verification:** `STAGE_X_VERIFIED.md`

Final deliverable:
- **`TEST_SUITE_COMPLETE.md`** - Full suite verification

---

## 🎉 SUCCESS CRITERIA

### **Per Stage:**
- ✅ All tests reviewed
- ✅ All issues classified
- ✅ All fixes applied
- ✅ All tests passing
- ✅ Tests wired into suite
- ✅ Component tests verified

### **Final:**
- ✅ All 67 test files reviewed
- ✅ All ~4,500 tests passing
- ✅ Full suite passes
- ✅ No test pollution
- ✅ Complete documentation

---

**Document Status:** ✅ Complete  
**Created:** 2026-01-20  
**Purpose:** Guide systematic test suite review  
**Next Action:** Start Stage 1.2 - Provider System
