# OLLM CLI - Test Commands Reference

**Last Updated:** January 19, 2026

This document provides all test commands for running tests in the OLLM CLI project, including options for logging and error tracking.

---

## Table of Contents

- [Basic Test Commands](#basic-test-commands)
- [Test Commands with Logging](#test-commands-with-logging)
- [Error-Only Logging](#error-only-logging)
- [Selective Test Execution](#selective-test-execution)
- [Coverage Reports](#coverage-reports)
- [Troubleshooting](#troubleshooting)

---

## Basic Test Commands

### Run All Tests
**Use Case:** Quick validation after making changes, pre-commit checks
```bash
npm test
```

### Run Tests in Watch Mode
**Use Case:** Active development - automatically re-run tests when files change
```bash
npm test -- --watch
```

### Run Tests with Verbose Output
**Use Case:** Debugging test failures, seeing detailed test execution flow
```bash
npm test -- --reporter=verbose
```

### Run Tests with Custom Timeout
**Use Case:** Prevent timeouts on slow tests (integration, MCP, property-based tests)
```bash
npm test -- --testTimeout=30000
```

### Run Specific Test File
**Use Case:** Testing a single feature or component you're working on
```bash
npm test -- packages/core/src/services/__tests__/modelManagement.test.ts
```

### Run Tests Matching Pattern
**Use Case:** Run all tests related to a specific feature across multiple files
```bash
npm test -- --grep "Model Management"
```

---

## Test Commands with Logging

### PowerShell Commands (Windows)

#### Save All Test Output to Log File
**Use Case:** Full test audit, CI/CD logs, sharing test results with team
```powershell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\test-run-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | Tee-Object -FilePath $logFile
Write-Host "Test log saved to: $logFile"
```

#### Save All Output with Custom Timeout
**Use Case:** Long-running integration tests, preventing timeouts while logging everything
```powershell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\test-run-$timestamp.log"
npm test -- --reporter=verbose --testTimeout=30000 2>&1 | Tee-Object -FilePath $logFile
Write-Host "Test log saved to: $logFile"
```

#### Run Tests and Save to Specific Log File
**Use Case:** Consistent log file name for automated scripts or CI pipelines
```powershell
npm test -- --reporter=verbose 2>&1 | Tee-Object -FilePath ".dev\debuging\logs\test-results.log"
```

### Bash Commands (Linux/macOS)

#### Save All Test Output to Log File
**Use Case:** Full test audit, CI/CD logs, sharing test results with team
```bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/test-run-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | tee "$logFile"
echo "Test log saved to: $logFile"
```

#### Save All Output with Custom Timeout
**Use Case:** Long-running integration tests, preventing timeouts while logging everything
```bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/test-run-$timestamp.log"
npm test -- --reporter=verbose --testTimeout=30000 2>&1 | tee "$logFile"
echo "Test log saved to: $logFile"
```

---

## Error-Only Logging

### PowerShell Commands (Windows)

#### Save Only Errors and Failures
**Use Case:** Quick bug identification, focusing on what's broken without noise
```powershell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\test-errors-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | Where-Object { 
    $_ -match "FAIL|Error|×|Test timed out|stderr" 
} | Tee-Object -FilePath $logFile
Write-Host "Error log saved to: $logFile"
```

#### Save Errors with Context (3 lines before/after)
**Use Case:** Understanding error context, seeing what led to the failure
```powershell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\test-errors-$timestamp.log"
$output = npm test -- --reporter=verbose 2>&1 | Out-String
$lines = $output -split "`n"
$errorLines = @()
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match "FAIL|Error|×|Test timed out") {
        $start = [Math]::Max(0, $i - 3)
        $end = [Math]::Min($lines.Count - 1, $i + 3)
        $errorLines += $lines[$start..$end]
        $errorLines += "---"
    }
}
$errorLines | Out-File -FilePath $logFile
Write-Host "Error log with context saved to: $logFile"
```

#### Save Only Failed Test Names
**Use Case:** Creating a quick list of failing tests for issue tracking or prioritization
```powershell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\test-failures-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | Select-String -Pattern "×.*>" | Tee-Object -FilePath $logFile
Write-Host "Failed test list saved to: $logFile"
```

### Bash Commands (Linux/macOS)

#### Save Only Errors and Failures
**Use Case:** Quick bug identification, focusing on what's broken without noise
```bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/test-errors-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | grep -E "FAIL|Error|×|Test timed out|stderr" | tee "$logFile"
echo "Error log saved to: $logFile"
```

#### Save Errors with Context (3 lines before/after)
**Use Case:** Understanding error context, seeing what led to the failure
```bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/test-errors-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | grep -E -B 3 -A 3 "FAIL|Error|×|Test timed out" | tee "$logFile"
echo "Error log with context saved to: $logFile"
```

#### Save Only Failed Test Names
**Use Case:** Creating a quick list of failing tests for issue tracking or prioritization
```bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/test-failures-$timestamp.log"
npm test -- --reporter=verbose 2>&1 | grep "×.*>" | tee "$logFile"
echo "Failed test list saved to: $logFile"
```

---

## Selective Test Execution

### Exclude Specific Test Files
**Use Case:** Skip known problematic tests (timeouts, flaky tests) for faster CI runs
```bash
# Exclude MCP tests that timeout
npm test -- --exclude="**/mcpClient.test.ts" --exclude="**/mcpTransport.test.ts"
```

### Run Only Unit Tests
**Use Case:** Fast feedback loop during development, pre-commit validation
```bash
npm test -- --exclude="**/*.integration.test.ts" --exclude="**/*.property.test.ts"
```

### Run Only Integration Tests
**Use Case:** Testing component interactions, validating system behavior
```bash
npm test -- packages/core/src/**/*.integration.test.ts
```

### Run Only Property Tests
**Use Case:** Thorough validation with property-based testing, edge case discovery
```bash
npm test -- packages/core/src/**/*.property.test.ts
```

### Run Tests for Specific Package
**Use Case:** Testing changes isolated to a single package
```bash
# Core package only
npm test -- packages/core/

# CLI package only
npm test -- packages/cli/

# Bridge package only
npm test -- packages/ollm-bridge/

# Test utils only
npm test -- packages/test-utils/
```

### Run Tests by Category

#### Context Management Tests
**Use Case:** Validating context compression, VRAM monitoring, snapshot features
```bash
npm test -- packages/core/src/context/
```

#### Service Tests
**Use Case:** Testing business logic, model management, memory services
```bash
npm test -- packages/core/src/services/
```

#### Tool Tests
**Use Case:** Validating tool execution, output formatting, tool registry
```bash
npm test -- packages/core/src/tools/
```

#### MCP Tests
**Use Case:** Testing MCP client, transport, server integration
```bash
npm test -- packages/core/src/mcp/
```

#### UI Tests
**Use Case:** Testing React components, Ink rendering, user interactions
```bash
npm test -- packages/cli/src/ui/
```

---

## Coverage Reports

### Generate Coverage Report
**Use Case:** Checking test coverage percentage, identifying untested code
```bash
npm test -- --coverage
```

### Generate Coverage with HTML Report
**Use Case:** Visual coverage analysis, sharing coverage reports with team
```bash
npm test -- --coverage --coverage.reporter=html
```

### Save Coverage Report to Log
**Use Case:** Tracking coverage over time, CI/CD coverage validation
```powershell
# PowerShell
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$logFile = ".dev\debuging\logs\coverage-$timestamp.log"
npm test -- --coverage 2>&1 | Tee-Object -FilePath $logFile
```

```bash
# Bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
logFile=".dev/debuging/logs/coverage-$timestamp.log"
npm test -- --coverage 2>&1 | tee "$logFile"
```

### Check Coverage Thresholds
**Use Case:** Enforcing minimum coverage requirements, preventing coverage regression
```bash
npm test -- --coverage --coverage.lines=80 --coverage.functions=80
```

---

## Troubleshooting

### Common Issues and Solutions

#### Tests Timing Out

**Problem:** Tests exceed the default timeout (5000ms)

**Use Case:** Integration tests, MCP server tests, property-based tests that need more time

**Solution:** Increase timeout
```bash
npm test -- --testTimeout=30000
```

#### Memory Issues

**Problem:** Tests fail with out-of-memory errors

**Use Case:** Running full test suite, property-based tests with large datasets

**Solution:** Increase Node.js memory limit
```bash
NODE_OPTIONS="--max-old-space-size=4096" npm test
```

#### Flaky Tests

**Problem:** Tests pass/fail inconsistently

**Use Case:** Timing-dependent tests, async operations, race conditions

**Solution:** Run tests multiple times
```bash
npm test -- --retry=3
```

#### Slow Test Execution

**Problem:** Tests take too long to run

**Use Case:** Large test suites, CI/CD optimization, local development speed

**Solution:** Run tests in parallel (default) or adjust workers
```bash
# Use specific number of workers
npm test -- --pool=threads --poolOptions.threads.maxThreads=4

# Run sequentially for debugging
npm test -- --pool=forks --poolOptions.forks.singleFork
```

### Debug Specific Test

#### Run Single Test with Debug Output
**Use Case:** Debugging a specific failing test, understanding test behavior
```bash
npm test -- --reporter=verbose --testNamePattern="should handle model selection"
```

#### Run Test File with Debug Logging
**Use Case:** Deep debugging with full logging, troubleshooting test infrastructure
```bash
DEBUG=* npm test -- packages/core/src/services/__tests__/modelManagement.test.ts
```

### Analyze Test Performance

#### Show Test Duration
**Use Case:** Identifying slow tests, optimizing test performance
```bash
npm test -- --reporter=verbose | grep -E "ms$"
```

#### Find Slowest Tests (PowerShell)
**Use Case:** Performance optimization, identifying bottlenecks in test suite
```powershell
npm test -- --reporter=verbose 2>&1 | Select-String -Pattern "\d+ms$" | 
    ForEach-Object { 
        if ($_ -match "(\d+)ms$") { 
            [PSCustomObject]@{Duration=$matches[1]; Line=$_} 
        } 
    } | Sort-Object {[int]$_.Duration} -Descending | Select-Object -First 10
```

---

## Quick Reference

### Most Common Commands

```bash
# Run all tests with logging
# Use Case: Complete test audit with full output saved
npm test -- --reporter=verbose 2>&1 | tee test-results.log

# Run tests excluding timeouts
# Use Case: Quick validation without waiting for slow MCP tests
npm test -- --testTimeout=30000 --exclude="**/mcpClient.test.ts"

# Run only failed tests from previous run
# Use Case: Fixing bugs - re-run only what failed last time
npm test -- --changed

# Run tests with coverage
# Use Case: Checking test coverage before PR submission
npm test -- --coverage

# Run specific test file
# Use Case: Testing a single feature you're actively developing
npm test -- path/to/test.ts

# Run tests matching pattern
# Use Case: Testing all related functionality across multiple files
npm test -- --grep "Model Management"
```

### Log File Naming Convention

- Full test runs: `test-run-YYYY-MM-DD_HH-MM-SS.log`
- Error logs: `test-errors-YYYY-MM-DD_HH-MM-SS.log`
- Failure lists: `test-failures-YYYY-MM-DD_HH-MM-SS.log`
- Coverage reports: `coverage-YYYY-MM-DD_HH-MM-SS.log`

---

## Environment Variables

### Useful Test Environment Variables

```bash
# Increase Node.js memory
NODE_OPTIONS="--max-old-space-size=4096"

# Enable debug logging
DEBUG=*

# Set test timeout globally
VITEST_TIMEOUT=30000

# Disable color output (for cleaner logs)
NO_COLOR=1

# Run tests in CI mode
CI=true
```

### Example with Multiple Variables (PowerShell)
```powershell
$env:NODE_OPTIONS="--max-old-space-size=4096"
$env:NO_COLOR="1"
npm test -- --reporter=verbose
```

### Example with Multiple Variables (Bash)
```bash
NODE_OPTIONS="--max-old-space-size=4096" NO_COLOR=1 npm test -- --reporter=verbose
```

---

## Notes

- All log files are saved to `.dev/debuging/logs/` directory
- The logs directory is created automatically if it doesn't exist
- Log files use timestamps to prevent overwriting
- Use `--reporter=verbose` for detailed test output
- Use `--testTimeout` to prevent timeout failures on slow tests
- MCP tests may timeout due to process spawning - consider excluding them for quick runs
- Property-based tests may take longer - adjust timeout accordingly

---

## Related Documentation

- [Vitest Documentation](https://vitest.dev/)
- [Test Utils Package](../packages/test-utils/README.md)
- [Bug Tracker](.dev/bugtracker.md)
- [Development Plan](.dev/development-plan.md)
