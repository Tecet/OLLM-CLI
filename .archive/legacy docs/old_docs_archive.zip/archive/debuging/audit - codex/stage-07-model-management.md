# Stage 07 - Model Management Audit

## 1) Scope and sources
- `.kiro/specs/stage-07-model-management/requirements.md`
- `.kiro/specs/stage-07-model-management/design.md`
- `.kiro/specs/stage-07-model-management/tasks.md`
- `.dev/draft/commands.md`
- `.dev/draft/memory-system.md`

## 2) Claimed intent
- Model management service supports list, pull, delete, and info.
- Comparison, templates, and project profiles are user-facing commands.
- Memory system supports search and LLM-initiated "remember" tool.
- Environment variables like OLLM_MODEL set defaults.

## 3) Implemented evidence
- Core services for model management, templates, memory, and project profiles exist in `packages/core/src/services/modelManagementService.ts:1`, `packages/core/src/services/templateService.ts:1`, `packages/core/src/services/memoryService.ts:1`, `packages/core/src/services/projectProfileService.ts:1`.
- CLI command handlers for model/template/memory/project exist under `packages/cli/src/commands`.

## 4) Missing or incomplete items
- `/compare` uses ComparisonService with `provider: undefined` and lacks DI setup (`packages/cli/src/commands/comparisonCommands.ts:41`), so the command cannot function as intended.
- `/project` commands instantiate `ProjectProfileService` via `Object as any` and have TODO DI (`packages/cli/src/commands/projectCommands.ts:11`, `packages/cli/src/commands/projectCommands.ts:168`).
- `/template create` only returns manual instructions and does not create a template file (`packages/cli/src/commands/templateCommands.ts:123`), conflicting with `.kiro/specs/stage-07-model-management/requirements.md:229`.
- `/memory search` is documented but not implemented in CLI (`packages/cli/src/commands/memoryCommands.ts:158` vs `.dev/draft/commands.md:137`).
- `RememberTool` exists but is not registered in the tool registry (`packages/core/src/tools/index.ts:19`, `packages/core/src/tools/index.ts:123`), conflicting with `.dev/draft/memory-system.md:281`.
- CLI config loader uses `OLLM_DEFAULT_MODEL` instead of `OLLM_MODEL` (`packages/cli/src/config/configLoader.ts:240`), conflicting with `.kiro/specs/stage-07-model-management/requirements.md:135`.
- `/model info` expects fields like `capabilities` and `contextWindow`, but LocalProvider `showModel` returns only `details` (and uses different field names), which will break formatting (`packages/cli/src/commands/modelCommands.ts:191`, `packages/ollm-bridge/src/provider/localProvider.ts:590`).

## 5) Divergences
- Draft command guide lists `/memory search` (`.dev/draft/commands.md:137`) and describes the `remember` tool (`.dev/draft/memory-system.md:281`), but the CLI and tool registry do not expose these behaviors (`packages/cli/src/commands/memoryCommands.ts:158`, `packages/core/src/tools/index.ts:123`).
- Spec calls for `OLLM_MODEL` environment variable (`.kiro/specs/stage-07-model-management/requirements.md:135`), but CLI config uses `OLLM_DEFAULT_MODEL` (`packages/cli/src/config/configLoader.ts:240`).

## 6) Verification notes
- Static inspection only. No model operations or CLI commands executed.

## 7) Open questions / assumptions
- Should `showModel` be normalized in the provider adapter or in the CLI formatting layer?

## 8) Re-audit note
- Re-audited against current code (static inspection). Findings unchanged.

