# Stage 03 - Tools and Policy Audit

## 1) Scope and sources
- `.kiro/specs/stage-03-tools-policy/requirements.md`
- `.kiro/specs/stage-03-tools-policy/design.md`
- `.kiro/specs/stage-03-tools-policy/tasks.md`
- `.dev/draft/tools.md`

## 2) Claimed intent
- File tools should preserve encoding, handle binary files, and validate allowed directories.
- Web tools should fetch with CSS selectors and provide real search results.
- Tool registry and policy engine should guard tool execution.

## 3) Implemented evidence
- Built-in tools are registered in `packages/core/src/tools/index.ts:110`.
- Tool system integration tests exist (example `packages/core/src/tools/__tests__/tool-system-integration.test.ts:100`).

## 4) Missing or incomplete items
- `read_file` always reads UTF-8, which does not preserve original encoding (`packages/core/src/tools/read-file.ts:144`), contrary to `.kiro/specs/stage-03-tools-policy/requirements.md:50`.
- `write_file` does not validate paths against allowed directories before writing (`packages/core/src/tools/write-file.ts:136`), contrary to `.kiro/specs/stage-03-tools-policy/requirements.md:65`.
- `web_search` defaults to a provider that returns an empty array (`packages/core/src/tools/web-search.ts:36`), so searches return no real results, contrary to `.kiro/specs/stage-03-tools-policy/requirements.md:112`.
- `web_fetch` selector extraction only matches tag names via regex, not general CSS selectors (`packages/core/src/tools/web-fetch.ts:170`), contrary to `.kiro/specs/stage-03-tools-policy/requirements.md:108`.

## 5) Divergences
- Draft tools overview lists web search as a supported tool (`.dev/draft/tools.md:4`), but the default provider returns empty results (`packages/core/src/tools/web-search.ts:43`).

## 6) Verification notes
- Static inspection only. No tool execution or network calls performed.

## 7) Open questions / assumptions
- Is there a separate policy or sandbox layer intended to enforce allowed directory checks for file write tools?

## 8) Re-audit note
- Re-audited against current code (static inspection). Findings unchanged.

