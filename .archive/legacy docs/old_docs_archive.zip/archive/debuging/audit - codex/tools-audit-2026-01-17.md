# Tools Implementation Audit
**Date:** January 17, 2026  
**Auditor:** System Analysis  
**Scope:** All 15 tool implementations in `packages/core/src/tools/`

## Executive Summary

This audit reviews all 15 tool implementations for:
- Logic correctness and edge cases
- Security vulnerabilities
- Error handling completeness
- Performance issues
- Code quality and maintainability
- Missing features or improvements

### Overall Assessment
- **Critical Issues:** 2
- **High Priority Issues:** 5
- **Medium Priority Issues:** 8
- **Low Priority Issues:** 6
- **Recommendations:** 12

---

## 1. File Operations Tools

### 1.1 read-file.ts

**Status:** ✅ Good with minor improvements needed

**Strengths:**
- Proper file size validation (10MB limit)
- Good error handling for common cases (ENOENT, EACCES, binary files)
- Line range support with validation
- Abort signal handling

**Issues:**

#### 🟡 MEDIUM: Line range validation edge case
**Location:** Line 127-128
```typescript
if (end < start + 1) {
```
**Issue:** Should be `end <= start` to catch equal start/end properly
**Impact:** May allow invalid ranges like startLine=5, endLine=5
**Fix:**
```typescript
if (end <= start) {
  return {
    llmContent: '',
    returnDisplay: '',
    error: {
      message: `Invalid line range: endLine (${this.params.endLine}) must be > startLine (${this.params.startLine})`,
      type: 'InvalidLineRangeError',
    },
  };
}
```

#### 🟢 LOW: Binary file detection is weak
**Location:** Line 161-164
**Issue:** Relies on error message string matching which is fragile
**Recommendation:** Use a proper binary detection library or check for null bytes
```typescript
// Better approach:
const hasBinaryContent = content.includes('\0');
if (hasBinaryContent) {
  return {
    llmContent: '',
    returnDisplay: '',
    error: {
      message: `File appears to be binary: ${this.params.path}`,
      type: 'BinaryFileError',
    },
  };
}
```

---

### 1.2 read-many-files.ts

**Status:** ✅ Good

**Strengths:**
- Continues on individual file errors (resilient)
- Provides summary of successes/failures
- Streaming output support
- Consistent error handling

**Issues:**

#### 🟢 LOW: No overall size limit
**Issue:** Could read 100 files × 10MB = 1GB of data
**Recommendation:** Add aggregate size limit
```typescript
const MAX_TOTAL_SIZE = 50 * 1024 * 1024; // 50MB total
let totalSize = 0;

// Before reading each file:
if (totalSize + stats.size > MAX_TOTAL_SIZE) {
  results.push(`=== ${filePath} ===\nError: Total size limit exceeded\n`);
  break;
}
totalSize += stats.size;
```

---

### 1.3 write-file.ts

**Status:** ⚠️ Needs attention

**Issues:**

#### 🔴 CRITICAL: Race condition in file existence check
**Location:** Lines 103-113
**Issue:** TOCTOU (Time-of-check-time-of-use) vulnerability
```typescript
// Check if file exists
let exists = false;
try {
  const stats = await fs.stat(resolvedPath);
  exists = true;
} catch {
  exists = false;
}

// Later: write the file
if (exists && !this.params.overwrite) {
  return error...
}
```
**Impact:** Two concurrent writes could both pass the existence check
**Fix:** Use atomic file operations with `wx` flag
```typescript
try {
  // Create parent directories
  await fs.mkdir(dir, { recursive: true });
  
  // Use 'wx' flag for atomic create-only operation
  if (!this.params.overwrite) {
    await fs.writeFile(resolvedPath, this.params.content, { 
      encoding: 'utf-8',
      flag: 'wx' // Fail if file exists
    });
  } else {
    await fs.writeFile(resolvedPath, this.params.content, 'utf-8');
  }
} catch (error) {
  if ((error as NodeJS.ErrnoException).code === 'EEXIST') {
    return {
      llmContent: '',
      returnDisplay: '',
      error: {
        message: `File ${this.params.path} already exists. Set overwrite=true to replace it.`,
        type: 'FileExistsError',
      },
    };
  }
  throw error;
}
```

#### 🟡 MEDIUM: No content size validation
**Issue:** Could write gigabytes of data
**Recommendation:** Add size limit
```typescript
const MAX_WRITE_SIZE = 10 * 1024 * 1024; // 10MB
if (this.params.content.length > MAX_WRITE_SIZE) {
  return {
    llmContent: '',
    returnDisplay: '',
    error: {
      message: `Content too large: ${this.params.content.length} bytes (max ${MAX_WRITE_SIZE} bytes)`,
      type: 'ContentTooLargeError',
    },
  };
}
```

---

### 1.4 edit-file.ts

**Status:** ⚠️ Needs attention

**Issues:**

#### 🔴 CRITICAL: Regex escape function is broken
**Location:** Line 177
```typescript
private escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\bd9b6a4d-6da0-4110-92bf-9fe51781a2ee');
}
```
**Issue:** This is completely wrong! It replaces special chars with a UUID instead of escaping them
**Impact:** Regex matching will fail for any string with special characters
**Fix:**
```typescript
private escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
```

#### 🟠 HIGH: No atomic write operation
**Issue:** File is modified in-place without backup
**Impact:** If write fails, original file is lost
**Recommendation:** Write to temp file first, then rename
```typescript
// After applying all edits:
const tempPath = `${resolvedPath}.tmp.${Date.now()}`;
try {
  await fs.writeFile(tempPath, content, 'utf-8');
  await fs.rename(tempPath, resolvedPath);
} catch (error) {
  // Clean up temp file
  try {
    await fs.unlink(tempPath);
  } catch {
    // Ignore cleanup errors
  }
  throw error;
}
```

#### 🟡 MEDIUM: Multiple edits could conflict
**Issue:** Edits are applied sequentially, later edits might not find their targets if earlier edits modified the same area
**Recommendation:** Validate all targets exist before applying any edits
```typescript
// Before applying edits, validate all targets exist
for (const edit of this.params.edits) {
  const escapedTarget = this.escapeRegex(edit.target);
  const regex = new RegExp(escapedTarget, 'g');
  const matches = content.match(regex);
  const occurrences = matches ? matches.length : 0;
  
  if (occurrences === 0) {
    return {
      llmContent: '',
      returnDisplay: '',
      error: {
        message: `Target text not found: "${edit.target}"`,
        type: 'EditTargetNotFound',
      },
    };
  }
  
  if (occurrences > 1) {
    return {
      llmContent: '',
      returnDisplay: '',
      error: {
        message: `Target text is ambiguous (${occurrences} matches): "${edit.target}"`,
        type: 'EditTargetAmbiguous',
      },
    };
  }
}

// Now apply all edits
for (const edit of this.params.edits) {
  content = content.replace(edit.target, edit.replacement);
}
```

---

## 2. File Discovery Tools

### 2.1 ls.ts

**Status:** ✅ Good

**Strengths:**
- Respects .gitignore patterns
- Proper recursion depth control
- Hidden file filtering
- Good error handling for permission errors

**Issues:**

#### 🟢 LOW: Path normalization inconsistency
**Location:** Line 127
**Issue:** Only normalizes for gitignore check, not for display
**Recommendation:** Normalize all paths consistently

---

### 2.2 glob.ts

**Status:** ✅ Good

**Strengths:**
- Respects .gitignore patterns
- Result limiting
- Proper hidden file handling
- Uses established glob library

**Issues:**

#### 🟢 LOW: Hardcoded ignore patterns
**Location:** Line 91
```typescript
ignore: ['**/node_modules/**', '**/.git/**'],
```
**Recommendation:** Make these configurable or load from .gitignore

---

### 2.3 grep.ts

**Status:** ⚠️ Needs attention

**Issues:**

#### 🟠 HIGH: Regex flag recreation in loop
**Location:** Line 115
```typescript
for (let i = 0; i < lines.length; i++) {
  const regex = new RegExp(this.params.pattern, flags);
  if (regex.test(lines[i])) {
```
**Issue:** Creates new regex object for every line - very inefficient
**Impact:** Performance degradation on large files
**Fix:**
```typescript
// Create regex once before the loop
const regex = new RegExp(this.params.pattern, flags);
for (let i = 0; i < lines.length; i++) {
  // Reset lastIndex if using global flag
  regex.lastIndex = 0;
  if (regex.test(lines[i])) {
```

#### 🟡 MEDIUM: No regex validation
**Issue:** Invalid regex patterns will throw errors
**Recommendation:** Validate regex before searching
```typescript
try {
  new RegExp(this.params.pattern, flags);
} catch (error) {
  return {
    llmContent: '',
    returnDisplay: '',
    error: {
      message: `Invalid regex pattern: ${this.params.pattern}`,
      type: 'InvalidRegexError',
    },
  };
}
```

#### 🟡 MEDIUM: Binary file handling
**Issue:** Tries to read all files as UTF-8, silently skips binary files
**Recommendation:** Detect and report binary files

---

## 3. Shell Execution Tool

### 3.1 shell.ts

**Status:** ✅ Good

**Strengths:**
- Uses dedicated ShellExecutionService
- Environment sanitization
- Timeout support (both total and idle)
- Background execution support
- Good error categorization

**Issues:**

#### 🟡 MEDIUM: Default timeout might be too short
**Location:** Line 127
```typescript
timeout: this.params.timeout ?? 30000,
```
**Issue:** 30 seconds might be too short for some operations (npm install, builds)
**Recommendation:** Make default configurable, or increase to 60000ms

#### 🟢 LOW: Exit code hint logic is basic
**Location:** Lines 143-150
**Recommendation:** Expand hint database for more common errors

---

## 4. Web Access Tools

### 4.1 web-fetch.ts

**Status:** ✅ Good

**Strengths:**
- URL validation
- Protocol validation (http/https only)
- Timeout handling
- Content truncation
- Abort signal handling

**Issues:**

#### 🟡 MEDIUM: CSS selector extraction is primitive
**Location:** Line 127-141
**Issue:** Only supports simple tag selectors, no class/id/attribute selectors
**Recommendation:** Use a proper HTML parser library (jsdom, cheerio)
```typescript
// Better approach with cheerio:
import * as cheerio from 'cheerio';

private extractWithSelector(html: string, selector: string): string {
  try {
    const $ = cheerio.load(html);
    const elements = $(selector);
    return elements.map((_, el) => $(el).text().trim()).get().join('\n\n');
  } catch (error) {
    // Fall back to returning full HTML
    return html;
  }
}
```

#### 🟢 LOW: No redirect limit
**Issue:** Could follow infinite redirects
**Recommendation:** Add redirect limit to fetch options
```typescript
const response = await fetch(this.params.url, {
  signal: combinedSignal,
  redirect: 'follow',
  // Note: fetch API doesn't have built-in redirect limit
  // Consider using a library like node-fetch with redirect limit
});
```

---

### 4.2 web-search.ts

**Status:** ✅ Good (but incomplete)

**Strengths:**
- Clean interface design
- Dependency injection for search provider
- Good parameter validation
- Result limiting

**Issues:**

#### 🟢 LOW: Default provider returns empty results
**Location:** Line 40-45
**Issue:** DefaultSearchProvider is a stub
**Recommendation:** Implement with a real search API or document that it needs configuration

---

## 5. Memory & State Tools

### 5.1 memory.ts

**Status:** ✅ Excellent

**Strengths:**
- Atomic writes with temp file + rename
- Null-prototype objects to prevent prototype pollution
- Object.hasOwn() for safe property checks
- Good concurrent access safety
- Comprehensive error handling

**Issues:**

#### 🟢 LOW: No memory size limit
**Issue:** Could store unlimited data
**Recommendation:** Add size limit per key and total size limit

---

### 5.2 remember.ts

**Status:** ✅ Good

**Strengths:**
- Clean integration with MemoryService
- Category support
- Source tracking ('llm')

**Issues:**

#### 🟢 LOW: Depends on external MemoryService
**Issue:** No validation that MemoryService is properly initialized
**Recommendation:** Add null check for memoryService

---

### 5.3 write-todos.ts

**Status:** ✅ Excellent

**Strengths:**
- Atomic writes with temp file + rename
- UUID for unique IDs
- ISO timestamps
- Good validation
- Comprehensive CRUD operations

**Issues:**

#### 🟢 LOW: No todo limit
**Issue:** Could create unlimited todos
**Recommendation:** Add limit (e.g., 1000 todos max)

---

## 6. Context Management Tools

### 6.1 HotSwapTool.ts

**Status:** ⚠️ Needs attention

**Issues:**

#### 🟠 HIGH: Complex parameter extraction logic
**Location:** Lines 67-85
**Issue:** Overly complex extraction with multiple fallbacks
**Impact:** Hard to maintain, prone to bugs
**Recommendation:** Simplify and validate input format
```typescript
// Simpler approach:
let skills: string[] = [];
if (Array.isArray(this.params.skills)) {
  skills = this.params.skills.map(String);
} else if (typeof this.params.skills === 'string') {
  skills = [this.params.skills];
} else if (this.params.skills) {
  return {
    llmContent: '',
    returnDisplay: '',
    error: {
      message: 'skills parameter must be an array of strings or a single string',
      type: 'ValidationError',
    },
  };
}
```

#### 🟡 MEDIUM: No validation of skill IDs
**Issue:** Accepts any skill IDs without checking if they exist
**Recommendation:** Validate against available skills

---

### 6.2 MemoryDumpTool.ts

**Status:** ✅ Good

**Strengths:**
- Simple and focused
- Good file naming with timestamps
- Creates directory if needed

**Issues:**

#### 🟢 LOW: No size limit on content
**Issue:** Could write gigabytes
**Recommendation:** Add size limit (e.g., 10MB)

#### 🟢 LOW: Hardcoded directory
**Location:** Line 48
```typescript
const dumpDir = path.join(process.cwd(), '.ollm', 'memory');
```
**Recommendation:** Make configurable

---

## 7. Tool System Infrastructure

### 7.1 types.ts

**Status:** ✅ Excellent

**Strengths:**
- Clean interface design
- Good separation of concerns
- Comprehensive type definitions
- Well-documented

**No issues found.**

---

### 7.2 tool-registry.ts

**Status:** ✅ Excellent

**Strengths:**
- Clean registry pattern
- Validation integration
- Alphabetical sorting for consistency
- Good error handling

**Issues:**

#### 🟢 LOW: No tool versioning
**Issue:** Can't have multiple versions of same tool
**Recommendation:** Consider adding version support for future extensibility

---

## Priority Issues Summary

### 🔴 Critical (Fix Immediately)

1. **edit-file.ts:** Broken regex escape function (Line 177)
   - **Impact:** Tool completely broken for strings with special characters
   - **Fix:** Replace UUID with proper escape sequence `\\$&`

2. **write-file.ts:** Race condition in file existence check (Lines 103-113)
   - **Impact:** Data corruption possible with concurrent writes
   - **Fix:** Use atomic operations with `wx` flag

### 🟠 High Priority (Fix Soon)

3. **edit-file.ts:** No atomic write operation
   - **Impact:** File corruption if write fails
   - **Fix:** Write to temp file, then rename

4. **grep.ts:** Regex recreation in loop
   - **Impact:** Severe performance degradation
   - **Fix:** Create regex once before loop

5. **HotSwapTool.ts:** Complex parameter extraction
   - **Impact:** Maintenance burden, potential bugs
   - **Fix:** Simplify validation logic

6. **write-file.ts:** No content size validation
   - **Impact:** Could exhaust disk space
   - **Fix:** Add 10MB limit

7. **grep.ts:** No regex validation
   - **Impact:** Crashes on invalid regex
   - **Fix:** Validate before use

### 🟡 Medium Priority (Address When Possible)

8. **read-file.ts:** Line range validation edge case
9. **edit-file.ts:** Multiple edits could conflict
10. **grep.ts:** Binary file handling
11. **shell.ts:** Default timeout might be too short
12. **web-fetch.ts:** CSS selector extraction is primitive
13. **HotSwapTool.ts:** No validation of skill IDs
14. **read-many-files.ts:** No overall size limit
15. **glob.ts:** Hardcoded ignore patterns

### 🟢 Low Priority (Nice to Have)

16-21. Various improvements for robustness and features

---

## Recommendations

### Security
1. ✅ Add input validation for all file paths (prevent path traversal)
2. ✅ Add size limits for all write operations
3. ✅ Use atomic operations for file writes
4. ✅ Validate regex patterns before use

### Performance
5. ✅ Fix regex recreation in grep loop
6. ✅ Consider caching for gitignore patterns
7. ✅ Add streaming for large file operations

### Reliability
8. ✅ Add atomic writes for all file modifications
9. ✅ Improve error messages with actionable hints
10. ✅ Add retry logic for transient failures

### Maintainability
11. ✅ Simplify complex parameter extraction logic
12. ✅ Add comprehensive unit tests for edge cases
13. ✅ Document security considerations in code comments

---

## Testing Gaps

Tools that need additional test coverage:
1. **edit-file.ts** - Test regex escaping, multiple edits, edge cases
2. **write-file.ts** - Test concurrent writes, race conditions
3. **grep.ts** - Test performance with large files, invalid regex
4. **HotSwapTool.ts** - Test parameter extraction edge cases
5. **web-fetch.ts** - Test CSS selector extraction, timeouts

---

## Conclusion

Overall, the tool implementations are well-structured and follow good patterns. However, there are **2 critical bugs** that need immediate attention:

1. The broken regex escape function in `edit-file.ts`
2. The race condition in `write-file.ts`

Additionally, there are **5 high-priority issues** related to performance, security, and reliability that should be addressed soon.

The memory and todo tools demonstrate excellent patterns (atomic writes, null-prototype objects) that should be applied to other file-writing tools.

**Next Steps:**
1. Fix critical bugs immediately
2. Address high-priority issues in next sprint
3. Add comprehensive test coverage for edge cases
4. Consider adding integration tests for concurrent operations
