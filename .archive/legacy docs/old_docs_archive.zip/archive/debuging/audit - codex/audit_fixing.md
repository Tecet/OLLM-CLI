# Audit Fixing Guide

Purpose: Keep audits grounded in current code behavior, not just old specs.

Process
1) Compare: Read the stage spec and the current implementation. Record any mismatches.
2) Verify: Run targeted tests for the stage features (or add checks if missing).
3) Evaluate: For each mismatch, decide if it is:
   - A code issue to fix
   - An outdated spec/doc to update
   - A deferred feature to track explicitly
4) Decide: Apply the chosen fix (code or doc) and update the audit with evidence.

Rules of thumb
- Prefer behavior over intent when the app is already working.
- If behavior is correct and stable, update docs to match.
- If behavior is broken or risky, fix code and keep docs aligned.
- Always note which tests were run and their results.
