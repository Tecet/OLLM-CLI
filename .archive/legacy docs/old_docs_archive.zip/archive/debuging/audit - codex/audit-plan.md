﻿# Audit plan

## System prompt (audit agent)
You are an audit agent specialized in verifying this project. Your job is to compare the implementation against the roadmap and specs in `.kiro/specs`, the concept documents in `.dev/draft`, and the published documentation in `docs` plus related documentation in `.dev` (for example `.dev/reference`, `.dev/Context`, `.dev/Models`, `.dev/templates`, `.dev/README.md`, `.dev/development-plan.md`, `.dev/task-tracking-guide.md`). Identify gaps, unfinished work, and divergences. For each stage, produce a concise report that cites evidence (files, line numbers) and clearly separates implemented items from missing or partial items. Do not change code unless explicitly asked.

## Scope and sources
- Roadmap truth source: `.kiro/specs` stages 01-15.
- Concepts and intended behavior: `.dev/draft` documents.
- Published docs and supporting notes: `docs` and related `.dev` documentation.
- Implementation evidence: `packages`, `scripts`, `dist`, and any runtime/config files at repo root.
- Claims of completion: `README.md`, `CHANGELOG.md`, and `.dev/*tracking*.md`.

## Deliverables
Create `.dev/audit/` reports as markdown files:
- Stage 01-07: one file per stage (match spec naming where possible).
- Stage 08: testing/QA.
- Stage 09: docs/release.
- Stage 10+ future feature development: one file per stage (10-15).
- Each report must list differences between documentation and code implementation.

Suggested filenames:
- `.dev/audit/stage-01-foundation.md`
- `.dev/audit/stage-02-core-provider.md`
- `.dev/audit/stage-03-tools-policy.md`
- `.dev/audit/stage-04-services-sessions.md` (include stage-04b context management within this file, or add a dedicated `stage-04b-context-management.md` if it needs separate tracking)
- `.dev/audit/stage-05-hooks-extensions-mcp.md`
- `.dev/audit/stage-06-cli-ui.md`
- `.dev/audit/stage-07-model-management.md`
- `.dev/audit/stage-08-testing-qa.md`
- `.dev/audit/stage-09-docs-release.md`
- `.dev/audit/stage-10-kraken-integration-future-dev.md`
- `.dev/audit/stage-11-developer-productivity-future-dev.md`
- `.dev/audit/stage-12-cross-platform-future-dev.md`
- `.dev/audit/stage-13-vllm-openai-future-dev.md`
- `.dev/audit/stage-14-file-upload-future-dev.md`
- `.dev/audit/stage-15-intelligence-layer-future-dev.md`

## Report template (use consistently)
For each stage report, use this structure:
1) Scope and sources (spec files, concept docs, docs used)
2) Claimed intent (short bullet list from specs/docs)
3) Implemented evidence (code/config/test references)
4) Missing or incomplete items (gaps vs specs/docs)
5) Divergences (implemented behavior conflicts with docs/specs)
6) Verification notes (tests run, logs, or limits)
7) Open questions / assumptions

## Methodology
1) Extract claims: read the stage spec in `.kiro/specs` and the related `.dev/draft` and `docs` pages. Build a checklist of requirements.
2) Map to implementation: use `rg` searches and trace references to code/config. Cite file paths and lines.
3) Verify behavior: prefer static verification; run tests only when required and with approval.
4) Record gaps: classify as missing, partial, outdated doc, or diverged behavior.
5) Maintain traceability: every claim should have a reference to a spec/doc and evidence or a stated lack of evidence.

## Notes and constraints
- Keep content ASCII unless existing files already use non-ASCII.
- Use concise, factual language. Avoid broad assumptions without evidence.
- If a source document cannot be found or is ambiguous, note it explicitly.
- Do not delete or modify existing work unless asked.
