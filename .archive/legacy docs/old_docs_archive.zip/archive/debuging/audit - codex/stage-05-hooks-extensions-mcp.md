# Stage 05 - Hooks, Extensions, MCP Audit

## 1) Scope and sources
- `.kiro/specs/stage-05-hooks-extensions-mcp/requirements.md`
- `.kiro/specs/stage-05-hooks-extensions-mcp/design.md`
- `.kiro/specs/stage-05-hooks-extensions-mcp/tasks.md`

## 2) Claimed intent
- Extension manager loads manifests, hooks, MCP servers, and settings.
- MCP OAuth flow supports token refresh and CLI auth commands.
- Extension installation should support extracting packaged archives.

## 3) Implemented evidence
- Extension registry and install flow exist in `packages/core/src/extensions/extensionRegistry.ts:247`.
- MCP OAuth provider scaffold exists in `packages/core/src/mcp/mcpOAuth.ts:61`.
- CLI exposes MCP auth commands in `packages/cli/src/commands/mcpCommands.ts:101`.

## 4) Missing or incomplete items
- Extension archive extraction is explicitly unimplemented and throws (`packages/core/src/extensions/extensionRegistry.ts:422`).
- OAuth token refresh is not implemented (`packages/core/src/mcp/mcpOAuth.ts:150`), conflicting with `.kiro/specs/stage-05-hooks-extensions-mcp/requirements.md:122`.
- CLI MCP auth status, revoke, and refresh commands return "not yet implemented" (`packages/cli/src/commands/mcpCommands.ts:114`, `packages/cli/src/commands/mcpCommands.ts:141`, `packages/cli/src/commands/mcpCommands.ts:168`).

## 5) Divergences
- Spec requires working OAuth token lifecycle and MCP management (`.kiro/specs/stage-05-hooks-extensions-mcp/requirements.md:122`), but the CLI and provider both expose TODO placeholders (`packages/cli/src/commands/mcpCommands.ts:114`, `packages/core/src/mcp/mcpOAuth.ts:150`).

## 6) Verification notes
- Static inspection only. No MCP servers started.

## 7) Open questions / assumptions
- Is extension installation expected to support archive formats (zip/tar), or will extensions be directory-only for now?

## 8) Re-audit note
- Re-audited against current code (static inspection). Findings unchanged.

