# File Explorer — Draft 3

Summary
- Goal: Add a local file manager (nav bar + side panel) that lets users browse their machine, add folders as project roots (work tree) and limit LLM workspace scope to selected project folders. Provide full file/folder navigation, create/delete, and a file viewer/editor workflow appropriate for a terminal-based coder IDE. Add a per-file "focus" feature so an individual file can be marked as the LLM reference for conversations.

Audit — what's already in the repo
- UI scaffolding: side panel and tabs exist; see [packages/cli/src/ui/components/layout/SidePanel.tsx](packages/cli/src/ui/components/layout/SidePanel.tsx) and [packages/cli/src/ui/components/tabs/FilesTab.tsx](packages/cli/src/ui/components/tabs/FilesTab.tsx).
- Context UI: active context and mode UI are implemented in [packages/cli/src/ui/components/layout/ContextSection.tsx](packages/cli/src/ui/components/layout/ContextSection.tsx).
- Planning/spec notes: preplanning for file uploads/features is in the Kiro specs: [.kiro/specs/stage-10c-file-upload-future-dev/design.md](.kiro/specs/stage-10c-file-upload-future-dev/design.md), [.kiro/specs/stage-10c-file-upload-future-dev/requirements.md](.kiro/specs/stage-10c-file-upload-future-dev/requirements.md), and [.kiro/specs/stage-10c-file-upload-future-dev/tasks.md](.kiro/specs/stage-10c-file-upload-future-dev/tasks.md).
- Tests: UI side-panel property tests are present (failing in current test output), indicating active work in side-panel persistence and focus handling (see test output in `test-results.json`).
- Missing/Not yet implemented: no UploadService/StorageManager/manifest implementation found in source; SidePanel currently shows a "File Tree (Coming Soon)" placeholder.

High-level design
- Two browsing modes:
  - Global File Browser (Main Menu / Nav bar): unrestricted local browsing for the user only (no LLM access by default). Users may open folders or "add to workspace" here.
  - Workspace File Tree (Right-side panel): shows only folders/projects the user added to the app work tree (the project root plus subfolders). This is the scope that LLMs are allowed to read/write when given project permissions.

- Core services (backend/internal):
  - ProjectRegistry: track added project roots and their metadata (id, rootPath, includedGlobs, readOnly flags).
  - WorkspaceFS (adapter): thin layer to list/read/write files under a project root with path-sanitization, quota checks, and audit logs.
  - FocusManager: store the current focused file per session (path + project id + metadata). Emits events when focus changes.

- Data model (minimal):
  - Project { id, rootPath, addedAt, config }
  - Manifest entries per project (optional) for files created/managed by the app
  - FocusedFile { projectId, path, markedByUserAt }

UX & interactions
- Nav bar file browser
  - Open global file browser command (keyboard/command). User can browse drives, expand folders, create new files/folders, and choose "Add Folder to Workspace" or "Open in Terminal".
  - Actions: Add to Workspace, Open With External Editor, Reveal in Workspace Tree, Copy Path.

- Right-side panel (workspace file tree)
  - Displays each project root added by user; supports expanding/collapsing tree, create/delete file/folder, rename, and context menu commands.
  - Keyboard navigation: up/down/left/right, Enter to open/view, `f` to mark/unmark as Focus File, `e` to open in editor (see editor options), `d` to delete.
  - When a folder is added to Workspace, the side panel shows only that folder + subfolders (no access to other FS locations).

- Focus file behavior
  - Mark file as Focus: toggled from side panel; FocusManager broadcasts the change; the Functions/Info container displays the focused file name and path.
  - LLM integration: when LLM chat runs, the system may include the focused file contents or a short summary as a referenced context item. Access rules: only include file content if the user explicitly marks it or grants workspace access for LLM operations.

Security & constraints
- Permission model: explicit user action required to add project roots. Global File Browser is user-only and never automatically exposed to LLMs.
- Sandboxing: LLM access constrained to ProjectRegistry roots; WorkspaceFS enforces path normalization and rejects traversal outside project root.
- Limits: per-project quotas, file-type whitelists for LLM reads, and maximum bytes to include in prompts.
- Audit logging: record user actions (add/remove project, focus changes, edits that originated from LLM) for traceability.

Editor / Viewer recommendations
- Terminal-friendly viewer + syntax highlighting:
  - Use `shiki` for high-quality static syntax highlighting (server-side Node rendering) or `prismjs` / `highlight.js` as lighter-weight alternatives.
  - Render highlighted output inside the Ink UI (preformatted blocks) for read-only viewing.

- Editing strategies for terminal-first UX:
  - Preferred minimal integration: spawn the user's `$EDITOR` (respect `VISUAL`/`EDITOR`) in a focused pane or separate terminal tab—keeps editing full-featured and avoids reimplementing complex editors.
  - Integrated terminal editor option: offer optional `neovim` embedding via a pty using `node-pty` + `neovim` client for tighter integration (more engineering cost but best in-terminal editing UX).
  - Future / GUI option: for a web/GUI mode, use `Monaco Editor` (VS Code backend) or `CodeMirror 6`.

LLM integration: how Focus works in prompts
- When a user marks FocusFile, add a short context header to LLM requests such as:
  - "Focus file: <relative/path> (project: <projectId>). Use only this file as the primary reference unless asked to access other project files."
  - Optionally include the file's content truncated or summarized. Always enforce configured maximum token/bytes.

Milestones (MVP -> v1)
- MVP (4–6 dev days):
  1. Implement ProjectRegistry + WorkspaceFS (safe listing, read-only operations).
  2. Replace side-panel placeholder with a basic Workspace Tree that shows added project roots and files (read-only). Hook keyboard navigation.
  3. Implement FocusManager and wire `f` mark/unmark; display focused file name in Functions/Info container.

- v1 (8–12 dev days):
  4. Add file create/delete/rename operations with confirmations and path-sanitization.
  5. Implement open-in-editor (spawn `$EDITOR`) and basic internal viewer with `shiki` highlighting.
  6. Add Project-level quotas and config UI.

- v2 (future):
  7. Upload service / session-scoped uploads (follow `.kiro` file-upload spec) and LLM upload integration.
  8. Optional in-terminal editor embedding via `neovim` or richer GUI editor integration.

Testing & verification
- Unit tests for WorkspaceFS path-sanitization, permissions, and quotas.
- Property tests for focus persistence across sessions, and for path traversal protections.
- Integration tests: open folder flow, add-to-workspace, and LLM-chat with focused file included (mock LLM).

Open questions / trade-offs
- In-terminal editor vs external editor: recommend starting with spawning `$EDITOR` (fast, low risk); embed neovim only if customers demand a single-pane integrated editor.
- How much of a file's content to include automatically in LLM prompts — pick a safe default (e.g., 64KB / N tokens) with user override.

References
- Existing UI scaffolding: [packages/cli/src/ui/components/layout/SidePanel.tsx](packages/cli/src/ui/components/layout/SidePanel.tsx)
- Existing files tab: [packages/cli/src/ui/components/tabs/FilesTab.tsx](packages/cli/src/ui/components/tabs/FilesTab.tsx)
- Kiro pre-planning: [.kiro/specs/stage-10c-file-upload-future-dev/design.md](.kiro/specs/stage-10c-file-upload-future-dev/design.md)

Next steps (short):
- Create issues for ProjectRegistry, WorkspaceFS, FocusManager, and SidePanel file-tree UI.
- Implement MVP tasks in order and add tests for path-safety and focus persistence.

Recommended improvements (added suggestions)
- **Permission model:** Require explicit `Add Folder to Workspace` before any LLM access; Global Browser remains user-only.
- **Path safety:** Enforce strict path normalization and traversal checks in `WorkspaceFS` and all file APIs.
- **Least-privilege LLM access:** Add per-project and per-file scope flags (none / read-only / read-write) that the user must opt into.
- **Focused file UX:** Support pin/unpin, timestamped focus history, diff-on-change, and an explicit opt-in toggle for including content in prompts.
- **Quota & truncation:** Apply per-project quotas and safe truncation/summarization rules when including file contents in prompts.
- **Audit & safety logs:** Record add/remove project, focus changes, and LLM file reads/writes; make logs reviewable and exportable.
- **Editor strategy:** Default to spawning the user's `$EDITOR`; offer optional `neovim` embedding (via `node-pty`) and GUI editor (Monaco) as future options.
- **File operations safety:** Add confirmations, soft-delete/recycle bin per project, and undo for destructive actions.
- **Git integration:** Detect repo roots, show status in file tree, support quick diff/stage/commit, and allow LLM scope narrowing to tracked files.
- **Performance:** Lazy-load large directories, incremental tree rendering, FS watch for updates, and caching with invalidation for remote drives.
- **Discoverability & shortcuts:** Add quick-open (fuzzy), breadcrumbs, filter-by-type, and keyboard shortcuts for common file actions.
- **Testing & verification:** Unit tests for `WorkspaceFS`, property tests for focus persistence and traversal protection, and integration tests for add-folder→LLM flows.
- **Extensibility & APIs:** Expose `ProjectRegistry` and `FocusManager` events/commands for safe extension integration (hooks/MCP).
- **Config & ignore rules:** Support per-project `.ollm` config for allowed filetypes, ignore globs, editor prefs, and token limits.
- **Onboarding & docs:** Add a first-run quick-tour explaining Global Browser vs Workspace, Focus semantics, and LLM safety defaults.
