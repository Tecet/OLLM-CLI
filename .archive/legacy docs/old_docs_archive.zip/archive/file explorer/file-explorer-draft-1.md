# File Explorer & Project Management Feature Plan (Draft 2)

## Overview

This feature transforms the OLLM CLI into a "Terminal-Based Coder's IDE". Unlike the existing "File Uploads" (Stage 10c) which handles session-scoped temporary files, this feature provides direct access to the **local file system**, enabling users to:

1.  **Browse** the entire local machine via a Navigation Bar Explorer.
2.  **Manage Projects** by adding folders to a persistent "Workspace".
3.  **Scope LLM** context to specific projects (`.ollm-project` config).
4.  **Edit & View** code directly in the terminal.
5.  **Focus** specific files for LLM attention.

## Architecture

The system utilizes a dual-pane approach:

1.  **Global Explorer (Nav Bar):** Unrestricted access to the host machine's file system for locating projects.
2.  **Project Explorer (Side Panel):** Restricted view of the currently active project(s).

### State Management

We will introduce a new `ProjectContext` to manage:
- Active project roots
- Open files
- Focused files (Reference files for LLM)
- File system watchers (optional, for live updates)

### Performance Strategy: Windowed Rendering (Critical)
To handle large directories (e.g., `node_modules`) without UI freezing:
- **Virtual Scrolling:** Only render the subset of visible rows (e.g., ~20 lines) based on the current scroll position.
- **Lazy Loading:** Directory contents are fetched only when expanded.

## UI Components & Interaction

### 1. Global Explorer (Nav Bar)
- **Function:** Browse drives/root directories.
- **Actions:**
  - `[Enter]` Enter directory.
  - `[Space]` Toggle expansion.
  - `[p]` **Add to Project:** Adds selected folder as a project root in the Side Panel.

### 2. Project Explorer (Side Panel)
- **Function:** Tree view of active project files.
- **Interaction Model:**
  - **Navigation:** Vim-style (`hjkl`) or Arrow keys.
  - **Quick Actions Menu:** Press `[Space]` or `[Enter]` on a file to open a context menu:
    - `▸ Open` (Editor/Viewer)
    - `▸ Focus/Pin` (Add to LLM Context)
    - `▸ Rename`
    - `▸ Delete`
    - `▸ Copy Path`
  - **Hotkeys (still available):** `[n]` New, `[d]` Delete.

### 3. Code Editor/Viewer Pane
- **Location:** Central area.
- **Viewer:** Syntax-highlighted read-only view using `cli-highlight`.
- **Editor:** Hybrid approach.
  - **Quick Edit:** In-app `ink-text-input` for small tweaks.
  - **External Edit:** Command to spawn user's `$EDITOR` (Vim/Nano/Code).

## Intelligence & Focus Strategy

### Smart Focus
- **Active File Context:** When a file is open in the Viewer/Editor, it is **temporarily** added to the LLM's context.
- **Pinned Focus (`[f]`):** User explicitly pins a file (e.g., `types.ts`). It remains in context even when closed.
- **Visuals:** Pinned files appear in the "Functions/Info" container.

### Follow Mode
- **Behavior:** When the LLM generates code or suggests changes for a specific file, the File Explorer **automatically expands and highlights** that file.
- **Benefit:** Creates a "Pair Programming" feel where the agent guides navigation.

## Library Recommendations

- **File Tree:** Custom `ink` component with **Virtual Scrolling**.
- **Icons:** `devicon` lookup map for Nerd Fonts (e.g., TS icon for `.ts`).
- **Git Integration:** Color-code filenames (Green=New, Yellow=Mod, Grey=Ignored).
- **Viewer:** `cli-highlight` rendered to string, displayed in `ink` `Text`.

## Development Roadmap

### Phase 1: Explorer Foundations
- [ ] Create `ProjectContext`.
- [ ] Implement `FileSystemService` (list, stat, read).
- [ ] Build `FileTree` core component with **Virtual Scrolling**.

### Phase 2: Panel Integration
- [ ] Implement Global Explorer (Nav Bar).
- [ ] Implement Project Explorer (Side Panel).
- [ ] Add "Add to Project" action.
- [ ] Implement **Quick Actions Menu** popup.

### Phase 3: Viewer & Editor
- [ ] Create `FileViewer` component with syntax highlighting.
- [ ] Implement "Quick Edit" mode.
- [ ] Add "Open External" capability.

### Phase 4: Intelligence & Focus
- [ ] Implement **Smart Focus** (Active vs Pinned).
- [ ] Integrate `focusedFiles` into `ContextManager` (Prompt Injection).
- [ ] Implement **Follow Mode** (LLM-driven navigation).

### Phase 5: Visual Polish
- [ ] **Nerd Fonts:** Add file-type specific icons.
- [ ] **Git Colors:** Integrate `simple-git` to colorize file tree based on status.
- [ ] Add Create/Rename/Delete dialogs.

## Integration notes
- **vs Stage 10c (Uploads):** Focused files act as persistent "live" uploads.
- **Tools:** Add `list_project_files` tool for LLM to explore the project structure intelligently.
