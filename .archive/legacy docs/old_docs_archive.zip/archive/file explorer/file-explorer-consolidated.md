# File Explorer — Final Implementation Plan

> **Status:** Approved  
> **Consolidated from:** `file-explorer-draft-1.md`, `file-explorer-draft-2.md`, `file-explorer-draft-3.md`

---

## Design Decisions (Finalized)

| Decision | Choice | Rationale |
|----------|--------|----------|
| **Editor Strategy** | `$EDITOR` spawn from day 1 | Standard dev experience, respects user preferences |
| **Focus Token Limit** | 8KB default | Reasonable for most files without bloating prompts |
| **Git Integration** | Basic status colors only | Full git features planned for future phase |
| **Multi-Project** | VS Code-style workspaces | Industry standard, supports multi-repo workflows |
| **Config Format** | Per-project `.ollm-project` files | Developer-friendly, portable, version-controllable |

---

## 1. Vision & Goals

Transform OLLM CLI into a **Terminal-Based Coder's IDE** with integrated file management:

| Capability | Description |
|------------|-------------|
| **Browse** | Full local filesystem access via Global Explorer |
| **Manage** | Add folders to persistent Workspace (project roots) |
| **Scope** | Restrict LLM context to selected projects only |
| **View/Edit** | Syntax-highlighted viewer + external editor integration |
| **Focus** | Pin files as explicit LLM context references |

---

## 2. Architecture

### 2.1 Dual-Pane Model

```
┌─────────────────────────────────────────────────────────────────┐
│ Nav Bar                                                         │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ Global Explorer (User-only, unrestricted FS access)        │ │
│ │ • Browse drives/directories                                 │ │
│ │ • "Add to Workspace" action                                 │ │
│ └─────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│ Main Area                          │ Side Panel                 │
│ ┌─────────────────────────────┐   │ ┌───────────────────────┐  │
│ │ Chat / Editor / Viewer      │   │ │ Workspace File Tree   │  │
│ │                             │   │ │ (LLM-accessible scope)│  │
│ │                             │   │ │ • Project roots only  │  │
│ │                             │   │ │ • Focus indicators    │  │
│ └─────────────────────────────┘   │ └───────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Core Services

| Service | Responsibility |
|---------|----------------|
| `ProjectRegistry` | Track added project roots, metadata, permissions |
| `WorkspaceFS` | Safe file ops with path-sanitization, quotas, audit |
| `FocusManager` | Track pinned/active files, emit change events |
| `FileSystemService` | Low-level list, stat, read, write operations |

### 2.3 Workspace & Project Model (VS Code Style)

#### `.ollm-workspace` File (Multi-Project Container)
```json
{
  "folders": [
    { "path": "C:/Projects/my-app-frontend", "name": "Frontend" },
    { "path": "C:/Projects/my-app-backend", "name": "Backend" },
    { "path": "C:/Projects/shared-libs", "name": "Shared" }
  ],
  "settings": {
    "activeProject": "Frontend",
    "focus.tokenLimit": 8192,
    "editor.external": true
  }
}
```

#### `.ollm-project` File (Per-Project Config)
```json
{
  "name": "my-app-frontend",
  "llmAccess": "read-write",
  "exclude": ["node_modules", "dist", ".git", "*.log"],
  "include": ["src/**", "tests/**"],
  "focusDefaults": ["src/types.ts"],
  "maxFocusSize": 8192
}
```

#### TypeScript Interfaces
```typescript
interface Workspace {
  path: string;           // Path to .ollm-workspace file
  folders: WorkspaceFolder[];
  settings: WorkspaceSettings;
}

interface WorkspaceFolder {
  path: string;
  name?: string;
  project?: Project;      // Loaded from .ollm-project if exists
}

interface WorkspaceSettings {
  activeProject?: string;
  focusTokenLimit: number;  // Default: 8192
  editorExternal: boolean;  // Default: true
}

interface Project {
  id: string;
  name: string;
  rootPath: string;
  llmAccess: 'none' | 'read-only' | 'read-write';
  exclude: string[];
  include: string[];
  focusDefaults: string[];
  maxFocusSize: number;
}

interface FocusedFile {
  projectId: string;
  relativePath: string;
  absolutePath: string;
  markedAt: Date;
  includeContent: boolean;
}
```

---

## 3. UI Components & Interactions

### 3.1 Global Explorer (Nav Bar)

**Purpose:** User-only browsing of full filesystem to locate and add projects.

| Key | Action |
|-----|--------|
| `↑/↓` or `j/k` | Navigate |
| `Enter` | Enter directory |
| `Space` | Toggle expand/collapse |
| `p` | **Add to Workspace** |
| `o` | Open with external editor |
| `y` | Copy path to clipboard |

### 3.2 Workspace File Tree (Side Panel)

**Purpose:** Display project roots added by user; this is the LLM-accessible scope.

| Key | Action |
|-----|--------|
| `↑/↓/←/→` or `hjkl` | Navigate tree |
| `Enter` or `Space` | Open Quick Actions Menu |
| `f` | Toggle Focus/Pin file |
| `e` | Edit (spawn `$EDITOR`) |
| `n` | Create new file/folder |
| `d` | Delete (with confirmation) |
| `r` | Rename |

**Quick Actions Menu (on Enter/Space):**
- ▸ Open (Viewer)
- ▸ Focus/Unpin
- ▸ Edit (External)
- ▸ Rename
- ▸ Delete
- ▸ Copy Path

### 3.3 File Viewer/Editor

| Mode | Implementation |
|------|----------------|
| **Viewer** | `shiki` for syntax highlighting, rendered in Ink |
| **External Editor** | Spawn `$EDITOR` / `$VISUAL` (Vim, Nano, VS Code, etc.) — **included from day 1** |
| **Future** | In-app quick edit, optional `neovim` embedding via `node-pty` |

---

## 4. Focus System (LLM Integration)

### 4.1 Focus Types

| Type | Behavior |
|------|----------|
| **Active Focus** | Currently open file in viewer; temporary context |
| **Pinned Focus** | Explicitly marked by user (`f`); persists until unpinned |

### 4.2 LLM Prompt Integration

When focus files exist, inject context header (max **8KB** per file):
```
Focus file: src/utils/helpers.ts (project: Frontend)
Use this file as the primary reference unless asked to access other project files.

[File content, truncated to 8KB]
```

### 4.3 Follow Mode

When LLM generates code referencing a file:
- File Explorer **auto-expands** and **highlights** the referenced file
- Creates a "pair programming" feel with agent-guided navigation

---

## 5. Security & Permissions

> [!IMPORTANT]
> LLM access is **sandboxed** to explicitly added project roots only.

| Rule | Description |
|------|-------------|
| **Explicit Add** | User must actively "Add to Workspace" before LLM can access |
| **Global Browser Isolation** | Nav bar explorer is user-only; never exposed to LLM |
| **Path Sanitization** | `WorkspaceFS` rejects traversal attempts (`../`) |
| **Per-Project Permissions** | `none` / `read-only` / `read-write` flags |
| **Quotas** | File size limits, token caps for prompt inclusion |
| **Audit Logging** | Record add/remove/focus/LLM-read/LLM-write actions |

---

## 6. Performance Optimizations

| Technique | Purpose |
|-----------|---------|
| **Virtual Scrolling** | Render only visible rows (~20 lines) |
| **Lazy Loading** | Fetch directory contents on expand |
| **FS Watching** | `chokidar` for live updates (optional) |
| **Caching** | Cache directory listings with invalidation |

---

## 7. Visual Enhancements

| Feature | Implementation | Phase |
|---------|----------------|-------|
| **File Icons** | Nerd Fonts via `devicon` lookup | MVP |
| **Git Status Colors** | Green=New, Yellow=Modified, Grey=Ignored (via `simple-git`) | MVP (basic) |
| **Focus Indicator** | `📌` or highlight for pinned files | MVP |
| **Breadcrumbs** | Path display in viewer header | MVP |
| **Active Project Indicator** | Bold/highlight in workspace tree | MVP |
| **Full Git (diff/stage/commit)** | Future phase | Future |

---

## 8. Development Roadmap

### Phase 1: Foundation & Workspace — 5-7 days

- [ ] Implement `WorkspaceManager` service (load/save `.ollm-workspace`)
- [ ] Implement `ProjectRegistry` service (load `.ollm-project` per folder)
- [ ] Implement `WorkspaceFS` with path sanitization
- [ ] Implement `FileSystemService` (list, stat, read, write)
- [ ] Build `FileTree` component with **Virtual Scrolling**
- [ ] Replace Side Panel placeholder with Workspace Tree (multi-project)

### Phase 2: Core Interactions — 3-4 days

- [ ] Implement Global Explorer in Nav Bar
- [ ] Add "Add to Workspace" action (creates/updates `.ollm-workspace`)
- [ ] Add "Set Active Project" action
- [ ] Implement Quick Actions Menu popup
- [ ] Add keyboard navigation (Vim-style + arrows)

### Phase 3: Focus System — 2-3 days

- [ ] Implement `FocusManager` service
- [ ] Wire `f` keybind for focus/unpin
- [ ] Enforce 8KB limit per focused file
- [ ] Display focused files in Functions/Info container
- [ ] Integrate focused files into `ContextManager` prompts

### Phase 4: Viewer & Editor — 3-4 days

- [ ] Build `FileViewer` with `shiki` syntax highlighting
- [ ] Implement `$EDITOR` spawn from day 1
- [ ] Add file content display in central pane
- [ ] Handle editor exit and file reload

### Phase 5: File Operations — 2-3 days

- [ ] Create file/folder functionality
- [ ] Rename with validation
- [ ] Delete with confirmation dialog
- [ ] Create new `.ollm-project` file wizard

### Phase 6: Polish & Intelligence — 3-4 days

- [ ] Git integration (status colors only — basic)
- [ ] Nerd Font file icons
- [ ] Follow Mode (LLM-guided navigation)
- [ ] Fuzzy quick-open (`Ctrl+P` style)

---

## 9. Tech Stack Summary

| Layer | Technology |
|-------|------------|
| UI Framework | Ink (React for terminal) |
| Syntax Highlighting | `shiki` or `cli-highlight` |
| File Watching | `chokidar` |
| Git Integration | `simple-git` |
| Icons | Nerd Fonts / `devicon` |
| Editor | Spawn `$EDITOR` (default) |

---

## 10. Integration Points

| Existing Component | Integration |
|--------------------|-------------|
| `SidePanel.tsx` | Replace "Coming Soon" with Workspace Tree |
| `FilesTab.tsx` | Wire up file operations |
| `ContextSection.tsx` | Display focused files |
| `ContextManager` | Include focused file content in prompts |
| Stage 10c Specs | Focused files act as "live uploads" |

---

## 11. Future Enhancements (Out of Scope for MVP)

- Full Git integration (diff viewer, staging, commit)
- In-app quick edit mode
- Neovim embedding via `node-pty`
- Remote filesystem support
- Project templates

---

## 12. References

- [SidePanel.tsx](file:///d:/Workspaces/OLLM%20CLI/packages/cli/src/ui/components/layout/SidePanel.tsx) — existing UI scaffold
- [FilesTab.tsx](file:///d:/Workspaces/OLLM%20CLI/packages/cli/src/ui/components/tabs/FilesTab.tsx) — existing files tab
- [Stage 10c Specs](file:///d:/Workspaces/OLLM%20CLI/.kiro/specs/stage-10c-file-upload-future-dev) — file upload pre-planning
