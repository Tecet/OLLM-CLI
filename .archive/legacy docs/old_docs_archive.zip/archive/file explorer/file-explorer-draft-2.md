## Plan: Implement File Manager Feature

Develop a terminal-based file manager for OLLM CLI, enabling local file browsing, project addition to restrict LLM to per-project environments, file/folder creation, and marking files for LLM focus. Use Ink for UI consistency with existing React-based components, terminal-kit for operations, and vscode-textmate for code viewing, integrating with nav bar/side panels and existing focus system for seamless navigation and chat reference. Note: Preplanning in stage-10c-file-upload-future-dev will be replaced with this updated plan.

### Steps
1. Design Ink-based file tree components for nav bar and side panel navigation.
2. Implement file browsing logic with chokidar watching and terminal-kit for operations.
3. Add project selection to restrict LLM context via updated JIT discovery.
4. Integrate code viewer with vscode-textmate syntax highlighting in side panel.
5. Enable file focus marking to display in Functions/Info container for LLM reference.
6. Update focus system and keybinds for file manager interaction.

### Further Considerations
1. Confirmed Ink is used in [packages/cli/package.json](packages/cli/package.json) and [packages/cli/src/](packages/cli/src/) for UI; blessed/neo-blessed not present—stick with Ink for consistency.
2. TODO: Evaluate terminal-kit vs custom fs ops for file creation/deletion.
3. Ensure path traversal security per preplanning in [.kiro/specs/stage-10c-file-upload-future-dev](.kiro/specs/stage-10c-file-upload-future-dev).