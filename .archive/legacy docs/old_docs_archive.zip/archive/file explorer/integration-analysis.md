# File Explorer — Integration Analysis

> **Purpose:** Document existing codebase integration points for File Explorer feature

---

## 1. Existing UI Structure

### App Layout (App.tsx)
```
┌────────────────────────────────────────────────────────────────────┐
│ Row 1: TabBar + Clock                                    (5%)      │
├──────────────────────────────────────┬─────────────────────────────┤
│ Row 2: Active Tab Content   (60%)    │ SidePanel (30%)             │
│  - ChatTab                           │  - Row 1: Status/HeaderBar  │
│  - ToolsTab                          │  - Row 2: ContextSection    │
│  - FilesTab  ← MAIN INTEGRATION      │  - Row 3: File Tree ← HERE  │
│  - DocsTab, etc.                     │  - Row 4: Functions/Info    │
├──────────────────────────────────────┤                             │
│ Row 3: SystemBar             (10%)   │                             │
├──────────────────────────────────────┤                             │
│ Row 4: ChatInputArea         (25%)   │                             │
└──────────────────────────────────────┴─────────────────────────────┘
```

---

## 2. Focus System Integration

### FocusContext.tsx — Already Has File Tree Support!

**Registered FocusableIds:**
```typescript
export type FocusableId = 
  | 'chat-input' 
  | 'chat-history' 
  | 'nav-bar' 
  | 'context-panel' 
  | 'file-tree'      // ✅ Already registered!
  | 'functions'
  | 'tools-panel'
  // ... more
```

**Focus Cycle (when side panel visible):**
```typescript
if (sidePanelVisible) {
  list.push('context-panel');
  list.push('file-tree');     // ✅ Already in cycle
  list.push('functions');
}
```

**Keybinds Already Wired (App.tsx):**
```typescript
{
  key: keybinds.global.focusFileTree,
  handler: () => focusManager.setFocus('file-tree'),
  description: 'Focus File Tree'
}
```

**Integration:** No changes needed to FocusContext — just use `isFocused('file-tree')`.

---

## 3. SidePanel.tsx — Primary Integration Point

**Current Structure (lines 29-83):**
```tsx
<Box flexDirection="column" flexGrow={1}>
  {/* Row 1: Status Info */}
  <Box borderStyle="single" ...>
    <HeaderBar ... />
  </Box>

  {/* Row 2: Active Context */}
  <Box borderColor={contextFocused ? theme.border.active : theme.border.primary}>
    <ContextSection />    // Shows mode, skills, hooks, MCP
  </Box>

  {/* Row 3: File Tree — PLACEHOLDER */}
  <Box height={10} borderColor={fileTreeFocused ? ...}>
    <Text color="yellow">File Tree (Coming Soon)</Text>  // ← REPLACE THIS
  </Box>

  {/* Row 4: Functions / Info */}
  <Box height={5} ...>
    <Text>Functions / Info</Text>  // ← Add focused files display here
  </Box>
</Box>
```

**Integration Tasks:**
1. Replace Row 3 placeholder with `<WorkspaceTree />` component
2. Update Row 4 to include focused files from `FocusManager`
3. Pass workspace data to SidePanel via new `WorkspaceContext`

---

## 4. FilesTab.tsx — Main Tab Integration

**Current Features:**
- `ContextFile[]` display (path, type, size)
- `GitStatus` display (branch, staged, modified, untracked)
- Quick actions (commit, stash, diff)
- Focus management via `useFocusManager()`

**Existing Interfaces:**
```typescript
interface ContextFile {
  path: string;
  type: 'file' | 'symbol' | 'url';
  size?: number;
}

interface GitStatus {
  branch: string;
  staged: number;
  modified: number;
  untracked: number;
}
```

**Integration Tasks:**
1. Add Global File Explorer (full FS browsing) 
2. Wire "Add to Workspace" action
3. Connect to `ProjectRegistry` for workspace management
4. Enhance ContextFile to support workspace projects

---

## 5. ContextSection.tsx — Focus Files Display

**Current Displays:**
- Mode confidence (from `useActiveContext`)
- Active skills
- MCP servers
- Active hooks

**Integration Task:**
Add focused files section:
```tsx
{/* Focused Files */}
<Box>
  <Text color="yellow" bold>📌 Focus: </Text>
  {focusedFiles.length === 0 ? (
    <Text dimColor>None</Text>
  ) : (
    <Text>{focusedFiles.map(f => f.name).join(', ')}</Text>
  )}
</Box>
```

---

## 6. Navigation Pattern (from docs)

### Browse Mode vs Active Mode
- **Browse Mode:** Tab cycles through focusable areas
- **Active Mode:** Enter activates, Esc exits to nav-bar
- File tree should follow this pattern exactly

### Windowed Rendering (CRITICAL)
From `scroll.md` and `navigation_menu.md`:
```typescript
// MUST use windowed rendering for large directories
const WINDOW_SIZE = 10;  // Show ~10 items
const visibleItems = items.slice(scrollOffset, scrollOffset + WINDOW_SIZE);

// Key patterns:
- overflow="hidden" on container
- flexShrink={0} on items
- Scroll indicators (▲ / ▼)
- Navigation snaps to items, not lines
```

---

## 7. New Components Needed

| Component | Location | Purpose |
|-----------|----------|---------|
| `WorkspaceTree.tsx` | `ui/components/files/` | Multi-project tree view with virtual scrolling |
| `FileNode.tsx` | `ui/components/files/` | Single file/folder row with icons |
| `GlobalExplorer.tsx` | `ui/components/files/` | Full FS browser for nav bar |
| `FileViewer.tsx` | `ui/components/files/` | Syntax-highlighted read-only view |
| `QuickActionsMenu.tsx` | `ui/components/files/` | Popup menu for file actions |

---

## 8. New Services Needed

| Service | Location | Purpose |
|---------|----------|---------|
| `WorkspaceManager` | `features/workspace/` | Load/save `.ollm-workspace` files |
| `ProjectRegistry` | `features/workspace/` | Track project roots, load `.ollm-project` |
| `WorkspaceFS` | `features/workspace/` | Safe file operations with path sanitization |
| `FocusManager` | `features/workspace/` | Track focused/pinned files (separate from UI focus) |

---

## 9. New Context Providers Needed

| Provider | Purpose |
|----------|---------|
| `WorkspaceProvider` | Workspace and project state |
| `FileFocusProvider` | Focused files for LLM context |

**Provider Tree Location (App.tsx):**
```tsx
<FocusProvider>
  <WorkspaceProvider>        {/* NEW */}
    <FileFocusProvider>      {/* NEW */}
      <ActiveContextProvider>
        <AppContent ... />
      </ActiveContextProvider>
    </FileFocusProvider>
  </WorkspaceProvider>
</FocusProvider>
```

---

## 10. Key Files to Modify

| File | Changes |
|------|---------|
| `SidePanel.tsx` | Replace placeholder, add WorkspaceTree |
| `FilesTab.tsx` | Add GlobalExplorer, enhance with workspace |
| `ContextSection.tsx` | Add focused files display |
| `FocusContext.tsx` | No changes needed (already supports file-tree) |
| `App.tsx` | Add new providers to tree |
| `ActiveContextState.tsx` | Add focusedFiles to context data |

---

## 11. Summary: What Already Exists vs What's Needed

### ✅ Already Exists
- Focus ID `'file-tree'` registered in FocusContext
- Keybind for `focusFileTree` wired in App.tsx
- SidePanel layout with placeholder for File Tree
- FilesTab with context files and git status UI
- Navigation pattern docs (Browse/Active modes)
- Windowed rendering pattern documented

### 🔧 Needs Implementation
- WorkspaceTree component (virtual scrolling tree)
- GlobalExplorer component (full FS browser)
- WorkspaceManager service (workspace file handling)
- ProjectRegistry service (project config)
- WorkspaceFS service (safe file ops)
- FileFocusProvider context
- Quick Actions Menu
- File Viewer with syntax highlighting
- $EDITOR spawn integration
