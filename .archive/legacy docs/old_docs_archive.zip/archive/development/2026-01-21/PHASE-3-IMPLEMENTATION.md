# Phase 3: Response Handler Integration - Implementation Plan

**Date:** 2026-01-21  
**Status:** In Progress

## Discovery Complete ✅

### Key Files Identified:

1. **Response Processing:**
   - `packages/core/src/core/chatClient.ts` - Main chat client, adds assistant messages to context
   - `packages/core/src/core/turn.ts` - Handles streaming and tool execution
   
2. **Reasoning Extraction:**
   - `packages/core/src/services/reasoningParser.ts` - Parses `<think>` tags
   - `packages/cli/src/features/context/ChatContext.tsx` - UI layer, captures thinking via `onThinking` callback

3. **System Prompt:**
   - Context manager already has `updateSystemPrompt()` method
   - Need to inject goal context into system prompt

## Integration Points

### 1. Reasoning Trace Capture (ChatContext.tsx)

**Location:** Line ~729 in `onThinking` callback

**Current Code:**
```typescript
// onThinking - Handle Ollama native thinking
(thinking: string) => {
  const targetId = currentAssistantMsgId;
  thinkingContent += thinking;
  
  // Update message with thinking content
  setMessages((prev) =>
    prev.map((msg) => {
      if (msg.id !== targetId) return msg;
      
      return {
        ...msg,
        reasoning: {
          content: thinkingContent,
          tokenCount: thinkingContent.split(/\s+/).length,
          duration: 0,
          complete: false,
        }
      };
    })
  );
}
```

**New Code:**
```typescript
// onThinking - Handle Ollama native thinking
(thinking: string) => {
  const targetId = currentAssistantMsgId;
  thinkingContent += thinking;
  
  // Update message with thinking content
  setMessages((prev) =>
    prev.map((msg) => {
      if (msg.id !== targetId) return msg;
      
      return {
        ...msg,
        reasoning: {
          content: thinkingContent,
          tokenCount: thinkingContent.split(/\s+/).length,
          duration: 0,
          complete: false,
        }
      };
    })
  );
  
  // Store reasoning trace in reasoning manager (NEW)
  if (contextActions) {
    const reasoningManager = contextActions.getReasoningManager();
    if (reasoningManager) {
      // Store trace (will be updated when complete)
      reasoningManager.addTrace({
        messageId: targetId,
        thinkingContent,
        timestamp: new Date()
      }).catch(err => {
        console.error('Failed to store reasoning trace:', err);
      });
    }
  }
}
```

**Also Update on Completion:** Line ~686
```typescript
// Mark reasoning as complete and calculate duration
if (msg.reasoning) {
  updates.reasoning = {
    ...msg.reasoning,
    complete: true,
    duration: metrics.evalDuration > 0 ? metrics.evalDuration / 1e9 : 0,
  };
  
  // Update reasoning manager with final trace (NEW)
  if (contextActions) {
    const reasoningManager = contextActions.getReasoningManager();
    if (reasoningManager) {
      reasoningManager.updateTrace(msg.id, {
        complete: true,
        duration: updates.reasoning.duration
      }).catch(err => {
        console.error('Failed to update reasoning trace:', err);
      });
    }
  }
  
  // Auto-collapse reasoning when complete
  updates.expanded = false;
}
```

### 2. Goal Context in System Prompt (contextManager.ts)

**Location:** `updateSystemPrompt()` method (already exists)

**Current Code:**
```typescript
private updateSystemPrompt(): void {
  const newPrompt = this.getSystemPromptForTierAndMode();
  
  // Set the prompt without emitting event
  const systemPrompt: Message = {
    id: `system-${Date.now()}`,
    role: 'system',
    content: newPrompt,
    timestamp: new Date(),
    tokenCount: this.tokenCounter.countTokensCached(
      `system-${Date.now()}`,
      newPrompt
    )
  };
  
  // ... rest of method
}
```

**New Code:**
```typescript
private updateSystemPrompt(): void {
  const basePrompt = this.getSystemPromptForTierAndMode();
  
  // Add goal context if available (NEW)
  const goalContext = this.goalManager.getGoalContext();
  const fullPrompt = goalContext 
    ? `${basePrompt}\n\n${goalContext}`
    : basePrompt;
  
  // Set the prompt without emitting event
  const systemPrompt: Message = {
    id: `system-${Date.now()}`,
    role: 'system',
    content: fullPrompt,
    timestamp: new Date(),
    tokenCount: this.tokenCounter.countTokensCached(
      `system-${Date.now()}`,
      fullPrompt
    )
  };
  
  // ... rest of method
}
```

### 3. Marker Parsing for Non-Tool Models (chatClient.ts)

**Location:** After assistant message is added to context (line ~800)

**New Code:**
```typescript
// Add assistant message to context management system
if (this.contextMgmtManager && assistantMessage && assistantMessage.parts.length > 0) {
  try {
    const content = assistantMessage.parts
      .filter(part => part.type === 'text')
      .map(part => part.type === 'text' ? part.text : '')
      .join('');
    
    await this.contextMgmtManager.addMessage({
      id: `assistant-${Date.now()}`,
      role: 'assistant',
      content,
      timestamp: new Date()
    });
    
    // Parse goal management markers for non-tool models (NEW)
    const goalManager = this.contextMgmtManager.getGoalManager();
    if (goalManager) {
      const { parseGoalManagementMarkers } = await import('../prompts/goalManagementPrompt.js');
      const actions = parseGoalManagementMarkers(content);
      
      for (const action of actions) {
        try {
          switch (action.type) {
            case 'NEW_GOAL':
              await goalManager.createGoal(action.data.title, action.data.description);
              break;
            case 'CHECKPOINT':
              await goalManager.createCheckpoint(action.data.summary, action.data.facts);
              break;
            case 'COMPLETE_GOAL':
              await goalManager.completeGoal(action.data.goalId, action.data.outcome);
              break;
            case 'DECISION':
              await goalManager.recordDecision(action.data.decision, action.data.rationale, action.data.locked);
              break;
            case 'SWITCH_GOAL':
              await goalManager.switchGoal(action.data.goalId);
              break;
          }
        } catch (error) {
          console.error(`Failed to execute goal action ${action.type}:`, error);
        }
      }
    }
  } catch (error) {
    // Log error but continue
    console.error('Failed to add assistant message to context manager:', error);
  }
}
```

### 4. Add Accessor Methods to Context Actions

**Location:** Need to find where `contextActions` is defined

**New Methods Needed:**
```typescript
getGoalManager(): GoalManager | undefined {
  return this.contextManager?.getGoalManager();
}

getReasoningManager(): ReasoningManager | undefined {
  return this.contextManager?.getReasoningManager();
}
```

## Implementation Steps

1. ✅ **Locate all integration points** - DONE
2. ⏳ **Add reasoning trace capture** - IN PROGRESS
   - Update `onThinking` callback
   - Update completion handler
   - Add accessor method to context actions
3. ⏳ **Add goal context to system prompt** - TODO
   - Update `updateSystemPrompt()` method
   - Test with different tiers and modes
4. ⏳ **Add marker parsing** - TODO
   - Import parser function
   - Parse markers after assistant message
   - Execute goal actions
5. ⏳ **Test integration** - TODO
   - Test with tool-capable model
   - Test with non-tool model
   - Test with reasoning model
   - Test goal persistence
   - Test reasoning persistence

## Files to Modify

1. ✅ `packages/core/src/context/contextManager.ts` - Add goal context to system prompt
2. ⏳ `packages/cli/src/features/context/ChatContext.tsx` - Add reasoning trace capture
3. ⏳ `packages/core/src/core/chatClient.ts` - Add marker parsing
4. ⏳ Context actions interface - Add accessor methods

## Testing Plan

### Unit Tests
- [ ] Goal context injection in system prompt
- [ ] Reasoning trace storage
- [ ] Marker parsing
- [ ] Goal action execution

### Integration Tests
- [ ] Full conversation with goals (tool-capable model)
- [ ] Full conversation with goals (non-tool model)
- [ ] Reasoning trace accumulation
- [ ] Snapshot persistence with goals and reasoning

### Manual Tests
- [ ] Create goal via tool call
- [ ] Create goal via marker
- [ ] Review reasoning traces
- [ ] Snapshot restore with goals
- [ ] Context rollover with goals

## Next Actions

1. Find context actions interface/implementation
2. Add accessor methods for goal and reasoning managers
3. Update ChatContext.tsx with reasoning trace capture
4. Update contextManager.ts with goal context injection
5. Add marker parsing to chatClient.ts
6. Build and test
