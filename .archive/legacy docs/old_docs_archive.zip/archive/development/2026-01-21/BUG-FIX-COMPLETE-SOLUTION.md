# Complete Bug Fix: Context Management Issues

**Date:** January 21, 2026  
**Status:** 🔧 Ready to Implement

---

## Two Critical Bugs Identified

### Bug 1: Double Context Limiting (85% Cap Conflict)
**Symptom:** Model crashes when streaming beyond limit  
**Root Cause:** Context manager doesn't know about 85% cap, applies additional safety checks

### Bug 2: Context Drops from 4K to 2K on First Message
**Symptom:** User selects 4K, but it drops to 2K immediately  
**Root Cause:** VRAM calculation bug or hardcoded model size

---

## Bug 1 Fix: Remove Double Limiting

### The Correct Design

**85% Cap Strategy:**
- User selects 4K → Ollama gets 3482 (85%)
- Model streams until 3482, then stops naturally
- App detects stop → creates snapshot
- No compression at 80%, no reduction at 90%

### Changes Required

#### 1. Remove Safety Check in ChatContext.tsx

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**REMOVE these lines (~line 597):**
```typescript
// REMOVE THIS ENTIRE BLOCK
if (contextActions && contextActions.getUsage) {
  try {
    const usage = contextActions.getUsage();
    console.log(`[ChatContext] Context usage: ${usage.percentage.toFixed(1)}%`);
    
    if (usage.percentage >= 95) {
      const errorMsg = `Context usage at ${usage.percentage.toFixed(1)}%. Please create a snapshot.`;
      addSystemMessage(errorMsg);
      setIsGenerating(false);
      return;
    }
    
    if (usage.percentage >= 80) {
      console.log(`[ChatContext] Triggering compression...`);
      addSystemMessage('Context usage high, compressing...');
      await contextActions.compress();
      const newUsage = contextActions.getUsage();
      addSystemMessage(`Context compressed: ${usage.percentage.toFixed(1)}% → ${newUsage.percentage.toFixed(1)}%`);
    }
  } catch (error) {
    console.error('[ChatContext] Safety check failed:', error);
  }
}
```

#### 2. Disable Memory Guard Auto-Actions

**File:** `packages/core/src/context/memoryGuard.ts`

**Change the switch statement (line ~156):**
```typescript
// BEFORE:
switch (level) {
  case MemoryLevel.WARNING:
    // 80-90%: Trigger compression
    if (this.compressionService && this.currentContext) {
      // ... compression code
    }
    break;
  case MemoryLevel.CRITICAL:
    // 90-95%: Force context reduction
    await this.forceContextReduction();
    break;
  case MemoryLevel.EMERGENCY:
    // >95%: Emergency actions
    await this.executeEmergencyActions();
    break;
}

// AFTER:
switch (level) {
  case MemoryLevel.WARNING:
  case MemoryLevel.CRITICAL:
    // Just emit event, don't auto-compress or reduce
    // The 85% cap will handle stopping naturally
    this.emit('threshold-reached', { level, percentage });
    break;
  case MemoryLevel.EMERGENCY:
    // Only at 95%+ do emergency snapshot
    await this.executeEmergencyActions();
    break;
}
```

#### 3. Add Snapshot on Natural Stop

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Add after model finishes (in onComplete callback):**
```typescript
onComplete: async (metrics?: ProviderMetrics) => {
  // ... existing code
  
  // Check if model stopped due to context limit
  if (finishReason === 'length') {
    const usage = contextActions.getUsage();
    
    // If we're near the 85% checkpoint (between 80-90%)
    if (usage.percentage >= 80 && usage.percentage <= 90) {
      console.log('[ChatContext] Natural checkpoint reached, creating snapshot...');
      addSystemMessage('Checkpoint reached - saving session...');
      
      try {
        await contextActions.createSnapshot();
        addSystemMessage('Session saved. You can continue the conversation.');
      } catch (error) {
        console.error('[ChatContext] Failed to create snapshot:', error);
        addSystemMessage('Warning: Failed to save session snapshot.');
      }
    }
  }
}
```

#### 4. Pass Effective Size to Context Manager

**File:** `packages/cli/src/ui/App.tsx`

**Update contextConfig (line ~986):**
```typescript
// Get profile for current model
const profile = profileManager.findProfile(initialModel);
const contextProfile = profile?.context_profiles?.find(
  p => p.size === persistedContextSize
);

const contextConfig = config.context ? {
  targetSize: persistedContextSize || config.context.targetSize,
  effectiveSize: contextProfile?.ollama_context_size || 
                 Math.floor((persistedContextSize || config.context.targetSize) * 0.85),
  minSize: config.context.minSize,
  maxSize: config.context.maxSize,
  autoSize: false, // DISABLE auto-size when using 85% cap
  vramBuffer: config.context.vramBuffer,
  // ... rest of config
} : undefined;
```

---

## Bug 2 Fix: VRAM Calculation

### Issue 1: Hardcoded Model Size

**File:** `packages/cli/src/ui/App.tsx` (line 981)

**BEFORE:**
```typescript
const modelInfo = {
  parameters: 7, // 7B default - could be derived from model name
  contextLimit: persistedContextSize || config.context?.maxSize || 8192,
};
```

**AFTER:**
```typescript
// Extract model size from model name
const extractModelSize = (modelName: string): number => {
  // Match patterns like "3b", "7b", "13b", "70b"
  const match = modelName.match(/(\d+\.?\d*)b/i);
  if (match) {
    return parseFloat(match[1]);
  }
  // Default to 7B if can't determine
  return 7;
};

const modelInfo = {
  parameters: extractModelSize(initialModel),
  contextLimit: persistedContextSize || config.context?.maxSize || 8192,
};
```

### Issue 2: Disable Auto-Size by Default

**File:** `packages/cli/src/ui/App.tsx`

**Change:**
```typescript
const contextConfig = config.context ? {
  // ... other config
  autoSize: false, // Disable by default, let user control
  // ... rest
} : undefined;
```

### Issue 3: Add Logging for VRAM Calculation

**File:** `packages/core/src/context/contextPool.ts`

**Add logging in calculateOptimalSize:**
```typescript
calculateOptimalSize(vramInfo: VRAMInfo, modelInfo: ModelInfo): number {
  // Store VRAM info for usage calculations
  this.vramInfo = vramInfo;

  // If auto-sizing is disabled, use target size
  if (!this.config.autoSize) {
    console.log('[ContextPool] Auto-size disabled, using target:', this.config.targetContextSize);
    return this.clampSize(this.config.targetContextSize);
  }

  // Calculate bytes per token
  const bytesPerToken = this.getBytesPerToken(
    modelInfo.parameters,
    this.config.kvCacheQuantization
  );

  // Calculate usable VRAM
  const usableVRAM = vramInfo.available - this.config.reserveBuffer;

  console.log('[ContextPool] VRAM Calculation:', {
    totalVRAM: vramInfo.total,
    usedVRAM: vramInfo.used,
    availableVRAM: vramInfo.available,
    reserveBuffer: this.config.reserveBuffer,
    usableVRAM: usableVRAM,
    modelParams: modelInfo.parameters,
    bytesPerToken: bytesPerToken,
    calculatedTokens: Math.floor(usableVRAM / bytesPerToken)
  });

  // Ensure we have positive usable VRAM
  if (usableVRAM <= 0) {
    console.warn('[ContextPool] No usable VRAM, using minimum:', this.config.minContextSize);
    return this.config.minContextSize;
  }

  // Calculate optimal size
  const optimalSize = Math.floor(usableVRAM / bytesPerToken);

  // Clamp to min/max and model limit
  const finalSize = this.clampSize(Math.min(optimalSize, modelInfo.contextLimit));
  console.log('[ContextPool] Final context size:', finalSize);
  
  return finalSize;
}
```

---

## Testing Plan

### Test 1: 85% Cap Works

1. Start with 4K context
2. Send long prompt
3. Model should stream until ~3482 tokens
4. Model stops naturally (finish reason: "length")
5. Snapshot created automatically
6. No compression at 80%
7. No reduction at 90%
8. No crash

### Test 2: Context Size Stays at 4K

1. Start with 4K context
2. Send first message
3. Context should stay at 4K (not drop to 2K)
4. Check logs for VRAM calculation
5. Verify autoSize is disabled

### Test 3: Model Size Detection

1. Test with 3B model → should detect 3
2. Test with 7B model → should detect 7
3. Test with 1.5B model → should detect 1.5
4. Check logs for correct parameters value

---

## Implementation Order

1. ✅ Fix Bug 2 first (VRAM calculation)
   - Extract model size from name
   - Disable autoSize by default
   - Add logging

2. ✅ Fix Bug 1 (double limiting)
   - Remove safety checks in ChatContext
   - Disable memory guard auto-actions
   - Add snapshot on natural stop
   - Pass effective size to context manager

3. ✅ Test thoroughly
   - Verify 4K stays at 4K
   - Verify 85% cap works
   - Verify snapshots created
   - Verify no crashes

---

## Summary

### Root Causes

1. **Double Limiting:** Context manager applied safety checks on top of 85% cap
2. **VRAM Bug:** Hardcoded model size + autoSize enabled caused wrong calculations

### Solutions

1. **Disable safety checks** - let 85% cap handle stopping
2. **Disable autoSize** - let user control context size
3. **Extract model size** - detect from model name
4. **Add logging** - debug VRAM calculations

### Expected Results

- ✅ Context stays at user-selected size
- ✅ Model stops naturally at 85% cap
- ✅ Snapshots created automatically
- ✅ No crashes
- ✅ No unexpected resizing

---

**Priority:** 🔴 CRITICAL  
**Estimated Time:** 2-3 hours  
**Risk:** Low (mostly removing code)  
**Impact:** High (fixes crashes and unexpected behavior)
