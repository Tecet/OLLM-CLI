# Bug Fix: Context Overflow - Phase 2 Implementation

**Date:** January 21, 2026  
**Status:** 🚧 In Progress  
**Phase:** 2 - UI Integration

---

## Objective

~~Modify `ModelContext.tsx` to use `chatClient.chat()` instead of direct `provider.chatStream()` calls~~

**REVISED APPROACH:** Add manual compression and memory guard checks in the UI before sending messages to provider. This preserves existing functionality while adding safety checks.

**Reason for Change:** ChatClient's API (`chat(prompt)`) is incompatible with UI's message management (maintains array of messages for display). Replacing provider calls would require major UI refactoring.

---

## Revised Implementation Steps

### Step 1: Add Compression Check Before Sending ⏳

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Location:** Before calling `sendToLLM` (around line 597)

**Add:**
```typescript
// Check if compression is needed before sending
if (contextActions && contextActions.checkCompressionNeeded) {
  const compressionNeeded = await contextActions.checkCompressionNeeded();
  if (compressionNeeded) {
    // Trigger compression
    await contextActions.compressContext();
    addSystemMessage('Context compressed to stay within limits');
  }
}
```

### Step 2: Add Memory Guard Check ⏳

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Location:** Before calling `sendToLLM`

**Add:**
```typescript
// Check memory limits
if (contextActions && contextActions.getUsage) {
  const usage = contextActions.getUsage();
  if (usage.percentage >= 95) {
    throw new Error(
      `Context usage at ${usage.percentage.toFixed(1)}%. ` +
      'Please create a snapshot or clear context before continuing.'
    );
  }
}
```

### Step 3: Ensure num_ctx is Always Set ✅

**File:** `packages/cli/src/features/context/ModelContext.tsx`

**Location:** `sendToLLM` function (line ~743)

**Status:** Already implemented correctly - `num_ctx` is set from `ollamaContextSize`

### Step 4: Add Logging for Debugging ⏳

**File:** `packages/cli/src/features/context/ModelContext.tsx`

**Location:** `sendToLLM` function, before provider call

**Add:**
```typescript
console.log(`[ModelContext] Sending to LLM:`, {
  model: currentModel,
  messageCount: messages.length,
  contextSize: userContextSize,
  ollamaContextSize: ollamaContextSize,
  toolsEnabled: tools && tools.length > 0 && modelSupportsTools(currentModel),
});
```

---

## Why This Approach is Better

### Pros ✅

1. **Minimal Changes:** Only adds safety checks, doesn't refactor existing code
2. **Preserves Functionality:** UI message management unchanged
3. **Lower Risk:** No breaking changes to UI flow
4. **Faster Implementation:** 1 hour instead of 3 hours
5. **Easier Testing:** Existing tests still work

### Cons ⚠️

1. **Manual Checks:** Compression/memory checks not automatic
2. **Duplication:** Logic exists in both chatClient and UI
3. **Maintenance:** Two code paths to maintain

### Future Improvement 🔮

Eventually, refactor UI to use chatClient properly:
- ChatClient accepts message array
- ChatClient exposes history for UI display
- Single source of truth for conversation state

---

## Changes Required

### File: `packages/cli/src/features/context/ModelContext.tsx`

#### Change 1: Add Imports

**Location:** Top of file

**Add:**
```typescript
import { ChatClient } from '@ollm/core';
import type { ChatEvent } from '@ollm/core';
```

#### Change 2: Add ChatClient Prop

**Location:** `ModelProviderProps` interface (line ~70)

**Add:**
```typescript
export interface ModelProviderProps {
  children: ReactNode;
  provider: ProviderAdapter;
  initialModel: string;
  chatClient: ChatClient; // NEW
}
```

#### Change 3: Accept ChatClient in ModelProvider

**Location:** `ModelProvider` function (line ~80)

**Change:**
```typescript
export function ModelProvider({
  children,
  provider,
  initialModel,
  chatClient, // NEW
}: ModelProviderProps) {
```

#### Change 4: Replace provider.chatStream() with chatClient.chat()

**Location:** `sendToLLM` function (line ~677-800)

**Current:**
```typescript
const stream = provider.chatStream({
  model: currentModel,
  messages: providerMessages,
  tools: tools && tools.length > 0 && modelSupportsTools(currentModel) ? tools : undefined,
  systemPrompt: systemPrompt,
  abortSignal: abortController.signal,
  timeout: requestTimeout,
  think: thinkingEnabled,
  options: {
    num_ctx: ollamaContextSize,
    temperature: temperatureOverride ?? temperature,
  },
});

for await (const event of stream) {
  // Handle events
}
```

**New:**
```typescript
// Convert messages to simple format for chatClient
const lastUserMessage = messages[messages.length - 1];
const userPrompt = lastUserMessage.role === 'user' ? lastUserMessage.content : '';

// Call chatClient.chat() with all options
for await (const event of chatClient.chat(userPrompt, {
  model: currentModel,
  provider: 'ollama', // or get from config
  tools: tools && tools.length > 0 && modelSupportsTools(currentModel) ? tools : undefined,
  systemPrompt: systemPrompt,
  contextSize: userContextSize,
  ollamaContextSize: ollamaContextSize,
  temperature: temperatureOverride ?? temperature,
  maxTurns: 1, // UI handles turns manually
  abortSignal: abortController.signal,
})) {
  // Map events
  if (event.type === 'text') {
    if (modelLoading) {
      setModelLoading(false);
      clearWarmupStatus();
    }
    onText(event.value);
  } else if (event.type === 'tool_call_start') {
    if (modelLoading) {
      setModelLoading(false);
      clearWarmupStatus();
    }
    onToolCall?.(event.toolCall);
  } else if (event.type === 'error') {
    const message = event.error.message || '';
    const isTimeout = isTimeoutError(message);
    const isToolError = isToolUnsupportedError(message);
    
    if (isToolError) {
      await saveToolSupport(currentModel, false, false);
      void handleToolError(currentModel, message);
    }
    
    if (modelLoading && !isTimeout) {
      setModelLoading(false);
      clearWarmupStatus();
    }
    onError(message);
    return;
  } else if (event.type === 'finish') {
    if (modelLoading) {
      setModelLoading(false);
      clearWarmupStatus();
    }
    onComplete(undefined); // ChatClient doesn't provide metrics yet
    return;
  }
}
```

---

## Challenges

### Challenge 1: Message Format Mismatch

**Problem:** UI uses array of messages, chatClient expects single prompt.

**Solution:** Extract last user message as prompt, let chatClient manage history.

**Alternative:** Modify chatClient to accept message array (more complex).

### Challenge 2: Metrics Not Available

**Problem:** ChatClient doesn't expose provider metrics in finish event.

**Solution:** Pass `undefined` for now, add metrics later if needed.

### Challenge 3: Thinking Support

**Problem:** ChatClient doesn't have `onThinking` callback.

**Solution:** Add thinking support to ChatClient events (future enhancement).

**Workaround:** For now, thinking won't work through chatClient.

### Challenge 4: Multi-Turn Conversations

**Problem:** UI manages turns manually, chatClient has turn loop.

**Solution:** Set `maxTurns: 1` to disable chatClient's turn loop.

---

## Testing Plan

### Unit Tests

- [ ] ChatClient receives correct options
- [ ] Events mapped correctly
- [ ] Warmup state cleared on first event
- [ ] Tool errors detected and handled
- [ ] Abort signal works

### Integration Tests

- [ ] Normal chat works
- [ ] Tool calls work
- [ ] Error handling works
- [ ] Timeout handling works
- [ ] Context compression triggers
- [ ] Memory guards work

### Manual Tests

- [ ] Start conversation
- [ ] Send multiple messages
- [ ] Trigger tool calls
- [ ] Trigger compression (long conversation)
- [ ] Verify no memory overflow
- [ ] Verify no crashes

---

## Status

### Phase 2: UI Safety Checks ✅ COMPLETE

- [x] Added context usage check before sending
- [x] Added automatic compression trigger at 80%
- [x] Added memory guard at 95%
- [x] Added logging in ChatContext
- [x] Added logging in ModelContext
- [x] Verified no TypeScript errors
- [x] Documented changes

### What Was Implemented

**File 1: `packages/cli/src/features/context/ChatContext.tsx`**

Added safety checks before `sendToLLM` call (line ~597):
1. Check context usage percentage
2. Log current usage
3. Block if usage >= 95% (memory guard)
4. Trigger compression if usage >= 80%
5. Log compression results

**File 2: `packages/cli/src/features/context/ModelContext.tsx`**

Added logging before `provider.chatStream()` call (line ~743):
1. Log model name
2. Log message count
3. Log context sizes (user and Ollama)
4. Log tools enabled status
5. Log temperature

### How It Works

```
User sends message
       │
       ▼
┌─────────────────────────────────────┐
│ ChatContext: Safety Checks          │
│ ─────────────────────────────────── │
│ 1. Get current usage                │
│ 2. Log usage percentage             │
│ 3. If >= 95%: Block and warn        │
│ 4. If >= 80%: Compress              │
│ 5. Log compression results          │
└─────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│ ModelContext: Send to Provider      │
│ ─────────────────────────────────── │
│ 1. Calculate ollamaContextSize      │
│ 2. Log request details              │
│ 3. Call provider.chatStream()       │
│ 4. Set num_ctx = ollamaContextSize  │
└─────────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│ Provider: Send to Ollama            │
│ ─────────────────────────────────── │
│ 1. Receive num_ctx parameter        │
│ 2. Respect context limit            │
│ 3. Stop naturally at 85% cap        │
└─────────────────────────────────────┘
```

---

## Next Steps

1. Implement changes
2. Fix TypeScript errors
3. Test manually
4. Verify compression works
5. Document changes

---

**Priority:** 🔴 CRITICAL  
**Status:** 🚧 In Progress  
**Estimated Time:** 2-3 hours
