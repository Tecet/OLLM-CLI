# Goal Management & Reasoning Traces Integration Plan

**Date:** 2026-01-21  
**Status:** In Progress  
**Session:** Context Transfer Session

## Overview

Integrating the goal management system and reasoning traces into the context manager and tool registry. Both systems are fully implemented and ready for integration.

## Completed Implementation

### Goal Management System (~1,500 lines)
- ✅ `packages/core/src/context/goalTypes.ts` - Complete type system
- ✅ `packages/core/src/context/goalManager.ts` - Full GoalManager implementation
- ✅ `packages/core/src/tools/goal-management.ts` - 5 LLM tools
- ✅ `packages/core/src/prompts/goalManagementPrompt.ts` - Additive prompt + parser
- ✅ Dual implementation (tool-capable + non-tool models)

### Reasoning Traces System (~550 lines)
- ✅ `packages/core/src/context/reasoningTypes.ts` - Complete type system
- ✅ `packages/core/src/context/reasoningManager.ts` - Full ReasoningManager implementation
- ✅ `packages/core/src/tools/read-reasoning.ts` - Tool for LLM to review past reasoning
- ✅ Auto-extraction of structured data from `<think>` tags

## Integration Points

### 1. Context Manager (`packages/core/src/context/contextManager.ts`)

**Constructor Changes:**
```typescript
constructor(
  sessionId: string,
  modelInfo: ModelInfo,
  config: Partial<ContextConfig> = {},
  services?: {
    vramMonitor?: VRAMMonitor;
    tokenCounter?: TokenCounter;
    contextPool?: ContextPool;
    snapshotStorage?: SnapshotStorage;
    snapshotManager?: SnapshotManager;
    compressionService?: ICompressionService;
    memoryGuard?: MemoryGuard;
    goalManager?: GoalManager;           // NEW
    reasoningManager?: ReasoningManager; // NEW
  }
)
```

**Private Fields:**
```typescript
private goalManager: GoalManager;
private reasoningManager: ReasoningManager;
```

**Initialization:**
```typescript
// Initialize goal manager
this.goalManager = services?.goalManager || new GoalManager();

// Initialize reasoning manager  
this.reasoningManager = services?.reasoningManager || new ReasoningManager();
```

**Snapshot Integration:**
```typescript
// In createSnapshot():
const snapshot = await this.snapshotManager.createSnapshot({
  ...this.currentContext,
  goalStack: this.goalManager.getGoalStack(),
  reasoningStorage: this.reasoningManager.getStorage()
});

// In restoreSnapshot():
if (context.goalStack) {
  this.goalManager.restoreGoalStack(context.goalStack);
}
if (context.reasoningStorage) {
  this.reasoningManager.restoreStorage(context.reasoningStorage);
}
```

**System Prompt Integration:**
```typescript
// In updateSystemPrompt() or getSystemPromptForTierAndMode():
const basePrompt = SYSTEM_PROMPT_TEMPLATES[key].template;
const goalContext = this.goalManager.getGoalContext();
const fullPrompt = `${basePrompt}\n\n${goalContext}`;
```

**Tool Context Integration:**
```typescript
// Add to ToolContext creation:
const toolContext: ToolContext = {
  messageBus,
  policyEngine,
  goalManager: this.goalManager,
  reasoningManager: this.reasoningManager,
  // ... other fields
};
```

### 2. Tool Registry (`packages/core/src/tools/index.ts`)

**Add Imports:**
```typescript
import { CreateGoalTool } from './goal-management.js';
import { CreateCheckpointTool } from './goal-management.js';
import { CompleteGoalTool } from './goal-management.js';
import { RecordDecisionTool } from './goal-management.js';
import { SwitchGoalTool } from './goal-management.js';
import { ReadReasoningTool } from './read-reasoning.js';
```

**Add to registerBuiltInTools():**
```typescript
export function registerBuiltInTools(registry: ToolRegistry, config?: BuiltInToolsConfig): void {
  // ... existing tools ...
  
  // Goal management tools (for tool-capable models)
  registry.register(new CreateGoalTool());
  registry.register(new CreateCheckpointTool());
  registry.register(new CompleteGoalTool());
  registry.register(new RecordDecisionTool());
  registry.register(new SwitchGoalTool());
  
  // Reasoning traces tool
  registry.register(new ReadReasoningTool());
}
```

### 3. Response Handler (Need to locate)

**For Tool-Capable Models:**
- Tools are called automatically via function calling
- No additional handling needed

**For Non-Tool Models:**
- Parse response for structured markers
- Extract and execute goal management actions
- Example markers: `NEW_GOAL:`, `CHECKPOINT:`, `DECISION:`, etc.

```typescript
// In response handler after receiving assistant message:
if (!modelSupportsTools) {
  const actions = parseGoalManagementMarkers(response.content);
  for (const action of actions) {
    await executeGoalAction(action, goalManager);
  }
}
```

### 4. Reasoning Trace Capture (Need to locate)

**When Processing Responses:**
```typescript
// After extracting <think> tags for UI:
if (thinkingContent) {
  await reasoningManager.addTrace({
    messageId: message.id,
    thinkingContent,
    timestamp: new Date()
  });
}
```

### 5. Types Update (`packages/core/src/tools/types.ts`)

**Already Done:**
```typescript
export interface ToolContext {
  messageBus: MessageBus;
  policyEngine: PolicyEngineInterface;
  goalManager?: GoalManager;           // ADDED
  reasoningManager?: ReasoningManager; // ADDED
  // ... other fields
}
```

## Implementation Steps

### Phase 1: Context Manager Integration ✅ NEXT
1. Add goalManager and reasoningManager to constructor services parameter
2. Initialize both managers in constructor
3. Add as private fields
4. Wire into snapshot creation/restoration
5. Add goal context to system prompt
6. Update tool context creation

### Phase 2: Tool Registry Integration
1. Import goal management tools
2. Import read reasoning tool
3. Register all tools in registerBuiltInTools()
4. Export tool classes

### Phase 3: Response Handler Integration
1. Locate response handler file
2. Add marker parsing for non-tool models
3. Add reasoning trace capture
4. Test with both tool-capable and non-tool models

### Phase 4: Testing
1. Test goal creation and completion
2. Test checkpoint creation
3. Test decision recording
4. Test goal switching
5. Test reasoning trace storage and retrieval
6. Test snapshot persistence
7. Test context rollover with goals and reasoning

### Phase 5: Documentation
1. Update Context documentation
2. Add user guide for goal management
3. Add examples for reasoning traces
4. Update API documentation

## Files to Modify

### Core Changes
- ✅ `packages/core/src/context/types.ts` - Already updated with goalStack and reasoningStorage
- ⏳ `packages/core/src/context/contextManager.ts` - Add managers, wire into snapshots
- ⏳ `packages/core/src/tools/index.ts` - Register new tools
- ⏳ `packages/core/src/tools/types.ts` - Already updated with goalManager and reasoningManager

### Integration Points (Need to Locate)
- ⏳ Response handler - Add marker parsing and reasoning capture
- ⏳ System prompt builder - Add goal context

## Testing Strategy

### Unit Tests
- Goal manager lifecycle
- Reasoning manager storage
- Snapshot persistence
- Tool invocations

### Integration Tests
- Full conversation with goals
- Context rollover with goals
- Reasoning trace accumulation
- Non-tool model marker parsing

### Manual Tests
- Long conversation (100+ messages)
- Multiple goal switches
- Reasoning model thinking preservation
- Snapshot restore after rollover

## Success Criteria

1. ✅ Goal manager initializes correctly
2. ✅ Reasoning manager initializes correctly
3. ⏳ Goals persist across snapshots
4. ⏳ Reasoning traces persist across snapshots
5. ⏳ LLM can create and manage goals autonomously
6. ⏳ LLM can review past reasoning
7. ⏳ Non-tool models can use structured markers
8. ⏳ System prompt includes goal context
9. ⏳ All tests pass
10. ⏳ Documentation complete

## Notes

- User already has reasoning model detection working
- User already extracts `<think>` tags for UI display
- App already detects models which can't use tools
- Additive prompt approach prevents need for duplicate prompts
- Goal stack and reasoning storage are separate from message history
- Both systems are designed to work with existing compression strategies

## Next Actions

1. Start with Phase 1: Context Manager Integration
2. Add managers to constructor
3. Wire into snapshots
4. Add goal context to system prompt
5. Update tool context creation
6. Build and test
