# Reasoning Traces Implementation

**Date:** January 21, 2026  
**Status:** ✅ COMPLETE - Ready for integration

## Overview

Added support for preserving reasoning traces from reasoning models (DeepSeek-R1, QwQ, o1, o3) across context rollovers. The LLM can now review its past thinking processes after compression.

## Problem Solved

**Before:**
```
Context rollover happens
→ Reasoning traces lost
→ LLM forgets why it made decisions
→ Can't learn from past analysis
→ Repeats same reasoning
```

**After:**
```
Context rollover happens
→ Reasoning traces preserved in snapshot
→ LLM can call read_reasoning tool
→ Reviews past thinking
→ Builds on previous analysis
→ Makes better decisions
```

## Implementation

### 1. Reasoning Types ✅

**File:** `packages/core/src/context/reasoningTypes.ts`

```typescript
interface ReasoningTrace {
  id: string;
  timestamp: Date;
  messageId: string;
  thinking: string;  // Full <think> content
  context: {
    goalId?: string;
    checkpointId?: string;
    decisionId?: string;
    userMessageId?: string;
  };
  structured?: {
    alternatives: string[];
    chosenApproach: string;
    rationale: string;
    confidence: number;
    keyInsights: string[];
  };
  metadata: {
    modelName: string;
    thinkingTokens: number;
    answerTokens: number;
  };
}

interface ReasoningStorage {
  recent: ReasoningTrace[];        // Last 5, full detail
  archived: ArchivedReasoningTrace[];  // Summaries only
  totalTraces: number;
  totalThinkingTokens: number;
}
```

### 2. Reasoning Manager ✅

**File:** `packages/core/src/context/reasoningManager.ts`

**Features:**
- Add reasoning traces
- Auto-extract structured data (alternatives, rationale, insights)
- Keep last 5 traces in full
- Archive older traces as summaries
- Get traces by goal/message
- Serialize for snapshots

### 3. Updated Snapshot Format ✅

**File:** `packages/core/src/context/types.ts`

```typescript
interface ContextSnapshot {
  // ... existing fields ...
  
  reasoningStorage?: ReasoningStorage;  // NEW
  
  metadata: {
    // ... existing fields ...
    isReasoningModel?: boolean;         // NEW
    totalThinkingTokens?: number;       // NEW
  };
}
```

### 4. Read Reasoning Tool ✅

**File:** `packages/core/src/tools/read-reasoning.ts`

**Tool:** `read_reasoning`

**Parameters:**
- `goalId` - Get traces for specific goal
- `traceId` - Get specific trace
- `limit` - Max traces to return (default: 5)
- `includeArchived` - Include archived summaries

**Returns:** Formatted reasoning traces with:
- Full thinking process
- Structured analysis
- Alternatives considered
- Chosen approach and rationale
- Key insights
- Confidence level

## Integration Steps

### Step 1: Initialize Reasoning Manager

```typescript
import { createReasoningManager, DEFAULT_REASONING_CONFIG } from './context/reasoningManager.js';

// Create reasoning manager
const reasoningManager = createReasoningManager(DEFAULT_REASONING_CONFIG);

// Add to context (alongside goal manager)
const context = {
  goalManager,
  reasoningManager  // NEW
};
```

### Step 2: Detect Reasoning Models

```typescript
// You already have this
function isReasoningModel(modelName: string): boolean {
  return (
    modelName.includes('deepseek-r1') ||
    modelName.includes('qwq') ||
    modelName.includes('o1') ||
    modelName.includes('o3')
  );
}
```

### Step 3: Extract and Store Reasoning

```typescript
// When processing LLM response
function handleResponse(response: string, messageId: string) {
  if (isReasoningModel(currentModel)) {
    // Extract <think> tags (you already do this for UI)
    const { thinking, finalAnswer } = extractThinkTags(response);
    
    if (thinking) {
      // Store reasoning trace
      reasoningManager.addTrace(
        messageId,
        thinking,
        currentModel,
        countTokens(thinking),
        countTokens(finalAnswer),
        {
          goalId: goalManager.getActiveGoal()?.id,
          userMessageId: lastUserMessageId
        }
      );
    }
    
    return finalAnswer;  // Display only final answer
  }
  
  return response;
}
```

### Step 4: Include in Snapshots

```typescript
// When creating snapshot
async function createSnapshot(context: ConversationContext) {
  const snapshot: ContextSnapshot = {
    // ... existing fields ...
    
    reasoningStorage: reasoningManager.getReasoningStorage(),  // NEW
    
    metadata: {
      // ... existing fields ...
      isReasoningModel: isReasoningModel(context.metadata.model),
      totalThinkingTokens: reasoningManager.getReasoningStorage().totalThinkingTokens
    }
  };
  
  return snapshot;
}

// When restoring snapshot
async function restoreSnapshot(snapshotId: string) {
  const snapshot = await storage.load(snapshotId);
  
  // Restore reasoning traces
  if (snapshot.reasoningStorage) {
    reasoningManager.restoreReasoningStorage(snapshot.reasoningStorage);
  }
  
  return snapshot;
}
```

### Step 5: Register Read Reasoning Tool

```typescript
import { ReadReasoningTool } from './tools/read-reasoning.js';

// Register tool
toolRegistry.register(new ReadReasoningTool());

// Add reasoning manager to tool context
const toolContext: ToolContext = {
  messageBus,
  policyEngine,
  goalManager,
  reasoningManager  // NEW
};
```

## Usage Example

### Scenario: Long Debugging Session with DeepSeek-R1

```
Hour 1: Initial Analysis
User: "Debug the authentication bug"

DeepSeek-R1:
<think>
Let me analyze the authentication flow...
- User login goes through validateUser()
- Error occurs on line 42
- Null pointer exception
- User object is undefined
- Alternative 1: Add null check
- Alternative 2: Throw exception
- Alternative 3: Return default user
- Chosen: Add null check (cleanest)
- Rationale: Prevents crash, returns proper error code
- Confidence: 85%
</think>

I found the bug. It's a missing null check on line 42...

[Reasoning trace stored]

Hour 2: Context Rollover
[Snapshot created with reasoning storage]
[Context compressed]

Hour 3: Continuing Work
User: "Now add rate limiting"

DeepSeek-R1: [Calls read_reasoning tool]
{
  "goalId": "previous-goal-id",
  "limit": 3
}

[Receives past reasoning traces]

<think>
Reviewing my previous analysis...
- I added null check for authentication
- Decided against throwing exceptions
- Used error code 401
- Now for rate limiting, I should:
  - Use similar error handling pattern
  - Return 429 error code
  - Keep consistent with previous decisions
</think>

Based on my previous analysis, I'll implement rate limiting
with the same error handling pattern I used for authentication...
```

## Benefits

### 1. Continuity Across Rollovers ✅
- LLM can review past thinking
- Builds on previous analysis
- Doesn't repeat reasoning
- Makes consistent decisions

### 2. Better Decision Making ✅
- Can see what alternatives were considered
- Understands rationale for past choices
- Maintains confidence levels
- Preserves key insights

### 3. Learning from Experience ✅
- Reviews what worked
- Avoids past mistakes
- Improves over time
- Builds knowledge base

### 4. Debugging Support ✅
- Can trace decision-making process
- Understand why choices were made
- Review confidence levels
- Identify reasoning patterns

## Token Budget

### Storage Overhead

**Recent Traces (5 full):**
```
Average thinking: 1000 tokens per trace
5 traces × 1000 = 5,000 tokens
```

**Archived Traces (20 summaries):**
```
Average summary: 50 tokens
20 summaries × 50 = 1,000 tokens
```

**Total:** ~6,000 tokens (18% of 32K context)

### Optimization

**For smaller contexts (4K-8K):**
- Keep only 3 recent traces
- Limit archived to 10
- Total: ~3,500 tokens

**For larger contexts (64K+):**
- Keep 10 recent traces
- Limit archived to 50
- Total: ~12,500 tokens

## Configuration

```typescript
const reasoningConfig: ReasoningConfig = {
  enabled: true,
  keepRecentTraces: 5,        // Adjust based on context size
  maxArchivedTraces: 20,      // Adjust based on context size
  autoExtractStructured: true // Parse alternatives, insights, etc.
};
```

## Files Created

```
packages/core/src/context/reasoningTypes.ts      (~150 lines)
packages/core/src/context/reasoningManager.ts    (~250 lines)
packages/core/src/tools/read-reasoning.ts        (~150 lines)
```

## Files Modified

```
packages/core/src/context/types.ts               (added reasoningStorage field)
```

## Build Status

✅ **Build successful**  
✅ **No TypeScript errors**  
✅ **Ready for integration**

## Next Steps

1. **Initialize reasoning manager in CLI startup**
2. **Extract thinking from responses** (you already do this)
3. **Store traces in reasoning manager**
4. **Include in snapshots**
5. **Register read_reasoning tool**
6. **Test with DeepSeek-R1 or QwQ**

## Testing Checklist

- [ ] Reasoning traces stored correctly
- [ ] Traces preserved across snapshots
- [ ] LLM can read past reasoning
- [ ] Structured data extracted correctly
- [ ] Archived traces work
- [ ] Token budget reasonable
- [ ] Works with multiple reasoning models

---

**Status:** Implementation complete  
**Estimated Integration Time:** 1-2 hours  
**Priority:** MEDIUM - Enhances reasoning model experience
