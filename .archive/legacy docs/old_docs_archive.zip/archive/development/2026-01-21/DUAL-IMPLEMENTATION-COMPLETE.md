# Dual Implementation: Tools + Prompt-Based Goal Management

**Date:** January 21, 2026  
**Status:** ✅ COMPLETE - Ready for integration

## Overview

Implemented dual-mode goal management system that works with **ALL** LLM models:
- **Tool-capable models:** Use native tool calling (cleaner, more reliable)
- **Non-tool models:** Use structured text markers (universal compatibility)

## Implementation Summary

### 1. Goal Management Tools ✅

Created 5 tools for tool-capable models:

**File:** `packages/core/src/tools/goal-management.ts`

| Tool | Purpose | Parameters |
|------|---------|------------|
| `create_goal` | Create new goal | description, priority, subtasks |
| `create_checkpoint` | Mark progress | description, filesModified, testsAdded, decisionsLocked |
| `complete_goal` | Mark goal done | summary, artifacts |
| `record_decision` | Track decisions | description, rationale, alternatives, locked |
| `switch_goal` | Pause/resume/new | action, goalId, newGoalDescription, priority |

### 2. Additive Prompt for Non-Tool Models ✅

Created universal prompt that gets appended to system prompt:

**File:** `packages/core/src/prompts/goalManagementPrompt.ts`

**Structured Markers:**
```
NEW_GOAL: [description] | [priority]
CHECKPOINT: [description]
DECISION: [description] | [rationale]
DECISION_LOCKED: [description] | [rationale]
ARTIFACT: [path] | [action]
GOAL_COMPLETE: [summary]
GOAL_PAUSE
```

**Parser Features:**
- Extracts all markers from LLM output
- Removes markers from displayed text
- Returns structured data for goal manager

### 3. Updated ToolContext ✅

Added goal manager to tool context:

**File:** `packages/core/src/tools/types.ts`

```typescript
export interface ToolContext {
  messageBus: MessageBus;
  policyEngine?: PolicyEngineInterface;
  goalManager?: GoalManager;        // NEW
  workspaceBoundary?: WorkspaceBoundary; // NEW
}
```

## How It Works

### For Tool-Capable Models (Llama 3.1+, Qwen 2.5, etc.)

```typescript
// LLM calls tool directly
{
  "tool": "create_checkpoint",
  "parameters": {
    "description": "Fixed authentication bug",
    "filesModified": ["src/auth/login.ts"],
    "decisionsLocked": ["Use JWT for auth"]
  }
}

// Tool executes → Updates goal manager → Returns result
```

### For Non-Tool Models (Llama 2, older models, etc.)

```typescript
// System prompt includes additive prompt
const systemPrompt = basePrompt + GOAL_MANAGEMENT_ADDITIVE_PROMPT;

// LLM outputs structured markers
"I've fixed the authentication bug.
CHECKPOINT: Fixed authentication bug
ARTIFACT: src/auth/login.ts | modified
DECISION: Use JWT for auth | More secure than sessions"

// Parser extracts markers → Updates goal manager → Removes markers from display
```

## Integration Steps

### Step 1: Detect Model Capabilities

```typescript
// Already exists in your app
const modelCapabilities = detectModelCapabilities(modelName);
const supportsTools = modelCapabilities.supportsTools;
```

### Step 2: Add Additive Prompt (Non-Tool Models)

```typescript
import { GOAL_MANAGEMENT_ADDITIVE_PROMPT } from './prompts/goalManagementPrompt.js';

function buildSystemPrompt(basePrompt: string, supportsTools: boolean): string {
  if (supportsTools) {
    // Tool-capable model - no additive prompt needed
    return basePrompt;
  } else {
    // Non-tool model - append additive prompt
    return basePrompt + GOAL_MANAGEMENT_ADDITIVE_PROMPT;
  }
}
```

### Step 3: Register Tools (Tool-Capable Models)

```typescript
import { GOAL_MANAGEMENT_TOOLS } from './tools/goal-management.js';

if (supportsTools) {
  // Register goal management tools
  for (const ToolClass of GOAL_MANAGEMENT_TOOLS) {
    toolRegistry.register(new ToolClass());
  }
}
```

### Step 4: Parse Output (Non-Tool Models)

```typescript
import { GoalManagementParser } from './prompts/goalManagementPrompt.js';

function handleLLMResponse(response: string, goalManager: GoalManager) {
  if (!supportsTools) {
    // Parse markers from response
    const markers = GoalManagementParser.parse(response);
    
    // Apply markers to goal manager
    applyMarkers(markers, goalManager);
    
    // Remove markers from displayed text
    const cleanResponse = GoalManagementParser.removeMarkers(response);
    return cleanResponse;
  }
  
  return response;
}

function applyMarkers(markers: ParsedMarkers, goalManager: GoalManager) {
  // Create new goals
  for (const goal of markers.newGoals) {
    goalManager.createGoal(goal.description, goal.priority);
  }
  
  // Create checkpoints
  const activeGoal = goalManager.getActiveGoal();
  if (activeGoal) {
    for (const checkpoint of markers.checkpoints) {
      goalManager.createCheckpoint(activeGoal.id, checkpoint.description, {});
    }
    
    // Record decisions
    for (const decision of markers.decisions) {
      const dec = goalManager.recordDecision(
        activeGoal.id,
        decision.description,
        decision.rationale
      );
      if (decision.locked) {
        goalManager.lockDecision(activeGoal.id, dec.id);
      }
    }
    
    // Record artifacts
    for (const artifact of markers.artifacts) {
      goalManager.recordArtifact(
        activeGoal.id,
        'file',
        artifact.path,
        artifact.action
      );
    }
    
    // Complete goal
    if (markers.goalComplete) {
      goalManager.completeGoal(activeGoal.id, markers.goalComplete);
    }
    
    // Pause goal
    if (markers.goalPause) {
      goalManager.pauseGoal(activeGoal.id);
    }
  }
}
```

### Step 5: Initialize Goal Manager

```typescript
import { createGoalManager, DEFAULT_GOAL_CONFIG } from './context/goalManager.js';

// Create goal manager
const goalManager = createGoalManager(DEFAULT_GOAL_CONFIG);

// Add to tool context
const toolContext: ToolContext = {
  messageBus,
  policyEngine,
  goalManager  // NEW
};
```

## Example Usage

### Tool-Capable Model (Llama 3.1)

```
User: "Fix the authentication bug in login.ts"

LLM: [Calls create_goal tool]
{
  "description": "Fix authentication bug in login.ts",
  "priority": "high",
  "subtasks": ["Find bug", "Write fix", "Test fix"]
}

LLM: "I'll analyze the code to find the bug..."

[Analysis happens]

LLM: [Calls create_checkpoint tool]
{
  "description": "Found bug: missing null check on line 42",
  "decisionsLocked": ["Bug is in validateUser() function"]
}

LLM: "Now I'll implement the fix..."

[Fix implemented]

LLM: [Calls create_checkpoint tool]
{
  "description": "Added null check and error handling",
  "filesModified": ["src/auth/login.ts"]
}

LLM: [Calls complete_goal tool]
{
  "summary": "Fixed authentication bug by adding null check",
  "artifacts": ["src/auth/login.ts", "tests/login.test.ts"]
}
```

### Non-Tool Model (Llama 2)

```
User: "Fix the authentication bug in login.ts"

LLM: "I'll start working on this issue.

NEW_GOAL: Fix authentication bug in login.ts | high

Let me analyze the code to find the bug...

[Analysis happens]

I found the issue - there's a missing null check on line 42.

CHECKPOINT: Found bug in validateUser() function on line 42
DECISION: Add null check before validation | Prevents crash on undefined user

Now I'll implement the fix...

[Fix implemented]

ARTIFACT: src/auth/login.ts | modified
CHECKPOINT: Added null check and error handling

Let me add tests...

[Tests added]

ARTIFACT: tests/login.test.ts | created

All tests pass. The authentication bug is fixed.

GOAL_COMPLETE: Fixed authentication bug by adding null check and comprehensive tests"

[Parser extracts markers, updates goal manager, displays clean text]
```

## Benefits

### 1. Universal Compatibility ✅
- Works with 100% of models
- No model left behind
- Graceful degradation

### 2. Better UX for Tool-Capable Models ✅
- Native tool calling is cleaner
- Better structured data
- More reliable parsing
- Richer metadata

### 3. Still Works for Non-Tool Models ✅
- Structured text markers
- Regex parsing
- Good enough for most cases
- Human-readable format

### 4. Single Codebase ✅
- One goal manager implementation
- One set of prompts (with additive)
- Automatic mode selection
- No duplication

### 5. Easy to Extend ✅
- Add new tools → Add new markers
- Same interface for both modes
- Consistent behavior

## Token Budget Impact

### Tool-Capable Models
```
No additional tokens in system prompt
Tools are passed separately
```

### Non-Tool Models
```
Additive prompt: ~600 tokens
Added to system prompt only for non-tool models
Markers in output: ~50-100 tokens per response
Removed before display
```

## Testing Strategy

### Unit Tests
- Test each tool individually
- Test marker parser
- Test marker removal
- Test applyMarkers function

### Integration Tests
- Test with tool-capable model
- Test with non-tool model
- Test mode switching
- Test goal manager integration

### End-to-End Tests
- Long session with tool model
- Long session with non-tool model
- Verify goal tracking works
- Verify no data loss

## Files Created

```
packages/core/src/tools/goal-management.ts          (5 tools, ~400 lines)
packages/core/src/prompts/goalManagementPrompt.ts  (prompt + parser, ~300 lines)
```

## Files Modified

```
packages/core/src/tools/types.ts                    (added goalManager to ToolContext)
```

## Build Status

✅ **Build successful**  
✅ **No TypeScript errors**  
✅ **Ready for integration**

## Next Steps

1. **Initialize goal manager in CLI startup**
2. **Add goal manager to tool context**
3. **Detect model capabilities**
4. **Add additive prompt for non-tool models**
5. **Register tools for tool-capable models**
6. **Parse markers for non-tool models**
7. **Test with both model types**
8. **Add to system prompt integration**

---

**Status:** Core implementation complete  
**Estimated Integration Time:** 2-3 hours  
**Priority:** HIGH - Enables autonomous goal tracking for all models
