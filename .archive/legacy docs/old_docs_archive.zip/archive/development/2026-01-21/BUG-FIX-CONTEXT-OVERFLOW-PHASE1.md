# Bug Fix: Context Overflow - Phase 1 Complete

**Date:** January 21, 2026  
**Status:** ✅ Phase 1 Complete  
**Next:** Phase 2 - UI Integration

---

## What Was Fixed

### Phase 1: ChatClient Context Size Validation ✅

**Problem:** ChatClient wasn't ensuring context size was set, so `num_ctx` was never sent to Ollama.

**Solution:** Added validation and fallback logic in `chatClient.chat()`.

---

## Changes Made

### 1. Added Context Size Validation in ChatClient ✅

**File:** `packages/core/src/core/chatClient.ts`

**Location:** After provider resolution (line ~107)

**Change:**
```typescript
// Ensure context size is set (CRITICAL: prevents context overflow)
if (!options?.contextSize && !options?.ollamaContextSize) {
  // Try to get from context manager
  if (this.contextMgmtManager) {
    const usage = this.contextMgmtManager.getUsage();
    options = {
      ...options,
      contextSize: usage.maxTokens,
      ollamaContextSize: Math.floor(usage.maxTokens * 0.85),
    };
    console.log(`[ChatClient] Context size from manager: ${usage.maxTokens}, Ollama: ${Math.floor(usage.maxTokens * 0.85)}`);
  } else {
    // Fallback to default
    const defaultContextSize = 8192;
    const defaultOllamaSize = 6963; // 85% of 8192
    options = {
      ...options,
      contextSize: defaultContextSize,
      ollamaContextSize: defaultOllamaSize,
    };
    console.warn(`[ChatClient] No context size specified, using default ${defaultContextSize} (Ollama: ${defaultOllamaSize})`);
  }
} else {
  console.log(`[ChatClient] Context size: ${options.contextSize}, Ollama: ${options.ollamaContextSize}`);
}
```

**Benefits:**
- ✅ Always ensures context size is set
- ✅ Gets from context manager if available
- ✅ Falls back to safe default (8192)
- ✅ Logs for debugging
- ✅ Prevents `num_ctx` from being undefined

### 2. Added Logging in Turn.buildGenerationOptions() ✅

**File:** `packages/core/src/core/turn.ts`

**Location:** `buildGenerationOptions()` method (line ~306-318)

**Change:**
```typescript
// Add num_ctx for Ollama (85% cap strategy)
if (this.options.ollamaContextSize !== undefined) {
  opts.num_ctx = this.options.ollamaContextSize;
  console.log(`[Turn] Setting num_ctx from ollamaContextSize: ${opts.num_ctx}`);
} else if (this.options.contextSize !== undefined) {
  opts.num_ctx = Math.floor(this.options.contextSize * 0.85);
  console.log(`[Turn] Setting num_ctx from contextSize (85%): ${opts.num_ctx}`);
} else {
  console.warn('[Turn] No context size provided, num_ctx will not be set!');
}
```

**Benefits:**
- ✅ Logs when `num_ctx` is set
- ✅ Warns if context size is missing
- ✅ Helps debug context overflow issues
- ✅ Verifies 85% cap strategy

---

## How It Works

### Flow Diagram

```
User calls chatClient.chat(prompt, options)
            │
            ▼
┌──────────────────────────────────────┐
│ ChatClient validates context size    │
│ ────────────────────────────────────│
│ If not set:                          │
│   1. Try context manager             │
│   2. Fallback to default (8192)      │
│ Log result                           │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ ChatClient creates Turn               │
│ ────────────────────────────────────│
│ Passes options with contextSize      │
│ and ollamaContextSize                │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ Turn.buildGenerationOptions()        │
│ ────────────────────────────────────│
│ Sets num_ctx from ollamaContextSize  │
│ or calculates 85% from contextSize   │
│ Logs the value                       │
└──────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────┐
│ Provider receives num_ctx             │
│ ────────────────────────────────────│
│ Ollama respects context limit        │
│ Stops naturally at 85% cap           │
└──────────────────────────────────────┘
```

---

## Testing

### Manual Testing

**Test 1: Direct ChatClient Call**
```typescript
const chatClient = new ChatClient(config);

// Without context size (should use default)
for await (const event of chatClient.chat("Hello", {})) {
  // Should log: "[ChatClient] No context size specified, using default 8192 (Ollama: 6963)"
  // Should log: "[Turn] Setting num_ctx from ollamaContextSize: 6963"
}

// With context size
for await (const event of chatClient.chat("Hello", {
  contextSize: 16384,
  ollamaContextSize: 13926
})) {
  // Should log: "[ChatClient] Context size: 16384, Ollama: 13926"
  // Should log: "[Turn] Setting num_ctx from ollamaContextSize: 13926"
}
```

**Expected Logs:**
```
[ChatClient] No context size specified, using default 8192 (Ollama: 6963)
[Turn] Setting num_ctx from ollamaContextSize: 6963

[ChatClient] Context size: 16384, Ollama: 13926
[Turn] Setting num_ctx from ollamaContextSize: 13926
```

### Verification

Run the app and check logs:
```bash
npm run dev
```

Look for:
- `[ChatClient] Context size:` messages
- `[Turn] Setting num_ctx` messages
- No `[Turn] No context size provided` warnings

---

## What's Still Needed

### Phase 2: UI Integration 🚧 NEXT

**Problem:** UI still calls `provider.chatStream()` directly, bypassing chatClient.

**Location:** `packages/cli/src/features/context/ModelContext.tsx` (line 743-756)

**Current Code:**
```typescript
// WRONG: Direct provider call
const stream = provider.chatStream({
  model: currentModel,
  messages: providerMessages,
  tools: tools,
  systemPrompt: systemPrompt,
  options: {
    num_ctx: ollamaContextSize, // Set correctly but bypasses chatClient
    temperature: temperatureOverride ?? temperature,
  },
});
```

**Needed Change:**
```typescript
// RIGHT: Use chatClient
const chatClient = getChatClient(); // Get from context
for await (const event of chatClient.chat(userMessage, {
  model: currentModel,
  provider: providerName,
  tools: tools,
  systemPrompt: systemPrompt,
  contextSize: userContextSize,
  ollamaContextSize: ollamaContextSize,
  temperature: temperatureOverride ?? temperature,
  abortSignal: abortController.signal,
})) {
  // Handle events
}
```

**Why This is Critical:**
- UI bypasses all context management
- No compression happens
- No memory guards trigger
- Messages accumulate indefinitely
- Eventually runs out of memory

**Effort:** 2-3 hours
**Risk:** Medium (requires testing all UI flows)

---

## Status

### Phase 1: ChatClient Validation ✅ COMPLETE

- [x] Added context size validation
- [x] Added fallback to default
- [x] Added logging for debugging
- [x] Verified no TypeScript errors
- [x] Documented changes

### Phase 2: UI Integration 🚧 NEXT

- [ ] Modify ModelContext to use chatClient
- [ ] Pass context size options
- [ ] Handle all event types
- [ ] Test all UI flows
- [ ] Test compression triggers
- [ ] Test memory guards

### Phase 3: Testing 📋 PENDING

- [ ] Unit tests
- [ ] Integration tests
- [ ] Manual testing
- [ ] Performance testing
- [ ] Crash recovery testing

---

## Impact

### What Phase 1 Fixes

✅ **For Direct ChatClient Users:**
- Context size always set
- `num_ctx` always sent to Ollama
- Safe fallback if not specified
- Better debugging with logs

⚠️ **For UI Users (Most Users):**
- Still broken (UI bypasses chatClient)
- Need Phase 2 to fix

### What Phase 2 Will Fix

✅ **For All Users:**
- Context management works
- Compression triggers automatically
- Memory guards prevent overflow
- No crashes from memory exhaustion
- Snapshots created before compression

---

## Next Steps

1. **Implement Phase 2** (UI Integration)
   - Modify `ModelContext.tsx`
   - Use `chatClient.chat()` instead of direct provider calls
   - Pass context size options
   - Test all flows

2. **Test Thoroughly**
   - All UI interactions
   - Long conversations
   - Compression triggers
   - Memory limits
   - Error handling

3. **Deploy and Monitor**
   - Watch logs for context size messages
   - Monitor memory usage
   - Check for crashes
   - Verify compression works

---

**Priority:** 🔴 CRITICAL  
**Phase 1 Status:** ✅ Complete  
**Phase 2 Status:** 🚧 Ready to start  
**Estimated Time for Phase 2:** 2-3 hours
