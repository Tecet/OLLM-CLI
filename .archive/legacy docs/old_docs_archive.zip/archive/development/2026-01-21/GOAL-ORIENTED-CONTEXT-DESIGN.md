# Goal-Oriented Context Management System

**Date:** January 21, 2026  
**Priority:** HIGH - Enables autonomous goal tracking and context management  
**Status:** Design Phase

## Problem Statement

**Current Issue:**
In long sessions (100+ messages), the LLM loses track of:
- Original goals and tasks
- What has been completed
- What decisions were made
- What the current focus is

**Example Scenario:**
```
Hour 1: "Verify test suite" → 50 messages
Hour 2: "Fix bugs found" → 30 messages  
Hour 3: "Document changes" → 20 messages
Total: 100+ messages

After compression:
- Only last 10 user messages preserved
- Original goals lost
- Completed work forgotten
- LLM confused about context
```

## Solution: Goal Stack with Structured Checkpoints

### Core Concept

**Goal Stack:** Hierarchical goal management where:
1. **Active Goal** - Current main task
2. **Completed Goals** - Archived finished tasks (retrievable)
3. **Checkpoints** - Progress markers within goals
4. **Structured Data** - Facts, not summaries (prevents hallucination)

### Key Benefits

1. ✅ **No Hallucination** - Structured facts, not LLM-generated summaries
2. ✅ **Autonomous Checkpointing** - LLM can mark progress
3. ✅ **Goal Switching** - Change direction without losing context
4. ✅ **Long Session Support** - Scales to 100+ messages
5. ✅ **Retrievable History** - Can look back at completed goals

## Data Structures

### Goal

```typescript
interface Goal {
  // Identity
  id: string;                    // UUID
  description: string;           // "Fix authentication bug in login.ts"
  
  // Status
  status: 'active' | 'completed' | 'paused' | 'blocked' | 'abandoned';
  createdAt: Date;
  completedAt?: Date;
  pausedAt?: Date;
  
  // Hierarchy
  parentGoalId?: string;         // For sub-goals
  subtasks: Subtask[];
  
  // Progress tracking
  checkpoints: Checkpoint[];
  decisions: Decision[];
  artifacts: Artifact[];
  blockers: Blocker[];
  
  // Metadata
  priority: 'high' | 'medium' | 'low';
  estimatedEffort?: string;      // "2 hours"
  actualEffort?: string;         // "3.5 hours"
  tags: string[];                // ["bug-fix", "authentication"]
}
```

### Subtask

```typescript
interface Subtask {
  id: string;
  description: string;           // "Identify bug location"
  status: 'pending' | 'in-progress' | 'completed' | 'blocked';
  createdAt: Date;
  completedAt?: Date;
  
  // Dependencies
  dependsOn: string[];           // IDs of other subtasks
  blockedBy?: string;            // Blocker ID
}
```

### Checkpoint

```typescript
interface Checkpoint {
  id: string;
  goalId: string;
  description: string;           // "Fixed login validation"
  timestamp: Date;
  
  // State snapshot
  state: {
    filesModified: string[];
    testsAdded: string[];
    decisionsLocked: string[];   // Decisions that shouldn't be changed
    metricsRecorded: Record<string, number>;  // { "tests_passed": 42 }
  };
  
  // Context
  userMessageId?: string;        // Which user message triggered this
  assistantSummary: string;      // Brief summary of what was done
}
```

### Decision

```typescript
interface Decision {
  id: string;
  description: string;           // "Use JWT for authentication"
  rationale: string;             // "More secure than session cookies"
  alternatives: string[];        // ["Session cookies", "OAuth"]
  timestamp: Date;
  locked: boolean;               // If true, shouldn't be changed
}
```

### Artifact

```typescript
interface Artifact {
  type: 'file' | 'test' | 'documentation' | 'configuration';
  path: string;                  // "src/auth/login.ts"
  action: 'created' | 'modified' | 'deleted';
  timestamp: Date;
  description?: string;          // "Added null check for user validation"
}
```

### Blocker

```typescript
interface Blocker {
  id: string;
  description: string;           // "Need API key from user"
  type: 'missing-info' | 'external-dependency' | 'technical-issue';
  createdAt: Date;
  resolvedAt?: Date;
  resolution?: string;
}
```

## Goal Stack Management

### GoalStack Interface

```typescript
interface GoalStack {
  // Current state
  activeGoal: Goal | null;
  goalHistory: Goal[];           // All goals (active + completed)
  
  // Quick access
  completedGoals: Goal[];        // Completed and archived
  pausedGoals: Goal[];           // Paused, can be resumed
  
  // Statistics
  stats: {
    totalGoals: number;
    completedGoals: number;
    totalCheckpoints: number;
    sessionDuration: number;     // milliseconds
  };
}
```

### Goal Operations

```typescript
interface GoalManager {
  // Goal lifecycle
  createGoal(description: string, priority?: string): Goal;
  completeGoal(goalId: string): void;
  pauseGoal(goalId: string): void;
  resumeGoal(goalId: string): void;
  abandonGoal(goalId: string, reason: string): void;
  
  // Subtask management
  addSubtask(goalId: string, description: string): Subtask;
  completeSubtask(goalId: string, subtaskId: string): void;
  
  // Checkpoint management
  createCheckpoint(goalId: string, description: string, state: CheckpointState): Checkpoint;
  
  // Decision tracking
  recordDecision(goalId: string, decision: Decision): void;
  lockDecision(goalId: string, decisionId: string): void;
  
  // Artifact tracking
  recordArtifact(goalId: string, artifact: Artifact): void;
  
  // Blocker management
  addBlocker(goalId: string, blocker: Blocker): void;
  resolveBlocker(goalId: string, blockerId: string, resolution: string): void;
  
  // Query
  getActiveGoal(): Goal | null;
  getGoalById(goalId: string): Goal | null;
  getCompletedGoals(): Goal[];
  getGoalProgress(goalId: string): number;  // 0-100%
}
```

## Integration with Snapshots

### Updated ContextSnapshot

```typescript
interface ContextSnapshot {
  // Existing fields
  id: string;
  sessionId: string;
  timestamp: Date;
  tokenCount: number;
  summary: string;
  
  // User messages (never compressed)
  userMessages: UserMessage[];
  archivedUserMessages: ArchivedUserMessage[];
  
  // Assistant messages (compressed)
  messages: Message[];
  
  // NEW: Goal-oriented context
  goalStack: GoalStack;
  
  // Metadata
  metadata: {
    model: string;
    contextSize: number;
    compressionRatio: number;
    totalUserMessages: number;
    
    // NEW: Goal statistics
    activeGoalId?: string;
    totalGoalsCompleted: number;
    totalCheckpoints: number;
  };
}
```

## LLM Tools for Goal Management

### Tool: create_goal

```typescript
{
  name: 'create_goal',
  description: 'Create a new goal or task to work on',
  parameters: {
    description: string;         // "Fix authentication bug"
    priority?: 'high' | 'medium' | 'low';
    subtasks?: string[];         // ["Find bug", "Write fix", "Test"]
  }
}
```

### Tool: create_checkpoint

```typescript
{
  name: 'create_checkpoint',
  description: 'Mark progress on current goal',
  parameters: {
    description: string;         // "Fixed login validation"
    filesModified?: string[];
    decisionsLocked?: string[];
  }
}
```

### Tool: complete_goal

```typescript
{
  name: 'complete_goal',
  description: 'Mark current goal as completed',
  parameters: {
    summary: string;             // "Fixed auth bug, added tests"
    artifacts?: string[];        // Files created/modified
  }
}
```

### Tool: switch_goal

```typescript
{
  name: 'switch_goal',
  description: 'Pause current goal and start/resume another',
  parameters: {
    action: 'pause' | 'resume' | 'new';
    goalId?: string;             // For resume
    newGoalDescription?: string; // For new
  }
}
```

### Tool: record_decision

```typescript
{
  name: 'record_decision',
  description: 'Record an important decision made',
  parameters: {
    description: string;         // "Use JWT for auth"
    rationale: string;           // "More secure than sessions"
    locked?: boolean;            // Should this decision be changed?
  }
}
```

## System Prompt Integration

### Goal Context in System Prompt

```typescript
function buildSystemPrompt(snapshot: ContextSnapshot): string {
  const activeGoal = snapshot.goalStack.activeGoal;
  
  if (!activeGoal) {
    return baseSystemPrompt;
  }
  
  return `
${baseSystemPrompt}

## Current Goal
${activeGoal.description}

Status: ${activeGoal.status}
Priority: ${activeGoal.priority}
Created: ${activeGoal.createdAt.toISOString()}

## Subtasks
${activeGoal.subtasks.map(st => 
  `- [${st.status === 'completed' ? 'x' : ' '}] ${st.description}`
).join('\n')}

## Recent Checkpoints
${activeGoal.checkpoints.slice(-3).map(cp => 
  `- ${cp.timestamp.toISOString()}: ${cp.description}`
).join('\n')}

## Key Decisions
${activeGoal.decisions.map(d => 
  `- ${d.description} (${d.locked ? 'LOCKED' : 'can be changed'})`
).join('\n')}

## Artifacts Created/Modified
${activeGoal.artifacts.map(a => 
  `- ${a.action} ${a.path}`
).join('\n')}

${activeGoal.blockers.length > 0 ? `
## Current Blockers
${activeGoal.blockers.filter(b => !b.resolvedAt).map(b => 
  `- ${b.description} (${b.type})`
).join('\n')}
` : ''}

## Completed Goals (This Session)
${snapshot.goalStack.completedGoals.slice(-5).map(g => 
  `- ✓ ${g.description} (completed ${g.completedAt?.toISOString()})`
).join('\n')}

## Recent User Messages
${snapshot.userMessages.map(m => 
  `- ${m.timestamp.toISOString()}: ${m.content}`
).join('\n')}
`;
}
```

## Workflow Examples

### Example 1: Single Goal with Checkpoints

```
User: "Fix the authentication bug in login.ts"

LLM: [Calls create_goal]
{
  description: "Fix authentication bug in login.ts",
  priority: "high",
  subtasks: ["Identify bug", "Write fix", "Test fix"]
}

--- LLM analyzes code ---

LLM: [Calls create_checkpoint]
{
  description: "Found bug: missing null check on line 42",
  decisionsLocked: ["Bug is in validateUser() function"]
}

--- LLM writes fix ---

LLM: [Calls create_checkpoint]
{
  description: "Added null check and error handling",
  filesModified: ["src/auth/login.ts"]
}

--- LLM tests fix ---

LLM: [Calls complete_goal]
{
  summary: "Fixed authentication bug by adding null check",
  artifacts: ["src/auth/login.ts (modified)", "tests/login.test.ts (added)"]
}
```

### Example 2: Goal Switching

```
User: "Fix the authentication bug"

LLM: [Creates Goal A: "Fix authentication bug"]

--- LLM starts working ---

User: "Actually, let's work on the database issue first"

LLM: [Calls switch_goal]
{
  action: "pause"  // Pauses Goal A
}

LLM: [Calls create_goal]
{
  description: "Fix database connection issue",
  priority: "high"
}

--- LLM fixes database issue ---

LLM: [Calls complete_goal]

LLM: "Database issue fixed. Should I resume the authentication bug fix?"

User: "Yes"

LLM: [Calls switch_goal]
{
  action: "resume",
  goalId: "goal-a-id"
}
```

### Example 3: Long Session (100+ Messages)

```
Hour 1: Goal 1 "Verify test suite"
- Checkpoint 1: "Verified batch 1-10"
- Checkpoint 2: "Verified batch 11-20"
- ...
- Checkpoint 10: "All tests verified"
- Complete Goal 1

Hour 2: Goal 2 "Fix bugs found in tests"
- Subtask 2.1: "Fix auth bug" → Completed
- Subtask 2.2: "Fix DB timeout" → Completed
- Subtask 2.3: "Fix API error" → Completed
- Complete Goal 2

Hour 3: Goal 3 "Document changes"
- Checkpoint 1: "Created CHANGELOG.md"
- Checkpoint 2: "Updated README.md"
- Complete Goal 3

After 100+ messages, LLM still knows:
- All 3 goals completed
- All checkpoints and decisions
- All artifacts created
- Current status: All work done
```

## Benefits

### 1. No Hallucination
- Structured data (facts, not summaries)
- LLM doesn't "remember" - it reads structured state
- Decisions are locked to prevent changes

### 2. Autonomous Operation
- LLM can create checkpoints
- LLM can mark goals complete
- LLM can switch goals
- LLM can track progress

### 3. Long Session Support
- Scales to 100+ messages
- Completed goals archived but retrievable
- Clear progress tracking
- No context loss

### 4. User Control
- User can see goal stack
- User can override LLM decisions
- User can switch goals manually
- User can review checkpoints

### 5. Better Compression
- Only compress assistant explanations
- Keep all structured data (goals, checkpoints, decisions)
- Keep recent user messages
- Archive completed goals

## Implementation Plan

### Phase 1: Core Data Structures ✅
- [x] Define Goal, Checkpoint, Decision interfaces
- [x] Define GoalStack interface
- [x] Define GoalManager interface

### Phase 2: Goal Manager Implementation
- [ ] Implement GoalManager class
- [ ] Add goal lifecycle methods
- [ ] Add checkpoint management
- [ ] Add decision tracking
- [ ] Add artifact tracking

### Phase 3: Snapshot Integration
- [ ] Update ContextSnapshot interface
- [ ] Update createSnapshot() to include goalStack
- [ ] Update restoreSnapshot() to restore goalStack
- [ ] Add migration for old snapshots

### Phase 4: LLM Tools
- [ ] Implement create_goal tool
- [ ] Implement create_checkpoint tool
- [ ] Implement complete_goal tool
- [ ] Implement switch_goal tool
- [ ] Implement record_decision tool

### Phase 5: System Prompt Integration
- [ ] Add goal context to system prompt
- [ ] Show active goal and progress
- [ ] Show recent checkpoints
- [ ] Show key decisions

### Phase 6: Testing
- [ ] Unit tests for GoalManager
- [ ] Integration tests with snapshots
- [ ] End-to-end tests with LLM tools
- [ ] Long session tests (100+ messages)

## Configuration

```typescript
interface GoalManagementConfig {
  enabled: boolean;              // Enable goal tracking
  maxCompletedGoals: number;     // Keep last N completed goals (default: 10)
  maxCheckpointsPerGoal: number; // Keep last N checkpoints (default: 20)
  autoCheckpoint: boolean;       // Auto-create checkpoints (default: false)
  autoCheckpointInterval: number; // Minutes between auto-checkpoints (default: 15)
}
```

## Token Budget Impact

### Without Goal Management
```
Context: 32K tokens
- System prompt: 1,000 tokens
- User messages (10): 2,000 tokens
- Compressed assistant: 3,000 tokens
- Recent messages: 26,000 tokens
Total: 32,000 tokens
```

### With Goal Management
```
Context: 32K tokens
- System prompt: 1,000 tokens
- Goal context: 500 tokens (active goal + checkpoints)
- User messages (10): 2,000 tokens
- Compressed assistant: 2,500 tokens
- Recent messages: 26,000 tokens
Total: 32,000 tokens

Goal context breakdown:
- Active goal: 100 tokens
- Subtasks (5): 100 tokens
- Checkpoints (last 3): 150 tokens
- Decisions (5): 100 tokens
- Artifacts (10): 50 tokens
```

**Impact:** ~500 tokens for goal context (1.5% of 32K)
**Benefit:** Clear structure, no hallucination, autonomous operation

## Next Steps

1. **Review this design** - Get feedback on approach
2. **Implement Phase 2** - GoalManager class
3. **Test with real scenarios** - Verify it works for long sessions
4. **Iterate based on usage** - Refine based on actual use

---

**Status:** Design Complete, Ready for Implementation  
**Estimated Time:** 8-10 hours for full implementation  
**Priority:** HIGH - Solves critical long-session context loss
