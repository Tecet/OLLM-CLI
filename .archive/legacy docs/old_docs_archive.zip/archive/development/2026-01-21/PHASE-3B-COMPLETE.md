# Phase 3B: Reasoning Trace Capture - COMPLETE ✅

**Date:** 2026-01-21  
**Status:** Complete  
**Build Status:** ✅ Passing

## Overview

Phase 3B implements automatic reasoning trace capture when reasoning models (DeepSeek-R1, QwQ, o1, etc.) produce `<think>` tags. These traces are stored in the ReasoningManager and persisted across context rollovers via snapshots.

## Implementation

### 1. Added Accessor Methods to ContextManagerContext

**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

**Changes:**
- Added `getGoalManager()` method to ContextManagerActions interface
- Added `getReasoningManager()` method to ContextManagerActions interface
- Implemented both methods to return the respective managers from the core ContextManager

```typescript
// Interface
export interface ContextManagerActions {
  // ... existing methods ...
  
  /** Get the goal manager instance */
  getGoalManager: () => import('@ollm/core').GoalManager | null;
  
  /** Get the reasoning manager instance */
  getReasoningManager: () => import('@ollm/core').ReasoningManagerImpl | null;
}

// Implementation
const actions = useMemo(() => ({
  // ... existing actions ...
  getGoalManager: () => managerRef.current?.getGoalManager() || null,
  getReasoningManager: () => managerRef.current?.getReasoningManager() || null,
}), [...]);
```

### 2. Integrated Reasoning Trace Capture in ChatContext

**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Location:** Line ~687 (where reasoning is marked complete)

**Changes:**
- Added reasoning trace capture when `<think>` content is complete
- Captures trace with full context (goal ID, message ID, token counts)
- Automatically links traces to active goals

```typescript
// Mark reasoning as complete and calculate duration
if (msg.reasoning) {
  updates.reasoning = {
    ...msg.reasoning,
    complete: true,
    duration: metrics.evalDuration > 0 ? metrics.evalDuration / 1e9 : 0,
  };
  // Auto-collapse reasoning when complete
  updates.expanded = false;
  
  // Capture reasoning trace in reasoning manager
  if (contextActions) {
    const reasoningManager = contextActions.getReasoningManager();
    const goalManager = contextActions.getGoalManager();
    
    if (reasoningManager && msg.reasoning.content) {
      const activeGoal = goalManager?.getActiveGoal();
      
      reasoningManager.addTrace(
        msg.id,
        msg.reasoning.content,
        currentModel,
        msg.reasoning.tokenCount,
        metrics.evalCount,
        {
          goalId: activeGoal?.id,
          userMessageId: lastUserMessageRef.current ? `user-${Date.now()}` : undefined
        }
      );
    }
  }
}
```

## What Works Now

1. ✅ **Automatic Trace Capture**: When a reasoning model produces `<think>` tags, the content is automatically captured
2. ✅ **Goal Linking**: Traces are automatically linked to the active goal (if one exists)
3. ✅ **Token Tracking**: Both thinking tokens and answer tokens are recorded
4. ✅ **Persistence**: Traces are stored in ReasoningManager and included in snapshots
5. ✅ **Context Rollover**: After rollover, LLM can use `read_reasoning` tool to review past thinking
6. ✅ **Structured Extraction**: ReasoningManager automatically extracts structured data (alternatives, rationale, insights)

## Data Flow

```
User sends message
  ↓
LLM generates response with <think> tags
  ↓
UI extracts <think> content for display ✅
  ↓
onThinking callback updates message.reasoning ✅
  ↓
Response completes with metrics
  ↓
ChatContext marks reasoning as complete ✅
  ↓
ReasoningManager.addTrace() called ✅
  ↓
Trace stored with:
  - Message ID
  - Thinking content
  - Model name
  - Token counts (thinking + answer)
  - Context (goal ID, user message ID)
  ↓
Structured data extracted automatically ✅
  ↓
Trace persisted in snapshots ✅
  ↓
After context rollover:
  LLM can call read_reasoning tool ✅
  ↓
  Reviews past thinking processes ✅
```

## Testing Checklist

### Manual Testing
- [ ] Test with DeepSeek-R1 model
- [ ] Test with QwQ model
- [ ] Verify traces are captured when `<think>` tags are present
- [ ] Verify traces are linked to active goals
- [ ] Verify traces persist across context rollovers
- [ ] Test `read_reasoning` tool after rollover
- [ ] Verify structured data extraction works

### Integration Testing
- [ ] Test with goal creation + reasoning traces
- [ ] Test snapshot creation includes reasoning storage
- [ ] Test snapshot restoration restores reasoning traces
- [ ] Test long conversation (100+ messages) with multiple traces

## Files Modified

1. ✅ `packages/cli/src/features/context/ContextManagerContext.tsx`
   - Added `getGoalManager()` method
   - Added `getReasoningManager()` method

2. ✅ `packages/cli/src/features/context/ChatContext.tsx`
   - Added reasoning trace capture on completion
   - Integrated with goal manager for context linking

## Build Status

✅ **Build Successful**
```
> ollm-cli@0.1.0 build
> node scripts/build.js

Building OLLM CLI...
✓ Build completed successfully
  Output: packages/cli/dist/cli.js
```

✅ **No TypeScript Errors**
✅ **No ESLint Errors**

## Next Steps

**Phase 3C: Marker Parsing** (for non-tool models)
- Location: `packages/core/src/core/chatClient.ts`
- Parse structured markers (NEW_GOAL:, CHECKPOINT:, etc.)
- Execute goal actions from markers
- Estimated: 1-2 hours

## Notes

- User already has reasoning model detection working
- User already extracts `<think>` tags for UI display with collapsible tab
- This implementation hooks into the existing infrastructure
- Traces are automatically captured without requiring any changes to the model or prompts
- The LLM can review its past reasoning using the `read_reasoning` tool after context rollover

## Estimated Remaining Work

- **Phase 3C:** 1-2 hours (marker parsing)
- **Phase 4:** 3-4 hours (testing)
- **Phase 5:** 2-3 hours (documentation)

**Total:** 6-9 hours remaining
