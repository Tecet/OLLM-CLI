# CRITICAL BUG: Context Overflow - LLM Runs Beyond Limit

**Date:** January 21, 2026  
**Severity:** 🔴 CRITICAL  
**Status:** 🔍 Identified, 🔧 Fixing

---

## Problem Description

The LLM runs beyond the context limit and crashes when memory runs out. The context manager is not preventing overflow.

**User Report:**
> "our context manager do not work, llm runed beyond context limit and crashed later when memory runed out."

---

## Root Cause Analysis

### Issue 1: UI Bypasses ChatClient ❌

**Location:** `packages/cli/src/features/context/ModelContext.tsx` (line 743-756)

**Problem:**
The UI calls `provider.chatStream()` directly instead of using `chatClient.chat()`. This bypasses:
- Context management
- Automatic compression
- Token counting
- Memory guards
- All safety checks

**Code:**
```typescript
// WRONG: Direct provider call
const stream = provider.chatStream({
  model: currentModel,
  messages: providerMessages,
  tools: tools && tools.length > 0 && modelSupportsTools(currentModel) ? tools : undefined,
  systemPrompt: systemPrompt,
  abortSignal: abortController.signal,
  timeout: requestTimeout,
  think: thinkingEnabled,
  options: {
    num_ctx: ollamaContextSize, // This is set correctly
    temperature: temperatureOverride ?? temperature,
  },
});
```

**Why This is Critical:**
- `num_ctx` is set correctly (85% cap)
- BUT the context manager never sees the messages
- No compression happens
- No memory guards trigger
- Messages accumulate indefinitely
- Eventually runs out of memory

### Issue 2: ChatClient Doesn't Pass Context Size ❌

**Location:** `packages/core/src/core/chatClient.ts` (line 337)

**Problem:**
Even if we used `chatClient.chat()`, it doesn't pass `contextSize` or `ollamaContextSize` to the Turn:

```typescript
// Create and execute turn
const turn = new Turn(provider, this.toolRegistry, messages, turnOptions);
```

`turnOptions` is just a copy of the original `options`, which doesn't include context size information.

### Issue 3: Turn Builds Options Without Context Size ⚠️

**Location:** `packages/core/src/core/turn.ts` (line 286-314)

**Problem:**
The `buildGenerationOptions()` method checks for `contextSize` and `ollamaContextSize`, but they're never set:

```typescript
private buildGenerationOptions(): GenerationOptions | undefined {
  // ...
  
  // Add num_ctx for Ollama (85% cap strategy)
  if (this.options.ollamaContextSize !== undefined) {
    opts.num_ctx = this.options.ollamaContextSize;
  } else if (this.options.contextSize !== undefined) {
    opts.num_ctx = Math.floor(this.options.contextSize * 0.85);
  }
  // If neither is set, num_ctx is NOT sent to Ollama!
  
  return Object.keys(opts).length > 0 ? opts : undefined;
}
```

**Result:** Ollama uses its default context size (often 2048 or 4096), which may be different from what the user selected.

---

## Impact

### Severity: CRITICAL 🔴

**Symptoms:**
1. LLM continues generating beyond context limit
2. Memory usage grows unbounded
3. System eventually runs out of RAM
4. Application crashes
5. User loses conversation

**Affected Users:**
- All users using the UI (most users)
- Any long conversations
- Especially users with limited RAM

**Data Loss:**
- Conversation lost on crash
- No snapshot created before crash
- No recovery possible

---

## Solution

### Fix 1: Make UI Use ChatClient ✅ RECOMMENDED

**Change:** Modify `ModelContext.tsx` to use `chatClient.chat()` instead of direct provider calls.

**Benefits:**
- ✅ Automatic context management
- ✅ Automatic compression
- ✅ Memory guards
- ✅ Token counting
- ✅ Snapshot creation
- ✅ All safety features

**Implementation:**
```typescript
// In ModelContext.tsx
// BEFORE: Direct provider call
const stream = provider.chatStream({ ... });

// AFTER: Use chatClient
const chatClient = getChatClient(); // Get from context
for await (const event of chatClient.chat(userMessage, {
  model: currentModel,
  provider: providerName,
  tools: tools,
  systemPrompt: systemPrompt,
  abortSignal: abortController.signal,
  contextSize: userContextSize,
  ollamaContextSize: ollamaContextSize,
  temperature: temperatureOverride ?? temperature,
  // ... other options
})) {
  // Handle events
}
```

**Effort:** 2-3 hours
**Risk:** Medium (requires testing all UI flows)

### Fix 2: Pass Context Size Through ChatClient ✅ REQUIRED

**Change:** Modify `chatClient.chat()` to accept and pass through context size options.

**Location:** `packages/core/src/core/chatClient.ts`

**Implementation:**
```typescript
// Add to ChatOptions interface
export interface ChatOptions {
  // ... existing options
  contextSize?: number;
  ollamaContextSize?: number;
}

// In chat() method, pass to Turn
const turnOptions: ChatOptions = {
  ...options,
  systemPrompt: systemPromptWithContext,
  contextSize: options.contextSize,
  ollamaContextSize: options.ollamaContextSize,
};

const turn = new Turn(provider, this.toolRegistry, messages, turnOptions);
```

**Effort:** 30 minutes
**Risk:** Low (simple pass-through)

### Fix 3: Add Context Size Validation ✅ SAFETY

**Change:** Add validation in `chatClient.chat()` to ensure context size is set.

**Implementation:**
```typescript
// In chat() method, before creating Turn
if (!options?.contextSize && !options?.ollamaContextSize) {
  // Get from context manager if available
  if (this.contextMgmtManager) {
    const usage = this.contextMgmtManager.getUsage();
    options = {
      ...options,
      contextSize: usage.maxTokens,
      ollamaContextSize: Math.floor(usage.maxTokens * 0.85),
    };
  } else {
    // Fallback to default
    console.warn('[ChatClient] No context size specified, using default 8192');
    options = {
      ...options,
      contextSize: 8192,
      ollamaContextSize: 6963, // 85% of 8192
    };
  }
}
```

**Effort:** 30 minutes
**Risk:** Low (safety net)

---

## Implementation Plan

### Phase 1: Immediate Fix (1 hour)

1. ✅ Add `contextSize` and `ollamaContextSize` to `ChatOptions` interface
2. ✅ Pass through in `chatClient.chat()`
3. ✅ Add validation/fallback
4. ✅ Test with direct chatClient calls

### Phase 2: UI Integration (2-3 hours)

1. ✅ Modify `ModelContext.tsx` to use `chatClient.chat()`
2. ✅ Pass context size options
3. ✅ Handle all event types
4. ✅ Test all UI flows (normal chat, tool calls, thinking, errors)
5. ✅ Test context compression triggers
6. ✅ Test memory guards

### Phase 3: Testing (1-2 hours)

1. ✅ Test with small context (4K)
2. ✅ Test with medium context (16K)
3. ✅ Test with large context (32K)
4. ✅ Test long conversations (trigger compression)
5. ✅ Test memory limits (trigger guards)
6. ✅ Test crash recovery

---

## Testing Checklist

### Unit Tests

- [ ] `ChatOptions` includes `contextSize` and `ollamaContextSize`
- [ ] `Turn.buildGenerationOptions()` uses context size
- [ ] `chatClient.chat()` passes context size to Turn
- [ ] Validation/fallback works when context size not provided

### Integration Tests

- [ ] UI sends messages through chatClient
- [ ] Context manager sees all messages
- [ ] Compression triggers at threshold
- [ ] Memory guards trigger when needed
- [ ] Snapshots created before compression
- [ ] `num_ctx` sent to Ollama correctly

### Manual Tests

- [ ] Start conversation with 4K context
- [ ] Continue until compression triggers
- [ ] Verify compression happens
- [ ] Verify context stays under limit
- [ ] Verify no memory overflow
- [ ] Verify no crashes

---

## Verification

### Success Criteria

1. ✅ `num_ctx` is always sent to Ollama
2. ✅ Context manager sees all messages
3. ✅ Compression triggers automatically
4. ✅ Memory guards prevent overflow
5. ✅ No crashes from memory exhaustion
6. ✅ Snapshots created before compression

### Monitoring

Add logging to verify:
```typescript
console.log('[ChatClient] Context size:', options.contextSize);
console.log('[ChatClient] Ollama context size:', options.ollamaContextSize);
console.log('[Turn] Sending num_ctx:', opts.num_ctx);
console.log('[ContextManager] Current usage:', usage.percentage);
```

---

## Related Issues

- Context manager not seeing messages
- Compression not triggering
- Memory guards not activating
- Snapshots not created
- 85% cap strategy not working

---

## Prevention

### Code Review Checklist

- [ ] All provider calls go through chatClient
- [ ] Context size always passed
- [ ] Validation/fallback in place
- [ ] Logging for debugging
- [ ] Tests cover edge cases

### Architecture Guidelines

1. **Never call provider directly from UI**
   - Always use chatClient
   - Let chatClient handle context management
   - Let chatClient handle safety checks

2. **Always pass context size**
   - Get from settings
   - Calculate 85% cap
   - Pass to chatClient
   - Validate before use

3. **Monitor context usage**
   - Log current usage
   - Log compression triggers
   - Log memory guard actions
   - Alert on anomalies

---

## Status

- [x] Bug identified
- [x] Root cause analyzed
- [x] Solution designed
- [ ] Fix 1 implemented (ChatOptions)
- [ ] Fix 2 implemented (UI integration)
- [ ] Fix 3 implemented (validation)
- [ ] Tests passing
- [ ] Manual testing complete
- [ ] Deployed

---

**Priority:** 🔴 CRITICAL - Fix immediately  
**Estimated Time:** 4-6 hours total  
**Risk:** Medium (requires careful testing)  
**Impact:** High (prevents crashes, data loss)
