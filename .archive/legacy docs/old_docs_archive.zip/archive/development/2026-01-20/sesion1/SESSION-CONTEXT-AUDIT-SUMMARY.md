# Session/Context Audit - Quick Summary

**Date:** January 20, 2026  
**Full Report:** [SESSION-CONTEXT-AUDIT.md](./SESSION-CONTEXT-AUDIT.md)

---

## 🔍 What We Found

### ✅ Good News
- Two separate systems already exist (chat history + context snapshots)
- Solid architecture with atomic writes and durability
- Comprehensive features (auto-save, indexing, cleanup)

### ❌ Issues Identified

1. **Same Base Directory** - Both systems use `~/.ollm/session-data`
   - Confusing for users
   - Hard to distinguish between chat history and context state

2. **Windows Path Resolution** - Files may be saved in wrong location
   - User reports: "inside app instead in user local machine"
   - Expected: `C:\Users\rad3k\.ollm\sessions`
   - Need to verify and fix

3. **No Recovery/Rollback UI** - Functionality exists but not exposed
   - No CLI commands to list/restore snapshots
   - No UI panel for session management
   - No documentation on recovery procedures

4. **Unclear Documentation** - Two-system architecture not explained
   - Users confused about what's saved where
   - No clear explanation of use cases

---

## 🎯 Proposed Solution

### Fix 1: Separate Directories

**Before:**
```
~/.ollm/session-data/
  ├── {sessionId}.json              # Chat history
  └── {sessionId}/snapshots/        # Context snapshots
```

**After:**
```
~/.ollm/
  ├── sessions/                     # Chat history
  │   ├── {sessionId-1}.json
  │   └── {sessionId-2}.json
  └── context-snapshots/            # Context state
      └── {sessionId}/
          └── snapshots/
              ├── snapshot-{id}.json
              └── snapshots-index.json
```

### Fix 2: Windows Path Validation

- Add path validation and logging
- Add startup diagnostic showing storage locations
- Add CLI command: `ollm config paths`
- Test on Windows to verify resolution

### Fix 3: Recovery/Rollback Commands

**New CLI Commands:**
```bash
# Session management
ollm session list                    # List all sessions
ollm session show <id>               # Show session details
ollm session restore <id>            # Restore session

# Snapshot management
ollm snapshot list <session-id>      # List snapshots
ollm snapshot show <snapshot-id>     # Show snapshot details
ollm snapshot restore <snapshot-id>  # Restore from snapshot
ollm snapshot rollback <session-id>  # Rollback to last snapshot
```

**New UI Panel:**
- Session history view
- Snapshot timeline
- Restore/rollback buttons
- Preview snapshot content

### Fix 4: Documentation

**Create:**
- User guide for session recovery
- Architecture documentation explaining two systems
- Recovery procedures and examples
- Migration guide for existing users

---

## 📋 Implementation Plan

### Phase 1: Critical Fixes (Immediate)
1. ✅ Separate directories
2. ✅ Windows path validation
3. ✅ Add path logging and diagnostics

**Files to Modify:**
- `packages/core/src/services/chatRecordingService.ts` (line 37)
- `packages/core/src/context/snapshotStorage.ts` (line 72)
- `packages/core/src/services/config.ts` (line 140)

### Phase 2: User-Facing Features (Next)
1. ✅ CLI commands for session management
2. ✅ CLI commands for snapshot management
3. ✅ Basic recovery documentation

**Files to Create:**
- `packages/cli/src/commands/session.ts`
- `packages/cli/src/commands/snapshot.ts`
- `docs/Context/management/session-recovery.md`

### Phase 3: Enhanced UI (Future)
1. ⏳ Session history panel
2. ⏳ Snapshot timeline view
3. ⏳ Interactive restore/rollback UI
4. ⏳ Comprehensive user guide

**Files to Create:**
- `packages/cli/src/ui/components/SessionPanel.tsx`
- `packages/cli/src/ui/components/SnapshotTimeline.tsx`

---

## 🔧 Two-System Architecture

### System 1: Chat History (Full Conversation)

**Purpose:** Complete record of all conversations

**Storage:** `~/.ollm/sessions/{sessionId}.json`

**Use Cases:**
- Review past conversations
- Audit and debugging
- Export conversation history

**What It Saves:**
- All messages (user, assistant, tool)
- Tool calls and results
- Token counts
- Compression history
- Mode transitions

**Retention:** Last 100 sessions

---

### System 2: Context Snapshots (Rollover State)

**Purpose:** Save context state for recovery and rollback

**Storage:** `~/.ollm/context-snapshots/{sessionId}/snapshots/`

**Use Cases:**
- Recover from LLM malfunction
- Rollback for development
- Continue from specific point

**What It Saves:**
- Context snapshot at specific time
- Messages at snapshot time
- Token counts and compression ratios
- Model and context size metadata
- Summary of conversation

**Retention:** Last 5 snapshots per session

---

## 🚀 Quick Start (After Implementation)

### Recover from Malfunction

```bash
# 1. List available snapshots
ollm snapshot list <session-id>

# 2. Choose snapshot before malfunction
ollm snapshot show <snapshot-id>

# 3. Restore from snapshot
ollm snapshot restore <snapshot-id>

# 4. Continue conversation
```

### Rollback for Development

```bash
# 1. Create snapshot before risky change
ollm snapshot create

# 2. Make changes and test

# 3. If needed, rollback
ollm snapshot rollback <session-id>

# 4. Try different approach
```

---

## 📊 Success Criteria

### Must Have
- ✅ Files saved to correct user directory on Windows
- ✅ Separate directories for sessions and snapshots
- ✅ Path validation and logging
- ✅ Basic CLI commands for recovery

### Should Have
- ✅ Complete CLI command set
- ✅ Recovery documentation
- ✅ Migration for existing users

### Nice to Have
- ⏳ UI panel for session management
- ⏳ Interactive recovery workflow
- ⏳ Snapshot preview

---

## 📝 Next Steps

1. **Verify Windows Path Issue**
   - Test on Windows machine
   - Add logging to show actual paths
   - Identify root cause

2. **Implement Directory Separation**
   - Update chatRecordingService.ts
   - Update snapshotStorage.ts
   - Update config.ts
   - Add migration script

3. **Add Path Validation**
   - Add validation functions
   - Add startup diagnostics
   - Add CLI command

4. **Create CLI Commands**
   - Session commands
   - Snapshot commands
   - Add to CLI router

5. **Document Everything**
   - User guide
   - Architecture docs
   - Examples and tutorials

---

**Estimated Effort:** 2-3 days  
**Risk Level:** Low (isolated changes)  
**Priority:** High (user-reported issue)

**Full Details:** See [SESSION-CONTEXT-AUDIT.md](./SESSION-CONTEXT-AUDIT.md)
