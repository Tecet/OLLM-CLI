# System Prompt Token Budget Revision

**Date:** January 20, 2026  
**Reason:** Include proper guardrails, examples, and behavioral guidance

---

## Changes Made

### Token Allocations

**Before (Too Minimal):**
```
Tier 1: 50 tokens   - Just role definition
Tier 2: 150 tokens  - Basic guidelines
Tier 3: 400 tokens  - Some detail
Tier 4: 800 tokens  - More detail
```

**After (Realistic):**
```
Tier 1: ~200 tokens  - Behavior + guardrails + examples
Tier 2: ~500 tokens  - Detailed guidance + multiple examples
Tier 3: ~1000 tokens - Comprehensive + do/don't examples ⭐
Tier 4: ~1500 tokens - Expert-level + extensive examples
```

### What's Included Now

**All Tiers Include:**
1. ✅ **Core Behavior** - How to approach tasks
2. ✅ **Guardrails** - What NOT to do (critical!)
3. ✅ **Examples** - Concrete do/don't demonstrations
4. ✅ **Quality Standards** - Clear expectations
5. ✅ **Reasoning** - Why these guidelines matter

**Tier-Specific Depth:**

**Tier 1 (~200 tokens):**
- Essential behavior
- Basic guardrails (5-7 rules)
- 1-2 simple examples
- Concise quality standards

**Tier 2 (~500 tokens):**
- Detailed responsibilities
- Comprehensive guardrails (10+ rules)
- 3-5 concrete examples with code
- Behavioral guidelines
- Quality standards with reasoning

**Tier 3 (~1000 tokens) ⭐:**
- Full methodology
- Complete guardrails with explanations
- 5-8 detailed examples with code
- Decision-making frameworks
- Trade-off analysis
- Best practices with rationale
- Common pitfalls to avoid

**Tier 4 (~1500 tokens):**
- Expert-level sophistication
- Extensive examples (10+)
- Multiple scenario handling
- Advanced patterns and techniques
- Mentoring approach
- Industry best practices
- Performance and security considerations

---

## Why This Is Better

### 1. Proper Guardrails

**Before (50 tokens):**
```
You are a coding assistant. Be concise.
```
❌ No guidance on what NOT to do

**After (200 tokens):**
```
You are a coding assistant focused on practical solutions.

Core Behavior:
- Write clean, working code
- Use TypeScript with types
- Add brief comments for complex logic
- Handle errors appropriately

Guardrails:
- Don't over-engineer simple solutions
- Don't skip error handling
- Don't ignore edge cases

Example:
✓ DO: Write simple, clear functions with error handling
✗ DON'T: Create complex abstractions for simple tasks
```
✅ Clear guidance on what to avoid

### 2. Concrete Examples

**Before (150 tokens):**
```
You are an expert coding assistant.
- Write clean, maintainable code
- Follow best practices
- Explain your decisions briefly
```
❌ Vague, no examples

**After (500 tokens):**
```
[... detailed guidance ...]

Examples - Do This, Not That:

Error Handling:
✓ DO:
  try {
    const result = await fetchData();
    return { success: true, data: result };
  } catch (error) {
    logger.error('Failed to fetch data', { error });
    return { success: false, error: 'Data fetch failed' };
  }

✗ DON'T:
  const result = await fetchData(); // No error handling
  return result;

Type Safety:
✓ DO:
  interface User {
    id: string;
    email: string;
    role: 'admin' | 'user';
  }

✗ DON'T:
  function getUser(id: any): Promise<any> { ... }
```
✅ Shows exactly what good code looks like

### 3. Behavioral Guidance

**Before:** No behavioral guidance

**After:**
```
Behavioral Guidelines:
- Explain your reasoning and approach
- Point out potential issues or risks
- Suggest improvements to existing code
- Ask clarifying questions when requirements are ambiguous
- Acknowledge trade-offs and limitations honestly
- Provide context for your decisions
```
✅ Sets tone and communication style

### 4. Decision Frameworks

**Before:** No decision guidance

**After (Tier 3):**
```
When Making Decisions:
1. Understand the full context and requirements
2. Consider 2-3 different approaches
3. Evaluate trade-offs (complexity, performance, maintainability)
4. Choose the approach that best fits the constraints
5. Document why you chose this approach
6. Implement with proper error handling and tests
7. Consider how this fits into the larger system
```
✅ Helps LLM make better choices

---

## Token Efficiency

### Still Very Efficient

**Tier 1 (8K context):**
- 200 tokens = 2.5% of context
- 7,800 tokens for work = 97.5%
- ✅ Minimal overhead, maximum work space

**Tier 3 (32K context) ⭐:**
- 1,000 tokens = 3.1% of context
- 31,000 tokens for work = 96.9%
- ✅ Excellent balance of guidance and work space

**Tier 4 (128K context):**
- 1,500 tokens = 1.2% of context
- 126,500 tokens for work = 98.8%
- ✅ Negligible overhead, comprehensive guidance

### Quality vs Overhead Trade-off

```
Tier 1: 2.5% overhead → Basic quality
Tier 2: 3.1% overhead → Good quality
Tier 3: 3.1% overhead → Excellent quality ⭐
Tier 4: 1.2% overhead → Professional quality
```

**The 3% overhead is worth it for:**
- ✅ Proper error handling
- ✅ Type safety
- ✅ Clear code structure
- ✅ Avoiding common mistakes
- ✅ Better decision-making
- ✅ Consistent quality

---

## Expected Quality Improvements

### Tier 1 (200 tokens)

**Output Quality:**
- ✅ Basic error handling
- ✅ Simple type annotations
- ✅ Avoids obvious mistakes
- ⚠️ May lack sophistication
- ⚠️ May miss edge cases

**Good For:**
- Quick scripts
- Simple utilities
- Prototypes
- Learning exercises

### Tier 2 (500 tokens)

**Output Quality:**
- ✅ Proper error handling
- ✅ Good type safety
- ✅ Clear code structure
- ✅ Avoids common pitfalls
- ⚠️ May lack advanced patterns

**Good For:**
- Production code
- Small to medium features
- Bug fixes
- Refactoring

### Tier 3 (1000 tokens) ⭐

**Output Quality:**
- ✅ Comprehensive error handling
- ✅ Strict type safety
- ✅ Well-structured code
- ✅ Considers edge cases
- ✅ Includes tests
- ✅ Good documentation
- ✅ Thoughtful architecture

**Good For:**
- Production systems
- Complex features
- Critical code paths
- Team projects
- **90% of professional work**

### Tier 4 (1500 tokens)

**Output Quality:**
- ✅ Enterprise-grade code
- ✅ Advanced patterns
- ✅ Performance optimized
- ✅ Security conscious
- ✅ Scalable architecture
- ✅ Comprehensive tests
- ✅ Excellent documentation
- ✅ Mentoring quality

**Good For:**
- Critical systems
- High-scale applications
- Complex architectures
- Technical leadership
- Code reviews

---

## Implementation

### Prompt Storage

```
packages/core/src/context/prompts/
├── tier1/
│   ├── developer.txt      (~200 tokens)
│   ├── planning.txt       (~200 tokens)
│   ├── assistant.txt      (~200 tokens)
│   └── debugger.txt       (~200 tokens)
├── tier2/
│   ├── developer.txt      (~500 tokens)
│   ├── planning.txt       (~500 tokens)
│   ├── assistant.txt      (~500 tokens)
│   └── debugger.txt       (~500 tokens)
├── tier3/
│   ├── developer.txt      (~1000 tokens)
│   ├── planning.txt       (~1000 tokens)
│   ├── assistant.txt      (~1000 tokens)
│   └── debugger.txt       (~1000 tokens)
└── tier4/
    ├── developer.txt      (~1500 tokens)
    ├── planning.txt       (~1500 tokens)
    ├── assistant.txt      (~1500 tokens)
    └── debugger.txt       (~1500 tokens)
```

### Token Verification

```typescript
// Verify token counts during build
const prompts = loadAllPrompts();

for (const [tier, mode, prompt] of prompts) {
  const tokens = countTokens(prompt);
  const expected = EXPECTED_TOKENS[tier];
  const tolerance = expected * 0.1; // 10% tolerance
  
  if (Math.abs(tokens - expected) > tolerance) {
    throw new Error(
      `Prompt ${tier}/${mode} has ${tokens} tokens, expected ~${expected}`
    );
  }
}
```

---

## Migration

### Backward Compatibility

**Existing behavior:**
- Static system prompt
- Same for all context sizes
- No automatic updates

**New behavior:**
- Adaptive system prompts
- Scales with context size
- Updates on tier/mode change

**Migration:**
- ✅ No breaking changes
- ✅ Existing code works
- ✅ New behavior is automatic
- ✅ Can be disabled if needed

### Configuration

```typescript
// Enable adaptive prompts (default)
const manager = new ConversationContextManager(
  sessionId,
  modelInfo,
  {
    adaptiveSystemPrompts: true,
    promptTokenBudgets: {
      tier1: 200,
      tier2: 500,
      tier3: 1000,
      tier4: 1500
    }
  }
);

// Disable adaptive prompts (use static)
const manager = new ConversationContextManager(
  sessionId,
  modelInfo,
  {
    adaptiveSystemPrompts: false,
    systemPrompt: 'My custom static prompt'
  }
);
```

---

## Success Metrics

### Token Efficiency
- ✅ Tier 1: < 3% overhead
- ✅ Tier 2: < 4% overhead
- ✅ Tier 3: < 4% overhead
- ✅ Tier 4: < 2% overhead

### Quality Improvement
- ✅ Tier 2+ includes error handling
- ✅ Tier 2+ includes type safety
- ✅ Tier 3+ includes tests
- ✅ Tier 3+ includes documentation
- ✅ Tier 4 includes advanced patterns

### User Experience
- ✅ Better code quality
- ✅ Fewer bugs and issues
- ✅ More consistent output
- ✅ Clearer reasoning
- ✅ Better decision-making

---

## Conclusion

**The revised token budgets provide:**
1. ✅ Proper guardrails to prevent mistakes
2. ✅ Concrete examples to demonstrate quality
3. ✅ Behavioral guidance for consistency
4. ✅ Decision frameworks for better choices
5. ✅ Still efficient token usage (< 4% overhead)

**The 3-4x increase in tokens is justified by:**
- Significantly better output quality
- Fewer errors and bugs
- More consistent results
- Better decision-making
- Clearer reasoning

**This is a worthwhile trade-off that will improve the overall system quality while maintaining efficiency.**

---

**Status:** ✅ Revised and Approved  
**Implementation:** Task 3 (3 hours)  
**Impact:** Significant quality improvement
