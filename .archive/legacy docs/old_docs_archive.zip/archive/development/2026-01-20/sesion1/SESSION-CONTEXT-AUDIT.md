# Session and Context Saving System - Audit Report

**Date:** January 20, 2026  
**Status:** Issues Identified - Fixes Required  
**Priority:** High

---

## Executive Summary

This audit examines the session and context saving system in OLLM CLI. The user identified critical issues with file storage locations and the need for two separate systems: one for chat history and one for context rollover/recovery.

### Key Findings

1. ✅ **Good Architecture**: Two separate systems already exist
   - `chatRecordingService.ts` - Chat history recording
   - `snapshotStorage.ts` + `snapshotManager.ts` - Context snapshots

2. ❌ **Path Resolution Issue**: Both systems use the same base directory
   - Default: `~/.ollm/session-data`
   - Need separate directories for clarity

3. ❌ **Windows Path Resolution**: May not be working correctly
   - User reports files saved "inside app instead of user local machine"
   - Need to verify `~/.ollm/` resolves to `C:\Users\rad3k\.ollm\` on Windows

4. ❌ **Missing Recovery/Rollback UI**: No user-facing commands or UI
   - Restore functionality exists but not exposed
   - No rollback command for development
   - No UI for viewing/managing snapshots

---

## Current Implementation Analysis

### System 1: Chat History Recording

**File:** `packages/core/src/services/chatRecordingService.ts`

**Purpose:** Preserve complete conversation history

**Storage Location:**
```typescript
// Line 37
dataDir: join(homedir(), '.ollm', 'session-data')
```

**What It Saves:**
- Complete session metadata (model, provider, timestamps)
- All messages in conversation
- All tool calls and results
- Token counts and compression history
- Mode transition history

**File Format:**
```json
{
  "sessionId": "uuid",
  "startTime": "ISO timestamp",
  "lastActivity": "ISO timestamp",
  "model": "model-name",
  "provider": "provider-name",
  "messages": [...],
  "toolCalls": [...],
  "metadata": {
    "tokenCount": 0,
    "compressionCount": 0,
    "modeHistory": [...]
  }
}
```

**Storage Pattern:**
```
~/.ollm/session-data/
  ├── {sessionId-1}.json
  ├── {sessionId-2}.json
  └── {sessionId-3}.json
```

**Features:**
- ✅ Atomic writes with durability (fsync)
- ✅ Session caching for performance
- ✅ Auto-save on every message/tool call
- ✅ Session listing and deletion
- ✅ Automatic cleanup (keeps last 100 sessions)

---

### System 2: Context Snapshots

**Files:** 
- `packages/core/src/context/snapshotStorage.ts`
- `packages/core/src/context/snapshotManager.ts`

**Purpose:** Save context state for rollover and recovery

**Storage Location:**
```typescript
// snapshotStorage.ts line 72
this.baseDir = baseDir || path.join(os.homedir(), '.ollm', 'session-data');
```

**What It Saves:**
- Context snapshot at specific point in time
- All messages at snapshot time
- Token counts and compression ratios
- Model and context size metadata
- Summary of conversation content

**File Format:**
```json
{
  "version": "1.0",
  "id": "snapshot-uuid",
  "sessionId": "session-uuid",
  "timestamp": "ISO timestamp",
  "tokenCount": 8192,
  "summary": "Brief summary...",
  "metadata": {
    "model": "model-name",
    "contextSize": 8192,
    "compressionRatio": 0.75
  },
  "messages": [...]
}
```

**Storage Pattern:**
```
~/.ollm/session-data/
  └── {sessionId}/
      └── snapshots/
          ├── snapshot-{id-1}.json
          ├── snapshot-{id-2}.json
          ├── snapshot-{id-3}.json
          └── snapshots-index.json
```

**Features:**
- ✅ Atomic writes with durability
- ✅ Snapshot indexing for fast lookup
- ✅ Automatic corruption detection and recovery
- ✅ Rolling cleanup (keeps last 5 snapshots)
- ✅ Threshold-based auto-creation (at 80% capacity)
- ✅ Snapshot verification and integrity checks

---

## Issues Identified

### Issue 1: Same Base Directory (Confusion)

**Problem:** Both systems use `~/.ollm/session-data` as base directory

**Impact:**
- Confusing for users and developers
- Hard to distinguish between chat history and context state
- Mixing concerns in same directory

**Recommendation:**
```
~/.ollm/
  ├── sessions/          # Chat history (chatRecordingService)
  │   ├── {sessionId-1}.json
  │   └── {sessionId-2}.json
  └── context-snapshots/ # Context state (snapshotStorage)
      └── {sessionId}/
          └── snapshots/
              ├── snapshot-{id}.json
              └── snapshots-index.json
```

---

### Issue 2: Windows Path Resolution

**Problem:** User reports files saved "inside app instead in user local machine"

**Expected:** `C:\Users\rad3k\.ollm\sessions`  
**Actual:** Unknown (need to verify)

**Root Cause Analysis:**

1. **Path Resolution Code:**
```typescript
// chatRecordingService.ts line 37
dataDir: join(homedir(), '.ollm', 'session-data')

// snapshotStorage.ts line 72
this.baseDir = baseDir || path.join(os.homedir(), '.ollm', 'session-data');
```

2. **Potential Issues:**
   - `os.homedir()` should return `C:\Users\rad3k` on Windows
   - `path.join()` should handle Windows paths correctly
   - BUT: May be issues with:
     - Relative vs absolute paths
     - Path normalization
     - Directory creation permissions
     - Working directory confusion

3. **Testing Needed:**
   - Add logging to show actual resolved paths
   - Verify directory creation succeeds
   - Check file write locations
   - Test on Windows specifically

**Recommendation:**
- Add path validation and logging
- Add explicit Windows path handling
- Add startup diagnostic to show storage locations
- Add CLI command to show storage paths

---

### Issue 3: No Recovery/Rollback UI

**Problem:** Restore functionality exists but not exposed to users

**What Exists:**
- ✅ `snapshotManager.restoreSnapshot(id)` - Restore from snapshot
- ✅ `snapshotManager.listSnapshots(sessionId)` - List snapshots
- ✅ `chatRecordingService.getSession(id)` - Load session

**What's Missing:**
- ❌ CLI command to list snapshots
- ❌ CLI command to restore snapshot
- ❌ CLI command to rollback to checkpoint
- ❌ UI panel to view snapshots
- ❌ UI to restore/rollback
- ❌ Documentation on recovery procedures

**User Requirements:**
1. **Recovery:** If LLM malfunctions, restore session from snapshot
2. **Rollback:** For development, rollback to earlier state
3. **Visibility:** See what snapshots exist and when they were created

**Recommendation:**
Add CLI commands:
```bash
ollm session list                    # List all sessions
ollm session show <id>               # Show session details
ollm session restore <id>            # Restore session

ollm snapshot list <session-id>      # List snapshots for session
ollm snapshot show <snapshot-id>     # Show snapshot details
ollm snapshot restore <snapshot-id>  # Restore from snapshot
ollm snapshot rollback <session-id>  # Rollback to last snapshot
```

Add UI panel:
- Session history view
- Snapshot timeline
- Restore/rollback buttons
- Preview snapshot content

---

### Issue 4: Unclear Separation of Concerns

**Problem:** Documentation doesn't clearly explain the two-system architecture

**Current State:**
- Code has two systems but not clearly documented
- User confused about what's being saved where
- No clear explanation of use cases

**Recommendation:**
Document the two-system architecture:

**System 1: Chat History (Full Conversation)**
- **Purpose:** Complete record of conversation
- **Use Case:** Review past conversations, audit, debugging
- **Storage:** `~/.ollm/sessions/{sessionId}.json`
- **Retention:** Last 100 sessions
- **Format:** Complete JSON with all messages and metadata

**System 2: Context Snapshots (Rollover State)**
- **Purpose:** Save context state for recovery and rollback
- **Use Case:** Recover from malfunction, rollback for development
- **Storage:** `~/.ollm/context-snapshots/{sessionId}/snapshots/`
- **Retention:** Last 5 snapshots per session
- **Format:** Context snapshot with messages and metadata

---

## Proposed Fixes

### Fix 1: Separate Directories

**Changes Required:**

1. **Update `chatRecordingService.ts` (line 37):**
```typescript
// OLD
dataDir: join(homedir(), '.ollm', 'session-data')

// NEW
dataDir: join(homedir(), '.ollm', 'sessions')
```

2. **Update `snapshotStorage.ts` (line 72):**
```typescript
// OLD
this.baseDir = baseDir || path.join(os.homedir(), '.ollm', 'session-data');

// NEW
this.baseDir = baseDir || path.join(os.homedir(), '.ollm', 'context-snapshots');
```

3. **Update `config.ts` (line 140):**
```typescript
// OLD
session: {
  dataDir: '~/.ollm/session-data',
  maxSessions: 100,
  autoSave: true,
}

// NEW
session: {
  dataDir: '~/.ollm/sessions',
  maxSessions: 100,
  autoSave: true,
},
contextManagement: {
  // ... existing config ...
  snapshots: {
    enabled: true,
    maxCount: 5,
    autoCreate: true,
    autoThreshold: 0.8,
    dataDir: '~/.ollm/context-snapshots', // ADD THIS
  },
}
```

**Migration Strategy:**
- Add migration script to move existing files
- Support both old and new locations temporarily
- Log warning if old location detected
- Auto-migrate on first run

---

### Fix 2: Windows Path Resolution

**Changes Required:**

1. **Add Path Validation:**
```typescript
// Add to both services
private validatePath(dirPath: string): void {
  const resolved = path.resolve(dirPath);
  console.log(`[Storage] Resolved path: ${resolved}`);
  
  // Check if path is absolute
  if (!path.isAbsolute(resolved)) {
    throw new Error(`Path must be absolute: ${resolved}`);
  }
  
  // Check if path is writable
  try {
    fs.accessSync(path.dirname(resolved), fs.constants.W_OK);
  } catch (error) {
    throw new Error(`Path not writable: ${resolved}`);
  }
}
```

2. **Add Startup Diagnostic:**
```typescript
// Add to CLI startup
console.log('Storage Locations:');
console.log(`  Sessions: ${chatRecordingService.getDataDir()}`);
console.log(`  Snapshots: ${snapshotStorage.getBasePath()}`);
```

3. **Add CLI Command:**
```bash
ollm config paths  # Show all storage paths
```

---

### Fix 3: Recovery/Rollback Commands

**Changes Required:**

1. **Add CLI Commands:**

Create `packages/cli/src/commands/session.ts`:
```typescript
export async function sessionList() {
  const sessions = await chatRecordingService.listSessions();
  // Display sessions in table format
}

export async function sessionShow(sessionId: string) {
  const session = await chatRecordingService.getSession(sessionId);
  // Display session details
}

export async function sessionRestore(sessionId: string) {
  // Load session and restore context
}
```

Create `packages/cli/src/commands/snapshot.ts`:
```typescript
export async function snapshotList(sessionId: string) {
  const snapshots = await snapshotManager.listSnapshots(sessionId);
  // Display snapshots in table format
}

export async function snapshotShow(snapshotId: string) {
  const snapshot = await snapshotStorage.load(snapshotId);
  // Display snapshot details
}

export async function snapshotRestore(snapshotId: string) {
  const context = await snapshotManager.restoreSnapshot(snapshotId);
  // Restore context and continue conversation
}

export async function snapshotRollback(sessionId: string) {
  const snapshots = await snapshotManager.listSnapshots(sessionId);
  if (snapshots.length === 0) {
    throw new Error('No snapshots available');
  }
  // Restore from most recent snapshot
  const latest = snapshots[0];
  await snapshotRestore(latest.id);
}
```

2. **Add UI Panel:**

Create `packages/cli/src/ui/components/SessionPanel.tsx`:
```typescript
export function SessionPanel() {
  // Display session history
  // Show snapshots timeline
  // Restore/rollback buttons
}
```

---

### Fix 4: Documentation

**Changes Required:**

1. **Create User Guide:**

Create `docs/Context/management/session-recovery.md`:
```markdown
# Session Recovery and Rollback

## Two-System Architecture

### Chat History (Full Conversation)
- Complete record of all conversations
- Location: `~/.ollm/sessions/`
- Use for: Review, audit, debugging

### Context Snapshots (Rollover State)
- Save context state at key points
- Location: `~/.ollm/context-snapshots/`
- Use for: Recovery, rollback, development

## Recovery Procedures

### Recover from Malfunction
1. List available snapshots
2. Choose snapshot before malfunction
3. Restore from snapshot
4. Continue conversation

### Rollback for Development
1. Create snapshot before risky change
2. Make changes
3. If needed, rollback to snapshot
4. Try different approach

## CLI Commands
[Document all commands]
```

2. **Update Architecture Docs:**

Update `.dev/docs/Context/Context-Architecture.md`:
- Add section on session/snapshot architecture
- Explain two-system design
- Document storage locations
- Explain recovery procedures

---

## Testing Plan

### Test 1: Path Resolution on Windows

**Steps:**
1. Install on Windows machine
2. Run CLI and create session
3. Check actual file locations
4. Verify paths match expected locations
5. Test with different user accounts

**Expected:**
- Files in `C:\Users\{username}\.ollm\sessions\`
- Snapshots in `C:\Users\{username}\.ollm\context-snapshots\`

---

### Test 2: Recovery Workflow

**Steps:**
1. Start conversation
2. Create manual snapshot
3. Continue conversation
4. Simulate malfunction (kill process)
5. Restart and restore from snapshot
6. Verify context restored correctly

**Expected:**
- Snapshot created successfully
- Restore loads correct context
- Conversation continues from snapshot point

---

### Test 3: Rollback Workflow

**Steps:**
1. Start development session
2. Create snapshot before change
3. Make code changes
4. Test changes
5. Rollback to snapshot
6. Verify state restored

**Expected:**
- Snapshot captures state before change
- Rollback restores exact state
- Can continue from rollback point

---

## Implementation Priority

### Phase 1: Critical Fixes (Immediate)
1. ✅ Separate directories (Fix 1)
2. ✅ Windows path validation (Fix 2)
3. ✅ Add path logging and diagnostics

### Phase 2: User-Facing Features (Next)
1. ✅ CLI commands for session management
2. ✅ CLI commands for snapshot management
3. ✅ Basic recovery documentation

### Phase 3: Enhanced UI (Future)
1. ⏳ Session history panel
2. ⏳ Snapshot timeline view
3. ⏳ Interactive restore/rollback UI
4. ⏳ Comprehensive user guide

---

## Migration Plan

### For Existing Users

**Step 1: Detect Old Location**
```typescript
const oldLocation = join(homedir(), '.ollm', 'session-data');
const newSessionsLocation = join(homedir(), '.ollm', 'sessions');
const newSnapshotsLocation = join(homedir(), '.ollm', 'context-snapshots');

if (fs.existsSync(oldLocation)) {
  console.log('Migrating storage to new locations...');
  // Migrate files
}
```

**Step 2: Migrate Files**
```typescript
// Move session files to new location
// Move snapshot directories to new location
// Update any references
```

**Step 3: Cleanup**
```typescript
// Remove old directory after successful migration
// Log migration success
```

---

## Success Criteria

### Must Have
- ✅ Files saved to correct user directory on Windows
- ✅ Separate directories for sessions and snapshots
- ✅ Path validation and logging
- ✅ Basic CLI commands for recovery

### Should Have
- ✅ Complete CLI command set
- ✅ Recovery documentation
- ✅ Migration for existing users

### Nice to Have
- ⏳ UI panel for session management
- ⏳ Interactive recovery workflow
- ⏳ Snapshot preview

---

## Next Steps

1. **Verify Windows Path Issue**
   - Test on Windows machine
   - Add logging to show actual paths
   - Identify root cause

2. **Implement Fix 1 (Separate Directories)**
   - Update chatRecordingService.ts
   - Update snapshotStorage.ts
   - Update config.ts
   - Add migration script

3. **Implement Fix 2 (Path Validation)**
   - Add path validation functions
   - Add startup diagnostics
   - Add CLI command to show paths

4. **Implement Fix 3 (CLI Commands)**
   - Create session commands
   - Create snapshot commands
   - Add to CLI router

5. **Document Everything**
   - Create user guide
   - Update architecture docs
   - Add examples and tutorials

---

## Conclusion

The session and context saving system has a solid foundation with two separate systems already in place. The main issues are:

1. **Path confusion** - Same base directory for both systems
2. **Windows paths** - Need to verify and fix path resolution
3. **Missing UI** - Recovery functionality exists but not exposed
4. **Documentation** - Two-system architecture not clearly explained

All issues are fixable with the proposed changes. Priority should be on separating directories and fixing Windows path resolution first, then adding user-facing commands and documentation.

---

**Status:** Ready for Implementation  
**Estimated Effort:** 2-3 days  
**Risk Level:** Low (changes are isolated and testable)
