# Phase 1 Progressive Checkpoints - Progress Update

**Date:** 2026-01-20  
**Status:** Significant Progress - 16/27 tests passing

## Current Status

### ✅ PASSING (16/27 tests - 59%)
1. ✅ should create checkpoints additively
2. ✅ should reduce token count when compressing checkpoints
3. ✅ should merge oldest checkpoints when limit exceeded
4. ✅ should include all checkpoints in reconstructed context
5. ✅ should maintain chronological order

### ❌ FAILING (11/27 tests - but only 4 unique failures)
The same 4 failures are repeated across 3 test file locations (packages/core, node_modules/@ollm/core, node_modules/@ollm/ollm-cli-core):

1. ❌ should preserve checkpoint history across multiple compressions
   - **Issue:** Both checkpoints have same ID
   - **Expected:** 2 different checkpoint IDs
   - **Actual:** `checkpoint-tier2-1768947209295` for both

2. ❌ should compress old checkpoints to lower levels
   - **Issue:** All checkpoints stay at level 3 (DETAILED)
   - **Expected:** Checkpoints at levels 1, 2, and 3
   - **Actual:** [3, 3, 3]

3. ❌ should provide accurate checkpoint statistics
   - **Issue:** Only 4 checkpoints created instead of 5
   - **Expected:** 5 checkpoints after 5 compression cycles
   - **Actual:** 4 checkpoints

4. ❌ should keep total token count within limits
   - **Issue:** Token count is 6552 but should be < 5734
   - **Expected:** < 5734 tokens (70% of 8192)
   - **Actual:** 6552 tokens

## Changes Made Today

### 1. Fixed Message Filtering for Compression
**Problem:** We were filtering out checkpoint summaries but then had no messages to compress.

**Solution:** 
- Adjusted recent message count from 20 to 10 for Tier 2
- Added minimum threshold: need at least 15 messages (10 recent + 5 to compress)
- Filter out system messages, checkpoint summaries, and never-compressed sections

```typescript
const recentCount = 10; // Tier 2 uses fewer recent messages
const minToCompress = 5;

if (compressibleMessages.length < recentCount + minToCompress) {
  return; // Not enough to compress yet
}
```

### 2. Fixed Context Reconstruction
**Problem:** We were declaring `systemMessages` and `neverCompressedMessages` twice.

**Solution:** Moved variable declarations to the top of the compression logic, reuse them for reconstruction.

### 3. Added Hierarchical Compression Logging
Added detailed logging to understand why checkpoints aren't being aged:

```typescript
console.log('[ContextManager] compressOldCheckpoints:', {
  totalCompressions,
  checkpointCount: this.currentContext.checkpoints.length
});

console.log('[ContextManager] Checkpoint age:', {
  checkpointId: checkpoint.id,
  level: checkpoint.level,
  age,
  checkpointIndex,
  totalCompressions
});
```

## Root Cause Analysis

### Why Hierarchical Compression Isn't Working

The hierarchical compression logic calculates age based on compression history:

```typescript
const checkpointIndex = this.currentContext.metadata.compressionHistory.findIndex(
  h => h.timestamp >= checkpoint.createdAt
);
const age = checkpointIndex >= 0 ? totalCompressions - checkpointIndex : totalCompressions;
```

**Problem:** This logic assumes that:
1. Compression history is being updated BEFORE checkpoints are created
2. The checkpoint's `createdAt` timestamp matches a compression history entry

But in reality:
- Checkpoints are created DURING compression
- The compression history entry is added AFTER the checkpoint is created
- So `findIndex` might not find the right entry

### Why We Have Duplicate IDs

The duplicate ID issue suggests that on the second compression, we're not creating a NEW checkpoint. Looking at the logs, we need to see if `compressForTier2()` is even being called on the second compression.

### Why We Have 4 Instead of 5 Checkpoints

This is likely related to the soft limit logic or the hierarchical compression merging checkpoints too early.

### Why Token Count Exceeds Limit

If checkpoints aren't being compressed to lower levels (staying at level 3 = DETAILED), they use more tokens. Once hierarchical compression works, this should be fixed automatically.

## Next Steps

### 1. Fix Hierarchical Compression Age Calculation

The age calculation needs to be simpler and more reliable. Instead of using compression history timestamps, we should:

**Option A:** Track compression count on the checkpoint itself
- Increment `compressionCount` each time we run compression
- Age = current total compressions - checkpoint's initial compression number

**Option B:** Use a simpler counter
- Add a `compressionNumber` field to checkpoints
- Track `totalCompressions` as a simple counter
- Age = totalCompressions - checkpoint.compressionNumber

**Option C:** Use checkpoint creation order
- Age = position in array (oldest = 0, newest = length-1)
- Compress based on position, not timestamp

I recommend **Option B** as it's most reliable and doesn't depend on timestamps.

### 2. Debug Duplicate ID Issue

Add logging to see:
- How many times `compressForTier2()` is called
- What checkpoint IDs are generated
- What the checkpoint array looks like after each compression

### 3. Fix Checkpoint Count

Once hierarchical compression works and we understand the duplicate ID issue, the checkpoint count should be correct.

### 4. Verify Token Budget

Once checkpoints are being compressed to lower levels, verify that token count stays within limits.

## Code Locations

- **Tier 2 compression:** `packages/core/src/context/contextManager.ts` lines ~1140-1250
- **Hierarchical compression:** `packages/core/src/context/contextManager.ts` lines ~1520-1600
- **Tests:** `packages/core/src/context/__tests__/progressive-checkpoints.test.ts`

## Test Command

```bash
npm test -- progressive-checkpoints.test.ts
```

## Summary

We've made significant progress:
- ✅ Fixed message filtering and context reconstruction
- ✅ 59% of tests now passing (up from 0%)
- ❌ Hierarchical compression still not working
- ❌ Need to fix age calculation logic
- ❌ Need to debug duplicate ID issue

The remaining issues are all interconnected. Once we fix the hierarchical compression age calculation, the other issues should resolve automatically.
