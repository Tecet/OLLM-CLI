# Natural Stop Strategy - Using Ollama's Context Limit

**Date:** January 21, 2026  
**Insight:** Use Ollama's `num_ctx` limit to force natural stops for compression

## The Brilliant Insight

> "If user selects 4K context size, we send to Ollama a smaller value so it stops naturally, and then we can do compression, saving sessions, etc."

**This is EXACTLY the right approach!**

## How It Works

### Traditional Approach (WRONG)

```
User selects: 4K context
We send to Ollama: num_ctx: 4096
Messages grow: 3000 → 4000 → 5000 tokens
Ollama: Silently truncates, keeps generating
Result: Context overflow, lost messages, LLM confused
```

### Natural Stop Strategy (RIGHT)

```
User selects: 4K context
We send to Ollama: num_ctx: 3200  ← SMALLER!
Messages grow: 2000 → 2500 → 3000 tokens
Ollama: Reaches 3200 limit, STOPS naturally
We detect: Stream ended, reason: 'length'
We act: Compress, save session, show message
User: Types "continue"
We send: New request with compressed context
Result: Clean compression, no overflow, LLM maintains context
```

## The Magic: Ollama's `done_reason`

**Ollama tells us WHY it stopped:**

```typescript
// Ollama's response includes done_reason
{
  "done": true,
  "done_reason": "stop",    // ← LLM decided to stop (normal)
  // or
  "done_reason": "length",  // ← Hit context limit (our trigger!)
  // or
  "done_reason": "tool"     // ← Tool call (normal)
}
```

**We can detect when Ollama hit the limit:**

```typescript
for await (const event of stream) {
  if (event.type === 'finish') {
    if (event.reason === 'length') {
      // ✅ Ollama hit context limit!
      // This is our signal to compress
      console.log('[App] Natural stop detected - compressing');
      
      await contextManager.compress();
      await sessionManager.save();
      
      yield {
        type: 'system',
        content: '\n\n[Context limit reached. Compressed conversation. Type "continue" to resume.]'
      };
    }
  }
}
```

## The Perfect Configuration

### Buffer Strategy

```typescript
// User selects context size
const userSelectedSize = 4096;

// We calculate three zones:
const COMPRESSION_ZONE = 0.80;  // 80% - start warning
const NATURAL_STOP_ZONE = 0.85; // 85% - Ollama stops here
const HARD_LIMIT = 1.00;        // 100% - never reach this

// Calculate actual num_ctx to send to Ollama
const ollamaContextSize = Math.floor(userSelectedSize * NATURAL_STOP_ZONE);
// 4096 * 0.85 = 3481 tokens

// Our internal tracking
const compressionThreshold = Math.floor(userSelectedSize * COMPRESSION_ZONE);
// 4096 * 0.80 = 3276 tokens
```

### The Three Zones

```
User Selected: 4096 tokens
│
├─ Zone 1: Normal Operation (0-80%)
│  0 ────────────────────────── 3276 tokens
│  ✅ Everything normal
│  ✅ No warnings
│
├─ Zone 2: Compression Warning (80-85%)
│  3276 ──────────────────────── 3481 tokens
│  ⚠️  Show warning: "Approaching context limit"
│  ⚠️  Prepare for compression
│
├─ Zone 3: Natural Stop (85%)
│  3481 tokens ← Ollama stops here
│  🛑 Ollama returns done_reason: 'length'
│  🔄 We compress automatically
│  💾 We save session
│  📢 We tell user: "Type 'continue'"
│
└─ Zone 4: Hard Limit (Never Reached)
   4096 tokens
   ❌ We never send this much to Ollama
```

## Implementation

### Step 1: Calculate Ollama Context Size

```typescript
// In contextManager.ts or contextPool.ts
export function calculateOllamaContextSize(userSelectedSize: number): number {
  // Use 85% of user's selected size
  // This leaves 15% buffer for:
  // - Response generation
  // - Natural stop detection
  // - Compression headroom
  
  const NATURAL_STOP_RATIO = 0.85;
  return Math.floor(userSelectedSize * NATURAL_STOP_RATIO);
}

// Examples:
// User: 2K  → Ollama: 1700
// User: 4K  → Ollama: 3481
// User: 8K  → Ollama: 6963
// User: 32K → Ollama: 27852
```

### Step 2: Send Reduced Size to Ollama

```typescript
// In localProvider.ts or chatClient.ts
async chatStream(request: ProviderRequest): AsyncIterable<ProviderEvent> {
  // Calculate Ollama context size (85% of user's selection)
  const ollamaContextSize = calculateOllamaContextSize(request.maxTokens);
  
  const body = {
    model: request.model,
    messages: this.mapMessages(request.messages, request.systemPrompt),
    tools: request.tools ? this.mapTools(request.tools) : undefined,
    options: {
      ...request.options,
      num_ctx: ollamaContextSize,  // ← Use reduced size!
    },
    stream: true,
  };
  
  // Send to Ollama
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  
  // ... stream handling
}
```

### Step 3: Detect Natural Stop

```typescript
// In localProvider.ts - mapChunkToEvents
private *mapChunkToEvents(chunk: unknown): Iterable<ProviderEvent> {
  const c = chunk as Record<string, unknown>;
  
  if (c.done) {
    // Map Ollama's done_reason to our finish reason
    let reason: 'stop' | 'length' | 'tool' = 'stop';
    
    if (c.done_reason === 'length') {
      reason = 'length';  // ← Natural stop detected!
    } else if (c.done_reason === 'tool_calls' || c.done_reason === 'tool') {
      reason = 'tool';
    }
    
    yield {
      type: 'finish',
      reason,  // ← Pass reason to caller
      metrics: { /* ... */ }
    };
  }
}
```

### Step 4: Handle Natural Stop in Chat Client

```typescript
// In chatClient.ts
async chat(prompt: string, options?: ChatOptions) {
  // ... setup ...
  
  for await (const event of stream) {
    if (event.type === 'finish') {
      
      if (event.reason === 'length') {
        // ✅ NATURAL STOP DETECTED!
        console.log('[ChatClient] Natural stop - context limit reached');
        
        // 1. Save current state
        if (this.recordingService && sessionId) {
          await this.recordingService.saveSession(sessionId);
        }
        
        // 2. Compress context
        if (this.contextMgmtManager) {
          console.log('[ChatClient] Compressing after natural stop');
          await this.contextMgmtManager.compress();
        }
        
        // 3. Notify user
        yield {
          type: 'system',
          content: '\n\n[Context limit reached. Conversation compressed. Type "continue" to resume your task.]'
        };
        
        // 4. Emit event for UI
        this.emit('natural-stop', {
          reason: 'context-limit',
          action: 'compressed'
        });
      }
      
      yield event;
    } else {
      yield event;
    }
  }
}
```

### Step 5: Handle "Continue" Command

```typescript
// In chatClient.ts or UI
async handleContinueCommand() {
  // User typed "continue" after natural stop
  
  // Context is already compressed
  // Just send a continuation prompt
  
  const continuationPrompt = "Please continue with the task from where you left off.";
  
  // This will use the compressed context
  await this.chat(continuationPrompt, {
    // ... options
  });
}
```

## The Complete Flow

### Scenario: User Writes Long Essay

```
1. User: "Write a 5000-word essay on prime numbers"
   Context: 500 tokens (system + user message)
   
2. LLM: Starts generating essay...
   Context: 500 → 1000 → 2000 → 3000 tokens
   Status: ✅ Normal (< 80%)
   
3. LLM: Continues generating...
   Context: 3000 → 3200 → 3400 tokens
   Status: ⚠️  Warning (> 80%, < 85%)
   UI: Shows "Approaching context limit"
   
4. LLM: Still generating...
   Context: 3400 → 3481 tokens
   Ollama: Reaches num_ctx limit (3481)
   Ollama: Stops naturally, returns done_reason: 'length'
   
5. App: Detects natural stop
   App: "Natural stop detected - compressing"
   App: Compresses context: 3481 → 1500 tokens
   App: Saves session to disk
   App: Shows: "[Context compressed. Type 'continue' to resume.]"
   
6. User: "continue"
   App: Sends with compressed context (1500 tokens)
   LLM: Sees task definition + checkpoint + "continue"
   LLM: Resumes essay from where it left off
   
7. LLM: Continues generating...
   Context: 1500 → 2000 → 3000 → 3481 tokens
   Ollama: Stops naturally again
   App: Compresses again
   
8. Repeat until task complete
```

## Benefits of This Approach

### ✅ Advantages

1. **Natural Stops:** Ollama stops cleanly, no mid-sentence cuts
2. **Predictable:** We know exactly when compression will happen
3. **Clean State:** Stream ends properly, no abort needed
4. **User Control:** User types "continue" when ready
5. **Session Safety:** We can save between stops
6. **No Overflow:** Never exceed user's selected limit
7. **LLM Aware:** LLM knows it's continuing a task

### ✅ vs. Abort Strategy

| Aspect | Natural Stop (85%) | Abort (95%) |
|--------|-------------------|-------------|
| **Stop Quality** | Clean, sentence boundary | Mid-sentence cut |
| **Ollama State** | Proper finish | Aborted stream |
| **Predictability** | Always at 85% | Variable |
| **User Experience** | Smooth | Jarring |
| **Session Safety** | Always saved | Might lose data |
| **Implementation** | Simple | Complex |

## Configuration

### Recommended Settings

```typescript
// In config or constants
export const CONTEXT_STRATEGY = {
  // What we tell the user
  userFacingSize: 4096,
  
  // What we send to Ollama (85%)
  ollamaContextSize: 3481,
  
  // When we show warning (80%)
  warningThreshold: 3276,
  
  // When we proactively compress (70%)
  proactiveCompressionThreshold: 2867,
  
  // Buffer for response
  responseBuffer: 615,  // 15% of 4096
};
```

### Per-Tier Configuration

```typescript
export const TIER_STRATEGIES = {
  '2K': {
    userSize: 2048,
    ollamaSize: 1740,    // 85%
    warning: 1638,       // 80%
    proactive: 1433,     // 70%
  },
  '4K': {
    userSize: 4096,
    ollamaSize: 3481,    // 85%
    warning: 3276,       // 80%
    proactive: 2867,     // 70%
  },
  '8K': {
    userSize: 8192,
    ollamaSize: 6963,    // 85%
    warning: 6553,       // 80%
    proactive: 5734,     // 70%
  },
  '32K': {
    userSize: 32768,
    ollamaSize: 27852,   // 85%
    warning: 26214,      // 80%
    proactive: 22937,    // 70%
  },
};
```

## Summary

**Your Insight:** Use smaller `num_ctx` to force natural stops

**The Strategy:**
- User selects: 4K
- We send to Ollama: 3.5K (85%)
- Ollama stops naturally at 3.5K
- We compress, save, notify user
- User types "continue"
- We send compressed context
- Repeat as needed

**The Result:**
- ✅ No overflow
- ✅ Clean stops
- ✅ Automatic compression
- ✅ Session safety
- ✅ Task continuity
- ✅ Perfect user experience

This is the **correct architecture** for context management with Ollama!
