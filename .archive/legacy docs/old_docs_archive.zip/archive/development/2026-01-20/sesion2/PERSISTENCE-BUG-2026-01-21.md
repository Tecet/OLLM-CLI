# Persistence and Context Overflow Bugs - January 21, 2026

**Date:** January 21, 2026  
**Severity:** CRITICAL  
**Status:** INVESTIGATING

## Bug Report

### Bug #1: Context Overflow - LLM Exceeded Limit

**Evidence from Screenshot:**
- Context shows: In: 1397 | Out: 2821 (Total: ~4218 tokens)
- But earlier showed: 5353/4096 (130% over limit!)
- LLM was streaming and went way over the 4096 token limit

**Expected Behavior:**
- Compression should trigger at 80% (3277 tokens)
- Hard stop at 100% (4096 tokens)
- Should never exceed context limit

**Actual Behavior:**
- LLM streamed past 4096 tokens
- Reached 5353 tokens (130% of limit)
- No compression triggered during streaming
- No hard stop enforced

**Root Cause:**
1. Inflight tokens (streaming text) not counted toward threshold
2. Threshold check only happens AFTER message is added
3. No enforcement during streaming
4. Compression threshold at 80% too high for streaming scenarios

### Bug #2: Complete Loss of Task Context

**Evidence from Screenshot:**
```
USER: continue

ASSISTANT:
# Mode: Assistant 🤝
You are OLLM, an intelligent and versatile AI assistant.
- Your primary goal is to be helpful, harmless, and honest.
- You can answer questions, explain concepts, and assist with general tasks.
...
What can I help you with today? Do you need assistance with a specific project...
```

**Expected Behavior:**
- After "continue", LLM should resume writing the prime numbers paper
- Should remember: essays, poems, 500-word summaries format
- Should continue from where it left off (prime number 20)

**Actual Behavior:**
- LLM completely forgot the task
- Switched to generic Assistant mode
- Lost all context about the paper
- No memory of prime numbers, essays, or poems

**Root Cause:**
1. Task definition never preserved in "never-compressed" section
2. Checkpoint summaries too generic
3. System prompt doesn't include task context
4. After compression, only recent messages remain
5. Original task instructions were in early messages (now compressed away)

### Bug #3: No Files Saved to Disk

**Evidence:**
- User checked: `C:\Users\rad3k\.ollm\sessions` - EMPTY
- User checked: `C:\Users\rad3k\.ollm\context-snapshots` - EMPTY
- No session files created
- No snapshot files created

**Expected Behavior:**
- Session file should be created at start: `{sessionId}.json`
- Session file should update after each message
- Snapshot should be created before compression
- Both folders should have files

**Actual Behavior:**
- No files in either directory
- All conversation lost
- No recovery possible
- No audit trail

**Root Cause (Hypothesis):**
1. ChatRecordingService might not be initialized
2. SnapshotStorage might not be initialized
3. Paths might be incorrect
4. Auto-save might be disabled
5. Write permissions might be missing
6. Errors might be silently caught

## Investigation Plan

### Step 1: Check if Services are Initialized

Need to verify:
- Is ChatRecordingService created in chatClient?
- Is SnapshotStorage created in contextManager?
- Are they receiving the correct paths?

### Step 2: Check if Save Methods are Called

Need to verify:
- Is `recordMessage()` being called?
- Is `saveSession()` being called?
- Is `createSnapshot()` being called?
- Are there any errors being thrown?

### Step 3: Check File System Permissions

Need to verify:
- Can Node.js write to `C:\Users\rad3k\.ollm\`?
- Do the directories exist?
- Are there any permission errors?

### Step 4: Check Configuration

Need to verify:
- Is `autoSave` enabled in ChatRecordingService?
- Is `snapshots.enabled` true in ContextManager?
- Are the paths configured correctly?

## Detailed Analysis

### Context Overflow Analysis

**Timeline:**
1. User starts with 4K context limit
2. LLM begins streaming response
3. Token count: 1000 → 2000 → 3000 → 4000 → 5000+
4. No compression triggered during streaming
5. LLM continues past limit
6. Eventually stops and asks "continue?"

**Why Compression Didn't Trigger:**
```typescript
// In contextManager.ts - addMessage()
async addMessage(message: Message): Promise<void> {
  // Token count is calculated
  const tokenCount = this.tokenCounter.countTokensCached(message.id, message.content);
  
  // Message is added
  this.currentContext.messages.push(message);
  this.currentContext.tokenCount += tokenCount;
  
  // THEN threshold is checked
  this.snapshotManager.checkThresholds(
    this.currentContext.tokenCount + this.inflightTokens,
    this.currentContext.maxTokens
  );
}
```

**Problem:** During streaming, the message isn't "added" until streaming completes. So threshold check happens AFTER the message is already over the limit.

### Task Context Loss Analysis

**What Happened:**
1. User's first message: "Write a extremely detailed, 5000-word academic paper..."
2. This message contains ALL task instructions
3. LLM starts generating (essays, poems, summaries)
4. Context fills up
5. Compression triggers
6. First message gets compressed into: "User requested information about prime numbers"
7. Task structure (essays/poems/summaries) is lost
8. After "continue", LLM only sees generic summary
9. LLM defaults to Assistant mode

**Why Task Was Lost:**
```typescript
// In compressionService.compress()
// Creates generic summary like:
"The conversation covered prime numbers and their properties."

// Missing:
// - Original task structure (essays, poems, 500-word summaries)
// - Specific requirements (for each prime 2-1000)
// - Format requirements (4 stanzas per poem)
// - Progress tracking (currently at prime 20)
```

### Persistence Failure Analysis

**Expected Flow:**
```
1. App starts
2. ChatRecordingService.createSession() → creates session file
3. User sends message
4. ChatRecordingService.recordMessage() → updates session file
5. Context fills up
6. SnapshotManager.createSnapshot() → creates snapshot file
7. Files exist on disk
```

**Actual Flow (Hypothesis):**
```
1. App starts
2. ChatRecordingService might not be initialized? ❌
3. User sends message
4. recordMessage() not called? ❌
5. Context fills up
6. SnapshotManager creates snapshot in memory ✓
7. But SnapshotStorage.save() not called? ❌
8. No files written to disk ❌
```

## Critical Fixes Needed

### Fix #1: Enforce Hard Context Limit (CRITICAL)

**Action:** Stop streaming when approaching limit

```typescript
// In chatClient.ts or contextManager.ts
private checkStreamingLimit(currentTokens: number, maxTokens: number): boolean {
  const HARD_LIMIT_THRESHOLD = 0.95; // 95%
  const usage = currentTokens / maxTokens;
  
  if (usage >= HARD_LIMIT_THRESHOLD) {
    console.warn('[ContextManager] Approaching hard limit, stopping stream');
    return false; // Stop streaming
  }
  
  return true; // Continue streaming
}
```

### Fix #2: Preserve Task Definition (CRITICAL)

**Action:** Extract and preserve task from first user message

```typescript
// In contextManager.ts - addMessage()
if (message.role === 'user' && !this.currentContext.taskDefinition) {
  // Extract task from first user message
  const taskDef: TaskDefinition = {
    id: `task-${Date.now()}`,
    description: message.content, // Full first message
    requirements: this.extractRequirements(message.content),
    deliverables: this.extractDeliverables(message.content),
    timestamp: new Date()
  };
  
  this.setTaskDefinition(taskDef);
  
  // Add to never-compressed section
  this.addNeverCompressed({
    type: 'task_definition',
    content: message.content,
    timestamp: new Date()
  });
}
```

### Fix #3: Verify Persistence (CRITICAL)

**Action:** Add logging and verification

```typescript
// In chatRecordingService.ts - saveSession()
async saveSession(sessionId: string): Promise<void> {
  // ... existing code ...
  
  // VERIFY file was written
  try {
    const stats = await stat(filePath);
    console.log(`[ChatRecording] ✓ Session saved: ${filePath}`);
    console.log(`[ChatRecording]   Size: ${stats.size} bytes`);
    console.log(`[ChatRecording]   Messages: ${session.messages.length}`);
  } catch (error) {
    console.error(`[ChatRecording] ✗ Failed to verify session file:`, error);
    throw error;
  }
}
```

### Fix #4: Lower Compression Threshold (HIGH)

**Action:** Trigger compression earlier

```typescript
// In contextManager.ts - DEFAULT_CONFIG
snapshots: {
  enabled: true,
  maxCount: 5,
  autoCreate: true,
  autoThreshold: 0.65  // Changed from 0.8 to 0.65 (65%)
}
```

## Next Steps

1. ✅ Document bugs
2. ⏳ Investigate why files aren't being saved
3. ⏳ Implement hard context limit
4. ⏳ Implement task preservation
5. ⏳ Lower compression threshold
6. ⏳ Test with long prompt again

## Files to Investigate

1. `packages/core/src/services/chatRecordingService.ts` - Session persistence
2. `packages/core/src/context/snapshotStorage.ts` - Snapshot persistence
3. `packages/core/src/core/chatClient.ts` - Service initialization
4. `packages/core/src/context/contextManager.ts` - Context overflow handling
5. `packages/cli/src/ui/App.tsx` - Service wiring

## User Impact

**Severity: CRITICAL**

- ❌ Cannot run long prompts (context overflow)
- ❌ LLM loses task context after compression
- ❌ No conversation history saved
- ❌ No recovery possible after crash
- ❌ No audit trail for debugging

**User Experience:**
- Starts task → LLM works → Context fills → LLM forgets task → User frustrated
- No way to resume work
- No way to see what happened
- Must start over from scratch


## ROOT CAUSE FOUND

### ChatRecordingService is NEVER Initialized!

**Evidence:**
1. Searched entire CLI codebase for `ChatRecordingService` initialization
2. Found ZERO instances of `new ChatRecordingService()`
3. Found ZERO instances of service being passed to ChatClient
4. Comments in code say "This will integrate with ChatRecordingService" (not integrated!)

**Code Evidence:**
```typescript
// In packages/cli/src/commands/sessionCommands.ts
async function sessionSaveHandler(_args: string[]): Promise<CommandResult> {
  // This will integrate with ChatRecordingService  ← NOT INTEGRATED!
  // For now, return a placeholder
  return {
    success: true,
    message: 'Session save not yet implemented'
  };
}
```

**Impact:**
- No session files created
- No messages saved to disk
- No conversation history
- No recovery possible

### SnapshotStorage Might Be Initialized But Not Saving

**Evidence:**
1. ContextManager creates SnapshotStorage internally
2. But snapshots might only be in memory
3. Need to verify if `save()` method is actually called

**Code Path:**
```
ContextManager constructor
  → createSnapshotStorage(sessionId)  ✓ Created
  → createSnapshotManager(storage)    ✓ Created
  → onContextThreshold callback       ✓ Registered
    → createSnapshot()                ✓ Called
      → snapshotStorage.save()        ❓ Is this called?
```

## Fix Implementation Plan

### Phase 1: Initialize ChatRecordingService (CRITICAL)

**Step 1:** Create service in App.tsx or ContextManagerContext

```typescript
// In ContextManagerContext.tsx or App.tsx
import { ChatRecordingService } from '@ollm/core';

// Create recording service
const recordingService = new ChatRecordingService({
  dataDir: path.join(os.homedir(), '.ollm', 'sessions'),
  maxSessions: 100,
  autoSave: true
});

// Pass to ChatClient
const chatClient = new ChatClient(providerRegistry, toolRegistry, {
  recordingService,  // ← ADD THIS!
  // ... other config
});
```

**Step 2:** Wire up to ContextManager

```typescript
// In ContextManagerContext.tsx
const contextManager = createContextManager(sessionId, modelInfo, {
  // ... existing config
});

// Create session when context manager starts
useEffect(() => {
  if (contextManager && recordingService) {
    recordingService.createSession(modelInfo.name, 'ollama')
      .then(sessionId => {
        console.log('[App] Session created:', sessionId);
      });
  }
}, [contextManager, recordingService]);
```

**Step 3:** Record messages

```typescript
// In chat handling code
const handleUserMessage = async (message: string) => {
  // Record to session
  if (recordingService && sessionId) {
    await recordingService.recordMessage(sessionId, {
      role: 'user',
      parts: [{ type: 'text', text: message }],
      timestamp: new Date().toISOString()
    });
  }
  
  // Add to context manager
  await contextManager.addMessage({
    role: 'user',
    content: message
  });
};
```

### Phase 2: Verify Snapshot Persistence (HIGH)

**Step 1:** Add logging to verify saves

```typescript
// In contextManager.ts - after createSnapshot
const snapshot = await this.snapshotManager.createSnapshot(this.currentContext);
console.log('[ContextManager] Snapshot created:', snapshot.id);

// Verify it was saved
const saved = await this.snapshotStorage.exists(snapshot.id);
console.log('[ContextManager] Snapshot saved to disk:', saved);
```

**Step 2:** Check directory creation

```typescript
// In snapshotStorage.ts - constructor
constructor(baseDir?: string) {
  this.baseDir = baseDir || path.join(os.homedir(), '.ollm', 'context-snapshots');
  
  // Ensure directory exists
  fs.mkdir(this.baseDir, { recursive: true })
    .then(() => console.log('[SnapshotStorage] Directory ready:', this.baseDir))
    .catch(err => console.error('[SnapshotStorage] Failed to create directory:', err));
}
```

### Phase 3: Enforce Context Limit (CRITICAL)

**Step 1:** Add hard limit check during streaming

```typescript
// In contextManager.ts - reportInflightTokens
public reportInflightTokens(delta: number): void {
  this.inflightTokens += delta;
  
  const totalTokens = this.currentContext.tokenCount + this.inflightTokens;
  const usage = totalTokens / this.currentContext.maxTokens;
  
  // HARD LIMIT: Stop at 95%
  if (usage >= 0.95) {
    console.warn('[ContextManager] Hard limit reached, stopping stream');
    this.emit('hard-limit-reached', { totalTokens, maxTokens: this.currentContext.maxTokens });
    throw new Error('Context limit reached');
  }
  
  // Update context pool
  this.contextPool.setCurrentTokens(totalTokens);
  
  // Check thresholds
  this.snapshotManager.checkThresholds(totalTokens, this.currentContext.maxTokens);
}
```

**Step 2:** Handle limit in chat client

```typescript
// In chatClient.ts - streaming loop
try {
  for await (const event of stream) {
    if (event.type === 'text') {
      // Update inflight tokens
      const tokens = estimateTokens(event.value);
      contextManager.reportInflightTokens(tokens);
      
      // Emit text
      yield event;
    }
  }
} catch (error) {
  if (error.message === 'Context limit reached') {
    // Gracefully stop streaming
    yield {
      type: 'text',
      value: '\n\n[Context limit reached. Please type "continue" to resume after compression.]'
    };
    
    // Trigger compression
    await contextManager.compress();
  }
}
```

### Phase 4: Preserve Task Definition (HIGH)

**Step 1:** Extract task from first message

```typescript
// In contextManager.ts - addMessage
async addMessage(message: Message): Promise<void> {
  // ... existing code ...
  
  // If this is the first user message, extract and preserve task
  if (message.role === 'user' && !this.currentContext.taskDefinition) {
    const taskDef: TaskDefinition = {
      id: `task-${Date.now()}`,
      description: message.content,
      requirements: this.extractRequirements(message.content),
      deliverables: this.extractDeliverables(message.content),
      timestamp: new Date()
    };
    
    this.setTaskDefinition(taskDef);
    console.log('[ContextManager] Task definition preserved:', taskDef.id);
  }
  
  // ... rest of existing code ...
}
```

**Step 2:** Include task in system prompt after compression

```typescript
// In contextManager.ts - after compression
private async compressForTier3(): Promise<void> {
  // ... existing compression logic ...
  
  // After reconstruction, inject task reminder
  if (this.currentContext.taskDefinition) {
    const taskReminder: Message = {
      id: `task-reminder-${Date.now()}`,
      role: 'system',
      content: `[TASK CONTEXT]\n${this.currentContext.taskDefinition.description}\n\n[CONTINUE WITH TASK]`,
      timestamp: new Date()
    };
    
    // Insert after system prompt, before checkpoints
    this.currentContext.messages.splice(1, 0, taskReminder);
    console.log('[ContextManager] Task reminder injected after compression');
  }
}
```

## Implementation Priority

1. **CRITICAL - Phase 1:** Initialize ChatRecordingService (fixes no files saved)
2. **CRITICAL - Phase 3:** Enforce context limit (fixes overflow)
3. **HIGH - Phase 4:** Preserve task definition (fixes context loss)
4. **MEDIUM - Phase 2:** Verify snapshot persistence (debugging)

## Testing Plan

After implementing fixes:

1. Start app and verify session file created in `~/.ollm/sessions/`
2. Send message and verify file updated
3. Run long prompt and verify:
   - Compression triggers at 65%
   - Hard stop at 95%
   - Task definition preserved
   - LLM continues task after "continue"
4. Check snapshot files in `~/.ollm/context-snapshots/`
5. Verify recovery after app restart

## Expected Outcomes

After fixes:
- ✅ Session files created and updated
- ✅ Snapshot files created before compression
- ✅ Context never exceeds limit
- ✅ Task definition preserved through compression
- ✅ LLM maintains task coherence
- ✅ User can resume work after restart
