# Context Rollover Audit - January 21, 2026

## Issue Report

**User Test:** Running extremely long prompt (5000-word paper on prime numbers with poems)
**Expected Behavior:** Context compression and rollover should maintain task coherence
**Actual Behavior:**
1. LLM went "mad" - started writing only poems instead of essays/poems/summaries
2. Session chat not saving messages to local PC
3. LLM went way beyond where context compression and rollover should have happened
4. **CRITICAL:** Context rollover triggered in infinite loop, spamming chat with "Summarizing conversation history..." messages
5. **CRITICAL:** Application crashed with "JavaScript heap out of memory" error after rollover loop

## Critical Bugs Discovered

### Bug #1: Infinite Compression Loop (CRITICAL)

**Symptoms:**
- Chat spammed with repeated messages:
  - "Summarizing conversation history..."
  - "[No messages to compress]"
  - "Summary complete. Type 'continue' to resume generation or 'stop' to abort."
  - "[Checkpoint Messages 1-7]"
  - "[Checkpoint Messages 1-11]"
- Loop repeats every few seconds
- Eventually causes memory exhaustion

**Evidence from Screenshot:**
```
SYSTEM • 04:09:43
Summarizing conversation history...

ASSISTANT • 04:09:43
[No messages to compress]

SYSTEM • 04:09:43
Summary complete. Type "continue" to resume generation or "stop" to abort.

SYSTEM • 04:09:47
Summarizing conversation history...

ASSISTANT • 04:09:48
[No messages to compress]

SYSTEM • 04:09:48
Summary complete. Type "continue" to resume generation or "stop" to abort.

[... repeats continuously ...]
```

**Root Cause:** Compression creates checkpoint messages, which increase token count, which triggers compression again, creating more checkpoints, ad infinitum.

### Bug #2: Memory Exhaustion and Crash (CRITICAL)

**Symptoms:**
- Application crashes with error:
  ```
  FATAL ERROR: Ineffective mark-compacts near heap limit Allocation failed - JavaScript heap out of memory
  ```
- Crash occurs after compression loop runs for ~30 seconds
- Multiple stack traces showing memory allocation failures

**Root Cause:** Infinite compression loop allocates unbounded memory:
1. Each compression creates new checkpoint objects
2. Checkpoints are added to context (ADDITIVE)
3. Old checkpoints are never properly cleaned up
4. Memory grows until Node.js heap exhausted (~2GB default limit)

## Deep Dive: Infinite Compression Loop

### The Vicious Cycle

```mermaid
graph TD
    A[Context at 80% threshold] --> B[Trigger compression]
    B --> C[Create checkpoint summary]
    C --> D[Add checkpoint to messages array]
    D --> E[Recalculate token count]
    E --> F{Token count > threshold?}
    F -->|Yes| B
    F -->|No| G[Continue]
    
    style B fill:#ff6b6b
    style D fill:#ff6b6b
    style F fill:#ffd93d
```

### Step-by-Step Breakdown

**Initial State:**
```typescript
messages = [
  { role: 'system', content: '...' },      // 1000 tokens
  { role: 'user', content: '...' },        // 500 tokens
  { role: 'assistant', content: '...' },   // 5000 tokens
  // ... more messages ...
]
Total: 25,600 tokens (80% of 32K context)
```

**Compression Triggered (Iteration 1):**
```typescript
// 1. Compress old messages
compressed = compressionService.compress(messages)
// Returns: summary with 700 tokens

// 2. Create checkpoint
checkpoint = {
  id: 'checkpoint-1',
  summary: { content: '...', tokens: 700 },
  // ...
}

// 3. Add checkpoint to array (ADDITIVE!)
context.checkpoints.push(checkpoint)

// 4. Rebuild messages
messages = [
  { role: 'system', content: '...' },      // 1000 tokens
  { role: 'system', content: checkpoint }, // 700 tokens (NEW!)
  { role: 'user', content: '...' },        // 500 tokens (recent)
  { role: 'assistant', content: '...' },   // 500 tokens (recent)
]
Total: 2,700 tokens (8.4% of 32K)
```

**Problem: Threshold Check Still Passes!**
```typescript
// In snapshotManager.checkThresholds()
const usage = 2700 / 32000 = 0.084 (8.4%)

// But wait... the check is called AGAIN because:
// 1. Token count was updated
// 2. checkThresholds() is called after every message
// 3. Cooldown is only 5 seconds
```

**Compression Triggered AGAIN (Iteration 2):**
```typescript
// Now there are NO old messages to compress!
// Only system prompt + checkpoint + recent messages

// compressionService.compress() returns:
// - status: 'inflated' (nothing to compress)
// - OR creates another checkpoint from the checkpoint!

// Either way, another checkpoint is created:
checkpoint2 = {
  id: 'checkpoint-2',
  summary: { content: '[Checkpoint Messages 1-7]', tokens: 100 },
}

context.checkpoints.push(checkpoint2) // ADDITIVE!

messages = [
  { role: 'system', content: '...' },       // 1000 tokens
  { role: 'system', content: checkpoint1 }, // 700 tokens
  { role: 'system', content: checkpoint2 }, // 100 tokens (NEW!)
  { role: 'user', content: '...' },         // 500 tokens
  { role: 'assistant', content: '...' },    // 500 tokens
]
Total: 2,800 tokens (8.75% of 32K)
```

**The Loop Continues:**
- Each iteration adds a new checkpoint
- Token count slowly grows: 2700 → 2800 → 2900 → 3000...
- Eventually hits threshold again
- More compressions triggered
- Memory grows unbounded
- Crash after ~100 iterations

### Why the Loop Doesn't Stop

**Issue 1: Cooldown is Insufficient**
```typescript
// Line 265-268 in contextManager.ts
if (this.lastAutoSummaryAt && (now - this.lastAutoSummaryAt) < this.AUTO_SUMMARY_COOLDOWN_MS) {
  console.debug('[ContextManager] autoThreshold reached but within cooldown; skipping');
  return;
}
```
- Cooldown is 5 seconds
- But compression completes in < 1 second
- So cooldown doesn't prevent rapid re-triggering

**Issue 2: No Check for "Already Compressed"**
```typescript
// There's no check like:
if (this.currentContext.messages.length < MIN_MESSAGES_TO_COMPRESS) {
  console.log('Not enough messages to compress, skipping');
  return;
}
```

**Issue 3: Checkpoints Count as Messages**
```typescript
// Line 340-345: Checkpoints are added as messages
const checkpointMessages = this.currentContext.checkpoints.map(cp => cp.summary);

this.currentContext.messages = [
  ...systemMessages,
  ...checkpointMessages,  // These count toward token total!
  ...compressed.preserved
];
```

**Issue 4: Token Count Includes Checkpoints**
```typescript
// Line 350-352: Token count includes checkpoint tokens
const newTokenCount = this.tokenCounter.countConversationTokens(
  this.currentContext.messages  // Includes checkpoint messages!
);
```

### Why It Causes Memory Exhaustion

**Memory Growth Pattern:**
```
Iteration 1:  1 checkpoint  = 700 tokens,  ~10KB memory
Iteration 2:  2 checkpoints = 800 tokens,  ~20KB memory
Iteration 3:  3 checkpoints = 900 tokens,  ~30KB memory
...
Iteration 100: 100 checkpoints = 10,000 tokens, ~1MB memory

But also:
- Each checkpoint has metadata (decisions, files, timestamps)
- Compression service keeps intermediate results
- Event emitters create closures
- String concatenation creates temporary objects

Total memory after 100 iterations: ~50-100MB
After 1000 iterations: ~500MB-1GB
After 2000 iterations: CRASH (heap exhausted)
```

**Why It Happens So Fast:**
- Compression triggers every 5 seconds (cooldown)
- Each compression takes ~1 second
- Loop runs at ~0.2 Hz (5 iterations per minute)
- Crash occurs after ~6-10 minutes (2000 iterations)

### The "No Messages to Compress" Message

**Why it appears:**
```typescript
// In compressionService.compress()
if (messages.length < MIN_COMPRESSIBLE) {
  return {
    status: 'inflated',
    summary: { content: '[No messages to compress]' },
    // ...
  }
}
```

This message is then added as a checkpoint, which triggers another compression, which creates another "[No messages to compress]" checkpoint, etc.

## Root Cause Analysis

### Problem 1: LLM Going Off-Track (Concept Drift)

**Location:** `packages/core/src/context/contextManager.ts` - Auto-summary compression

**Issue:** When auto-summary triggers at 80% context threshold:
1. System creates a checkpoint with summary
2. Reconstructs context as: `[System] + [Checkpoints] + [Recent Messages]`
3. **BUT**: The system prompt is NOT being re-applied or updated after compression
4. The checkpoint summaries are generic and don't preserve the original task instructions

**Code Evidence:**
```typescript
// Line 305-340 in contextManager.ts
// After compression, context is rebuilt:
this.currentContext.messages = [
  ...systemMessages,
  ...checkpointMessages,  // Generic summaries
  ...compressed.preserved  // Recent messages only
];
```

**Why LLM Goes Mad:**
- Original detailed task ("write essays, poems, 500-word summaries") is in early messages
- These get compressed into generic checkpoint: "Discussed prime numbers..."
- LLM only sees recent context (poems) + vague summary
- LLM thinks task is "just write poems" because that's all it sees
- **System prompt doesn't contain task-specific instructions**

### Problem 2: Messages Not Saving to Disk

**Location:** `packages/core/src/core/chatClient.ts` + `packages/core/src/services/chatRecordingService.ts`

**Issue:** Two separate systems managing messages:

1. **ContextManager** (`packages/core/src/context/contextManager.ts`):
   - Manages in-memory conversation context
   - Handles compression and checkpoints
   - **Does NOT persist to disk**
   - Only used for LLM context window management

2. **ChatRecordingService** (`packages/core/src/services/chatRecordingService.ts`):
   - Persists messages to `~/.ollm/sessions/`
   - Saves to disk with atomic writes
   - **Only called from chatClient**

**The Disconnect:**
```typescript
// In chatClient.ts - messages ARE being recorded:
await this.recordingService.recordMessage(sessionId, {
  role: 'user',
  parts: [{ type: 'text', text: prompt }],
  timestamp: new Date().toISOString(),
});

// BUT: ContextManager compression doesn't update recording service
// When compression happens, the recording service still has ALL messages
// But the LLM only sees compressed context
```

**Why Messages Appear Missing:**
- Messages ARE being saved to disk by `ChatRecordingService`
- But user might be looking at wrong location
- Or session file might not be flushing properly during long-running operations
- **Auto-save is enabled** but might not be triggering during streaming

### Problem 3: Compression Not Triggering at Right Time

**Location:** `packages/core/src/context/contextManager.ts` - Line 260-290

**Issue:** Auto-summary threshold check:

```typescript
// Line 260-290: Auto-summary triggers at 80% threshold
this.snapshotManager.onContextThreshold(
  this.config.snapshots.autoThreshold, // Default: 0.8 (80%)
  async () => {
    // Compression logic
  }
);
```

**Why It's Not Triggering:**
1. **Threshold might be too high** - 80% means compression only happens when almost full
2. **Token counting might be inaccurate** - Using multiplier method (0.25 chars/token)
3. **Inflight tokens not tracked** - Streaming responses don't update token count until complete
4. **Cooldown prevents rapid compression** - 5-second cooldown might delay compression

**Evidence:**
```typescript
// Line 98-100: Cooldown check
if (this.lastAutoSummaryAt && (now - this.lastAutoSummaryAt) < this.AUTO_SUMMARY_COOLDOWN_MS) {
  console.debug('[ContextManager] autoThreshold reached but within cooldown; skipping');
  return;
}
```

## Architecture Issues

### Issue 1: Task Definition Not Preserved

**Problem:** The system has a `taskDefinition` field but it's never set:

```typescript
// In contextManager.ts - Line 207
this.currentContext = {
  sessionId,
  messages: [],
  systemPrompt: { ... },
  tokenCount: 0,
  maxTokens: this.contextPool.currentSize,
  checkpoints: [],
  architectureDecisions: [],
  neverCompressed: [],
  metadata: { ... }
};

// taskDefinition is NEVER initialized or set!
// There's a setTaskDefinition() method but nothing calls it
```

**Impact:** Original task instructions are lost during compression

### Issue 2: System Prompt Not Task-Aware

**Problem:** System prompts are tier/mode-based but don't include user's task:

```typescript
// Line 870-900: System prompt selection
private getSystemPromptForTierAndMode(): string {
  const tier = this.getEffectivePromptTier();
  const mode = this.currentMode;
  
  // Returns generic prompt for tier/mode
  // Does NOT include user's specific task
  return template.template;
}
```

**Impact:** After compression, LLM doesn't remember what it's supposed to be doing

### Issue 3: Checkpoint Summaries Too Generic

**Problem:** Compression service creates generic summaries:

```typescript
// In compressionService.ts (not shown but referenced)
// Summary is created by LLM but without task context
// Result: "Discussed prime numbers and their properties"
// Missing: "Writing 5000-word paper with essays, poems, and summaries"
```

**Impact:** Compressed checkpoints don't preserve task structure

## Recommended Fixes

### Fix 1: Preserve Task Definition (HIGH PRIORITY)

**Action:** Extract and preserve task definition from initial user message

```typescript
// In contextManager.ts - after first user message
public async addMessage(message: Message): Promise<void> {
  // ... existing code ...
  
  // If this is the first user message, extract task definition
  if (message.role === 'user' && !this.currentContext.taskDefinition) {
    const taskDef = this.extractTaskDefinition(message.content);
    if (taskDef) {
      this.setTaskDefinition(taskDef);
    }
  }
}

private extractTaskDefinition(content: string): TaskDefinition | null {
  // Extract task from first user message
  // Look for: instructions, requirements, deliverables
  // Store as never-compressed section
  return {
    id: `task-${Date.now()}`,
    description: content, // Full first message
    requirements: this.extractRequirements(content),
    deliverables: this.extractDeliverables(content),
    timestamp: new Date()
  };
}
```

### Fix 2: Include Task in System Prompt (HIGH PRIORITY)

**Action:** Append task definition to system prompt after compression

```typescript
// In contextManager.ts - after compression
private async compressForTier3(): Promise<void> {
  // ... existing compression logic ...
  
  // After reconstruction, inject task reminder
  if (this.currentContext.taskDefinition) {
    const taskReminder: Message = {
      id: `task-reminder-${Date.now()}`,
      role: 'system',
      content: `[TASK REMINDER]\n${this.currentContext.taskDefinition.description}`,
      timestamp: new Date()
    };
    
    // Insert after system prompt, before checkpoints
    this.currentContext.messages.splice(1, 0, taskReminder);
  }
}
```

### Fix 3: Lower Compression Threshold (MEDIUM PRIORITY)

**Action:** Trigger compression earlier to prevent context overflow

```typescript
// In contextManager.ts - DEFAULT_CONFIG
const DEFAULT_CONFIG: ContextConfig = {
  // ... other config ...
  snapshots: {
    enabled: true,
    maxCount: 5,
    autoCreate: true,
    autoThreshold: 0.65  // Changed from 0.8 to 0.65 (65%)
  }
};
```

**Rationale:**
- 65% gives more headroom before context fills
- Allows compression to complete before hitting limit
- Reduces risk of overflow during streaming

### Fix 4: Track Inflight Tokens (MEDIUM PRIORITY)

**Action:** Update token count during streaming, not just after

```typescript
// In contextManager.ts
public updateInflightTokens(delta: number): void {
  this.inflightTokens += delta;
  
  // Check thresholds with inflight tokens included
  this.snapshotManager.checkThresholds(
    this.currentContext.tokenCount + this.inflightTokens,
    this.currentContext.maxTokens
  );
}

// In chatClient.ts - during streaming
for await (const event of stream) {
  if (event.type === 'text') {
    const tokens = estimateTokens(event.value);
    contextManager.updateInflightTokens(tokens);
  }
}
```

### Fix 5: Improve Checkpoint Quality (LOW PRIORITY)

**Action:** Include task context in compression prompts

```typescript
// In compressionService.ts
async compress(messages: Message[], strategy: CompressionStrategy): Promise<CompressionResult> {
  // Get task definition from context
  const taskContext = this.getTaskContext();
  
  // Include in compression prompt
  const compressionPrompt = `
    Summarize the following conversation while preserving:
    - Original task: ${taskContext.description}
    - Key requirements: ${taskContext.requirements.join(', ')}
    - Progress toward deliverables
    
    Conversation:
    ${messages.map(m => `${m.role}: ${m.content}`).join('\n')}
  `;
  
  // ... rest of compression logic ...
}
```

### Fix 6: Verify Session Persistence (LOW PRIORITY)

**Action:** Add logging to confirm messages are being saved

```typescript
// In chatRecordingService.ts - saveSession method
async saveSession(sessionId: string): Promise<void> {
  // ... existing code ...
  
  // Add confirmation logging
  console.log(`[ChatRecording] Session saved: ${sessionId}, messages: ${session.messages.length}, path: ${filePath}`);
  
  // Verify file was written
  const stats = await stat(filePath);
  console.log(`[ChatRecording] File size: ${stats.size} bytes, modified: ${stats.mtime}`);
}
```

## Testing Plan

### Test 1: Task Preservation
1. Start chat with complex multi-part task
2. Generate enough content to trigger compression (65% threshold)
3. Verify task definition is preserved in context
4. Verify LLM continues following original instructions

### Test 2: Compression Timing
1. Monitor token count during long-running generation
2. Verify compression triggers at 65% threshold
3. Verify compression completes before context fills
4. Verify no "context overflow" errors

### Test 3: Session Persistence
1. Start chat and send several messages
2. Check `~/.ollm/sessions/` directory for session file
3. Verify file is being updated during conversation
4. Verify file contains all messages after compression

### Test 4: Checkpoint Quality
1. Trigger compression with complex conversation
2. Examine checkpoint summaries
3. Verify summaries preserve task structure
4. Verify summaries include key decisions and progress

## Priority Implementation Order

1. **CRITICAL - Fix 1 & 2:** Preserve task definition and include in system prompt
   - This directly addresses the "LLM going mad" issue
   - Prevents concept drift during compression

2. **HIGH - Fix 3:** Lower compression threshold to 65%
   - Prevents context overflow
   - Gives more headroom for compression

3. **MEDIUM - Fix 4:** Track inflight tokens
   - Improves compression timing accuracy
   - Prevents late compression triggers

4. **LOW - Fix 5 & 6:** Improve checkpoint quality and verify persistence
   - Nice-to-have improvements
   - Can be done after critical fixes

## Expected Outcomes

After implementing fixes:
1. ✅ LLM maintains task coherence through multiple compressions
2. ✅ Original instructions preserved in "never-compressed" sections
3. ✅ Compression triggers earlier (65% vs 80%)
4. ✅ Checkpoint summaries include task context
5. ✅ Session files confirmed to be saving properly
6. ✅ User can run extremely long prompts without concept drift

## Files to Modify

1. `packages/core/src/context/contextManager.ts` - Task preservation, compression threshold
2. `packages/core/src/context/types.ts` - TaskDefinition interface (already exists)
3. `packages/core/src/context/compressionService.ts` - Checkpoint quality
4. `packages/core/src/core/chatClient.ts` - Inflight token tracking
5. `packages/core/src/services/chatRecordingService.ts` - Logging verification

## Notes

- The architecture already has the right pieces (TaskDefinition, never-compressed sections)
- They're just not being used properly
- Main issue is task context getting lost during compression
- Secondary issue is compression triggering too late
- Session persistence is probably working, just needs verification


## EMERGENCY Fixes for Infinite Loop

### EMERGENCY FIX #1: Stop Infinite Loop (IMMEDIATE - CRITICAL)

**Action:** Add guard to prevent compression when there are no compressible messages

```typescript
// In contextManager.ts - Line 258, inside onContextThreshold callback
async () => {
  // Prevent re-entrant or rapid repeated auto-summary triggers
  const now = Date.now();
  if (this.autoSummaryRunning) {
    console.debug('[ContextManager] autoThreshold reached but auto-summary already running; skipping');
    return;
  }
  if (this.lastAutoSummaryAt && (now - this.lastAutoSummaryAt) < this.AUTO_SUMMARY_COOLDOWN_MS) {
    console.debug('[ContextManager] autoThreshold reached but within cooldown; skipping');
    return;
  }
  
  // NEW: Check if there are enough compressible messages
  const systemMessages = this.currentContext.messages.filter(m => m.role === 'system');
  const checkpointIds = new Set((this.currentContext.checkpoints || []).map(cp => cp.summary.id));
  const compressibleMessages = this.currentContext.messages.filter(m => 
    m.role !== 'system' && 
    !checkpointIds.has(m.id)
  );
  
  const MIN_MESSAGES_TO_COMPRESS = 10; // Need at least 10 messages
  if (compressibleMessages.length < MIN_MESSAGES_TO_COMPRESS) {
    console.log('[ContextManager] Not enough compressible messages, skipping compression', {
      compressible: compressibleMessages.length,
      minimum: MIN_MESSAGES_TO_COMPRESS
    });
    return;
  }
  
  this.autoSummaryRunning = true;
  this.lastAutoSummaryAt = now;
  // ... rest of compression logic ...
}
```

### EMERGENCY FIX #2: Exclude Checkpoints from Threshold Check (IMMEDIATE - CRITICAL)

**Action:** Don't count checkpoint messages when checking if compression is needed

```typescript
// In contextManager.ts - Line 678, in addMessage method
this.snapshotManager.checkThresholds(
  this.currentContext.tokenCount + this.inflightTokens,
  this.currentContext.maxTokens
);

// CHANGE TO:
// Calculate token count WITHOUT checkpoint messages
const checkpointIds = new Set((this.currentContext.checkpoints || []).map(cp => cp.summary.id));
const nonCheckpointMessages = this.currentContext.messages.filter(m => !checkpointIds.has(m.id));
const nonCheckpointTokens = this.tokenCounter.countConversationTokens(nonCheckpointMessages);

this.snapshotManager.checkThresholds(
  nonCheckpointTokens + this.inflightTokens,
  this.currentContext.maxTokens
);
```

### EMERGENCY FIX #3: Increase Cooldown (IMMEDIATE - CRITICAL)

**Action:** Increase cooldown to prevent rapid re-triggering

```typescript
// In contextManager.ts - Line 100
private AUTO_SUMMARY_COOLDOWN_MS: number = 5000;

// CHANGE TO:
private AUTO_SUMMARY_COOLDOWN_MS: number = 60000; // 60 seconds
```

### EMERGENCY FIX #4: Limit Checkpoint Count (IMMEDIATE - CRITICAL)

**Action:** Hard limit on number of checkpoints to prevent unbounded growth

```typescript
// In contextManager.ts - after creating checkpoint (Line 340)
// Add new checkpoint to history
this.currentContext.checkpoints.push(checkpoint);

// NEW: Enforce hard limit on checkpoint count
const MAX_CHECKPOINTS = 10;
if (this.currentContext.checkpoints.length > MAX_CHECKPOINTS) {
  // Remove oldest checkpoints, keeping only the most recent
  this.currentContext.checkpoints = this.currentContext.checkpoints.slice(-MAX_CHECKPOINTS);
  console.log('[ContextManager] Checkpoint limit reached, removed oldest checkpoints');
}
```

### EMERGENCY FIX #5: Don't Return Checkpoint on "No Messages" (IMMEDIATE - CRITICAL)

**Action:** When there's nothing to compress, don't create a checkpoint at all

```typescript
// In contextManager.ts - Line 305, after compression
if (compressed.status === 'inflated' || compressed.status === 'skipped') {
  console.log('[ContextManager] Compression skipped - no messages to compress');
  this.emit('compression-skipped', { reason: compressed.status });
  return; // EXIT - don't create checkpoint!
}

// Only create checkpoint if compression actually happened
if (compressed && compressed.summary) {
  // ... create checkpoint logic ...
}
```

