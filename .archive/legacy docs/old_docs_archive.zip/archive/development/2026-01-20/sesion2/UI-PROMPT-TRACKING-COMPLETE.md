# UI Prompt Tracking Implementation - Complete

**Date:** January 21, 2026  
**Session:** Session 2  
**Status:** ✅ COMPLETE

## Overview

Implemented UI integration to display the current adaptive system prompt tier and mode in the side panel. Users can now see which prompt is being used in real-time.

## Changes Made

### 1. Extended ContextManagerState Interface

**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

Added three new fields to expose tier information to the UI:

```typescript
export interface ContextManagerState {
  // ... existing fields ...
  
  /** Current prompt tier (for display) */
  currentTier: string;
  
  /** Effective prompt tier (hardware capability tier) */
  effectivePromptTier: string;
  
  /** Actual context tier (based on context size) */
  actualContextTier: string;
}
```

### 2. Added Tier Change Event Listener

**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

Added listener for `tier-changed` and `started` events from ContextManager:

```typescript
const tierChangeCallback = (data: unknown) => {
  const tierData = data as {
    tier?: number;
    effectivePromptTier?: number;
    actualContextTier?: number;
  };
  
  // Convert tier numbers to display strings
  const tierToString = (tier: number | undefined): string => {
    if (tier === undefined) return 'Unknown';
    return `Tier ${tier}`;
  };
  
  if (tierData.tier !== undefined) {
    setCurrentTier(tierToString(tierData.tier));
  }
  if (tierData.effectivePromptTier !== undefined) {
    setEffectivePromptTier(tierToString(tierData.effectivePromptTier));
  }
  if (tierData.actualContextTier !== undefined) {
    setActualContextTier(tierToString(tierData.actualContextTier));
  }
};

manager.on('tier-changed', tierChangeCallback);
manager.on('started', tierChangeCallback); // Also listen to started event for initial tier
```

### 3. Updated ContextSection Component

**File:** `packages/cli/src/ui/components/layout/ContextSection.tsx`

Added "Active Prompt" display section showing:
- Effective prompt tier (the tier used for prompt selection)
- Current mode (Developer, Assistant, Planning, Debugger)
- Actual context tier (if different from effective tier)

```typescript
{/* Prompt Tier Display */}
<Box flexDirection="column" marginBottom={1} paddingX={1} alignSelf="flex-start">
  <Text color={uiState.theme.status.info} bold>Active Prompt:</Text>
  <Box marginLeft={1} alignSelf="flex-start">
    <Text color={uiState.theme.text.primary}>
      {contextState.effectivePromptTier} - {currentMode}
    </Text>
  </Box>
  {contextState.effectivePromptTier !== contextState.actualContextTier && (
    <Box marginLeft={1} alignSelf="flex-start">
      <Text dimColor>
        (Context: {contextState.actualContextTier})
      </Text>
    </Box>
  )}
</Box>
```

## UI Display Format

The side panel now shows:

```
Active Prompt:
  Tier 3 - developer
  (Context: Tier 4)  ← Only shown if different from effective tier
```

### Display Logic

1. **Effective Prompt Tier**: The tier used for prompt selection (locked to hardware capability when auto-sizing is enabled)
2. **Current Mode**: The operational mode (developer, assistant, planning, debugger)
3. **Actual Context Tier**: Only displayed if different from effective tier (e.g., when auto-sizing adjusts context size but prompt stays locked)

## Integration Points

### Event Flow

```
ContextManager (core)
  ↓ emits 'tier-changed' event
ContextManagerContext (React)
  ↓ updates state
ContextSection (UI Component)
  ↓ displays to user
Side Panel
```

### State Management

- **ContextManager**: Tracks `currentTier`, `effectivePromptTier`, `actualContextTier` internally
- **ContextManagerContext**: Exposes tier information as React state
- **ContextSection**: Consumes state and renders UI

## Testing

All 264 context tests pass:
- ✅ Tier detection tests
- ✅ Adaptive prompt tests
- ✅ Mode management tests
- ✅ Integration tests
- ✅ Property-based tests

## Benefits

1. **Transparency**: Users can see which prompt tier is active
2. **Debugging**: Easier to understand why the AI behaves differently in different contexts
3. **Awareness**: Users know when hardware limitations affect prompt quality
4. **Consistency**: Prompt tier display matches the actual prompt being used

## Example Scenarios

### Scenario 1: Auto-Sizing Enabled (Default)
```
Hardware: 16GB VRAM → Tier 4 capability
Context: 32K tokens → Tier 4 context
Display: "Tier 4 - developer"
```

### Scenario 2: Auto-Sizing with Context Adjustment
```
Hardware: 16GB VRAM → Tier 4 capability
Context: 8K tokens (auto-adjusted) → Tier 2 context
Display: "Tier 4 - developer"
        "(Context: Tier 2)"
```

### Scenario 3: Manual Context Size
```
Hardware: 8GB VRAM → Tier 3 capability
Context: 64K tokens (user set) → Tier 5 context
Display: "Tier 5 - developer"  ← Uses higher tier
```

## Related Documentation

- [Adaptive System Prompts](./../../../Adaptive_system_Prompts.md)
- [Context Architecture](./../../../Context-Architecture.md)
- [Prompts Routing](./../../../prompts-routing.md)
- [Implementation Status](./IMPLEMENTATION-STATUS.md)

## Completion Status

- ✅ Tier information exposed to UI state
- ✅ Event listeners wired up
- ✅ UI component updated to display prompt info
- ✅ All tests passing
- ✅ No TypeScript errors

**Status: COMPLETE** 🎉
