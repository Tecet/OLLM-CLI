# Context Limit Architecture - How It Should Work

**Date:** January 21, 2026  
**Topic:** Graceful context limit handling with Ollama

## The Question

> "We pass context size to Ollama. Is there a way to pause LLM stream and remind it it's time to do context compression/rollover? Is that graceful stop instruction passed to LLM? Will Ollama accept that instruction and stop model so we can pass instruction to summarize context?"

## The Answer: NO - We Cannot Pause Ollama Mid-Stream

### How Ollama Works

**Ollama's Context Window:**
```
When you send a request to Ollama:
1. You specify num_ctx (e.g., 4096 tokens)
2. Ollama loads the ENTIRE conversation into the model
3. Model generates response token by token
4. Ollama streams tokens back to us
5. We CANNOT interrupt or pause the generation
```

**Key Limitation:**
- Ollama does NOT have a "pause" or "stop gracefully" API
- Once generation starts, it runs until:
  - Model decides to stop (generates `<|end|>` token)
  - Context limit reached (Ollama truncates internally)
  - We abort the request (hard stop, no graceful)

### What Happens When Context Fills

**Current Ollama Behavior:**
```
Context: 4096 tokens
Messages: 3500 tokens (85%)
User: "Write a long essay..."

Ollama:
1. Loads 3500 tokens of history
2. Starts generating response
3. Token 1, 2, 3... 500, 600...
4. Reaches 4096 total tokens
5. Ollama SILENTLY TRUNCATES oldest messages
6. Continues generating with truncated context
7. LLM doesn't know it lost context!
```

**Problem:**
- LLM doesn't know context was truncated
- No warning to LLM
- No graceful stop
- Just keeps generating with partial context

## The Correct Architecture

### Strategy 1: Prevent Overflow (PROACTIVE)

**Don't let context fill up in the first place!**

```typescript
// BEFORE sending to Ollama, check if we have room
const currentTokens = contextManager.getTokenCount();
const maxTokens = contextManager.getMaxTokens();
const usage = currentTokens / maxTokens;

if (usage > 0.65) {  // 65% threshold
  // STOP - Don't send to Ollama yet
  // Compress first, THEN send
  
  console.log('[App] Context at 65%, compressing before next request');
  
  // 1. Compress context
  await contextManager.compress();
  
  // 2. NOW send to Ollama with compressed context
  const response = await ollama.chat({
    model: 'llama2',
    messages: contextManager.getMessages(),  // Compressed!
    options: { num_ctx: 4096 }
  });
}
```

**Flow:**
```
User sends message
  ↓
Check context usage
  ↓
If > 65%:
  → Compress FIRST
  → Update context
  → THEN send to Ollama
  ↓
If < 65%:
  → Send directly to Ollama
```

### Strategy 2: Abort and Compress (REACTIVE)

**If we detect overflow during streaming, abort and compress**

```typescript
// During streaming, track tokens
for await (const chunk of stream) {
  if (chunk.type === 'text') {
    accumulatedText += chunk.value;
    const estimatedTokens = estimateTokens(accumulatedText);
    
    // Check if approaching limit
    const totalTokens = currentTokens + estimatedTokens;
    if (totalTokens > maxTokens * 0.95) {  // 95% hard limit
      
      // ABORT the stream
      abortController.abort();
      
      // Add what we got so far
      await contextManager.addMessage({
        role: 'assistant',
        content: accumulatedText + '\n\n[Context limit reached]'
      });
      
      // Compress
      await contextManager.compress();
      
      // Tell user
      yield {
        type: 'system',
        content: 'Context compressed. Type "continue" to resume.'
      };
      
      break;  // Stop streaming
    }
    
    yield chunk;
  }
}
```

**Flow:**
```
Ollama streaming response
  ↓
We track tokens in real-time
  ↓
If approaching limit (95%):
  → Abort stream (hard stop)
  → Save partial response
  → Compress context
  → Tell user to type "continue"
  ↓
User types "continue":
  → Send NEW request with compressed context
  → LLM sees: "Continue with the task..."
```

### Strategy 3: Teach LLM to Self-Limit (COOPERATIVE)

**Include instructions in system prompt**

```typescript
const systemPrompt = `
You are an AI assistant with a ${maxTokens} token context window.

IMPORTANT CONTEXT MANAGEMENT:
- When writing long responses, periodically check your progress
- If you're writing a multi-part response, break it into sections
- After each major section, ask: "Would you like me to continue?"
- This allows the system to compress context between sections

Example:
"I've completed the analysis of prime numbers 2-20. 
Would you like me to continue with 21-40?"

This helps maintain context quality throughout long tasks.
`;
```

**Flow:**
```
LLM generates response
  ↓
LLM self-limits to reasonable length
  ↓
LLM asks: "Continue?"
  ↓
User: "continue"
  ↓
We check context usage
  ↓
If high: Compress before sending "continue"
If low: Send "continue" directly
```

## Recommended Implementation

### Hybrid Approach (Best of All Strategies)

**1. Proactive Prevention (Primary)**
```typescript
// Before EVERY request to Ollama
async function sendToOllama(userMessage: string) {
  // Check context BEFORE sending
  const usage = contextManager.getUsage();
  
  if (usage.percentage > 65) {
    console.log('[App] Proactive compression triggered');
    await contextManager.compress();
  }
  
  // Now send with compressed context
  return await ollama.chat({
    model: currentModel,
    messages: contextManager.getMessages(),
    options: { num_ctx: contextManager.getMaxTokens() }
  });
}
```

**2. Reactive Abort (Safety Net)**
```typescript
// During streaming, enforce hard limit
for await (const chunk of stream) {
  const totalTokens = currentTokens + inflightTokens;
  
  if (totalTokens > maxTokens * 0.95) {
    // HARD STOP
    abortController.abort();
    await handleContextOverflow();
    break;
  }
  
  yield chunk;
}
```

**3. Cooperative Self-Limiting (UX Enhancement)**
```typescript
// In system prompt
const systemPrompt = `
${basePrompt}

CONTEXT MANAGEMENT:
- For long tasks, work in sections
- After each section, ask if user wants to continue
- This allows optimal context management
`;
```

## What We Pass to Ollama

### Current Request Format

```typescript
// What we send to Ollama
{
  model: 'llama2',
  messages: [
    { role: 'system', content: 'You are...' },
    { role: 'user', content: 'Write essay...' },
    { role: 'assistant', content: 'Here is...' },
    // ... more messages
  ],
  options: {
    num_ctx: 4096,        // ← Context window size
    temperature: 0.7,
    // ... other options
  },
  stream: true
}
```

**What Ollama Does:**
1. Counts tokens in ALL messages
2. If total > num_ctx, SILENTLY truncates oldest messages
3. Generates response with whatever fits
4. Streams tokens back to us

**What Ollama Does NOT Do:**
- ❌ Tell us context was truncated
- ❌ Warn the LLM about truncation
- ❌ Provide "pause" or "graceful stop" API
- ❌ Let us inject instructions mid-stream

## The Correct Flow

### Before Compression (Proactive)

```
User: "Write a 5000-word essay..."
  ↓
App: Check context usage
  ↓
App: 70% full - COMPRESS FIRST
  ↓
App: Create checkpoint of conversation
  ↓
App: Compress old messages into summary
  ↓
App: Rebuild context:
      [System Prompt]
      [Task Definition] ← PRESERVED
      [Checkpoint Summary]
      [Recent Messages]
  ↓
App: NOW send to Ollama with compressed context
  ↓
Ollama: Receives clean, compressed context
  ↓
LLM: Generates response with full context awareness
```

### After Overflow (Reactive)

```
Ollama: Streaming response...
  ↓
App: Tracking tokens in real-time
  ↓
App: 95% full - ABORT!
  ↓
App: abortController.abort()
  ↓
Ollama: Stream stops
  ↓
App: Save partial response
  ↓
App: Compress context
  ↓
App: Show message: "Context compressed. Type 'continue' to resume."
  ↓
User: "continue"
  ↓
App: Send NEW request with compressed context + "continue with task"
  ↓
Ollama: Receives fresh request with compressed context
  ↓
LLM: Continues task with context awareness
```

## Key Insights

### What We CAN Do:
✅ Check context usage BEFORE sending to Ollama
✅ Compress proactively when approaching limit
✅ Abort stream if we detect overflow
✅ Preserve task definition through compression
✅ Teach LLM to self-limit via system prompt

### What We CANNOT Do:
❌ Pause Ollama mid-generation
❌ Inject instructions during streaming
❌ Make Ollama stop gracefully mid-response
❌ Get Ollama to tell LLM about context limits

### The Solution:
**Don't let context fill up!**
- Compress at 65% (proactive)
- Hard stop at 95% (reactive)
- Preserve task definition (never compress)
- Teach LLM to self-limit (cooperative)

## Implementation Priority

1. **CRITICAL:** Proactive compression at 65%
2. **CRITICAL:** Hard stop at 95% during streaming
3. **HIGH:** Preserve task definition
4. **MEDIUM:** Add self-limiting instructions to system prompt
5. **LOW:** Optimize compression quality

## Code Changes Needed

### 1. Proactive Check (chatClient.ts)

```typescript
async chat(prompt: string, options?: ChatOptions) {
  // CHECK BEFORE SENDING
  if (this.contextMgmtManager) {
    const usage = this.contextMgmtManager.getUsage();
    
    if (usage.percentage > 65) {
      console.log('[ChatClient] Proactive compression at', usage.percentage);
      await this.contextMgmtManager.compress();
    }
  }
  
  // NOW send to Ollama
  const stream = this.provider.chatStream({
    model: options?.model || this.config.defaultModel,
    messages: this.getMessages(),
    // ...
  });
}
```

### 2. Reactive Abort (chatClient.ts)

```typescript
for await (const event of stream) {
  if (event.type === 'text') {
    // Track inflight tokens
    if (this.contextMgmtManager) {
      const tokens = estimateTokens(event.value);
      this.contextMgmtManager.reportInflightTokens(tokens);
      
      // Check for overflow
      const usage = this.contextMgmtManager.getUsage();
      if (usage.percentage > 95) {
        // ABORT!
        abortController.abort();
        
        yield {
          type: 'system',
          value: '\n\n[Context limit reached. Compressing... Type "continue" to resume.]'
        };
        
        await this.contextMgmtManager.compress();
        break;
      }
    }
    
    yield event;
  }
}
```

### 3. Task Preservation (contextManager.ts)

```typescript
async addMessage(message: Message): Promise<void> {
  // Preserve first user message as task definition
  if (message.role === 'user' && !this.currentContext.taskDefinition) {
    this.setTaskDefinition({
      id: `task-${Date.now()}`,
      description: message.content,
      timestamp: new Date()
    });
  }
  
  // ... rest of code
}
```

## Summary

**The Answer to Your Question:**

No, we cannot pause Ollama mid-stream or send it graceful stop instructions. Ollama doesn't support that.

**The Solution:**

Don't let context fill up! Compress BEFORE sending to Ollama, not during streaming.

**The Architecture:**

1. **Proactive:** Check context before every request, compress if > 65%
2. **Reactive:** Abort stream if overflow detected, compress, ask user to continue
3. **Cooperative:** Teach LLM to self-limit via system prompt

This way, Ollama always receives a clean, compressed context and never hits the limit.
