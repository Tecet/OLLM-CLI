# Session & Snapshot Persistence Bug Fix

**Date:** January 21, 2026  
**Status:** ✅ FIXED (Snapshots) | ⚠️ PENDING (Sessions)

## Problem

Sessions and snapshots were being saved in the app directory (e.g., `session-1768880583082/`) instead of the user's home directory (`C:\Users\rad3k\.ollm\sessions` and `C:\Users\rad3k\.ollm\context-snapshots`).

## Root Causes

### 1. Snapshot Storage Bug ✅ FIXED

**Location:** `packages/core/src/context/contextManager.ts` line 166

**Issue:**
```typescript
// WRONG - passing sessionId as baseDir
this.snapshotStorage = services?.snapshotStorage || createSnapshotStorage(sessionId);
```

This passed the sessionId (e.g., `"session-1768880583082"`) as the base directory, causing snapshots to be created in `./session-1768880583082/snapshots/` instead of `~/.ollm/context-snapshots/session-1768880583082/snapshots/`.

**Fix:**
```typescript
// CORRECT - use default path
this.snapshotStorage = services?.snapshotStorage || createSnapshotStorage();
```

Now `createSnapshotStorage()` uses its default path: `~/.ollm/context-snapshots/`

### 2. Session Recording Not Integrated ⚠️ PENDING

**Location:** `packages/cli/src/commands/sessionCommands.ts`

**Issue:** The `ChatRecordingService` is not yet integrated into the CLI. All session commands are placeholders:

```typescript
async function sessionSaveHandler(_args: string[]): Promise<CommandResult> {
  // This will integrate with ChatRecordingService
  // For now, return a placeholder
  return {
    success: true,
    message: 'Session save not yet implemented',
  };
}
```

**Impact:** Sessions are not being saved to disk at all. The service is correctly configured to use `~/.ollm/sessions`, but it's never instantiated or used.

## File Access for LLM

### Current State

The LLM can write files through the `write_file` tool, which:
- ✅ Works correctly
- ✅ Uses `path.resolve()` to handle both relative and absolute paths
- ✅ Has no workspace restrictions
- ✅ Can write anywhere the user has permissions

**How it works:**
```typescript
// Relative path - resolves from current working directory (app directory)
write_file({ path: "document.txt", content: "..." })
// Creates: D:\Workspaces\OLLM CLI\document.txt

// Absolute path - uses exact path
write_file({ path: "C:\\Users\\rad3k\\Documents\\file.txt", content: "..." })
// Creates: C:\Users\rad3k\Documents\file.txt
```

### The Problem

The LLM doesn't know:
1. What the current working directory is
2. Where the user's home directory is
3. Where the `.ollm` data directory is

So when it tries to save files, it uses relative paths which end up in the app directory.

## Solutions

### ✅ Completed

1. **Fixed snapshot storage path** - Snapshots now go to `~/.ollm/context-snapshots/`
2. **Verified ChatRecordingService configuration** - Already configured to use `~/.ollm/sessions/`

### ⚠️ Pending

1. **Integrate ChatRecordingService into CLI**
   - Instantiate the service in the app
   - Wire up session save/load/list commands
   - Connect to context manager for automatic session recording

2. **Provide workspace context to LLM**
   - Add system prompt information about paths:
     ```
     # Workspace Context
     - Current working directory: D:\Workspaces\OLLM CLI
     - User home directory: C:\Users\rad3k
     - OLLM data directory: C:\Users\rad3k\.ollm
     - Sessions directory: C:\Users\rad3k\.ollm\sessions
     - Snapshots directory: C:\Users\rad3k\.ollm\context-snapshots
     ```
   - This allows LLM to use correct absolute paths when saving files

3. **Add helper tools for common paths**
   - `get_ollm_path` - Returns path to `.ollm` directory
   - `get_session_path` - Returns path to current session
   - `get_workspace_path` - Returns current working directory

## Testing

### Verify Snapshot Fix

1. Start the app
2. Have a conversation that triggers compression
3. Check that snapshots are created in:
   ```
   C:\Users\rad3k\.ollm\context-snapshots\{sessionId}\snapshots\
   ```
4. Verify no `session-*` folders in app directory

### Verify Session Recording (After Integration)

1. Start the app
2. Have a conversation
3. Check that session is saved in:
   ```
   C:\Users\rad3k\.ollm\sessions\{sessionId}.json
   ```
4. Use `/session list` command to see saved sessions
5. Use `/session load {id}` to restore a session

## Implementation Priority

### High Priority (Immediate)

1. ✅ **Fix snapshot storage path** - DONE
2. **Integrate ChatRecordingService** - Required for session persistence
3. **Add workspace context to system prompt** - Required for LLM to save files correctly

### Medium Priority (Soon)

1. **Add path helper tools** - Makes it easier for LLM to work with files
2. **Test session save/load workflow** - Verify everything works end-to-end
3. **Add session auto-save** - Save sessions automatically during conversation

### Low Priority (Future)

1. **Session migration** - Migrate old sessions from app directory to user directory
2. **Cleanup old session folders** - Remove `session-*` folders from app directory
3. **Session export/import** - Allow users to backup/restore sessions

## Files Modified

1. ✅ `packages/core/src/context/contextManager.ts` - Fixed snapshot storage initialization

## Files to Modify (Pending)

1. `packages/cli/src/features/context/ContextManagerContext.tsx` - Integrate ChatRecordingService
2. `packages/cli/src/commands/sessionCommands.ts` - Implement session commands
3. `packages/core/src/context/contextManager.ts` - Add session recording hooks
4. System prompt templates - Add workspace context information

## Related Documentation

- [Session Recovery](../../docs/Context/management/session-recovery.md)
- [Storage Migration](../../../packages/core/src/utils/storageMigration.ts)
- [Chat Recording Service](../../../packages/core/src/services/chatRecordingService.ts)
- [Snapshot Storage](../../../packages/core/src/context/snapshotStorage.ts)

---

**Status:** Snapshot storage fixed, session recording integration pending.
