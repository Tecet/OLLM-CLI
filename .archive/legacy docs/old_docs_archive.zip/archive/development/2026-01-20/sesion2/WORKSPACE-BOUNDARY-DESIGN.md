# Workspace Boundary System - Design

**Date:** January 21, 2026  
**Status:** Design Phase

## Overview

Implement a workspace boundary system that restricts LLM file access to:
1. **User-defined workspace** (project directory)
2. **OLLM data directories** (sessions, snapshots, config, etc.)

This prevents the LLM from accessing arbitrary files on the system while allowing it to work within defined boundaries.

## Requirements

### 1. Workspace Definition

**User sets workspace at startup:**
```bash
ollm --workspace "D:\Projects\MyApp"
ollm --workspace "C:\Users\rad3k\Documents\MyProject"
```

**Or via config:**
```yaml
# ~/.ollm/settings.json
{
  "workspace": {
    "path": "D:\\Projects\\MyApp",
    "allowSubdirectories": true
  }
}
```

**Default behavior:**
- If no workspace specified, use current working directory
- Workspace is always an absolute path
- Workspace can be changed during session (with confirmation)

### 2. Allowed Paths

**Always Allowed:**
```
~/.ollm/sessions/          - Session data
~/.ollm/context-snapshots/ - Context snapshots
~/.ollm/config/            - Configuration files
~/.ollm/cache/             - Cache data
~/.ollm/templates/         - User templates
~/.ollm/memory/            - Memory dumps
```

**Conditionally Allowed:**
```
{workspace}/               - User-defined project directory
{workspace}/**/*           - All subdirectories (if allowSubdirectories: true)
```

**Never Allowed:**
```
C:\Windows\                - System directories
C:\Program Files\          - Program directories
~/.ssh/                    - SSH keys
~/.aws/                    - AWS credentials
Any path outside workspace and .ollm directories
```

### 3. Path Validation

**Before any file operation:**
1. Resolve path to absolute path
2. Normalize path (handle `..`, `.`, symlinks)
3. Check if path is within allowed boundaries
4. If not allowed, reject with clear error message

**Example:**
```typescript
// User workspace: D:\Projects\MyApp
// LLM tries: write_file({ path: "../../../Windows/System32/file.txt" })

// Validation:
// 1. Resolve: D:\Windows\System32\file.txt
// 2. Check boundaries: NOT in workspace, NOT in .ollm
// 3. Reject: "Access denied: Path outside workspace boundary"
```

## Architecture

### 1. WorkspaceBoundary Service

```typescript
interface WorkspaceBoundaryConfig {
  workspacePath: string;
  allowSubdirectories: boolean;
  allowedOllmPaths: string[];
  blockedPaths: string[];
}

class WorkspaceBoundary {
  constructor(config: WorkspaceBoundaryConfig);
  
  // Check if path is allowed
  isPathAllowed(path: string): boolean;
  
  // Get normalized absolute path
  resolvePath(path: string): string;
  
  // Validate and resolve path (throws if not allowed)
  validatePath(path: string): string;
  
  // Get workspace info for LLM
  getWorkspaceInfo(): WorkspaceInfo;
  
  // Change workspace (requires confirmation)
  setWorkspace(newPath: string): Promise<void>;
}
```

### 2. Integration with Tools

**All file tools must validate paths:**
```typescript
// read-file.ts
async execute(signal: AbortSignal): Promise<ToolResult> {
  try {
    // Validate path before reading
    const validatedPath = this.workspaceBoundary.validatePath(this.params.path);
    
    // Read file
    const content = await fs.readFile(validatedPath, 'utf-8');
    // ...
  } catch (error) {
    if (error instanceof WorkspaceBoundaryError) {
      return {
        error: {
          message: error.message,
          type: 'WorkspaceBoundaryError',
        },
      };
    }
    // ...
  }
}
```

**Tools that need validation:**
- ✅ `read_file` - Read files
- ✅ `write_file` - Write files
- ✅ `edit_file` - Edit files
- ✅ `glob` - Search files
- ✅ `grep` - Search in files
- ✅ `ls` - List directory
- ✅ `shell` - Execute commands (validate cwd)

### 3. System Prompt Integration

**Add workspace context to system prompt:**
```
# Workspace Context

You are working in a restricted workspace with the following boundaries:

**Workspace Directory:**
- Path: D:\Projects\MyApp
- You can read, write, and search files within this directory
- All relative paths are resolved from this directory

**OLLM Data Directories:**
- Sessions: C:\Users\rad3k\.ollm\sessions
- Snapshots: C:\Users\rad3k\.ollm\context-snapshots
- Config: C:\Users\rad3k\.ollm\config
- You can access these directories for app-related data

**Restrictions:**
- You CANNOT access files outside the workspace directory
- You CANNOT access system directories (Windows, Program Files, etc.)
- You CANNOT access sensitive directories (.ssh, .aws, etc.)
- Attempting to access restricted paths will result in an error

**File Operations:**
- Use relative paths for files in the workspace: "src/main.ts"
- Use absolute paths for OLLM data: "C:\\Users\\rad3k\\.ollm\\sessions\\session.json"
- All paths are validated before execution
```

## Implementation Plan

### Phase 1: Core Boundary Service (2-3 hours)

1. **Create WorkspaceBoundary service** (`packages/core/src/workspace/workspaceBoundary.ts`)
   - Path validation logic
   - Allowed/blocked path checking
   - Path normalization and resolution
   - Error types and messages

2. **Add configuration** (`packages/core/src/config/types.ts`)
   - Add workspace config to settings
   - Default values
   - Validation

3. **Unit tests** (`packages/core/src/workspace/__tests__/workspaceBoundary.test.ts`)
   - Test path validation
   - Test boundary checking
   - Test edge cases (symlinks, .., etc.)
   - Test Windows-specific paths

### Phase 2: Tool Integration (2-3 hours)

1. **Update all file tools** to use WorkspaceBoundary
   - `read-file.ts`
   - `write-file.ts`
   - `edit-file.ts`
   - `glob.ts`
   - `grep.ts`
   - `ls.ts`
   - `shell.ts` (validate cwd)

2. **Add WorkspaceBoundary to ToolContext**
   ```typescript
   interface ToolContext {
     messageBus: MessageBus;
     policyEngine?: PolicyEngineInterface;
     workspaceBoundary: WorkspaceBoundary; // NEW
   }
   ```

3. **Integration tests**
   - Test tools respect boundaries
   - Test error messages
   - Test OLLM data access

### Phase 3: CLI Integration (1-2 hours)

1. **Add workspace flag** to CLI
   ```bash
   ollm --workspace "D:\Projects\MyApp"
   ```

2. **Initialize WorkspaceBoundary** in app startup
   - Read from config or CLI flag
   - Default to current working directory
   - Pass to all tools

3. **Add workspace info to system prompt**
   - Generate workspace context section
   - Include in all prompts
   - Update on workspace change

4. **Add workspace commands**
   ```bash
   /workspace info          # Show current workspace
   /workspace set <path>    # Change workspace (with confirmation)
   /workspace allowed       # List allowed paths
   ```

### Phase 4: UI Integration (1 hour)

1. **Show workspace in status bar**
   ```
   Workspace: D:\Projects\MyApp | Context: 4K | Model: qwen2.5:7b
   ```

2. **Workspace change confirmation dialog**
   - Show old and new workspace
   - Warn about access changes
   - Require explicit confirmation

3. **Error display for boundary violations**
   - Clear error messages
   - Show attempted path
   - Show allowed boundaries

## Security Considerations

### 1. Path Traversal Prevention

**Attack:** LLM tries `../../../../../../etc/passwd`

**Defense:**
```typescript
// Normalize and resolve path
const resolved = path.resolve(workspacePath, userPath);

// Check if resolved path starts with workspace
if (!resolved.startsWith(workspacePath)) {
  throw new WorkspaceBoundaryError('Path outside workspace');
}
```

### 2. Symlink Handling

**Attack:** LLM creates symlink to sensitive directory

**Defense:**
```typescript
// Resolve symlinks before checking
const realPath = await fs.realpath(resolved);

// Check real path against boundaries
if (!isPathAllowed(realPath)) {
  throw new WorkspaceBoundaryError('Symlink target outside workspace');
}
```

### 3. Case Sensitivity (Windows)

**Attack:** LLM uses different case to bypass checks

**Defense:**
```typescript
// Normalize case on Windows
const normalizedPath = process.platform === 'win32' 
  ? resolved.toLowerCase() 
  : resolved;

const normalizedWorkspace = process.platform === 'win32'
  ? workspacePath.toLowerCase()
  : workspacePath;

if (!normalizedPath.startsWith(normalizedWorkspace)) {
  throw new WorkspaceBoundaryError('Path outside workspace');
}
```

### 4. Blocked Paths

**Always block these patterns:**
```typescript
const BLOCKED_PATTERNS = [
  /^C:\\Windows\\/i,           // Windows system
  /^C:\\Program Files/i,       // Program files
  /^\/etc\//,                  // Linux system config
  /^\/sys\//,                  // Linux system
  /^\/proc\//,                 // Linux processes
  /\.ssh\//,                   // SSH keys
  /\.aws\//,                   // AWS credentials
  /\.kube\//,                  // Kubernetes config
  /\.docker\//,                // Docker config
];
```

## User Experience

### Good Error Messages

**Instead of:**
```
Error: EACCES: permission denied
```

**Show:**
```
❌ Access Denied: Path Outside Workspace

Attempted path: C:\Windows\System32\file.txt
Workspace: D:\Projects\MyApp

You can only access files within:
  • Workspace: D:\Projects\MyApp
  • OLLM Data: C:\Users\rad3k\.ollm

To access files outside the workspace, change your workspace:
  /workspace set "C:\Windows"
```

### Workspace Change Confirmation

```
⚠️  Change Workspace?

Current: D:\Projects\MyApp
New:     D:\Projects\OtherApp

This will:
  • Change file access boundaries
  • Start a new session
  • Save current session

Continue? (y/n)
```

## Configuration Example

```json
{
  "workspace": {
    "path": "D:\\Projects\\MyApp",
    "allowSubdirectories": true,
    "allowedOllmPaths": [
      "sessions",
      "context-snapshots",
      "config",
      "cache",
      "templates",
      "memory"
    ],
    "blockedPaths": [
      "C:\\Windows",
      "C:\\Program Files",
      ".ssh",
      ".aws"
    ],
    "enforceStrict": true
  }
}
```

## Testing Strategy

### Unit Tests

1. **Path validation**
   - Valid workspace paths
   - Valid OLLM paths
   - Invalid paths (outside boundaries)
   - Path traversal attempts
   - Symlink handling

2. **Edge cases**
   - Relative paths
   - Absolute paths
   - Mixed separators (\ and /)
   - Case sensitivity (Windows)
   - Unicode paths

### Integration Tests

1. **Tool integration**
   - All file tools respect boundaries
   - Error messages are clear
   - OLLM data access works

2. **End-to-end**
   - Start app with workspace
   - LLM tries to access files
   - Boundary violations are caught
   - Allowed operations succeed

## Benefits

1. **Security** - Prevents LLM from accessing sensitive files
2. **Organization** - Keeps LLM focused on project files
3. **Clarity** - LLM knows exactly where it can work
4. **Safety** - Prevents accidental system file modifications
5. **User Control** - User explicitly defines boundaries

## Future Enhancements

1. **Multiple workspaces** - Switch between projects
2. **Workspace templates** - Pre-configured workspace settings
3. **Workspace history** - Remember recent workspaces
4. **Workspace profiles** - Different settings per workspace
5. **Workspace sharing** - Export/import workspace configs

---

**Next Steps:** Implement Phase 1 (Core Boundary Service)
