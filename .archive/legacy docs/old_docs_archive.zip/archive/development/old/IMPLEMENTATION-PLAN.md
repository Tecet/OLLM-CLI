# Context System Implementation Plan

**Date:** January 20, 2026  
**Status:** Ready for Implementation  
**Priority:** HIGH

---

## Current State

### ✅ Phase 0: Audit & Critical Fixes (COMPLETE)

**What was fixed:**
1. ✅ Floating-point threshold comparison bug
2. ✅ Duplicate callback registration
3. ✅ Memory guard compression API mismatch
4. ✅ Resume loop prevention (max 3 retries)
5. ✅ Inflight token race condition
6. ✅ Threshold unit normalization

**Result:** System no longer has infinite loops, compression triggers correctly

### ✅ Phase 1: Progressive Checkpoints (COMPLETE)

**What was built:**
1. ✅ Additive checkpoint system
2. ✅ Hierarchical compression (3 levels: COMPACT, MODERATE, DETAILED)
3. ✅ Checkpoint aging and merging
4. ✅ Maximum 10 checkpoints with automatic merging
5. ✅ Test suite for progressive checkpoints

**Result:** Basic checkpoint system working, prevents concept drift

---

## Phase 2: Adaptive Context System (NEXT)

### Goal
Implement context-size-aware and mode-aware compression that adapts to different scenarios.

### Target
**Tier 3 (16-32K contexts)** - where 90% of local LLM users operate

### Key Features
1. Context tier detection (4 tiers: 2-8K, 8-16K, 16-32K, 32K+)
2. Mode-specific profiles (Developer, Planning, Assistant, Debugger)
3. Never-compressed sections (task definition, architecture decisions)
4. Enhanced progressive checkpoints for Tier 3
5. Rollover mechanism for Tier 1
6. Smart compression for Tier 2

---

## Code Audit Summary

**See:** `.dev/docs/Context/CODE-AUDIT.md` for detailed analysis

**Key Findings:**
- ✅ Checkpoint system already implemented (Phase 1)
- ✅ Compression infrastructure ready
- ✅ Event system in place
- ⚠️ Need to add operational modes (separate from routing profiles)
- ❌ No context status UI component
- ❌ No tier detection system

**Alignment:** Good - no major conflicts, mostly additive changes

---

## Implementation Tasks

### Task 1: Add Context Tier Detection (2 hours)

**File:** `packages/core/src/context/types.ts`

**Add:**
```typescript
export enum ContextTier {
  TIER_1_MINIMAL = '2-4K',
  TIER_2_BASIC = '4-8K',
  TIER_3_STANDARD = '8-32K',
  TIER_4_PREMIUM = '32-64K',
  TIER_5_ULTRA = '64K+'
}

export interface TierConfig {
  tier: ContextTier;
  minTokens: number;
  maxTokens: number;
  strategy: 'rollover' | 'smart' | 'progressive' | 'structured';
  maxCheckpoints: number;
  utilizationTarget: number; // 0.7 = 70%
}

export const TIER_CONFIGS: Record<ContextTier, TierConfig> = {
  [ContextTier.TIER_1_MINIMAL]: {
    tier: ContextTier.TIER_1_MINIMAL,
    minTokens: 2048,
    maxTokens: 4096,
    strategy: 'rollover',
    maxCheckpoints: 0,
    utilizationTarget: 0.90
  },
  [ContextTier.TIER_2_BASIC]: {
    tier: ContextTier.TIER_2_BASIC,
    minTokens: 4096,
    maxTokens: 8192,
    strategy: 'smart',
    maxCheckpoints: 1,
    utilizationTarget: 0.80
  },
  [ContextTier.TIER_3_STANDARD]: {
    tier: ContextTier.TIER_3_STANDARD,
    minTokens: 8192,
    maxTokens: 32768,
    strategy: 'progressive',
    maxCheckpoints: 5,
    utilizationTarget: 0.70
  },
  [ContextTier.TIER_4_PREMIUM]: {
    tier: ContextTier.TIER_4_PREMIUM,
    minTokens: 32768,
    maxTokens: 65536,
    strategy: 'structured',
    maxCheckpoints: 10,
    utilizationTarget: 0.70
  },
  [ContextTier.TIER_5_ULTRA]: {
    tier: ContextTier.TIER_5_ULTRA,
    minTokens: 65536,
    maxTokens: 131072,
    strategy: 'structured',
    maxCheckpoints: 15,
    utilizationTarget: 0.65
  }
};
```

**File:** `packages/core/src/context/contextManager.ts`

**Add method:**
```typescript
private detectContextTier(): TierConfig {
  const maxTokens = this.config.maxTokens;
  
  if (maxTokens <= 8192) return TIER_CONFIGS[ContextTier.TIER_1_MINIMAL];
  if (maxTokens <= 16384) return TIER_CONFIGS[ContextTier.TIER_2_BASIC];
  if (maxTokens <= 32768) return TIER_CONFIGS[ContextTier.TIER_3_STANDARD];
  return TIER_CONFIGS[ContextTier.TIER_4_PREMIUM];
}
```

**Tests:**
- Test tier detection for each range
- Test tier config retrieval
- Test boundary conditions (8192, 16384, 32768)

---

### Task 2: Add Mode Profiles (3 hours)

**File:** `packages/core/src/context/types.ts`

**Add:**
```typescript
export enum OperationalMode {
  DEVELOPER = 'developer',
  PLANNING = 'planning',
  ASSISTANT = 'assistant',
  DEBUGGER = 'debugger'
}

export interface ModeProfile {
  mode: OperationalMode;
  neverCompress: string[]; // Section types to never compress
  compressionPriority: string[]; // Order to compress (first = compress first)
  extractionRules?: Record<string, RegExp>; // Patterns to extract
}

export const MODE_PROFILES: Record<OperationalMode, ModeProfile> = {
  [OperationalMode.DEVELOPER]: {
    mode: OperationalMode.DEVELOPER,
    neverCompress: ['architecture_decisions', 'api_contracts', 'data_models'],
    compressionPriority: ['discussion', 'exploration', 'dependencies', 'tests', 'file_structure', 'code_changes'],
    extractionRules: {
      architecture_decision: /(?:decided|chose|using|implementing)\s+(\w+)\s+(?:because|for|to)/i,
      file_change: /(?:created|modified|updated|changed)\s+([^\s]+\.\w+)/i,
      api_definition: /(?:interface|class|function|endpoint)\s+(\w+)/i
    }
  },
  [OperationalMode.PLANNING]: {
    mode: OperationalMode.PLANNING,
    neverCompress: ['goals', 'requirements', 'constraints'],
    compressionPriority: ['brainstorming', 'rejected_ideas', 'resources', 'timeline', 'dependencies', 'tasks'],
    extractionRules: {
      requirement: /(?:must|should|need to|required to)\s+(.+?)(?:\.|$)/i,
      task: /(?:task|step|action):\s*(.+?)(?:\.|$)/i,
      milestone: /(?:milestone|deadline|due):\s*(.+?)(?:\.|$)/i
    }
  },
  [OperationalMode.ASSISTANT]: {
    mode: OperationalMode.ASSISTANT,
    neverCompress: ['user_preferences', 'conversation_context'],
    compressionPriority: ['small_talk', 'clarifications', 'examples', 'explanations', 'questions'],
    extractionRules: {
      preference: /(?:prefer|like|want|need)\s+(.+?)(?:\.|$)/i,
      important: /(?:important|critical|must remember)\s+(.+?)(?:\.|$)/i
    }
  },
  [OperationalMode.DEBUGGER]: {
    mode: OperationalMode.DEBUGGER,
    neverCompress: ['error_messages', 'stack_traces', 'reproduction_steps'],
    compressionPriority: ['discussion', 'successful_tests', 'environment', 'test_results', 'fixes_attempted'],
    extractionRules: {
      error: /(?:error|exception|failed):\s*(.+?)(?:\n|$)/i,
      fix_attempt: /(?:tried|attempted|fixed)\s+(.+?)(?:\.|$)/i,
      reproduction: /(?:reproduce|replicate|steps):\s*(.+?)(?:\.|$)/i
    }
  }
};
```

**File:** `packages/core/src/context/contextManager.ts`

**Add:**
```typescript
private currentMode: OperationalMode = OperationalMode.DEVELOPER;
private modeProfile: ModeProfile = MODE_PROFILES[OperationalMode.DEVELOPER];

public setMode(mode: OperationalMode): void {
  this.currentMode = mode;
  this.modeProfile = MODE_PROFILES[mode];
  this.emit('mode-changed', { mode, profile: this.modeProfile });
}

public getMode(): OperationalMode {
  return this.currentMode;
}
```

**Tests:**
- Test mode profile retrieval
- Test mode switching
- Test extraction rules
- Test never-compress sections

---

### Task 3: Add Adaptive System Prompts (3 hours) ⭐ NEW

**Concept:** System prompt complexity should match context capacity and operational mode

**File:** `packages/core/src/context/types.ts`

**Add:**
```typescript
export interface SystemPromptTemplate {
  tier: ContextTier;
  mode: OperationalMode;
  template: string;
  tokenBudget: number; // How many tokens this prompt uses
}

export const SYSTEM_PROMPT_TEMPLATES: Record<string, SystemPromptTemplate> = {
  // Tier 1 (2-8K) - Minimal prompts
  'tier1-developer': {
    tier: ContextTier.TIER_1_MINIMAL,
    mode: OperationalMode.DEVELOPER,
    template: 'You are a coding assistant. Be concise.',
    tokenBudget: 50
  },
  'tier1-planning': {
    tier: ContextTier.TIER_1_MINIMAL,
    mode: OperationalMode.PLANNING,
    template: 'You help plan tasks. Be brief.',
    tokenBudget: 50
  },
  
  // Tier 2 (8-16K) - Basic prompts
  'tier2-developer': {
    tier: ContextTier.TIER_2_BASIC,
    mode: OperationalMode.DEVELOPER,
    template: `You are an expert coding assistant.
- Write clean, maintainable code
- Follow best practices
- Explain your decisions briefly`,
    tokenBudget: 150
  },
  'tier2-planning': {
    tier: ContextTier.TIER_2_BASIC,
    mode: OperationalMode.PLANNING,
    template: `You help plan and organize tasks.
- Break down complex goals
- Identify dependencies
- Suggest priorities`,
    tokenBudget: 150
  },
  
  // Tier 3 (16-32K) - Detailed prompts ⭐ PRIMARY
  'tier3-developer': {
    tier: ContextTier.TIER_3_STANDARD,
    mode: OperationalMode.DEVELOPER,
    template: `You are an expert software developer and architect.

Core Responsibilities:
- Write production-quality code with proper error handling
- Design scalable, maintainable architectures
- Follow SOLID principles and design patterns
- Document architectural decisions and rationale
- Consider performance, security, and accessibility

Code Quality Standards:
- Use TypeScript with strict mode
- Write comprehensive tests
- Add clear comments for complex logic
- Follow project conventions

When Making Decisions:
- Explain your architectural choices
- Consider trade-offs and alternatives
- Document why you chose this approach
- Think about long-term maintenance`,
    tokenBudget: 400
  },
  'tier3-planning': {
    tier: ContextTier.TIER_3_STANDARD,
    mode: OperationalMode.PLANNING,
    template: `You are an expert project planner and strategist.

Core Responsibilities:
- Break down complex projects into manageable tasks
- Identify dependencies and critical paths
- Estimate effort and timeline realistically
- Anticipate risks and plan mitigation
- Define clear success criteria

Planning Approach:
- Start with goals and requirements
- Work backwards from desired outcome
- Consider resource constraints
- Plan for iteration and feedback
- Document assumptions and decisions

Task Breakdown:
- Each task should be completable in 1-4 hours
- Clear acceptance criteria
- Explicit dependencies
- Risk assessment`,
    tokenBudget: 400
  },
  'tier3-assistant': {
    tier: ContextTier.TIER_3_STANDARD,
    mode: OperationalMode.ASSISTANT,
    template: `You are a helpful, knowledgeable assistant.

Core Responsibilities:
- Provide accurate, well-researched information
- Explain complex topics clearly
- Adapt communication style to user needs
- Remember user preferences and context
- Ask clarifying questions when needed

Communication Style:
- Be conversational but professional
- Use examples to illustrate concepts
- Break down complex ideas
- Acknowledge uncertainty
- Provide sources when relevant`,
    tokenBudget: 350
  },
  'tier3-debugger': {
    tier: ContextTier.TIER_3_STANDARD,
    mode: OperationalMode.DEBUGGER,
    template: `You are an expert debugger and problem solver.

Core Responsibilities:
- Analyze error messages and stack traces
- Identify root causes, not just symptoms
- Suggest systematic debugging approaches
- Provide clear reproduction steps
- Document fixes and prevention strategies

Debugging Process:
1. Understand the expected behavior
2. Identify what's actually happening
3. Isolate the problem area
4. Form hypotheses about the cause
5. Test hypotheses systematically
6. Verify the fix works
7. Document for future reference

When Analyzing Errors:
- Read the full stack trace
- Check recent code changes
- Consider environment differences
- Look for common patterns
- Test edge cases`,
    tokenBudget: 450
  },
  
  // Tier 4 (32K+) - Comprehensive prompts
  'tier4-developer': {
    tier: ContextTier.TIER_4_PREMIUM,
    mode: OperationalMode.DEVELOPER,
    template: `You are a senior software architect and technical lead with deep expertise across the full stack.

Core Responsibilities:
- Design and implement production-grade systems
- Make architectural decisions with long-term impact
- Mentor through code reviews and documentation
- Balance technical excellence with pragmatic delivery
- Consider scalability, performance, security, and maintainability

Technical Excellence:
- Write clean, self-documenting code
- Apply SOLID principles and design patterns appropriately
- Use TypeScript with strict mode and comprehensive types
- Implement proper error handling and logging
- Write tests at appropriate levels (unit, integration, e2e)
- Consider edge cases and failure modes
- Optimize for readability and maintainability first

Architectural Thinking:
- Start with requirements and constraints
- Consider multiple approaches and trade-offs
- Document decisions and rationale
- Think about evolution and future changes
- Plan for monitoring and observability
- Consider operational concerns (deployment, scaling, debugging)

Code Review Mindset:
- Look for potential bugs and edge cases
- Suggest improvements to clarity and maintainability
- Identify performance bottlenecks
- Check for security vulnerabilities
- Ensure tests cover critical paths
- Verify error handling is comprehensive

Communication:
- Explain complex concepts clearly
- Provide context for decisions
- Share knowledge through documentation
- Ask clarifying questions
- Acknowledge trade-offs and limitations
- Be specific about implementation details

When Solving Problems:
1. Understand the full context and requirements
2. Consider multiple approaches
3. Evaluate trade-offs (performance, complexity, maintainability)
4. Choose the simplest solution that meets requirements
5. Document the decision and rationale
6. Implement with proper error handling
7. Add tests to prevent regressions
8. Consider how this fits into the larger system`,
    tokenBudget: 800
  },
  'tier4-planning': {
    tier: ContextTier.TIER_4_PREMIUM,
    mode: OperationalMode.PLANNING,
    template: `You are an expert technical project manager and strategic planner with deep experience in software development.

Core Responsibilities:
- Transform vague ideas into concrete, actionable plans
- Break down complex projects into manageable phases
- Identify dependencies, risks, and critical paths
- Estimate effort realistically based on complexity
- Define clear success criteria and milestones
- Plan for iteration, feedback, and course correction

Strategic Planning:
- Start with the end goal and work backwards
- Understand stakeholder needs and constraints
- Consider technical feasibility and resource availability
- Plan for both happy path and failure scenarios
- Build in time for learning and discovery
- Document assumptions and decision points

Task Breakdown Methodology:
- Each task should be completable in 1-4 hours
- Clear, testable acceptance criteria
- Explicit dependencies and prerequisites
- Risk level and mitigation strategies
- Required skills and resources
- Definition of done

Risk Management:
- Identify technical risks early
- Plan mitigation strategies
- Build in buffer for unknowns
- Have fallback options
- Monitor and adjust as needed

Communication:
- Document decisions and rationale
- Explain trade-offs clearly
- Keep stakeholders informed
- Ask clarifying questions
- Acknowledge uncertainty
- Provide regular status updates

When Creating Plans:
1. Clarify goals and success criteria
2. Identify constraints and requirements
3. Break down into phases/milestones
4. Decompose into specific tasks
5. Identify dependencies
6. Estimate effort realistically
7. Assess risks and plan mitigation
8. Define metrics for tracking progress
9. Plan for iteration and feedback
10. Document assumptions and decisions`,
    tokenBudget: 800
  }
};
```

**File:** `packages/core/src/context/contextManager.ts`

**Add methods:**
```typescript
private getSystemPromptForTierAndMode(): string {
  const tier = this.detectContextTier();
  const mode = this.currentMode;
  
  const key = `tier${tier.tier.split('-')[0]}-${mode}`;
  const template = SYSTEM_PROMPT_TEMPLATES[key];
  
  if (!template) {
    // Fallback to tier 3 developer
    return SYSTEM_PROMPT_TEMPLATES['tier3-developer'].template;
  }
  
  return template.template;
}

public updateSystemPrompt(): void {
  const newPrompt = this.getSystemPromptForTierAndMode();
  this.setSystemPrompt(newPrompt);
  this.emit('system-prompt-updated', { 
    tier: this.currentTier,
    mode: this.currentMode,
    tokenBudget: this.getSystemPromptTokenBudget()
  });
}

private getSystemPromptTokenBudget(): number {
  const tier = this.detectContextTier();
  const mode = this.currentMode;
  const key = `tier${tier.tier.split('-')[0]}-${mode}`;
  const template = SYSTEM_PROMPT_TEMPLATES[key];
  return template?.tokenBudget || 400;
}

// Call this when tier or mode changes
private onTierOrModeChange(): void {
  this.updateSystemPrompt();
  // Recalculate available tokens
  const usage = this.getUsage();
  this.emit('context-recalculated', { usage });
}
```

**Token Budget Strategy:**
```
Tier 1 (2-8K):   50 tokens  (0.6% of 8K)
Tier 2 (8-16K):  150 tokens (0.9% of 16K)
Tier 3 (16-32K): 400 tokens (1.2% of 32K) ⭐
Tier 4 (32K+):   800 tokens (0.6% of 128K)
```

**Benefits:**
- ✅ Small contexts get concise prompts (more room for work)
- ✅ Large contexts get detailed guidance (better quality)
- ✅ Mode-specific instructions (developer vs planning)
- ✅ Automatic adjustment on tier/mode change
- ✅ Token budget scales with context size

**Tests:**
- Test prompt selection for each tier/mode combination
- Test token budget calculation
- Test automatic update on tier change
- Test automatic update on mode change
- Test fallback to default prompt

---

### Task 4: Add Never-Compressed Sections (4 hours)

**File:** `packages/core/src/context/types.ts`

**Add:**
```typescript
export interface NeverCompressedSection {
  type: string; // 'task_definition', 'architecture_decision', etc.
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface TaskDefinition {
  goal: string;
  requirements: string[];
  constraints: string[];
  timestamp: Date;
}

export interface ArchitectureDecision {
  id: string;
  decision: string;
  reason: string;
  impact: string;
  timestamp: Date;
  alternatives?: string[];
}
```

**Update ConversationContext:**
```typescript
export interface ConversationContext {
  // ... existing fields
  taskDefinition?: TaskDefinition;
  architectureDecisions: ArchitectureDecision[];
  neverCompressed: NeverCompressedSection[];
}
```

**File:** `packages/core/src/context/contextManager.ts`

**Add methods:**
```typescript
public setTaskDefinition(task: TaskDefinition): void {
  this.currentContext.taskDefinition = task;
  this.emit('task-defined', { task });
}

public addArchitectureDecision(decision: ArchitectureDecision): void {
  this.currentContext.architectureDecisions.push(decision);
  this.emit('architecture-decision', { decision });
}

public addNeverCompressed(section: NeverCompressedSection): void {
  this.currentContext.neverCompressed.push(section);
  this.emit('never-compressed-added', { section });
}

private preserveNeverCompressed(context: ConversationContext): NeverCompressedSection[] {
  const preserved: NeverCompressedSection[] = [];
  
  // Add task definition
  if (context.taskDefinition) {
    preserved.push({
      type: 'task_definition',
      content: JSON.stringify(context.taskDefinition),
      timestamp: context.taskDefinition.timestamp
    });
  }
  
  // Add architecture decisions
  for (const decision of context.architectureDecisions) {
    preserved.push({
      type: 'architecture_decision',
      content: JSON.stringify(decision),
      timestamp: decision.timestamp,
      metadata: { id: decision.id }
    });
  }
  
  // Add explicit never-compressed sections
  preserved.push(...context.neverCompressed);
  
  return preserved;
}
```

**Tests:**
- Test task definition storage
- Test architecture decision tracking
- Test never-compressed preservation
- Test reconstruction after compression

---

### Task 4: Enhance Progressive Checkpoints for Tier 3 (4 hours)

**File:** `packages/core/src/context/contextManager.ts`

**Update compression logic:**
```typescript
private async compressForTier3(): Promise<CompressedContext> {
  const tier = this.detectContextTier();
  const profile = this.modeProfile;
  
  // Preserve never-compressed sections
  const preserved = this.preserveNeverCompressed(this.currentContext);
  
  // Create checkpoint with mode-aware extraction
  const checkpoint = await this.createModeAwareCheckpoint(
    this.currentContext.messages,
    profile
  );
  
  // Add to checkpoint history
  this.checkpoints.push(checkpoint);
  
  // Age old checkpoints
  this.compressOldCheckpoints();
  
  // Merge if over limit
  if (this.checkpoints.length > tier.maxCheckpoints) {
    this.mergeOldestCheckpoints();
  }
  
  // Reconstruct context
  return {
    messages: [
      ...this.reconstructNeverCompressed(preserved),
      ...this.reconstructCheckpoints(),
      ...this.getRecentMessages(4096)
    ],
    summary: checkpoint.summary,
    metadata: {
      tier: tier.tier,
      mode: profile.mode,
      checkpointCount: this.checkpoints.length,
      preservedSections: preserved.length
    }
  };
}

private async createModeAwareCheckpoint(
  messages: Message[],
  profile: ModeProfile
): Promise<CompressionCheckpoint> {
  // Extract important information based on mode
  const extracted = this.extractByMode(messages, profile);
  
  // Create summary with extracted info
  const summary = await this.generateSummary(messages, {
    preservePatterns: profile.extractionRules,
    neverCompress: profile.neverCompress
  });
  
  return {
    id: generateId(),
    level: CheckpointLevel.DETAILED,
    range: `Messages ${messages[0].id} - ${messages[messages.length - 1].id}`,
    summary,
    keyDecisions: extracted.decisions,
    filesModified: extracted.files,
    createdAt: new Date(),
    compressedAt: undefined
  };
}
```

**Tests:**
- Test Tier 3 compression
- Test mode-aware extraction
- Test never-compressed preservation
- Test checkpoint reconstruction

---

### Task 5: Implement Rollover for Tier 1 (3 hours)

**File:** `packages/core/src/context/contextManager.ts`

**Add:**
```typescript
private async rolloverContext(): Promise<void> {
  // Create snapshot
  const snapshot = await this.snapshotManager.createSnapshot(
    this.currentContext,
    { reason: 'rollover', auto: true }
  );
  
  // Generate ultra-compact summary (200-300 tokens)
  const summary = await this.generateCompactSummary(
    this.currentContext.messages,
    { maxTokens: 300 }
  );
  
  // Reset context
  this.currentContext = {
    ...this.currentContext,
    messages: [],
    checkpoints: [],
    neverCompressed: []
  };
  
  // Add summary as system message
  this.addMessage({
    role: 'system',
    content: `[Previous conversation summary]\n${summary}`,
    excludeFromContext: false
  });
  
  this.emit('rollover-complete', { snapshot, summary });
}

private async generateCompactSummary(
  messages: Message[],
  options: { maxTokens: number }
): Promise<string> {
  // Ultra-compact summary for Tier 1
  const keyPoints = messages
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .slice(-10) // Last 10 exchanges
    .map(m => `${m.role}: ${m.content.substring(0, 100)}...`)
    .join('\n');
  
  return `Session summary (${messages.length} messages):\n${keyPoints}`;
}
```

**Tests:**
- Test rollover trigger at 90%
- Test snapshot creation
- Test summary generation
- Test context reset
- Test continuation after rollover

---

### Task 6: Implement Rollover for Tier 1 (3 hours)

**File:** `packages/core/src/context/contextManager.ts`

**Add:**
```typescript
private async compressForTier2(): Promise<CompressedContext> {
  const profile = this.modeProfile;
  
  // Extract critical information
  const critical = this.extractCritical(this.currentContext.messages, profile);
  
  // Create ONE detailed checkpoint
  const checkpoint = await this.createDetailedCheckpoint(
    this.currentContext.messages.slice(0, -20) // All but recent 20
  );
  
  // Keep recent messages
  const recent = this.currentContext.messages.slice(-20);
  
  return {
    messages: [
      ...this.reconstructCritical(critical),
      ...this.reconstructCheckpoint(checkpoint),
      ...recent
    ],
    summary: checkpoint.summary,
    metadata: {
      tier: ContextTier.TIER_2_BASIC,
      mode: profile.mode,
      criticalSections: critical.length
    }
  };
}

private extractCritical(
  messages: Message[],
  profile: ModeProfile
): NeverCompressedSection[] {
  const critical: NeverCompressedSection[] = [];
  
  for (const message of messages) {
    for (const [type, pattern] of Object.entries(profile.extractionRules || {})) {
      const matches = message.content.match(pattern);
      if (matches && profile.neverCompress.includes(type)) {
        critical.push({
          type,
          content: matches[0],
          timestamp: new Date(),
          metadata: { messageId: message.id }
        });
      }
    }
  }
  
  return critical;
}
```

**Tests:**
- Test Tier 2 compression
- Test critical extraction
- Test single checkpoint creation
- Test reconstruction

---

### Task 7: Implement Smart Compression for Tier 2 (3 hours)

**File:** `packages/core/src/context/contextManager.ts`

**Add:**
```typescript
private async compressForTier2(): Promise<CompressedContext> {
  const profile = this.modeProfile;
  
  // Extract critical information
  const critical = this.extractCritical(this.currentContext.messages, profile);
  
  // Create ONE detailed checkpoint
  const checkpoint = await this.createDetailedCheckpoint(
    this.currentContext.messages.slice(0, -20) // All but recent 20
  );
  
  // Keep recent messages
  const recent = this.currentContext.messages.slice(-20);
  
  return {
    messages: [
      ...this.reconstructCritical(critical),
      ...this.reconstructCheckpoint(checkpoint),
      ...recent
    ],
    summary: checkpoint.summary,
    metadata: {
      tier: ContextTier.TIER_2_BASIC,
      mode: profile.mode,
      criticalSections: critical.length
    }
  };
}

private extractCritical(
  messages: Message[],
  profile: ModeProfile
): NeverCompressedSection[] {
  const critical: NeverCompressedSection[] = [];
  
  for (const message of messages) {
    for (const [type, pattern] of Object.entries(profile.extractionRules || {})) {
      const matches = message.content.match(pattern);
      if (matches && profile.neverCompress.includes(type)) {
        critical.push({
          type,
          content: matches[0],
          timestamp: new Date(),
          metadata: { messageId: message.id }
        });
      }
    }
  }
  
  return critical;
}
```

**Tests:**
- Test Tier 2 compression
- Test critical extraction
- Test single checkpoint creation
- Test reconstruction

---

### Task 8: Update Test Suite (4 hours)

**Create:** `packages/core/src/context/__tests__/adaptive-compression.test.ts`

**Tests:**
```typescript
describe('Adaptive Context Compression', () => {
  describe('Tier Detection', () => {
    it('should detect Tier 1 for 2-8K contexts', () => {});
    it('should detect Tier 2 for 8-16K contexts', () => {});
    it('should detect Tier 3 for 16-32K contexts', () => {});
    it('should detect Tier 4 for 32K+ contexts', () => {});
  });
  
  describe('Mode Profiles', () => {
    it('should load developer mode profile', () => {});
    it('should load planning mode profile', () => {});
    it('should load assistant mode profile', () => {});
    it('should load debugger mode profile', () => {});
    it('should switch modes correctly', () => {});
  });
  
  describe('Never-Compressed Sections', () => {
    it('should preserve task definition', () => {});
    it('should preserve architecture decisions', () => {});
    it('should preserve explicit never-compressed sections', () => {});
    it('should reconstruct after compression', () => {});
  });
  
  describe('Tier 1: Rollover', () => {
    it('should trigger rollover at 90%', () => {});
    it('should create snapshot', () => {});
    it('should generate compact summary', () => {});
    it('should reset context', () => {});
  });
  
  describe('Tier 2: Smart Compression', () => {
    it('should trigger at 75%', () => {});
    it('should extract critical info', () => {});
    it('should create single checkpoint', () => {});
    it('should preserve recent messages', () => {});
  });
  
  describe('Tier 3: Progressive Checkpoints', () => {
    it('should trigger at 70%', () => {});
    it('should create mode-aware checkpoints', () => {});
    it('should preserve never-compressed sections', () => {});
    it('should maintain checkpoint hierarchy', () => {});
    it('should limit to 5 checkpoints', () => {});
  });
  
  describe('Integration', () => {
    it('should handle full conversation 0% -> 95%', () => {});
    it('should switch tiers when context size changes', () => {});
    it('should switch modes without data loss', () => {});
  });
});
```

**Update existing tests:**
- Update `progressive-checkpoints.test.ts` to work with Tier 3
- Add tier detection to all compression tests
- Add mode profile tests

---

### Task 9: Create Context Status UI Component (4 hours) ⭐ NEW

**File:** `packages/cli/src/ui/components/status/ContextStatus.tsx`

**Create:**
```typescript
import React from 'react';
import { Box, Text } from 'ink';
import { useContextManager } from '../../../features/context/ContextManagerContext.js';

export const ContextStatus: React.FC = () => {
  const context = useContextManager();
  
  if (!context) return null;
  
  const { usage, mode, tier, checkpointStats, neverCompressedCount } = context;
  
  return (
    <Box flexDirection="column" borderStyle="round" borderColor="cyan" padding={1}>
      <Text bold color="cyan">Context Status</Text>
      
      {/* Mode Display */}
      <Box marginTop={1}>
        <Text>Mode: </Text>
        <Text bold color="green">{mode || 'Developer'}</Text>
      </Box>
      
      {/* Tier Display */}
      <Box>
        <Text>Tier: </Text>
        <Text bold color="yellow">
          {tier ? `Level ${tier.split('-')[0]} (${tier})` : 'Detecting...'}
        </Text>
      </Box>
      
      {/* Strategy Display */}
      <Box>
        <Text>Strategy: </Text>
        <Text bold color="blue">{getTierStrategy(tier)}</Text>
      </Box>
      
      {/* Usage Display */}
      {usage && (
        <Box marginTop={1} flexDirection="column">
          <Text>Usage: {usage.currentTokens.toLocaleString()} / {usage.maxTokens.toLocaleString()}</Text>
          <Box>
            <Text>├─ </Text>
            <Text color={getUsageColor(usage.percentage)}>
              {usage.percentage.toFixed(1)}% utilized
            </Text>
          </Box>
          <Box>
            <Text>└─ </Text>
            <Text>{(usage.maxTokens - usage.currentTokens).toLocaleString()} tokens available</Text>
          </Box>
        </Box>
      )}
      
      {/* Checkpoints Display */}
      {checkpointStats && (
        <Box marginTop={1} flexDirection="column">
          <Text>Checkpoints: {checkpointStats.total}</Text>
          <Box><Text>├─ Compact: {checkpointStats.byLevel.compact}</Text></Box>
          <Box><Text>├─ Moderate: {checkpointStats.byLevel.moderate}</Text></Box>
          <Box><Text>└─ Detailed: {checkpointStats.byLevel.detailed}</Text></Box>
        </Box>
      )}
      
      {/* Never-Compressed Display */}
      {neverCompressedCount > 0 && (
        <Box marginTop={1} flexDirection="column">
          <Text>Never-Compressed: {neverCompressedCount} sections</Text>
        </Box>
      )}
    </Box>
  );
};

function getTierStrategy(tier: string | null): string {
  if (!tier) return 'Progressive';
  if (tier.includes('2-8K')) return 'Rollover';
  if (tier.includes('8-16K')) return 'Smart';
  if (tier.includes('16-32K')) return 'Progressive';
  return 'Structured';
}

function getUsageColor(percentage: number): string {
  if (percentage >= 90) return 'red';
  if (percentage >= 75) return 'yellow';
  return 'green';
}
```

**Add to App.tsx:**
```typescript
import { ContextStatus } from './components/status/ContextStatus.js';

// In render:
<Box flexDirection="row">
  <Box flexGrow={1}>
    {/* Main content */}
  </Box>
  <Box width={35} borderStyle="single" borderColor="gray">
    <ContextStatus />
  </Box>
</Box>
```

**Tests:**
- Test component renders correctly
- Test mode display
- Test tier display
- Test usage colors
- Test checkpoint stats

---

### Task 10: Add Visual Feedback (2 hours)

**File:** `packages/cli/src/ui/components/status/ContextStatus.tsx`

**Add animations:**
```typescript
import { useEffect, useState } from 'react';

export const ContextStatus: React.FC = () => {
  const [modeChanged, setModeChanged] = useState(false);
  const [tierChanged, setTierChanged] = useState(false);
  
  // Animate mode change
  useEffect(() => {
    if (mode) {
      setModeChanged(true);
      setTimeout(() => setModeChanged(false), 1000);
    }
  }, [mode]);
  
  // Animate tier change
  useEffect(() => {
    if (tier) {
      setTierChanged(true);
      setTimeout(() => setTierChanged(false), 1000);
    }
  }, [tier]);
  
  return (
    <Box>
      {/* Mode with highlight */}
      <Box backgroundColor={modeChanged ? 'green' : undefined}>
        <Text>Mode: </Text>
        <Text bold color="green">{mode}</Text>
        {modeChanged && <Text> ✓</Text>}
      </Box>
      
      {/* Tier with highlight */}
      <Box backgroundColor={tierChanged ? 'yellow' : undefined}>
        <Text>Tier: </Text>
        <Text bold color="yellow">{tier}</Text>
        {tierChanged && <Text> ✓</Text>}
      </Box>
    </Box>
  );
};
```

**Tests:**
- Test mode change animation
- Test tier change animation
- Test animation timing
- Test visual feedback

---

### Task 11: Update Context Provider (2 hours)

**File:** `packages/cli/src/features/context/ContextManagerContext.tsx`

**Add state:**
```typescript
const [mode, setMode] = useState<OperationalMode>(OperationalMode.DEVELOPER);
const [tier, setTier] = useState<string | null>(null);
const [checkpointStats, setCheckpointStats] = useState<any>(null);
const [neverCompressedCount, setNeverCompressedCount] = useState<number>(0);

// Add event listeners
useEffect(() => {
  if (!manager) return;
  
  const handleModeChange = (data: any) => setMode(data.mode);
  const handleTierChange = (data: any) => setTier(data.tier);
  const handleCheckpointCreated = () => {
    // Update checkpoint stats
    const stats = manager.getCheckpointStats?.();
    if (stats) setCheckpointStats(stats);
  };
  const handleNeverCompressedAdded = () => {
    setNeverCompressedCount(prev => prev + 1);
  };
  
  manager.on('mode-changed', handleModeChange);
  manager.on('tier-changed', handleTierChange);
  manager.on('checkpoint-created', handleCheckpointCreated);
  manager.on('never-compressed-added', handleNeverCompressedAdded);
  
  return () => {
    manager.off('mode-changed', handleModeChange);
    manager.off('tier-changed', handleTierChange);
    manager.off('checkpoint-created', handleCheckpointCreated);
    manager.off('never-compressed-added', handleNeverCompressedAdded);
  };
}, [manager]);

// Add to context value
const contextValue = {
  ...contextActions,
  mode,
  tier,
  checkpointStats,
  neverCompressedCount,
  setMode: (newMode: OperationalMode) => {
    manager?.setMode?.(newMode);
  },
  getTier: () => tier,
};
```

**Tests:**
- Test mode state updates
- Test tier state updates
- Test checkpoint stats updates
- Test event listener cleanup

---

## Implementation Order

### Week 1: Core Infrastructure
1. **Day 1:** Task 1 (Tier Detection) - 2 hours
2. **Day 2:** Task 2 (Mode Profiles) - 3 hours
3. **Day 3:** Task 3 (Adaptive System Prompts) - 3 hours ⭐ NEW
4. **Day 4:** Task 9 (Context Status UI) - 4 hours ⭐
5. **Day 5:** Task 4 (Never-Compressed Sections) - 4 hours

### Week 2: Tier Implementations
1. **Day 1-2:** Task 5 (Tier 3 Enhancement) - 4 hours ⭐ PRIMARY TARGET
2. **Day 3:** Task 7 (Tier 2 Smart Compression) - 3 hours
3. **Day 4:** Task 6 (Tier 1 Rollover) - 3 hours
4. **Day 5:** Task 10 (Visual Feedback) + Task 11 (Context Provider) - 4 hours

### Week 3: Testing & Refinement
1. **Day 1-2:** Task 8 (Test Suite) - 4 hours
2. **Day 3:** Integration testing - 4 hours
3. **Day 4:** Bug fixes - 4 hours
4. **Day 5:** Documentation updates - 2 hours

### Week 4: Polish & Release
1. **Day 1:** Performance optimization - 4 hours
2. **Day 2:** UI polish - 4 hours
3. **Day 3:** Final testing - 4 hours
4. **Day 4:** Documentation - 4 hours
5. **Day 5:** Release preparation - 2 hours

---

## Success Criteria

### Must Have
- ✅ Tier detection works for all 4 tiers
- ✅ Mode profiles load and switch correctly
- ✅ Never-compressed sections are preserved
- ✅ Tier 3 (16-32K) works perfectly (PRIMARY TARGET)
- ✅ All tests pass
- ✅ No regressions from Phase 1

### Should Have
- ✅ Tier 2 (8-16K) smart compression works
- ✅ Tier 1 (2-8K) rollover works
- ✅ Mode-aware extraction works
- ✅ Integration tests pass

### Nice to Have
- ✅ Tier 4 (32K+) structured checkpoints
- ✅ Performance benchmarks
- ✅ Documentation complete

---

## Estimated Effort

| Task | Hours | Priority |
|------|-------|----------|
| Task 1: Tier Detection | 2 | HIGH |
| Task 2: Mode Profiles | 3 | HIGH |
| Task 3: Never-Compressed | 4 | HIGH |
| Task 4: Tier 3 Enhancement | 4 | **CRITICAL** ⭐ |
| Task 5: Tier 1 Rollover | 3 | MEDIUM |
| Task 6: Tier 2 Smart | 3 | MEDIUM |
| Task 7: Test Suite | 4 | HIGH |
| Task 8: Context Status UI | 4 | **CRITICAL** ⭐ |
| Task 9: Visual Feedback | 2 | HIGH |
| Task 10: Context Provider | 2 | HIGH |
| **TOTAL** | **31 hours** | ~4 weeks |

**UI Tasks Added:** 8 hours (Tasks 9, 10, 11)  
**Adaptive Prompts Added:** 3 hours (Task 3) ⭐ NEW  
**Primary Focus:** Task 5 (Tier 3) + Task 9 (UI) + Task 3 (Prompts)

---

## Next Steps

1. **Review this plan** - Confirm approach and priorities
2. **Start with Task 1** - Tier detection (2 hours)
3. **Continue with Task 2** - Mode profiles (3 hours)
4. **Focus on Task 4** - Tier 3 enhancement (PRIMARY TARGET)
5. **Complete test suite** - Ensure everything works

---

**Status:** Ready to implement  
**Priority:** HIGH  
**Target:** Tier 3 (16-32K) - 90% of users  
**Timeline:** 3 weeks
