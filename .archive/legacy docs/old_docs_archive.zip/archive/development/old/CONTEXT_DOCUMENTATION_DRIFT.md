# Context Management Documentation Drift Analysis
**Date:** 2026-01-20  
**Status:** 🟡 Documentation Incomplete  
**Purpose:** Identify gaps between implementation and documentation

---

## 📋 EXECUTIVE SUMMARY

The Context Management documentation in `docs/Context/` is **comprehensive and well-structured** (16 files, ~9,075 lines), but it **does not reflect recent implementation changes** and **missing critical features** that are actually implemented in the code.

### **Key Findings:**

1. ✅ **Well-Documented:** Basic compression, snapshots, VRAM monitoring, configuration
2. ❌ **Missing:** Auto-summary feature, inflight token accounting, cooldown guards, resume behavior
3. ❌ **Outdated:** Threshold behavior (60% compression vs 80% documented)
4. ❌ **Incomplete:** Error handling, retry logic, event system details

---

## 🔍 DETAILED DRIFT ANALYSIS

### **1. Auto-Summary Feature (CRITICAL - NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `ChatContext.tsx`:
- Auto-summary triggers at **80% threshold** (configurable via `autoThreshold`)
- LLM generates conversation summary
- System emits `auto-summary-created` event
- UI shows "Summary complete. Type 'continue' to resume..."
- User can type "continue" to resume or "stop" to abort
- Configurable via `llm.resumeAfterSummary` setting (`ask` | `auto` | `never`)

#### **Documentation Status:**
- ❌ **NOT mentioned** in `docs/Context/management/compression.md`
- ❌ **NOT mentioned** in `docs/Context/Context_configuration.md`
- ❌ **NOT mentioned** in `docs/Context/getting-started.md`
- ❌ **NOT mentioned** in `docs/Context/README.md`

#### **What's Documented Instead:**
- Only mentions **compression** at 80% threshold
- No distinction between compression (60%) and summary (80%)
- No mention of auto-summary vs manual compression
- No mention of resume behavior

#### **Impact:**
- **HIGH** - Users don't know this feature exists
- Users don't know how to configure `resumeAfterSummary`
- Users don't understand the difference between compression and summary
- Users don't know about the "continue" command

---

### **2. Dual Threshold System (CRITICAL - PARTIALLY DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `contextManager.ts`:
- **60% threshold:** Triggers compression (reduce context size)
- **80% threshold:** Triggers auto-summary (LLM summarization + resume)
- Two separate mechanisms with different behaviors
- Configurable via `compression.threshold` (60%) and `autoThreshold` (80%)

#### **Documentation Status:**
- ⚠️ **PARTIALLY documented** - Only mentions single 80% threshold
- ❌ **NOT clear** that there are two different thresholds
- ❌ **NOT explained** what happens at each threshold

#### **What's Documented:**
From `docs/Context/management/compression.md`:
```yaml
compression:
  threshold: 0.8  # Trigger at 80%
```

**Says:** "Trigger compression at 80%"  
**Reality:** Compression at 60%, Summary at 80%

#### **Impact:**
- **HIGH** - Users configure wrong threshold
- Users don't understand why compression happens "early"
- Users don't know about the 60% compression threshold

---

### **3. Inflight Token Accounting (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `ChatContext.tsx`:
- Streaming tokens are tracked in real-time
- `reportInflightTokens(delta)` adds to accumulator
- Batched flush every 500ms to reduce GC pressure
- `clearInflightTokens()` clears accumulator
- Inflight tokens included in threshold checks
- Prevents premature compression during streaming

#### **Documentation Status:**
- ❌ **NOT mentioned** anywhere in docs
- ❌ **NOT explained** in architecture docs
- ❌ **NOT mentioned** in API reference

#### **Impact:**
- **MEDIUM** - Advanced users don't understand token counting
- Developers don't know about this optimization
- No documentation for troubleshooting token count issues

---

### **4. Cooldown Guard (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `contextManager.ts`:
- 5-second cooldown after compression
- Prevents repeated auto-summary triggers
- Reentrancy guard to avoid spam
- Debug logs for investigation

#### **Documentation Status:**
- ❌ **NOT mentioned** anywhere
- ❌ **NOT explained** why compression might be delayed

#### **Impact:**
- **LOW** - Users don't understand why compression doesn't trigger immediately
- Developers don't know about this safety mechanism

---

### **5. Resume Behavior (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `ChatContext.tsx`:
- After auto-summary, system waits for user input
- User types "continue" to resume generation
- User types "stop" to abort
- Configurable via `llm.resumeAfterSummary`:
  - `ask` (default): Wait for user to type "continue"
  - `auto`: Automatically resume
  - `never`: Don't resume, just summarize
- Last user message is re-dispatched after resume
- Retry logic with compression flag

#### **Documentation Status:**
- ❌ **NOT mentioned** in any user guide
- ❌ **NOT mentioned** in configuration docs
- ❌ **NOT mentioned** in commands reference

#### **Impact:**
- **HIGH** - Users don't know about "continue" command
- Users don't know how to configure auto-resume
- Users get confused when system waits for input

---

### **6. Timeout Configuration (PARTIALLY DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md`:
- Summarization requests use 120s timeout (not default 30s)
- `summaryTimeout` forwarded to provider
- Prevents provider default timeout aborts
- Configurable timeout for long-running summarization

#### **Documentation Status:**
- ⚠️ **PARTIALLY mentioned** - No timeout configuration in docs
- ❌ **NOT explained** why 120s is needed
- ❌ **NOT configurable** in documented config

#### **Impact:**
- **LOW** - Users can't configure timeout
- Users don't understand timeout errors

---

### **7. Event System (PARTIALLY DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `ChatContext.tsx`:
- Events emitted during compression/summary:
  - `summarizing` - Before summarization starts
  - `auto-snapshot-created` - Snapshot created before summary
  - `auto-summary-created` - Summary generated successfully
  - `auto-summary-failed` - Summary generation failed
  - `compressed` - Compression completed
  - `memory-warning` - Context usage warning
- UI listens to events and shows messages
- Event payload includes summary text, error details, etc.

#### **Documentation Status:**
- ⚠️ **PARTIALLY documented** in API reference
- ❌ **NOT complete** - Missing auto-summary events
- ❌ **NOT explained** in user guides

#### **Impact:**
- **MEDIUM** - Developers don't know all available events
- Integration guides incomplete

---

### **8. Retry and Continuity Logic (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md` and `ChatContext.tsx`:
- If compression happens mid-generation, UI flags it
- Agent retries once after compression
- Retry logic re-adds last user message
- Prevents model from repeating last output
- `compressionOccurredRef` flag tracks compression state
- `compressionRetryCountRef` limits retries

#### **Documentation Status:**
- ❌ **NOT mentioned** anywhere
- ❌ **NOT explained** in troubleshooting

#### **Impact:**
- **MEDIUM** - Users don't understand retry behavior
- Users don't know why message is re-sent

---

### **9. Error Handling and Diagnostics (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context_tests.md`:
- Global uncaughtException/unhandledRejection handlers
- Crash traces written to `logs/cli-errors.log`
- Debug logs for snapshot creation, compression, errors
- Guidance for OOM issues (increase heap, use --trace-gc)

#### **Documentation Status:**
- ❌ **NOT mentioned** in troubleshooting docs
- ❌ **NOT explained** where to find error logs
- ❌ **NOT documented** how to debug OOM issues

#### **Impact:**
- **HIGH** - Users can't troubleshoot crashes
- Users don't know about error logs
- Support burden increases

---

### **10. Compression Service API Mismatch (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context-audit.md`:
- Two compression services with incompatible APIs:
  - `context/compressionService.ts` - Returns `CompressedContext`
  - `services/chatCompressionService.ts` - Returns `CompressionResult`
- Different message formats (`Message` vs `SessionMessage`)
- Different method signatures
- API mismatch causes runtime failures

#### **Documentation Status:**
- ❌ **NOT mentioned** in API docs
- ❌ **NOT explained** which service to use
- ❌ **NOT documented** that there are two services

#### **Impact:**
- **CRITICAL** - Developers use wrong API
- Integration failures
- Runtime crashes

---

### **11. Token Counting Inconsistency (NOT DOCUMENTED)**

#### **Implementation Reality:**
From `context-audit.md`:
- 15+ locations use `Math.ceil(length/4)` heuristic
- `TokenCounterService` exists but not used consistently
- Inaccurate token counts lead to wrong threshold triggers
- Different services disagree on token counts

#### **Documentation Status:**
- ❌ **NOT mentioned** in architecture docs
- ❌ **NOT explained** how tokens are counted
- ❌ **NOT documented** that heuristic is used

#### **Impact:**
- **HIGH** - Users don't understand token counts
- Developers don't know to use `TokenCounterService`
- Threshold triggers are unpredictable

---

### **12. Memory Guard Thresholds (PARTIALLY DOCUMENTED)**

#### **Implementation Reality:**
From `context-audit.md` and `memoryGuard.ts`:
- 4-level threshold system:
  - **80% (WARNING):** Trigger compression
  - **90% (CRITICAL):** Create emergency snapshot
  - **95% (EMERGENCY):** Aggressive truncation
  - **100% (OVERFLOW):** Crash prevention
- Automatic actions at each level
- Configurable thresholds

#### **Documentation Status:**
- ⚠️ **PARTIALLY documented** in `docs/Context/monitoring/memory-safety.md`
- ❌ **NOT clear** that compression happens at 80% VRAM (not context)
- ❌ **NOT explained** difference between context threshold and VRAM threshold

#### **Impact:**
- **MEDIUM** - Users confuse VRAM thresholds with context thresholds
- Users don't understand when compression triggers

---

## 📊 DOCUMENTATION COMPLETENESS MATRIX

| Feature | Implemented | Documented | Status | Priority |
|---------|-------------|------------|--------|----------|
| **Basic Compression** | ✅ Yes | ✅ Yes | Complete | - |
| **Compression Strategies** | ✅ Yes | ✅ Yes | Complete | - |
| **Snapshots** | ✅ Yes | ✅ Yes | Complete | - |
| **VRAM Monitoring** | ✅ Yes | ✅ Yes | Complete | - |
| **Auto-Summary (80%)** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **Dual Thresholds (60%/80%)** | ✅ Yes | ⚠️ Partial | **Incomplete** | 🔴 HIGH |
| **Resume Behavior** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **`resumeAfterSummary` Setting** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **"continue" Command** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **Inflight Token Accounting** | ✅ Yes | ❌ No | **Missing** | 🟡 MEDIUM |
| **Cooldown Guard (5s)** | ✅ Yes | ❌ No | **Missing** | 🟢 LOW |
| **Retry Logic** | ✅ Yes | ❌ No | **Missing** | 🟡 MEDIUM |
| **Event System (full)** | ✅ Yes | ⚠️ Partial | **Incomplete** | 🟡 MEDIUM |
| **Error Logging** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **Timeout Configuration** | ✅ Yes | ❌ No | **Missing** | 🟢 LOW |
| **Dual Compression Services** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **Token Counting Heuristic** | ✅ Yes | ❌ No | **Missing** | 🔴 HIGH |
| **Memory Guard Thresholds** | ✅ Yes | ⚠️ Partial | **Incomplete** | 🟡 MEDIUM |

---

## 🎯 PRIORITY DOCUMENTATION UPDATES

### **Priority 1: Critical User-Facing Features (HIGH)**

#### **1. Auto-Summary Feature**
**Files to Update:**
- `docs/Context/management/compression.md`
- `docs/Context/getting-started.md`
- `docs/Context/README.md`
- `docs/Context/Context_configuration.md`

**What to Add:**
```markdown
## Auto-Summary Feature

When context usage reaches 80%, the system automatically:
1. Creates a pre-summary snapshot
2. Generates an LLM-based conversation summary
3. Replaces older messages with the summary
4. Prompts you to continue or stop

### Resume Behavior

After auto-summary completes, you'll see:
```
Summary complete. Type "continue" to resume generation or "stop" to abort.
```

**Options:**
- Type `continue` to resume the task
- Type `stop` to abort

### Configuration

```yaml
llm:
  resumeAfterSummary: ask  # ask | auto | never
```

**Values:**
- `ask` (default): Wait for user to type "continue"
- `auto`: Automatically resume generation
- `never`: Only summarize, don't resume
```

---

#### **2. Dual Threshold System**
**Files to Update:**
- `docs/Context/management/compression.md`
- `docs/Context/Context_configuration.md`

**What to Add:**
```markdown
## Compression Thresholds

The system uses two thresholds:

### Compression Threshold (60%)
- **Trigger:** Context usage reaches 60%
- **Action:** Compress older messages
- **Purpose:** Free up space proactively
- **Configuration:** `compression.threshold: 0.6`

### Summary Threshold (80%)
- **Trigger:** Context usage reaches 80%
- **Action:** LLM generates conversation summary
- **Purpose:** Preserve context quality
- **Configuration:** `snapshots.autoThreshold: 0.8`

**Example:**
```yaml
context:
  compression:
    threshold: 0.6  # Compress at 60%
  snapshots:
    autoThreshold: 0.8  # Summarize at 80%
```
```

---

#### **3. Error Logging and Diagnostics**
**Files to Update:**
- `docs/Context/README.md` (Troubleshooting section)
- New file: `docs/Context/troubleshooting.md`

**What to Add:**
```markdown
## Error Logging

Context management errors are logged to:
```
~/.ollm/logs/cli-errors.log
```

### Viewing Error Logs

```bash
# View recent errors
tail -n 50 ~/.ollm/logs/cli-errors.log

# Watch errors in real-time
tail -f ~/.ollm/logs/cli-errors.log
```

### Common Errors

#### Out of Memory (OOM)
**Symptoms:** Crash during compression or summary  
**Log:** "JavaScript heap out of memory"

**Solutions:**
1. Increase Node heap size:
   ```bash
   node --max-old-space-size=4096 ollm
   ```

2. Enable GC tracing:
   ```bash
   node --trace-gc ollm
   ```

3. Reduce context size:
   ```yaml
   context:
     targetSize: 8192  # Reduce from 16384
   ```
```

---

#### **4. "continue" Command**
**Files to Update:**
- `docs/Context/Context_commands.md`
- `docs/Context/getting-started.md`

**What to Add:**
```markdown
## Special Commands

### `continue`

**Purpose:** Resume generation after auto-summary

**Usage:**
```
> continue
```

**When to Use:**
- After seeing "Summary complete. Type 'continue'..."
- To resume a task that was interrupted by summarization

**Example:**
```
SYSTEM: Summary complete. Type "continue" to resume generation or "stop" to abort.
> continue
SYSTEM: Resuming generation...
ASSISTANT: [continues task]
```

### `stop`

**Purpose:** Abort generation after auto-summary

**Usage:**
```
> stop
```
```

---

### **Priority 2: Developer Documentation (MEDIUM)**

#### **5. Event System**
**Files to Update:**
- `docs/Context/api/context-manager.md`
- New file: `docs/Context/api/events.md`

**What to Add:**
```markdown
## Context Management Events

### Compression Events

#### `summarizing`
**Emitted:** Before auto-summary starts  
**Payload:** None  
**Use:** Show UI feedback

#### `auto-summary-created`
**Emitted:** After summary generated successfully  
**Payload:**
```typescript
{
  summary: {
    content: string;
    tokenCount: number;
  }
}
```

#### `auto-summary-failed`
**Emitted:** If summary generation fails  
**Payload:**
```typescript
{
  error: Error;
  reason: string;
}
```

#### `compressed`
**Emitted:** After compression completes  
**Payload:**
```typescript
{
  originalTokens: number;
  compressedTokens: number;
  ratio: number;
}
```

### Example Usage

```typescript
contextManager.on('auto-summary-created', (data) => {
  console.log('Summary:', data.summary.content);
  console.log('Tokens:', data.summary.tokenCount);
});

contextManager.on('auto-summary-failed', (data) => {
  console.error('Summary failed:', data.reason);
});
```
```

---

#### **6. Compression Service APIs**
**Files to Update:**
- `docs/Context/api/compression-service.md`
- New file: `docs/Context/api/migration-guide.md`

**What to Add:**
```markdown
## Compression Service APIs

### ⚠️ Important: Two Compression Services

There are currently two compression service implementations:

#### 1. Context Compression Service
**Location:** `packages/core/src/context/compressionService.ts`  
**Use for:** Context management, memory guard  
**API:**
```typescript
interface ICompressionService {
  compress(
    messages: Message[],
    strategy: CompressionStrategy
  ): Promise<CompressedContext>;
}
```

#### 2. Chat Compression Service
**Location:** `packages/core/src/services/chatCompressionService.ts`  
**Use for:** Chat client, non-interactive mode  
**API:**
```typescript
class ChatCompressionService {
  compress(
    messages: SessionMessage[],
    options: CompressionOptions
  ): Promise<CompressionResult>;
}
```

### Which One to Use?

- **Context management:** Use `ICompressionService`
- **Chat operations:** Use `ChatCompressionService`
- **Memory guard:** Use `ICompressionService`

### Migration Note

These services will be unified in a future release. For now, use the appropriate service for your use case.
```

---

#### **7. Token Counting**
**Files to Update:**
- `docs/Context/api/context-manager.md`
- New file: `docs/Context/api/token-counting.md`

**What to Add:**
```markdown
## Token Counting

### TokenCounterService

**Recommended:** Use `TokenCounterService` for accurate token counting.

```typescript
import { TokenCounterService } from '@ollm/core';

const tokenCounter = new TokenCounterService(provider);
const count = await tokenCounter.countTokens(text, modelId);
```

### Heuristic Fallback

If `TokenCounterService` is unavailable, a heuristic is used:

```typescript
const estimatedTokens = Math.ceil(text.length / 4);
```

**Accuracy:** ±20-50% depending on content  
**Use only for:** Quick estimates, testing

### Best Practices

1. **Always use TokenCounterService** in production code
2. **Cache token counts** to avoid repeated calculations
3. **Don't rely on heuristic** for threshold decisions
4. **Test with actual tokenizer** for critical features
```

---

### **Priority 3: Architecture Documentation (LOW)**

#### **8. Inflight Token Accounting**
**Files to Update:**
- `docs/Context/Context_architecture.md`

**What to Add:**
```markdown
## Inflight Token Accounting

### Purpose
Track streaming tokens in real-time to prevent premature compression during generation.

### Implementation
- Streaming tokens accumulated in `inflightTokenAccumulatorRef`
- Batched flush every 500ms to reduce GC pressure
- Included in threshold checks: `currentTokens + inflightTokens`
- Cleared after generation completes or is aborted

### Benefits
- Accurate threshold triggering during streaming
- Prevents compression mid-generation
- Reduces memory allocation churn
```

---

#### **9. Cooldown Guard**
**Files to Update:**
- `docs/Context/Context_architecture.md`

**What to Add:**
```markdown
## Compression Cooldown

### Purpose
Prevent repeated compression triggers in rapid succession.

### Implementation
- 5-second cooldown after compression
- Reentrancy guard prevents overlapping compressions
- Debug logs for investigation

### Benefits
- Prevents compression spam
- Reduces CPU/memory overhead
- Improves system stability
```

---

## 📝 DOCUMENTATION UPDATE CHECKLIST

### **Phase 1: Critical User Features (Week 1)**

- [ ] **Add auto-summary section** to `compression.md`
- [ ] **Add dual threshold explanation** to `compression.md`
- [ ] **Add `resumeAfterSummary` config** to `Context_configuration.md`
- [ ] **Add "continue" command** to `Context_commands.md`
- [ ] **Add error logging section** to `README.md`
- [ ] **Create troubleshooting.md** with error diagnostics
- [ ] **Update getting-started.md** with auto-summary workflow

### **Phase 2: Developer Documentation (Week 2)**

- [ ] **Create events.md** with all event types
- [ ] **Update compression-service.md** with dual API warning
- [ ] **Create token-counting.md** with best practices
- [ ] **Update context-manager.md** with event examples
- [ ] **Create migration-guide.md** for API changes

### **Phase 3: Architecture Updates (Week 3)**

- [ ] **Add inflight token accounting** to `Context_architecture.md`
- [ ] **Add cooldown guard** to `Context_architecture.md`
- [ ] **Add retry logic** to `Context_architecture.md`
- [ ] **Update data flow diagrams** with new features
- [ ] **Add Mermaid diagrams** for auto-summary flow

### **Phase 4: Examples and Tutorials (Week 4)**

- [ ] **Add auto-summary example** to getting-started
- [ ] **Add resume workflow** to user-guide
- [ ] **Add error handling examples** to troubleshooting
- [ ] **Add event handling examples** to API docs
- [ ] **Add configuration examples** for all new features

---

## 🎯 SUCCESS CRITERIA

### **Documentation is Complete When:**

- ✅ All implemented features are documented
- ✅ Configuration options match implementation
- ✅ Commands reference includes all commands
- ✅ Troubleshooting covers common issues
- ✅ API docs match actual APIs
- ✅ Examples work as documented
- ✅ No user confusion about auto-summary
- ✅ No developer confusion about which API to use

---

## 📊 ESTIMATED EFFORT

| Phase | Tasks | Estimated Time |
|-------|-------|----------------|
| **Phase 1** | 7 critical updates | 8-10 hours |
| **Phase 2** | 5 developer docs | 6-8 hours |
| **Phase 3** | 5 architecture updates | 4-6 hours |
| **Phase 4** | 5 examples/tutorials | 4-6 hours |
| **TOTAL** | 22 documentation updates | **22-30 hours** |

---

## 🔍 NEXT STEPS

1. **Review this analysis** with team
2. **Prioritize updates** based on user impact
3. **Assign documentation tasks** to team members
4. **Create tracking issues** for each update
5. **Set deadlines** for each phase
6. **Review and merge** documentation updates

---

**Document Status:** 🟢 Ready for Review  
**Created:** 2026-01-20  
**Purpose:** Guide documentation updates to match implementation  
**Next Action:** Review with team and prioritize updates
