# Context Management System - Development Documentation

**Last Updated:** January 17, 2026  
**Status:** ✅ Documentation Complete

This directory contains development documentation, tracking files, and reference materials for the Context Management System in OLLM CLI.

---

## 📁 Directory Structure

```
.dev/Context/
├── README.md                              # This file - navigation guide
├── CONTEXT_docs.md                        # Main documentation index
│
├── debugging/                             # Bug tracking and fixes
│   ├── bugs-summary.md                   # Summary of context-related bugs
│   └── memoryguard-bug-fix.md            # MemoryGuard compression fix details
│
├── development/                           # Development tracking
│   ├── documentation-tracking.md         # Documentation creation progress
│   └── implementation-progress.md        # Implementation status tracking
│
└── reference/                             # Reference materials
    └── README.md                          # Reference documentation index
```

---

## 📚 User Documentation (docs/Context/)

The main user-facing documentation is located in `docs/Context/`:

### Core Documentation

| File | Description |
|------|-------------|
| **[README.md](../../docs/Context/README.md)** | Main entry point for users |
| **[getting-started.md](../../docs/Context/getting-started.md)** | Quick start guide |
| **[Context_index.md](../../docs/Context/Context_index.md)** | Complete documentation index |
| **[Context_architecture.md](../../docs/Context/Context_architecture.md)** | System architecture overview |
| **[Context_commands.md](../../docs/Context/Context_commands.md)** | CLI commands reference |
| **[Context_configuration.md](../../docs/Context/Context_configuration.md)** | Configuration guide |

### API Documentation (docs/Context/api/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Context/api/README.md)** | API overview |
| **[context-manager.md](../../docs/Context/api/context-manager.md)** | ContextManager API reference |
| **[compression-service.md](../../docs/Context/api/compression-service.md)** | CompressionService API reference |
| **[snapshot-manager.md](../../docs/Context/api/snapshot-manager.md)** | SnapshotManager API reference |

### Management Guides (docs/Context/management/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Context/management/README.md)** | Management overview |
| **[user-guide.md](../../docs/Context/management/user-guide.md)** | User guide for context management |
| **[compression.md](../../docs/Context/management/compression.md)** | Compression strategies guide |
| **[snapshots.md](../../docs/Context/management/snapshots.md)** | Snapshot management guide |

### Monitoring Guides (docs/Context/monitoring/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Context/monitoring/README.md)** | Monitoring overview |
| **[vram-monitoring.md](../../docs/Context/monitoring/vram-monitoring.md)** | VRAM monitoring guide |
| **[memory-safety.md](../../docs/Context/monitoring/memory-safety.md)** | Memory safety features |

---

## 🎯 What is Context Management?

The Context Management System handles the "memory" that AI models have during conversations. It includes:

### Core Features

1. **Dynamic Context Sizing**
   - Automatically adjusts context size based on available GPU memory (VRAM)
   - Prevents out-of-memory errors
   - Optimizes performance

2. **VRAM Monitoring**
   - Real-time GPU memory tracking
   - Support for NVIDIA, AMD, and Apple Silicon
   - Memory pressure warnings at 80%, 90%, 95% thresholds

3. **Context Compression**
   - Multiple compression strategies (summarization, pruning, semantic)
   - Automatic compression when approaching limits
   - Preserves important information

4. **Snapshot Management**
   - Save conversation state at any point
   - Restore previous conversation states
   - Automatic snapshots at 80% capacity
   - Rollover to new context when full

5. **Memory Guard**
   - Prevents OOM (Out of Memory) crashes
   - Three-tier warning system
   - Automatic intervention at critical levels

---

## 🔧 Implementation Files

The Context Management System is implemented in `packages/core/src/context/`:

### Core Components

| File | Purpose |
|------|---------|
| `contextManager.ts` | Main orchestrator for all context features |
| `contextPool.ts` | Dynamic context sizing based on VRAM |
| `vramMonitor.ts` | GPU memory monitoring |
| `memoryGuard.ts` | Memory safety and OOM prevention |
| `compressionService.ts` | Context compression strategies |
| `snapshotManager.ts` | Snapshot save/restore functionality |
| `snapshotStorage.ts` | Snapshot persistence layer |
| `SnapshotParser.ts` | Snapshot format parsing |
| `tokenCounter.ts` | Token counting and estimation |
| `SystemPromptBuilder.ts` | System prompt construction |
| `HotSwapService.ts` | Context hot-swapping |
| `jitDiscovery.ts` | Just-in-time context discovery |
| `gpuDetector.ts` | GPU detection and capabilities |
| `types.ts` | TypeScript type definitions |

### Test Files

Located in `packages/core/src/context/__tests__/`:
- Unit tests for each component
- Integration tests for full workflows
- Property-based tests for edge cases

---

## 📊 Key Concepts

### Context Window

The "context window" is how much conversation history the AI can remember:
- **Small models (7B):** ~4K-8K tokens
- **Medium models (13B):** ~8K-16K tokens  
- **Large models (70B+):** ~32K-128K tokens

**1 token ≈ 4 characters** (rough estimate)

### VRAM Requirements

Context uses GPU memory (VRAM):
- **Base model:** 4-8GB (for 7B model)
- **Context:** ~1-2GB per 8K tokens
- **Total:** Model size + context size

### Memory Thresholds

The system monitors memory usage:
- **80% (Warning):** Trigger compression
- **90% (Critical):** Create snapshot, aggressive compression
- **95% (Emergency):** Force context rollover

---

## 🐛 Known Issues & Fixes

### Fixed Issues

1. **MemoryGuard Compression Not Triggered** (Fixed 2026-01-16)
   - Issue: Soft threshold emitted event but didn't compress
   - Fix: Added compression service invocation at 80% threshold
   - Details: [memoryguard-bug-fix.md](debugging/memoryguard-bug-fix.md)

### Current Limitations

From audit findings (see `../.dev/audit/AUDIT-FINDINGS-EXPLAINED.md`):

1. **Provider Coordination Missing**
   - Resize callback updates metadata but doesn't adjust provider limits
   - Impact: Context resizing may not reduce actual memory usage
   - Status: Medium priority fix needed

2. **CLI Commands Incomplete**
   - `/context clear` and `/context compress` not implemented
   - `/context list` returns placeholder
   - `/context stats` missing KV cache size and compression ratios
   - Status: Medium priority integration work

3. **UI Integration Partial**
   - System bar shows token usage but not VRAM usage
   - No snapshot count display
   - No memory warnings in UI
   - Status: Medium priority UI work

---

## 🚀 Usage Examples

### Basic Usage

```bash
# Check context status
/context

# View detailed statistics
/context stats

# List snapshots
/context list

# Create manual snapshot
/context snapshot save "before-refactor"

# Restore snapshot
/context snapshot restore snapshot-abc123
```

### Configuration

```yaml
# ~/.ollm/config.yaml
context:
  autoSize: true              # Enable dynamic sizing
  maxTokens: 8192            # Maximum context size
  compression:
    enabled: true            # Enable auto-compression
    strategy: "semantic"     # Compression strategy
  snapshots:
    enabled: true            # Enable auto-snapshots
    threshold: 0.8           # Snapshot at 80% full
  vram:
    monitoring: true         # Enable VRAM monitoring
    safetyMargin: 0.1        # Reserve 10% VRAM
```

---

## 📈 Development Status

### ✅ Completed

- Core context management system
- VRAM monitoring (NVIDIA, AMD, Apple Silicon)
- Dynamic context sizing with auto-size formula
- Memory guard with three-tier thresholds
- Compression service with multiple strategies
- Snapshot management (save/restore/auto)
- Token counting and estimation
- Comprehensive documentation (4,500+ lines)

### 🔧 In Progress

- CLI command integration (see audit findings)
- UI integration (system bar, side panel)
- Provider coordination for resizing

### 📋 Planned

- Advanced compression strategies
- Context analytics and insights
- Multi-model context sharing
- Context export/import

---

## 🔗 Related Documentation

### Development Documentation

- **[Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md)** - Issues found in audit
- **[Fix Plan](../audit/fix_plan.md)** - Prioritized fix tasks
- **[Bug Tracker](../bugtracker.md)** - Current bugs and fixes

### Specifications

- **Stage 04b Spec:** `.kiro/specs/stage-04b-context-management/`
  - `requirements.md` - Feature requirements
  - `design.md` - System design
  - `tasks.md` - Implementation tasks

### Implementation Logs

- **[Stage 04b Log](../logs/stages/stage-04b-context-management.md)** - Implementation history

---

## 🤝 Contributing

When working on context management:

1. **Read the architecture docs** - Understand the system design
2. **Check audit findings** - Know current limitations
3. **Run tests** - Ensure changes don't break existing functionality
4. **Update docs** - Keep documentation in sync with code
5. **Test with real models** - Verify VRAM monitoring works

### Testing

```bash
# Run context tests
npm test packages/core/src/context

# Run specific test file
npx vitest run packages/core/src/context/__tests__/contextManager.test.ts

# Run with coverage
npm test -- --coverage packages/core/src/context
```

---

## 📞 Support

For questions or issues:

1. Check the [User Guide](../../docs/Context/management/user-guide.md)
2. Review [Troubleshooting](../../docs/troubleshooting.md)
3. Check [Bug Tracker](../bugtracker.md) for known issues
4. See [Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md) for limitations

---

## 📝 Quick Reference

### Key Files to Know

| Purpose | File |
|---------|------|
| **User docs entry** | `docs/Context/README.md` |
| **Architecture** | `docs/Context/Context_architecture.md` |
| **Commands** | `docs/Context/Context_commands.md` |
| **API reference** | `docs/Context/api/context-manager.md` |
| **Implementation** | `packages/core/src/context/contextManager.ts` |
| **Tests** | `packages/core/src/context/__tests__/` |
| **Bug tracking** | `.dev/Context/debugging/bugs-summary.md` |

### Common Tasks

| Task | Command/File |
|------|--------------|
| View context status | `/context` |
| Check VRAM usage | `/context stats` |
| Create snapshot | `/context snapshot save` |
| Run tests | `npm test packages/core/src/context` |
| Read architecture | `docs/Context/Context_architecture.md` |
| Check known issues | `.dev/audit/AUDIT-FINDINGS-EXPLAINED.md` |

---

**Last Updated:** January 17, 2026  
**Documentation Status:** Complete  
**Implementation Status:** Core complete, integration in progress
