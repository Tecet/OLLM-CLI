# Context Management Flow - Current vs Expected

## 🔴 CURRENT BROKEN FLOW (What's Happening Now)

```
User sends message
    ↓
Context reaches 60% (compression threshold)
    ↓
SnapshotManager.checkThresholds() called
    ↓
[BUG] Floating-point equality check fails
    ↓
Threshold callback NOT invoked ❌
    ↓
Compression NOT triggered ❌
    ↓
Context continues to grow
    ↓
Context reaches 80% (summary threshold)
    ↓
SnapshotManager.checkThresholds() called again
    ↓
[BUG] Floating-point equality check fails again
    ↓
Summary callback NOT invoked ❌
    ↓
BUT... event handlers emit "summarizing" anyway ❌
    ↓
UI shows "Summarizing conversation history..."
    ↓
Compression service called with WRONG arguments ❌
    ↓
Compression service throws error or returns undefined
    ↓
Error caught and silently ignored ❌
    ↓
UI shows "[No messages to compress]"
    ↓
Event emits "auto-summary-created" with empty summary ❌
    ↓
UI shows "Summary complete. Type 'continue'..."
    ↓
User types "continue" OR auto-resume triggers
    ↓
Last user message re-dispatched
    ↓
[LOOP] Context STILL at 80%+ (wasn't compressed)
    ↓
Threshold check fires again
    ↓
Same broken flow repeats...
    ↓
Eventually: Context reaches 100%
    ↓
LLM crashes with context overflow
    ↓
Task restarts from beginning ❌
```

---

## ✅ EXPECTED CORRECT FLOW (What Should Happen)

```
User sends message
    ↓
Context reaches 60% (compression threshold)
    ↓
SnapshotManager.checkThresholds() called
    ↓
[FIX] Epsilon comparison succeeds ✅
    ↓
Threshold callback invoked ✅
    ↓
ContextManager.compress() called
    ↓
CompressionService.compress(messages, strategy) called ✅
    ↓
Older messages compressed/summarized
    ↓
Context reduced to ~40% ✅
    ↓
Event emits "compressed" with summary
    ↓
UI shows compression summary
    ↓
LLM continues task seamlessly ✅
    ↓
---
    ↓
Context grows again and reaches 80% (summary threshold)
    ↓
SnapshotManager.checkThresholds() called
    ↓
[FIX] Epsilon comparison succeeds ✅
    ↓
Summary callback invoked ✅
    ↓
CompressionService.summarize() called
    ↓
LLM generates conversation summary
    ↓
Summary message added to context
    ↓
Old messages removed
    ↓
Context reduced to ~50% ✅
    ↓
Event emits "auto-summary-created" with summary
    ↓
UI shows summary
    ↓
[FIX] Resume with retry counter (max 3 attempts) ✅
    ↓
IF resumeAfterSummary = 'ask':
    ↓
    UI shows "Type 'continue' to resume..."
    ↓
    User types "continue"
    ↓
    Last message re-dispatched
    ↓
    [SUCCESS] Context is now reduced, no loop ✅
    ↓
IF resumeAfterSummary = 'auto':
    ↓
    Last message re-dispatched automatically
    ↓
    [SUCCESS] Context is now reduced, no loop ✅
    ↓
LLM continues task from where it left off ✅
    ↓
Task completes successfully ✅
```

---

## 🔧 KEY FIXES NEEDED

### Fix 1: Floating-Point Threshold Comparison
```typescript
// BEFORE (snapshotManager.ts:193)
if (this.config.autoCreate === false && threshold === this.config.autoThreshold) {
  continue; // ❌ This never matches due to floating-point precision
}

// AFTER
const EPSILON = 0.0001;
if (this.config.autoCreate === false && Math.abs(threshold - this.config.autoThreshold) < EPSILON) {
  continue; // ✅ This correctly matches floating-point thresholds
}
```

**Why this matters:**
- `0.8 === 0.8` might be `false` in JavaScript due to floating-point representation
- `Math.abs(0.8 - 0.8) < 0.0001` will always correctly evaluate to `true`

---

### Fix 2: Memory Guard API Call
```typescript
// BEFORE (memoryGuard.ts:163)
await this.compressionService.compress(this.currentContext);
// ❌ Passes ConversationContext object
// ❌ Compression service expects (messages[], strategy)

// AFTER
await this.compressionService.compress(
  this.currentContext.messages,  // ✅ Pass messages array
  { type: 'hybrid', preserveRecentTokens: 500 }  // ✅ Pass strategy object
);
```

**Why this matters:**
- API mismatch causes compression to fail silently
- No error is surfaced to user
- Context never actually gets compressed

---

### Fix 3: Resume Loop Prevention
```typescript
// BEFORE (ChatContext.tsx:413)
setTimeout(() => { void sendMessage(last); }, 0);
// ❌ No retry limit, loops forever if compression fails

// AFTER
if (compressionRetryCountRef.current < 3) {
  compressionRetryCountRef.current++;
  setTimeout(() => { void sendMessage(last); }, 0);
} else {
  addMessage({ 
    role: 'system', 
    content: 'Maximum retry attempts reached. Please start a new conversation.', 
    excludeFromContext: true 
  });
}
// ✅ Retry limit prevents infinite loops
```

**Why this matters:**
- If compression fails, system would retry forever
- Retry counter stops loop after 3 attempts
- User gets clear error message

---

## 🎯 VERIFICATION CHECKLIST

After applying fixes, verify:

### ✅ Compression at 60%
- [ ] Context reaches 60% usage
- [ ] "Compressing context..." message appears ONCE
- [ ] Context is reduced to ~40%
- [ ] LLM continues task without interruption

### ✅ Summary at 80%
- [ ] Context reaches 80% usage
- [ ] "Summarizing conversation history..." message appears ONCE
- [ ] Summary message is created
- [ ] Context is reduced to ~50%
- [ ] "Type 'continue'..." prompt appears (if resumeAfterSummary='ask')
- [ ] Typing "continue" resumes task successfully

### ✅ No Infinite Loops
- [ ] No repeated "Summarizing..." messages
- [ ] No repeated "[No messages to compress]" messages
- [ ] No repeated "Summary complete..." messages
- [ ] Retry counter stops after 3 attempts if compression fails

### ✅ Task Continuation
- [ ] LLM continues task after compression
- [ ] LLM continues task after summary
- [ ] Task does NOT restart from beginning
- [ ] No crashes due to context overflow

---

## 📊 DEBUGGING TIPS

### Add These Debug Logs:

```typescript
// In snapshotManager.ts - checkThresholds()
console.log('[SNAPSHOT] Usage:', usage.toFixed(4), 'Thresholds:', Array.from(this.thresholdCallbacks.keys()));
console.log('[SNAPSHOT] AutoCreate:', this.config.autoCreate, 'AutoThreshold:', this.config.autoThreshold);
console.log('[SNAPSHOT] Threshold match check:', threshold, '===', this.config.autoThreshold, '?', threshold === this.config.autoThreshold);

// In contextManager.ts - compress()
console.log('[CONTEXT] Compression triggered - current tokens:', this.currentContext.tokenCount);
console.log('[CONTEXT] Calling compression service...');

// In ChatContext.tsx - handleSummarizing
console.log('[CHAT] Summarizing event received');
console.log('[CHAT] waitingForResumeRef:', waitingForResumeRef.current);
console.log('[CHAT] compressionRetryCountRef:', compressionRetryCountRef.current);
```

### Watch For:
- ❌ "Threshold match check: 0.8 === 0.8 ? false" → Floating-point bug
- ❌ "Calling compression service..." never appears → Callback not invoked
- ❌ compressionRetryCountRef keeps incrementing → Infinite loop
- ✅ "Usage: 0.6000" → Compression should trigger
- ✅ "Usage: 0.8000" → Summary should trigger
- ✅ "current tokens" decreases after compression → Success!

---

**Document Status:** 🟢 Ready for Implementation  
**Created:** 2026-01-20  
**Use:** Quick reference during debugging and fixing
