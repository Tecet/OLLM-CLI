# Progressive Checkpoints - Quick Reference

## What It Does

Prevents **concept drift** in long tasks by maintaining conversation history through additive checkpoints instead of replacing it with a single summary.

## The Problem It Solves

```
❌ OLD WAY (Concept Drift):
[System] + [Summary] + [Recent]
→ LLM forgets journey, changes direction, repeats work

✅ NEW WAY (Progressive Checkpoints):
[System] + [Checkpoint 1] + [Checkpoint 2] + [Checkpoint 3] + [Recent]
→ LLM maintains direction, remembers decisions, stays consistent
```

## How It Works

### 1. Checkpoint Creation (Additive)

Every compression creates a new checkpoint that's **added** to history:

```typescript
// Compression triggered at 80% capacity
→ Create checkpoint from compressed messages
→ Add to checkpoint array (not replace!)
→ Compress old checkpoints hierarchically
→ Reconstruct: [System] + [All Checkpoints] + [Recent]
```

### 2. Hierarchical Compression (3 Levels)

Checkpoints age and compress over time:

| Level | Age | Detail | Tokens |
|-------|-----|--------|--------|
| 3 - DETAILED | 1-4 compressions | Full summary + metadata | ~800 |
| 2 - MODERATE | 5-9 compressions | Key decisions + summary | ~300 |
| 1 - COMPACT | 10+ compressions | Ultra-compact | ~80 |

### 3. Bounded Growth

Maximum 10 checkpoints - oldest are merged when limit exceeded.

## API Usage

### Get Checkpoints

```typescript
const checkpoints = contextManager.getCheckpoints();

for (const cp of checkpoints) {
  console.log(`${cp.range} - Level ${cp.level} - ${cp.currentTokens} tokens`);
}
```

### Get Statistics

```typescript
const stats = contextManager.getCheckpointStats();

console.log('Total checkpoints:', stats.total);
console.log('By level:', stats.byLevel);
console.log('Total tokens:', stats.totalTokens);
```

### Monitor Events

```typescript
contextManager.on('auto-summary-created', ({ checkpoint }) => {
  console.log('New checkpoint:', checkpoint.range);
});

contextManager.on('compressed', ({ checkpoint, ratio }) => {
  console.log('Compression ratio:', ratio);
});
```

## Configuration

### Default Settings

```typescript
// In contextManager.ts
const MAX_CHECKPOINTS = 10;      // Maximum to keep
const MODERATE_AGE = 5;          // Compress to moderate after 5
const COMPACT_AGE = 10;          // Compress to compact after 10

// In config
compression: {
  enabled: true,
  threshold: 0.8,                // Trigger at 80%
  preserveRecent: 4096,          // Keep last 4K tokens
  summaryMaxTokens: 1024         // Max per summary
}
```

### Tuning

**Keep more history:**
```typescript
const MAX_CHECKPOINTS = 15;
const MODERATE_AGE = 7;
const COMPACT_AGE = 12;
```

**Tighter token budget:**
```typescript
const MAX_CHECKPOINTS = 5;
const MODERATE_AGE = 3;
const COMPACT_AGE = 6;
```

## Token Budget

### Example After 10 Compressions

```
System Prompt:              1,000 tokens
Checkpoint 1 (COMPACT):        80 tokens
Checkpoint 2 (COMPACT):        80 tokens
Checkpoint 3 (MODERATE):      300 tokens
Checkpoint 4 (MODERATE):      300 tokens
Checkpoint 5 (DETAILED):      800 tokens
Checkpoint 6 (DETAILED):      800 tokens
Recent Messages:            4,096 tokens
────────────────────────────────────────
Total:                      7,456 tokens (23% of 32K)
```

**Overhead:** ~1,860 tokens for checkpoint history  
**Benefit:** Prevents concept drift worth 10K+ tokens of rework

## Testing

```bash
# Run checkpoint tests
npm test progressive-checkpoints

# Run all context tests
npm test context
```

## Troubleshooting

### Too Many Tokens in Checkpoints

```typescript
// Compress sooner
const MODERATE_AGE = 3;
const COMPACT_AGE = 6;
```

### Losing Important Context

```typescript
// Keep more recent detail
compression: {
  preserveRecent: 8192,
}
```

### Checkpoints Not Compressing

```typescript
// Check compression is happening
const checkpoints = contextManager.getCheckpoints();
console.log('Ages:', checkpoints.map(cp => cp.compressionCount));
```

## Key Benefits

✅ **Prevents Concept Drift** - LLM maintains direction  
✅ **Efficient Tokens** - Hierarchical compression  
✅ **Scales to Long Tasks** - 100+ compressions  
✅ **Preserves Decisions** - Metadata tracking  
✅ **Bounded Growth** - Maximum 10 checkpoints  

## Files Modified

- `packages/core/src/context/types.ts` - Added checkpoint types
- `packages/core/src/context/contextManager.ts` - Implemented checkpoint logic
- `packages/core/src/context/__tests__/progressive-checkpoints.test.ts` - Tests
- `docs/Context/management/progressive-checkpoints.md` - Full documentation

## Next Steps

**Phase 2 (Planned):** Structured checkpoints with explicit architecture decision tracking  
**Phase 3 (Planned):** Semantic checkpoint merging using embeddings  
**Phase 4 (Planned):** Checkpoint visualization UI  

## References

- [Full Documentation](../../docs/Context/management/progressive-checkpoints.md)
- [Implementation Summary](./development/progressive-checkpoints-implementation.md)
- [Context Architecture](../../docs/Context/Context_architecture.md)
