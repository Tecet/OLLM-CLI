# Context Management System Audit - Checklist & Action Plan
**Date:** 2026-01-20  
**Status:** 🔴 Critical Issues Identified  
**Priority:** URGENT - System in Loop State

---

## 🚨 CRITICAL ISSUE SUMMARY

Based on the screenshots and documentation review, the system is experiencing:

### **Primary Symptom:**
- LLM getting stuck in infinite loop
- System message "Summarizing conversation history..." appears repeatedly
- Message "[No messages to compress]" appears repeatedly  
- System message "Summary complete. Type 'continue' to resume..." appears repeatedly
- **Context compression NOT triggering at 60% threshold**
- **Summary NOT triggering at 80% threshold**
- **LLM crashes instead of gracefully handling context overflow**
- **Task restarts from beginning instead of continuing**

### **Root Cause Analysis:**
The loop is caused by a **broken event/callback chain** where:
1. Context threshold checks are firing
2. But compression/summary is NOT actually executing
3. System keeps emitting events without taking action
4. LLM tries to continue but hits context limit
5. Crashes and restarts task from beginning

---

## 📋 SYSTEM AUDIT CHECKLIST

### ✅ Documentation Review (COMPLETED)

- [x] Read `.dev/context_tests.md` - Recent changes and test notes
- [x] Read `.dev/contect_debug.md` - Deep audit findings (10 critical issues)
- [x] Read `.dev/docs/Context/CONTEXT_docs.md` - Documentation project status
- [x] Read `.dev/debuging/Context Audit/context-audit.md` - Comprehensive audit (7 critical issues)
- [x] Review screenshots showing loop behavior

**Key Findings from Documentation:**

#### From `contect_debug.md` (10 Issues):
1. ❌ **Inconsistent summary-timeout forwarding** in compression strategies
2. ❌ **Floating-point equality** used for threshold testing
3. ❌ **Duplicate threshold callback registration** allowed
4. ❌ **Provider timeout semantics mismatch** (AbortError handling)
5. ❌ **Inexact tool-unsupported error detection**
6. ❌ **Inflight token accounting race conditions**
7. ❌ **Hybrid compression path message format mismatch**
8. ❌ **Threshold semantics mix fraction vs percentage**
9. ❌ **Missing defensive checks** when manager not initialized
10. ⚠️ **Floating ID generation patterns** (minor)

#### From `context-audit.md` (7 Issues):
1. 🔴 **API Mismatch Between Compression Services** (CRITICAL)
2. 🔴 **Inconsistent Token Counting** (CRITICAL - 15+ locations)
3. 🔴 **Memory Guard Compression Failure** (CRITICAL)
4. 🟠 **Duplicate Compression Implementations** (HIGH)
5. 🟠 **Token Counter Not Used Consistently** (HIGH)
6. 🟡 **Dynamic Sizing Validation Gap** (MEDIUM)
7. 🟡 **Windows Path Testing** (MEDIUM)

#### From `context_tests.md`:
- ✅ Auto-summary trigger at 80% implemented
- ✅ UI feedback for summarization implemented
- ✅ Resume behavior with "continue" command implemented
- ✅ Inflight token accounting implemented
- ✅ Timeout forwarding (120s) implemented
- ⚠️ **Cooldown guard (5s) may be preventing compression**
- ⚠️ **Retry logic may be causing loops**

---

### 🔍 CODE INSPECTION CHECKLIST

#### A. Context Manager (`packages/core/src/context/contextManager.ts`)

- [ ] **Line ~447-527**: `addMessage()` - Check threshold triggering logic
  - [ ] Verify `usage.percentage >= this.config.compression.threshold * 100` calculation
  - [ ] Check if compression is actually called or just event emitted
  - [ ] Verify cooldown guard isn't blocking legitimate compression
  
- [ ] **Line ~599-663**: `compress()` - Manual compression method
  - [ ] Verify compression service is called correctly
  - [ ] Check error handling doesn't silently fail
  - [ ] Verify compressed context replaces current context

- [ ] **Line ~665-676**: `reportInflightTokens()` - Inflight token tracking
  - [ ] Check if inflight tokens are included in threshold checks
  - [ ] Verify accumulator doesn't overflow or get stuck

- [ ] **Line ~678-686**: `clearInflightTokens()` - Cleanup method
  - [ ] Verify this is called after generation completes
  - [ ] Check for race conditions with flush timer

- [ ] **Line ~196-354**: `setupEventCoordination()` - Event handlers
  - [ ] Verify events are actually emitted when thresholds hit
  - [ ] Check for event handler memory leaks or duplicates

#### B. Snapshot Manager (`packages/core/src/context/snapshotManager.ts`)

- [ ] **Line ~182-203**: `checkThresholds()` - Threshold checking logic
  - [ ] **CRITICAL**: Line 193 - `if (this.config.autoCreate === false && threshold === this.config.autoThreshold)`
    - [ ] This uses **floating-point equality** which may fail
    - [ ] Could cause autoThreshold to be skipped incorrectly
  - [ ] Verify `usage >= threshold` comparison works correctly
  - [ ] Check if callbacks are actually invoked

- [ ] **Line ~151-159**: `onContextThreshold()` - Callback registration
  - [ ] **CRITICAL**: No deduplication - callbacks can be registered multiple times
  - [ ] Could cause compression to trigger repeatedly
  - [ ] Verify callbacks array doesn't grow unbounded

- [ ] **Line ~161-166**: `onBeforeOverflow()` - Pre-overflow callbacks
  - [ ] Check if overflow callbacks are triggered at 95%
  - [ ] Verify emergency actions are taken

#### C. Compression Service (`packages/core/src/context/compressionService.ts`)

- [ ] **Check for API mismatch** with `chatCompressionService.ts`
  - [ ] Verify method signatures match expected callers
  - [ ] Check return types are compatible
  - [ ] Verify message format conversions

- [ ] **Timeout forwarding**
  - [ ] Verify `summaryTimeout` is passed to all strategies
  - [ ] Check `hybrid()` strategy includes timeout parameter
  - [ ] Verify 120s timeout reaches provider

- [ ] **Token counting**
  - [ ] Check if using `TokenCounterService` or local heuristic
  - [ ] Verify token counts are accurate
  - [ ] Check for Math.ceil(length/4) usage

#### D. Memory Guard (`packages/core/src/context/memoryGuard.ts`)

- [ ] **Line ~158-162**: Compression call in WARNING handler
  - [ ] **CRITICAL**: Verify arguments passed to `compress()`
  - [ ] Should be: `compress(messages[], strategy)` not `compress(context)`
  - [ ] Check error handling doesn't silently fail
  - [ ] Verify compression actually reduces memory

- [ ] **VRAM monitoring integration**
  - [ ] Check if VRAM thresholds (80%, 90%, 95%) are correct
  - [ ] Verify emergency actions are taken at each level
  - [ ] Check for race conditions between levels

#### E. Chat Context (`packages/cli/src/features/context/ChatContext.tsx`)

- [ ] **Line ~250-353**: Event handlers for context events
  - [ ] **Line ~287-294**: `handleSummarizing` - Shows "Summarizing..." message
    - [ ] Verify this is called when compression starts
    - [ ] Check if message is added correctly
  
  - [ ] **Line ~296-324**: `handleAutoSummary` - Handles summary completion
    - [ ] **CRITICAL**: Line 315 - `waitingForResumeRef.current = true`
    - [ ] This blocks further processing until user types "continue"
    - [ ] Verify resume logic doesn't cause loops
    - [ ] Check `resumeAfterSummary` setting is respected
  
  - [ ] **Line ~268-285**: `handleCompressed` - Handles compression completion
    - [ ] Verify summary message is extracted correctly
    - [ ] Check `compressionOccurredRef.current = true` flag
    - [ ] Verify retry logic doesn't cause infinite loops

- [ ] **Line ~406-416**: Resume command handling
  - [ ] **CRITICAL**: Line 413 - `setTimeout(() => { void sendMessage(last); }, 0);`
    - [ ] This re-dispatches last user message
    - [ ] Could cause infinite loop if compression keeps failing
    - [ ] Verify `lastUserMessageRef.current` is cleared appropriately

- [ ] **Line ~712-736**: Inflight token reporting
  - [ ] Check accumulator logic is correct
  - [ ] Verify 500ms flush timer works
  - [ ] Check for race conditions with clearInflightTokens

- [ ] **Line ~754-758**: Error handling - inflight cleanup
  - [ ] Verify cleanup happens on all error paths
  - [ ] Check timer is cleared properly

#### F. Context Manager Context (`packages/cli/src/features/context/ContextManagerContext.tsx`)

- [ ] **Event emission**
  - [ ] Verify `summarizing` event is emitted before compression
  - [ ] Verify `compressed` event is emitted after compression
  - [ ] Verify `auto-summary-created` event includes summary data
  - [ ] Check for event handler leaks

- [ ] **Action wrappers**
  - [ ] Verify `compress()` action calls manager correctly
  - [ ] Check `reportInflightTokens()` action works
  - [ ] Verify `clearInflightTokens()` action works
  - [ ] Check for null reference errors

---

### 🧪 TEST EXECUTION CHECKLIST

- [ ] **Run existing tests**
  ```bash
  npm run test:unit -- contextManager
  npm run test:unit -- snapshotManager
  npm run test:unit -- compressionService
  npm run test:unit -- memoryGuard
  ```

- [ ] **Check for failing tests**
  - [ ] `memoryGuard.enforce-compress-signature.test.ts` (intentionally failing)
  - [ ] `compression-api-mismatch.test.ts` (intentionally failing)
  - [ ] Review test failures for clues

- [ ] **Integration tests**
  - [ ] Test compression at 60% threshold
  - [ ] Test summary at 80% threshold
  - [ ] Test emergency actions at 95%
  - [ ] Test resume after summary

---

### 🔧 RUNTIME DEBUGGING CHECKLIST

- [ ] **Add debug logging**
  - [ ] Log when `checkThresholds()` is called
  - [ ] Log when threshold callbacks are invoked
  - [ ] Log when compression starts/completes
  - [ ] Log when summary starts/completes
  - [ ] Log inflight token accumulator values
  - [ ] Log cooldown guard state

- [ ] **Monitor event flow**
  - [ ] Track `summarizing` event emission
  - [ ] Track `compressed` event emission
  - [ ] Track `auto-summary-created` event emission
  - [ ] Track `auto-summary-failed` event emission
  - [ ] Check for missing events in the chain

- [ ] **Check state consistency**
  - [ ] Verify `compressionOccurredRef.current` flag
  - [ ] Verify `waitingForResumeRef.current` flag
  - [ ] Verify `lastUserMessageRef.current` value
  - [ ] Check `inflightTokenAccumulatorRef.current` value

---

## 🎯 PRIORITIZED ACTION PLAN

### **Phase 0: Emergency Diagnosis (2 hours) - DO THIS FIRST**

**Goal:** Identify exact point of failure causing the loop

#### Step 1: Add Comprehensive Debug Logging (30 min)
```typescript
// In contextManager.ts - addMessage()
console.log('[CONTEXT] Token usage:', usage.percentage, '% | Threshold:', this.config.compression.threshold * 100, '%');
console.log('[CONTEXT] Should compress:', usage.percentage >= this.config.compression.threshold * 100);

// In snapshotManager.ts - checkThresholds()
console.log('[SNAPSHOT] Checking thresholds - usage:', usage, 'registered thresholds:', Array.from(this.thresholdCallbacks.keys()));
console.log('[SNAPSHOT] Callbacks to invoke:', callbacks.length);

// In ChatContext.tsx - event handlers
console.log('[CHAT] Event received:', eventName, data);
console.log('[CHAT] waitingForResumeRef:', waitingForResumeRef.current);
console.log('[CHAT] compressionOccurredRef:', compressionOccurredRef.current);
```

#### Step 2: Reproduce the Loop (30 min)
- [ ] Start app with debug logging enabled
- [ ] Send long messages to reach 60% context
- [ ] Observe console output
- [ ] Identify which event/callback is NOT firing
- [ ] Identify which event/callback is firing repeatedly

#### Step 3: Verify Threshold Calculation (30 min)
- [ ] Check actual token counts vs expected
- [ ] Verify percentage calculation is correct
- [ ] Check if inflight tokens are included
- [ ] Verify threshold comparison logic

#### Step 4: Check Compression Execution (30 min)
- [ ] Verify compression service is called
- [ ] Check if compression returns successfully
- [ ] Verify compressed context replaces original
- [ ] Check if summary message is created

**Deliverable:** Root cause identified with evidence

---

### **Phase 1: Critical Fixes (8 hours)**

**Goal:** Stop the infinite loop and restore basic functionality

#### Fix 1: Floating-Point Threshold Comparison (1 hour)
**File:** `packages/core/src/context/snapshotManager.ts`

**Problem:** Line 193 uses `threshold === this.config.autoThreshold` which fails for floats

**Solution:**
```typescript
// BEFORE (Line 193):
if (this.config.autoCreate === false && threshold === this.config.autoThreshold) {
  continue;
}

// AFTER:
const EPSILON = 0.0001;
if (this.config.autoCreate === false && Math.abs(threshold - this.config.autoThreshold) < EPSILON) {
  continue;
}
```

**Why:** Floating-point equality is unreliable. Use epsilon comparison.

---

#### Fix 2: Deduplicate Threshold Callbacks (1 hour)
**File:** `packages/core/src/context/snapshotManager.ts`

**Problem:** Line 151-159 allows duplicate callback registration

**Solution:**
```typescript
// BEFORE (Line 151-159):
onContextThreshold(threshold: number, callback: ThresholdCallback): void {
  if (!this.thresholdCallbacks.has(threshold)) {
    this.thresholdCallbacks.set(threshold, []);
  }
  this.thresholdCallbacks.get(threshold)!.push(callback);
}

// AFTER:
onContextThreshold(threshold: number, callback: ThresholdCallback): void {
  if (!this.thresholdCallbacks.has(threshold)) {
    this.thresholdCallbacks.set(threshold, []);
  }
  const callbacks = this.thresholdCallbacks.get(threshold)!;
  // Deduplicate by function reference
  if (!callbacks.includes(callback)) {
    callbacks.push(callback);
  }
}
```

**Why:** Prevents callbacks from firing multiple times per threshold hit.

---

#### Fix 3: Normalize Threshold Units (2 hours)
**Files:** 
- `packages/core/src/context/contextManager.ts`
- `packages/core/src/context/snapshotManager.ts`

**Problem:** Mixing fractions (0.6) and percentages (60) in different places

**Solution:** Standardize to fractions (0.0 to 1.0) everywhere

```typescript
// In contextManager.ts - addMessage()
// BEFORE:
if (usage.percentage >= this.config.compression.threshold * 100) {
  // compress
}

// AFTER:
const usageFraction = usage.currentTokens / usage.maxTokens;
if (usageFraction >= this.config.compression.threshold) {
  // compress
}

// In snapshotManager.ts - checkThresholds()
// Already uses fractions correctly, no change needed
```

**Why:** Eliminates confusion and calculation errors.

---

#### Fix 4: Fix Memory Guard Compression Call (1 hour)
**File:** `packages/core/src/context/memoryGuard.ts`

**Problem:** Line 163 passes wrong arguments to compression service

**Solution:**
```typescript
// BEFORE (Line 158-162):
case MemoryLevel.WARNING:
  if (this.compressionService && this.currentContext) {
    try {
      await this.compressionService.compress(this.currentContext);
    } catch (error) {
      console.error('Failed to compress context:', error);
    }
  }
  break;

// AFTER:
case MemoryLevel.WARNING:
  if (this.compressionService && this.currentContext) {
    try {
      await this.compressionService.compress(
        this.currentContext.messages,
        { type: 'hybrid', preserveRecentTokens: 500 }
      );
    } catch (error) {
      console.error('Failed to compress context:', error);
      // Re-throw to surface the error instead of silently failing
      throw error;
    }
  }
  break;
```

**Why:** Matches expected API signature and surfaces errors.

---

#### Fix 5: Fix Inflight Token Race Condition (2 hours)
**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Problem:** Lines 712-736 have race conditions with flush timer

**Solution:**
```typescript
// Add mutex for flush operations
const inflightFlushMutexRef = useRef(false);

// In onText callback (Line 712-736):
try {
  if (contextActions && contextActions.reportInflightTokens) {
    const estimatedTokens = Math.max(1, Math.ceil(text.length / 4));
    inflightTokenAccumulatorRef.current += estimatedTokens;
    
    // Schedule flush with mutex protection
    if (!inflightFlushTimerRef.current && !inflightFlushMutexRef.current) {
      inflightFlushTimerRef.current = setTimeout(() => {
        inflightFlushMutexRef.current = true;
        try {
          const toReport = inflightTokenAccumulatorRef.current;
          inflightTokenAccumulatorRef.current = 0;
          inflightFlushTimerRef.current = null;
          if (toReport > 0) {
            contextActions.reportInflightTokens(toReport);
          }
        } finally {
          inflightFlushMutexRef.current = false;
        }
      }, 500);
    }
  }
} catch (e) {
  // ignore estimation/report errors
}

// In error handler and cancel paths:
const cleanupInflightTokens = () => {
  if (inflightFlushTimerRef.current) {
    clearTimeout(inflightFlushTimerRef.current);
    inflightFlushTimerRef.current = null;
  }
  inflightTokenAccumulatorRef.current = 0;
  inflightFlushMutexRef.current = false;
  contextActions?.clearInflightTokens();
};
```

**Why:** Prevents double-reporting and ensures atomic cleanup.

---

#### Fix 6: Fix Resume Loop (1 hour)
**File:** `packages/cli/src/features/context/ChatContext.tsx`

**Problem:** Line 413 can cause infinite loop if compression keeps failing

**Solution:**
```typescript
// In handleAutoSummary (Line 296-324):
const handleAutoSummary = async (data: any) => {
  try {
    const summary = data?.summary;
    const text = summary?.content || '[Conversation summary]';

    addMessage({
      role: 'assistant',
      content: text,
      excludeFromContext: true,
    });
    
    compressionOccurredRef.current = true;
    compressionRetryCountRef.current = 0;
    
    // Check resume preference
    const settings = SettingsService.getInstance().getSettings();
    const resumePref = settings.llm?.resumeAfterSummary || 'ask';
    
    if (resumePref === 'ask') {
      waitingForResumeRef.current = true;
      addMessage({ 
        role: 'system', 
        content: 'Summary complete. Type "continue" to resume generation or "stop" to abort.', 
        excludeFromContext: true 
      });
    } else if (resumePref === 'auto') {
      // Auto-resume but with safety check
      const last = lastUserMessageRef.current;
      if (last && compressionRetryCountRef.current < 3) {
        compressionRetryCountRef.current++;
        setTimeout(() => { void sendMessage(last); }, 100);
      } else {
        addMessage({ 
          role: 'system', 
          content: 'Auto-resume failed after 3 attempts. Please try again manually.', 
          excludeFromContext: true 
        });
      }
    }
  } catch (err) {
    // ignore
  }
};

// In resume command handler (Line 406-416):
if (content.trim().toLowerCase() === 'continue' && waitingForResumeRef.current) {
  waitingForResumeRef.current = false;
  
  // Safety check: don't resume if we've retried too many times
  if (compressionRetryCountRef.current >= 3) {
    addMessage({ 
      role: 'system', 
      content: 'Maximum retry attempts reached. Please start a new conversation.', 
      excludeFromContext: true 
    });
    return;
  }
  
  addMessage({ role: 'system', content: 'Resuming generation...', excludeFromContext: true });
  const last = lastUserMessageRef.current;
  if (last) {
    compressionRetryCountRef.current++;
    setTimeout(() => { void sendMessage(last); }, 0);
  }
  return;
}
```

**Why:** Prevents infinite retry loops with safety counter.

---

### **Phase 2: Verification & Testing (4 hours)**

#### Test 1: Threshold Triggering (1 hour)
- [ ] Create test conversation that reaches 60% context
- [ ] Verify compression is triggered
- [ ] Verify "Summarizing..." message appears ONCE
- [ ] Verify compression completes
- [ ] Verify context is reduced

#### Test 2: Summary Triggering (1 hour)
- [ ] Create test conversation that reaches 80% context
- [ ] Verify summary is triggered
- [ ] Verify summary message is created
- [ ] Verify "continue" prompt appears (if resumeAfterSummary='ask')
- [ ] Verify typing "continue" resumes correctly

#### Test 3: Loop Prevention (1 hour)
- [ ] Simulate compression failure
- [ ] Verify retry counter works
- [ ] Verify max retries stops the loop
- [ ] Verify error message is shown

#### Test 4: Integration Test (1 hour)
- [ ] Run full conversation from 0% to 95% context
- [ ] Verify all thresholds trigger correctly
- [ ] Verify no infinite loops
- [ ] Verify task continues after compression/summary

**Deliverable:** All tests passing, no loops observed

---

### **Phase 3: Additional Fixes (8 hours)**

#### Fix 7: Timeout Forwarding in Hybrid Strategy (1 hour)
**File:** `packages/core/src/context/compressionService.ts`

**Problem:** `hybrid()` doesn't pass `summaryTimeout` to `generateLLMSummary()`

**Solution:** Add timeout parameter to all `generateLLMSummary()` calls

---

#### Fix 8: Standardize Token Counting (4 hours)
**Files:** Multiple services

**Problem:** 15+ locations use `Math.ceil(length/4)` instead of `TokenCounterService`

**Solution:** Refactor all services to use `TokenCounterService`

---

#### Fix 9: Add Integration Tests (3 hours)
**Files:** New test files in `packages/core/src/context/__tests__/integration/`

**Tests:**
- End-to-end compression flow
- End-to-end summary flow
- Memory guard integration
- Threshold triggering

---

## 📊 SUCCESS CRITERIA

### Must Have (Phase 1)
- ✅ No infinite loops when reaching context thresholds
- ✅ Compression triggers at 60% threshold
- ✅ Summary triggers at 80% threshold
- ✅ Resume command works without loops
- ✅ Task continues after compression/summary
- ✅ No crashes due to context overflow

### Should Have (Phase 2)
- ✅ All threshold callbacks fire correctly
- ✅ Inflight token accounting is accurate
- ✅ Event chain completes without gaps
- ✅ Error messages are clear and actionable

### Nice to Have (Phase 3)
- ✅ Token counting uses TokenCounterService everywhere
- ✅ Comprehensive integration tests
- ✅ Performance benchmarks
- ✅ Documentation updated

---

## 🔍 MONITORING & VALIDATION

### Runtime Checks
- [ ] Monitor console for debug logs
- [ ] Check for repeated "Summarizing..." messages
- [ ] Check for repeated "[No messages to compress]" messages
- [ ] Verify context usage percentage is accurate
- [ ] Verify compression reduces token count

### Health Indicators
- ✅ Context usage stays below 95%
- ✅ Compression completes in < 120s
- ✅ Summary completes in < 120s
- ✅ No memory leaks in event handlers
- ✅ No duplicate callback registrations

---

## 📝 NEXT STEPS

1. **IMMEDIATE:** Run Phase 0 (Emergency Diagnosis)
2. **TODAY:** Implement Phase 1 fixes
3. **TOMORROW:** Run Phase 2 verification tests
4. **THIS WEEK:** Complete Phase 3 additional fixes

---

**Document Status:** 🟢 Ready for Action  
**Created:** 2026-01-20  
**Priority:** URGENT  
**Estimated Total Time:** 22 hours (2-3 days)
