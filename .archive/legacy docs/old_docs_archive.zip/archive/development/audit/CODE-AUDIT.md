# Context System Code Audit

**Date:** January 20, 2026  
**Purpose:** Align implementation plan with existing codebase

---

## Executive Summary

**What Exists:**
- ✅ Basic context management infrastructure
- ✅ Progressive checkpoint system (Phase 1 complete)
- ✅ Token counting and VRAM monitoring
- ✅ Compression service with multiple strategies
- ✅ Snapshot management
- ⚠️ Model routing profiles (NOT operational modes)

**What's Missing:**
- ❌ Context tier detection system
- ❌ Operational mode system (Developer, Planning, Assistant, Debugger)
- ❌ Never-compressed sections
- ❌ Mode-aware compression
- ❌ UI for context status display

---

## Detailed Audit

### 1. Context Types (`packages/core/src/context/types.ts`)

**✅ Already Exists:**
```typescript
// Checkpoint system
export enum CheckpointLevel { COMPACT = 1, MODERATE = 2, DETAILED = 3 }
export interface CompressionCheckpoint { ... }

// Context structures
export interface ConversationContext {
  sessionId: string;
  messages: Message[];
  systemPrompt: Message;
  tokenCount: number;
  maxTokens: number;
  checkpoints?: CompressionCheckpoint[]; // ✅ Already has checkpoints
  metadata: { ... };
}

// Compression
export interface CompressionConfig {
  enabled: boolean;
  threshold: number; // ✅ Already has threshold
  strategy: CompressionStrategyType;
  preserveRecent: number;
  summaryMaxTokens: number;
}
```

**❌ Missing (Need to Add):**
```typescript
// Context tiers
export enum ContextTier {
  TIER_1_MINIMAL = '2-8K',
  TIER_2_BASIC = '8-16K',
  TIER_3_STANDARD = '16-32K',
  TIER_4_PREMIUM = '32K+'
}

export interface TierConfig { ... }

// Operational modes
export enum OperationalMode {
  DEVELOPER = 'developer',
  PLANNING = 'planning',
  ASSISTANT = 'assistant',
  DEBUGGER = 'debugger'
}

export interface ModeProfile { ... }

// Never-compressed sections
export interface NeverCompressedSection { ... }
export interface TaskDefinition { ... }
export interface ArchitectureDecision { ... }

// Update ConversationContext
export interface ConversationContext {
  // ... existing fields
  taskDefinition?: TaskDefinition; // ❌ ADD
  architectureDecisions: ArchitectureDecision[]; // ❌ ADD
  neverCompressed: NeverCompressedSection[]; // ❌ ADD
}
```

**⚠️ Confusion Alert:**
- There's a `ModelRouter` with routing profiles (fast, general, code, creative)
- These are NOT operational modes - they're for model selection
- We need separate operational modes for context management

---

### 2. Context Manager (`packages/core/src/context/contextManager.ts`)

**✅ Already Exists:**
```typescript
export class ConversationContextManager extends EventEmitter {
  public config: ContextConfig;
  private currentContext: ConversationContext;
  private checkpoints: CompressionCheckpoint[]; // ✅ Checkpoint tracking
  
  // Services
  private vramMonitor: VRAMMonitor;
  private tokenCounter: TokenCounter;
  private contextPool: ContextPool;
  private snapshotManager: SnapshotManager;
  private compressionService: ICompressionService;
  private memoryGuard: MemoryGuard;
  
  // Methods
  async addMessage(message: Message): Promise<void>
  async compress(): Promise<void>
  getUsage(): ContextUsage
  // ... more
}
```

**❌ Missing (Need to Add):**
```typescript
// Tier detection
private currentTier: ContextTier;
private tierConfig: TierConfig;
private detectContextTier(): TierConfig { ... }

// Mode management
private currentMode: OperationalMode = OperationalMode.DEVELOPER;
private modeProfile: ModeProfile;
public setMode(mode: OperationalMode): void { ... }
public getMode(): OperationalMode { ... }

// Never-compressed sections
public setTaskDefinition(task: TaskDefinition): void { ... }
public addArchitectureDecision(decision: ArchitectureDecision): void { ... }
public addNeverCompressed(section: NeverCompressedSection): void { ... }
private preserveNeverCompressed(context: ConversationContext): NeverCompressedSection[] { ... }

// Tier-specific compression
private async compressForTier1(): Promise<CompressedContext> { ... } // Rollover
private async compressForTier2(): Promise<CompressedContext> { ... } // Smart
private async compressForTier3(): Promise<CompressedContext> { ... } // Progressive
private async compressForTier4(): Promise<CompressedContext> { ... } // Structured
```

**🔧 Needs Modification:**
```typescript
// Current compress() method needs to dispatch to tier-specific methods
async compress(): Promise<void> {
  const tier = this.detectContextTier();
  
  switch (tier.strategy) {
    case 'rollover':
      await this.compressForTier1();
      break;
    case 'smart':
      await this.compressForTier2();
      break;
    case 'progressive':
      await this.compressForTier3(); // ✅ Already partially implemented
      break;
    case 'structured':
      await this.compressForTier4();
      break;
  }
}
```

---

### 3. Compression Service (`packages/core/src/context/compressionService.ts`)

**✅ Already Exists:**
```typescript
export class CompressionService implements ICompressionService {
  async compress(
    messages: Message[],
    strategy: CompressionStrategy
  ): Promise<CompressedContext> {
    switch (strategy.type) {
      case 'summarize': return this.summarize(messages, strategy);
      case 'truncate': return this.truncate(messages, strategy);
      case 'hybrid': return this.hybrid(messages, strategy);
    }
  }
}
```

**✅ Good News:**
- Compression service is already flexible
- Can be used by tier-specific methods
- No changes needed here

---

### 4. UI Components

**✅ Already Exists:**
```
packages/cli/src/ui/
├── components/
│   ├── status/
│   │   ├── MCPStatus.tsx ✅
│   │   └── WorkflowStatus.tsx ✅
│   ├── chat/ ✅
│   ├── model/ ✅
│   └── ...
├── contexts/ ✅
└── App.tsx ✅
```

**❌ Missing (Need to Create):**
```
packages/cli/src/ui/
├── components/
│   ├── status/
│   │   └── ContextStatus.tsx ❌ NEW - Right panel context display
│   └── ...
├── contexts/
│   └── ContextManagerContext.tsx ⚠️ EXISTS but needs mode support
└── ...
```

**📋 UI Requirements:**

**Right Panel - Context Status Display:**
```
┌─────────────────────────────┐
│ Context Status              │
├─────────────────────────────┤
│ Mode: Developer             │ ← Current operational mode
│ Strategy: Progressive       │ ← Compression strategy
│ Tier: Level 3 (16-32K)      │ ← Context tier
│ Usage: 18,432 / 32,768      │ ← Token usage
│ ├─ 56% utilized             │
│ └─ 14,336 tokens available  │
├─────────────────────────────┤
│ Checkpoints: 3              │ ← Checkpoint count
│ ├─ Compact: 1               │
│ ├─ Moderate: 1              │
│ └─ Detailed: 1              │
├─────────────────────────────┤
│ Never-Compressed:           │
│ ├─ Task Definition ✓        │
│ ├─ Architecture: 4 decisions│
│ └─ API Contracts: 2         │
└─────────────────────────────┘
```

**Visual Feedback on Changes:**
- Mode switch: Brief highlight/animation
- Tier change: Color change + notification
- Compression: Progress indicator
- Checkpoint created: Badge animation

---

### 5. Context Manager Context (`packages/cli/src/features/context/ContextManagerContext.tsx`)

**✅ Already Exists:**
```typescript
export const ContextManagerProvider: React.FC<Props> = ({ children, manager }) => {
  const [usage, setUsage] = useState<ContextUsage | null>(null);
  
  const contextActions = {
    compress: async () => { ... },
    reportInflightTokens: (delta: number) => { ... },
    clearInflightTokens: () => { ... },
    // ... more
  };
  
  return (
    <ContextManagerContext.Provider value={contextActions}>
      {children}
    </ContextManagerContext.Provider>
  );
};
```

**❌ Missing (Need to Add):**
```typescript
// Add to context state
const [mode, setMode] = useState<OperationalMode>(OperationalMode.DEVELOPER);
const [tier, setTier] = useState<ContextTier | null>(null);
const [checkpointStats, setCheckpointStats] = useState<CheckpointStats | null>(null);
const [neverCompressedCount, setNeverCompressedCount] = useState<number>(0);

// Add to context actions
const contextActions = {
  // ... existing
  setMode: (mode: OperationalMode) => { ... },
  getMode: () => mode,
  getTier: () => tier,
  getCheckpointStats: () => checkpointStats,
  setTaskDefinition: (task: TaskDefinition) => { ... },
  addArchitectureDecision: (decision: ArchitectureDecision) => { ... },
};

// Add event listeners
useEffect(() => {
  manager.on('mode-changed', ({ mode }) => setMode(mode));
  manager.on('tier-changed', ({ tier }) => setTier(tier));
  manager.on('checkpoint-created', () => updateCheckpointStats());
  manager.on('never-compressed-added', () => updateNeverCompressedCount());
}, [manager]);
```

---

## Alignment Analysis

### What Aligns Well ✅

1. **Checkpoint System**
   - Already implemented with 3 levels
   - Already has additive history
   - Already has aging and merging
   - ✅ Can be used directly for Tier 3

2. **Compression Infrastructure**
   - Already has multiple strategies
   - Already has threshold triggering
   - Already has token counting
   - ✅ Can be extended for tier-specific logic

3. **Event System**
   - Already uses EventEmitter
   - Already emits compression events
   - Already has event listeners in UI
   - ✅ Can add new events for modes/tiers

4. **UI Structure**
   - Already has status components
   - Already has context system
   - Already has event handling
   - ✅ Can add new ContextStatus component

### What Needs Adjustment ⚠️

1. **Mode Confusion**
   - Existing "modes" are routing profiles for model selection
   - Need separate operational modes for context management
   - ✅ Solution: Add `OperationalMode` enum, keep routing profiles separate

2. **Context Structure**
   - `ConversationContext` needs new fields
   - Need to add never-compressed sections
   - ✅ Solution: Extend interface, maintain backward compatibility

3. **Compression Logic**
   - Current `compress()` doesn't dispatch by tier
   - Need tier-specific compression methods
   - ✅ Solution: Add tier detection, dispatch to tier methods

4. **UI Integration**
   - No context status display
   - No mode switching UI
   - ✅ Solution: Create `ContextStatus` component, add to right panel

---

## Updated Implementation Plan

### Phase 2A: Core Infrastructure (Week 1)

**Task 1: Add Types (2 hours)**
- Add `ContextTier`, `TierConfig`, `TIER_CONFIGS` to `types.ts`
- Add `OperationalMode`, `ModeProfile`, `MODE_PROFILES` to `types.ts`
- Add `NeverCompressedSection`, `TaskDefinition`, `ArchitectureDecision` to `types.ts`
- Update `ConversationContext` interface
- ✅ No conflicts with existing code

**Task 2: Add Mode Management (3 hours)**
- Add mode fields to `ConversationContextManager`
- Add `setMode()`, `getMode()` methods
- Add mode change events
- ✅ Separate from routing profiles

**Task 3: Add Tier Detection (2 hours)**
- Add `detectContextTier()` method
- Add tier change events
- Update `compress()` to dispatch by tier
- ✅ Uses existing `maxTokens` from config

**Task 4: Add Never-Compressed Sections (4 hours)**
- Add storage fields to context
- Add `setTaskDefinition()`, `addArchitectureDecision()` methods
- Add `preserveNeverCompressed()` method
- Add reconstruction logic
- ✅ Extends existing checkpoint system

### Phase 2B: Tier Implementations (Week 2)

**Task 5: Enhance Tier 3 (4 hours)** ⭐ PRIMARY
- Modify existing progressive checkpoint logic
- Add mode-aware extraction
- Add never-compressed preservation
- ✅ Builds on existing checkpoint system

**Task 6: Implement Tier 2 (3 hours)**
- Add smart compression method
- Add critical extraction
- Add single checkpoint logic
- ✅ Uses existing compression service

**Task 7: Implement Tier 1 (3 hours)**
- Add rollover method
- Add snapshot creation
- Add compact summary generation
- ✅ Uses existing snapshot manager

### Phase 2C: UI Integration (Week 3)

**Task 8: Create ContextStatus Component (4 hours)** ⭐ NEW
- Create `packages/cli/src/ui/components/status/ContextStatus.tsx`
- Display mode, tier, usage, checkpoints
- Add visual feedback for changes
- Add to right panel in App.tsx

**Task 9: Update Context Provider (2 hours)**
- Add mode/tier state to `ContextManagerContext`
- Add mode/tier actions
- Add event listeners
- Expose to UI components

**Task 10: Add Visual Feedback (2 hours)**
- Mode switch animation
- Tier change notification
- Compression progress
- Checkpoint badges

### Phase 2D: Testing (Week 3)

**Task 11: Update Test Suite (4 hours)**
- Update existing tests for new fields
- Add tier detection tests
- Add mode profile tests
- Add never-compressed tests
- Add UI component tests

---

## Migration Strategy

### Backward Compatibility

**✅ Safe Changes:**
- Adding new optional fields to `ConversationContext`
- Adding new methods to `ConversationContextManager`
- Adding new event types
- Adding new UI components

**⚠️ Breaking Changes (None Expected):**
- All changes are additive
- Existing code continues to work
- New features are opt-in

### Default Behavior

**Without Configuration:**
- Mode: `DEVELOPER` (default)
- Tier: Auto-detected from `maxTokens`
- Strategy: Existing behavior (progressive checkpoints)
- Never-compressed: Empty (no sections)

**With Configuration:**
- User can set mode explicitly
- User can override tier detection
- User can add never-compressed sections
- User can customize mode profiles

---

## File Changes Summary

### New Files (3)
1. `packages/cli/src/ui/components/status/ContextStatus.tsx` - Context status display
2. `packages/core/src/context/__tests__/adaptive-compression.test.ts` - New tests
3. `packages/core/src/context/__tests__/context-ui.test.tsx` - UI tests

### Modified Files (4)
1. `packages/core/src/context/types.ts` - Add new types
2. `packages/core/src/context/contextManager.ts` - Add mode/tier logic
3. `packages/cli/src/features/context/ContextManagerContext.tsx` - Add mode/tier state
4. `packages/cli/src/ui/App.tsx` - Add ContextStatus component

### Test Files (2)
1. `packages/core/src/context/__tests__/progressive-checkpoints.test.ts` - Update
2. `packages/core/src/context/__tests__/contextManager.test.ts` - Update

---

## Risk Assessment

### Low Risk ✅
- Adding new types (no breaking changes)
- Adding new methods (backward compatible)
- Adding new UI components (isolated)
- Adding new events (opt-in)

### Medium Risk ⚠️
- Modifying `compress()` method (needs careful testing)
- Updating `ConversationContext` structure (needs migration)
- Adding event listeners (needs cleanup)

### High Risk ❌
- None identified

---

## Success Criteria

### Code Quality
- ✅ All TypeScript compiles without errors
- ✅ All existing tests pass
- ✅ New tests achieve >80% coverage
- ✅ No breaking changes to existing API

### Functionality
- ✅ Tier detection works for all 4 tiers
- ✅ Mode switching works correctly
- ✅ Never-compressed sections are preserved
- ✅ UI displays context status accurately
- ✅ Visual feedback works on changes

### Performance
- ✅ No performance regression
- ✅ Tier detection is fast (<10ms)
- ✅ Mode switching is instant
- ✅ UI updates are smooth (60fps)

---

## Next Steps

1. **Review this audit** - Confirm alignment with existing code
2. **Update implementation plan** - Incorporate UI tasks
3. **Start with Task 1** - Add types (2 hours)
4. **Create ContextStatus component** - UI foundation (4 hours)
5. **Implement tier detection** - Core logic (2 hours)
6. **Test integration** - Ensure everything works together

---

**Audit Status:** ✅ Complete  
**Alignment:** ✅ Good - No major conflicts  
**Ready to Implement:** ✅ Yes  
**Estimated Total:** 33 hours (4 weeks with UI)
