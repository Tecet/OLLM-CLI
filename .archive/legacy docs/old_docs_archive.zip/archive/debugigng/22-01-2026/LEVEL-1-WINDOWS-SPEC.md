# Level 1 Windows Specification

**Date:** January 22, 2026  
**Status:** 📝 Documentation

## Level 1 Areas with Multiple Windows

### Left Main Area - Chat Window
This area can display different windows:
1. **LLM Chat** (chat-history) - Default chat interface
2. **Terminal** (terminal-window) - Terminal emulator
3. **Editor** (editor-window) - Code editor

**Focus ID:** All use `chat-history` as the focus ID for Level 1

### Right Panel - Side Panel
This area can display different views:
1. **Tools** (context-panel) - Default tools view
2. **Workspace** (context-panel) - Workspace file browser

**Focus ID:** Both use `context-panel` as the focus ID for Level 1

## ESC Behavior (2-Step) Applies to ALL Windows

### From LLM Chat Window
```
LLM Chat (chat-history)
  ↓ ESC (1st)
Nav Bar on Chat tab
  ↓ ESC (2nd)
User Input
```

### From Terminal Window
```
Terminal (chat-history)
  ↓ ESC (1st)
Nav Bar on Chat tab
  ↓ ESC (2nd)
User Input
```

### From Editor Window
```
Editor (chat-history)
  ↓ ESC (1st)
Nav Bar on Chat tab
  ↓ ESC (2nd)
User Input
```

### From Tools View (Right Panel)
```
Tools (context-panel)
  ↓ ESC (1st)
Nav Bar on Chat tab
  ↓ ESC (2nd)
User Input
```

### From Workspace View (Right Panel)
```
Workspace (context-panel)
  ↓ ESC (1st)
Nav Bar on Chat tab
  ↓ ESC (2nd)
User Input
```

## Current Focus IDs

### Level 1 Focus IDs
```typescript
const level1: FocusableId[] = [
  'chat-input',      // User Input area
  'chat-history',    // Chat Window (LLM Chat, Terminal, Editor)
  'nav-bar',         // Navigation bar
  'context-panel',   // Side Panel (Tools, Workspace)
  'system-bar',      // System status bar
];
```

**Note:** 
- `chat-history` covers all left main area windows (LLM Chat, Terminal, Editor)
- `context-panel` covers all right panel views (Tools, Workspace)

## Window Switching

Users can switch between windows within the same area:
- **Ctrl+Left/Right** - Switch between LLM Chat, Terminal, Editor
- **Panel Toggle** - Switch between Tools and Workspace views

**Important:** Window switching does NOT change the focus ID. All windows in the same area share the same Level 1 focus ID.

## Implementation Status

### ✅ Already Correct
The current implementation treats all windows within an area as the same Level 1 focus:
- All left main windows (Chat, Terminal, Editor) → `chat-history`
- All right panel views (Tools, Workspace) → `context-panel`

### ✅ ESC Works Consistently
The 2-step ESC process works the same regardless of which window is active:
1. First ESC → Nav Bar on Chat tab
2. Second ESC → User Input

## Testing Checklist

### Left Main Area Windows
- [ ] LLM Chat → ESC → Nav Bar Chat → ESC → User Input
- [ ] Terminal → ESC → Nav Bar Chat → ESC → User Input
- [ ] Editor → ESC → Nav Bar Chat → ESC → User Input

### Right Panel Views
- [ ] Tools View → ESC → Nav Bar Chat → ESC → User Input
- [ ] Workspace View → ESC → Nav Bar Chat → ESC → User Input

### Window Switching + ESC
- [ ] Switch to Terminal → ESC → Nav Bar Chat → ESC → User Input
- [ ] Switch to Editor → ESC → Nav Bar Chat → ESC → User Input
- [ ] Switch to Workspace → ESC → Nav Bar Chat → ESC → User Input

## Visual Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                      LEVEL 1: Tab Cycle                     │
│                                                              │
│  ┌──────────────┐                    ┌──────────────┐       │
│  │ User Input   │                    │  Side Panel  │       │
│  │              │                    │  ┌────────┐  │       │
│  │ chat-input   │                    │  │ Tools  │  │       │
│  └──────────────┘                    │  │   or   │  │       │
│                                       │  │Workspace│  │       │
│  ┌──────────────┐                    │  └────────┘  │       │
│  │ Chat Window  │                    │              │       │
│  │  ┌────────┐  │                    │context-panel │       │
│  │  │LLM Chat│  │                    └──────────────┘       │
│  │  │   or   │  │                                           │
│  │  │Terminal│  │         ┌──────────────┐                 │
│  │  │   or   │  │         │   Nav Bar    │                 │
│  │  │ Editor │  │         │              │                 │
│  │  └────────┘  │         │   nav-bar    │                 │
│  │              │         └──────────────┘                 │
│  │chat-history  │                                           │
│  └──────────────┘                                           │
│                                                              │
│  ESC from ANY window:                                       │
│    1st ESC → Nav Bar on Chat tab                            │
│    2nd ESC → User Input                                     │
└─────────────────────────────────────────────────────────────┘
```

## Summary

The 2-step ESC process (Nav Bar Chat → User Input) applies to **ALL** Level 1 windows:

**Left Main Area:**
- LLM Chat ✅
- Terminal ✅
- Editor ✅

**Right Panel:**
- Tools View ✅
- Workspace View ✅

**Other Level 1:**
- Nav Bar ✅
- User Input ✅
- System Bar ✅

All windows within the same area share the same focus ID, so ESC behavior is consistent regardless of which window is currently displayed.
