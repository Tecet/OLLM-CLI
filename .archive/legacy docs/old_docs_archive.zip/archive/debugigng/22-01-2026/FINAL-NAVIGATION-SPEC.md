# Final Navigation Specification

**Date:** January 22, 2026  
**Status:** ✅ Complete

## Navigation Keys

### Tab - Cycle Through Level 1
Cycles through main UI areas:
```
User Input → Chat Window → Nav Bar → Side Panel → (loop back to User Input)
```

### Enter - Go Deeper
Activates/opens selected item:
```
Nav Bar (on Files tab) → Enter → Files Tab Content (Level 2)
Files Tab (on file) → Enter → Syntax Viewer (Level 3)
```

### ESC - Go Up/Home
Moves up one level, with 2-step process from Level 1:
```
Level 3 → ESC → Level 2
Level 2 → ESC → Nav Bar (Level 1)
Level 1 → ESC → Nav Bar on Chat (if not already there)
Nav Bar on Chat → ESC → User Input
```

## Complete ESC Flow

### From Level 3 (Modals/Viewers)
```
Syntax Viewer
  ↓ ESC
Files Tab (Level 2)
```

### From Level 2 (Tab Content)
```
Files Tab
  ↓ ESC
Nav Bar (Level 1)
```

### From Level 1 (Tab Cycle) - Two-Step Process

#### If NOT on Chat tab in navbar:
```
Side Panel (Level 1)
  ↓ ESC (1st press)
Nav Bar on Chat tab (Level 1) ← Visual confirmation
  ↓ ESC (2nd press)
User Input
```

#### If on Chat tab in navbar:
```
Nav Bar on Chat tab (Level 1)
  ↓ ESC (1st press)
User Input
```

#### If on Chat Window or User Input:
```
Chat Window (Level 1)
  ↓ ESC (1st press)
Nav Bar on Chat tab (Level 1) ← Visual confirmation
  ↓ ESC (2nd press)
User Input
```

## Visual Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    LEVEL 3: Modals & Viewers                │
│                                                              │
│  Syntax Viewer, Dialogs, Help Panel, etc.                  │
│                                                              │
│  ESC → Parent (Level 2)                                     │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    LEVEL 2: Tab Content                     │
│                                                              │
│  Files Tab, Tools Tab, Hooks Tab, etc.                     │
│                                                              │
│  ESC → Nav Bar (Level 1)                                    │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                 LEVEL 1: Tab Cycle (Main UI)                │
│                                                              │
│  ┌──────────────┐   Tab    ┌──────────────┐                │
│  │ User Input   │ ←──────→ │ Chat Window  │                │
│  └──────────────┘          └──────────────┘                │
│         ↕                          ↕                         │
│  ┌──────────────┐          ┌──────────────┐                │
│  │ Side Panel   │ ←──────→ │ Nav Bar      │                │
│  └──────────────┘   Tab    └──────────────┘                │
│                                                              │
│  ESC (1st) → Nav Bar on Chat tab                            │
│  ESC (2nd) → User Input                                     │
└─────────────────────────────────────────────────────────────┘
```

## Example Scenarios

### Scenario 1: Deep Navigation from Files Tab
```
1. User Input
2. Tab → Chat Window
3. Tab → Nav Bar
4. Arrow keys to Files tab
5. Enter → Files Tab Content (Level 2)
6. Navigate files, Enter on file.ts
7. Syntax Viewer opens (Level 3)
8. ESC → Back to Files Tab (Level 2)
9. ESC → Nav Bar (Level 1)
10. ESC → Nav Bar switches to Chat tab (visual confirmation)
11. ESC → User Input
```

### Scenario 2: Quick Return from Side Panel
```
1. User Input
2. Tab → Tab → Tab → Side Panel
3. ESC → Nav Bar on Chat tab (visual confirmation)
4. ESC → User Input
```

### Scenario 3: Already on Chat Tab
```
1. User Input
2. Tab → Chat Window
3. Tab → Nav Bar (already on Chat tab)
4. ESC → User Input (only 1 ESC needed)
```

### Scenario 4: From Tools Tab
```
1. Nav Bar on Tools tab
2. ESC → Nav Bar switches to Chat tab (visual confirmation)
3. ESC → User Input
```

## Benefits of 2-Step ESC

### 1. Visual Confirmation
Users see the Chat tab become active before going to input, confirming they're going home.

### 2. Prevents Accidental Jumps
If user is on Tools tab and accidentally presses ESC, they see Chat tab activate and can press Tab to go back to Tools.

### 3. Consistent with Tab Cycling
The navbar is part of the Tab cycle, so ESC goes through it on the way to input.

### 4. Muscle Memory
Users learn: "ESC twice from anywhere in Level 1 gets me to input"

## Implementation

### exitOneLevel() Logic

```typescript
const exitOneLevel = useCallback(() => {
  const currentLevel = getFocusLevel(activeId);

  if (currentLevel === 3) {
    // Level 3 → Level 2 (return to parent)
    if (modalParent) {
      setActiveId(modalParent);
      setModalParent(null);
    } else {
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    }
  } else if (currentLevel === 2) {
    // Level 2 → Level 1 (go to navbar)
    setActiveId('nav-bar');
    setModeState('browse');
  } else if (currentLevel === 1) {
    // Level 1 → Two-step process
    if (activeId === 'nav-bar' && activeTab === 'chat') {
      // Already on Chat tab in navbar → Go to user input
      setActiveId('chat-input');
    } else {
      // Not on Chat tab in navbar → Switch to Chat tab (stay in navbar)
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    }
  }
}, [activeId, modalParent, getFocusLevel, activeTab, setActiveTab]);
```

## Testing Checklist

### Level 1 ESC (2-Step)
- [ ] User Input → ESC → Nav Bar Chat → ESC → User Input
- [ ] Chat Window → ESC → Nav Bar Chat → ESC → User Input
- [ ] Nav Bar (Tools) → ESC → Nav Bar Chat → ESC → User Input
- [ ] Nav Bar (Chat) → ESC → User Input (1 step)
- [ ] Side Panel → ESC → Nav Bar Chat → ESC → User Input

### Level 2 ESC
- [ ] Files Tab → ESC → Nav Bar
- [ ] Tools Tab → ESC → Nav Bar
- [ ] Any Tab → ESC → Nav Bar

### Level 3 ESC
- [ ] Syntax Viewer → ESC → Files Tab
- [ ] Search Dialog → ESC → Files Tab
- [ ] Any Modal → ESC → Parent Tab

### Tab Cycling
- [ ] User Input → Tab → Chat Window
- [ ] Chat Window → Tab → Nav Bar
- [ ] Nav Bar → Tab → Side Panel
- [ ] Side Panel → Tab → User Input (loops)

### Enter Navigation
- [ ] Nav Bar → Enter → Tab Content
- [ ] Files Tab → Enter on file → Syntax Viewer

## Summary

The navigation system now uses:

1. **Tab** - Cycle through Level 1 areas
2. **Enter** - Go deeper into selected item
3. **ESC** - Go up one level with 2-step process from Level 1

**ESC from Level 1 (2-step):**
- 1st ESC → Nav Bar on Chat tab (visual confirmation)
- 2nd ESC → User Input

**ESC from Level 2:**
- ESC → Nav Bar (Level 1)

**ESC from Level 3:**
- ESC → Parent (Level 2)

This provides intuitive, predictable navigation with visual feedback at each step.
