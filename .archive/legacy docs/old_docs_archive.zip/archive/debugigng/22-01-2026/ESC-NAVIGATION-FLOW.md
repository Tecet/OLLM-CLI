# ESC Navigation Flow - Complete Specification

**Date:** January 22, 2026  
**Status:** ✅ Implemented

## Overview

The ESC key provides consistent navigation back to the user input area, with intelligent handling of the navbar and tab switching.

## Complete ESC Flow

### Level 4: Modals & Viewers
**From:** Syntax viewer, search dialog, help panel, quick open, etc.  
**ESC Action:** Close modal, return to parent tab content  
**Example:**
```
Syntax Viewer (Level 4)
  ↓ ESC
Files Tab (Level 3) - returns to the tab that opened the viewer
```

### Level 3: Tab Content & Panels
**From:** Files tab, side panel, chat history, tools panel, etc.  
**ESC Action:** Switch to Chat tab + Jump to user input (skip navbar)  
**Example:**
```
Files Tab (Level 3)
  ↓ ESC
Chat Tab selected in navbar + User Input focused (Level 1)
```

**Rationale:** Users working in tabs want to quickly return to input. Forcing them to go through navbar would require an extra ESC press.

### Level 2: Navigation Bar
**From:** Navbar (browsing tabs)  
**ESC Action:** Depends on current tab

#### If NOT on Chat tab:
```
Navbar on Tools Tab (Level 2)
  ↓ ESC
Navbar on Chat Tab (Level 2) - stay in navbar, just switch tab
```

#### If on Chat tab:
```
Navbar on Chat Tab (Level 2)
  ↓ ESC
User Input (Level 1)
```

**Rationale:** If user is actively browsing tabs in navbar, they might want to see the Chat tab before going to input. This gives them a chance to see what's in chat.

### Level 1: User Input
**From:** User input (chat-input)  
**ESC Action:** Nothing (already at root)

## Visual Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ Level 4: Modals & Viewers                                   │
│ (syntax-viewer, search-dialog, help-panel, etc.)            │
│                                                              │
│  ESC → Return to parent tab content (Level 3)               │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Level 3: Tab Content & Panels                               │
│ (file-tree, side-file-tree, chat-history, tools-panel, etc.)│
│                                                              │
│  ESC → Switch to Chat tab + Jump to User Input (Level 1)    │
│        (Skip navbar entirely)                                │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Level 2: Navigation Bar                                     │
│ (nav-bar - browsing tabs)                                   │
│                                                              │
│  If NOT on Chat tab:                                         │
│    ESC → Switch to Chat tab (stay in navbar)                │
│                                                              │
│  If on Chat tab:                                             │
│    ESC → User Input (Level 1)                                │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Level 1: User Input                                         │
│ (chat-input - root)                                         │
│                                                              │
│  ESC → Nothing (already at root)                             │
└─────────────────────────────────────────────────────────────┘
```

## Example Scenarios

### Scenario 1: Working in Files Tab

```
User is in Files tab, browsing files
  ↓ Press Enter on file
Syntax viewer opens
  ↓ Press ESC
Back to Files tab
  ↓ Press ESC
Chat tab selected + User input focused
  ↓ User can type immediately
```

### Scenario 2: Working in Side Panel

```
User is in Workspace panel (side panel)
  ↓ Press Enter on file
Syntax viewer opens
  ↓ Press ESC
Back to Workspace panel
  ↓ Press ESC
Chat tab selected + User input focused
  ↓ User can type immediately
```

### Scenario 3: Browsing Tabs in Navbar

```
User is in navbar, on Tools tab
  ↓ Press ESC
Navbar switches to Chat tab (stays in navbar)
  ↓ Press ESC
User input focused
  ↓ User can type immediately
```

### Scenario 4: Already on Chat Tab in Navbar

```
User is in navbar, on Chat tab
  ↓ Press ESC
User input focused
  ↓ User can type immediately
```

### Scenario 5: Deep Nesting

```
User is in Files tab
  ↓ Press Ctrl+F
Search dialog opens (Level 4)
  ↓ Press ESC
Back to Files tab (Level 3)
  ↓ Press ESC
Chat tab selected + User input focused (Level 1)
  ↓ User can type immediately
```

## Implementation Details

### FocusContext.tsx - exitOneLevel()

```typescript
const exitOneLevel = useCallback(() => {
  const currentLevel = getFocusLevel(activeId);

  if (currentLevel === 4) {
    // Modal/Viewer → Parent tab content
    if (modalParent) {
      setActiveId(modalParent);
      setModalParent(null);
    } else {
      // Fallback: go to nav-bar on chat tab
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    }
  } else if (currentLevel === 3) {
    // Tab content (including side panel) → Switch to Chat tab AND go to user input
    // This skips the navbar and goes straight to input, but ensures chat tab is selected
    setActiveTab('chat');
    setActiveId('chat-input');
  } else if (currentLevel === 2) {
    // Nav bar → First ensure we're on chat tab, then go to user input
    if (activeTab !== 'chat') {
      // If not on chat tab, switch to chat tab in nav bar (stay in nav bar)
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    } else {
      // Already on chat tab in nav bar, go to user input
      setActiveId('chat-input');
    }
  }
  // Level 1: Already at root, do nothing
}, [activeId, modalParent, getFocusLevel, activeTab, setActiveTab]);
```

### Key Points

1. **Level 4 → Level 3:** Returns to parent that opened the modal
2. **Level 3 → Level 1:** Skips navbar, goes straight to input (but switches to chat tab)
3. **Level 2 → Level 2 or Level 1:** Smart handling based on current tab
4. **Level 1:** No-op (already at root)

## Why This Design?

### Why Skip Navbar from Level 3?

**Problem:** If we forced users to go through navbar, they'd need 2 ESC presses to get back to input:
```
Files Tab → ESC → Navbar → ESC → Input
```

**Solution:** Skip navbar, go straight to input:
```
Files Tab → ESC → Input (with Chat tab selected)
```

**Benefit:** Faster return to input, which is the most common action.

### Why Keep Navbar Logic for Level 2?

**Problem:** If user is actively browsing tabs in navbar, they might want to see Chat tab before going to input.

**Solution:** If not on Chat tab, switch to Chat tab (stay in navbar). If on Chat tab, go to input.

**Benefit:** Gives users a chance to see what's in Chat before committing to input.

### Why Always Switch to Chat Tab?

**Problem:** If user is on Tools tab and presses ESC, should they stay on Tools tab?

**Solution:** Always switch to Chat tab when going to input.

**Benefit:** 
- Chat is the "home" tab
- User input is for chat
- Consistent behavior: ESC always leads to Chat + Input

## Edge Cases

### Case 1: Modal with No Parent

**Scenario:** Modal opens but parent tracking fails  
**Behavior:** Falls back to navbar on chat tab  
**Code:**
```typescript
if (modalParent) {
  setActiveId(modalParent);
  setModalParent(null);
} else {
  // Fallback
  setActiveTab('chat');
  setActiveId('nav-bar');
  setModeState('browse');
}
```

### Case 2: Rapid ESC Presses

**Scenario:** User mashes ESC key  
**Behavior:** Each press moves up one level until reaching input, then stops  
**Protection:** Level 1 check prevents further action

### Case 3: ESC During Streaming

**Scenario:** User presses ESC while LLM is generating  
**Behavior:** Cancels generation (handled in App.tsx before exitOneLevel)  
**Code:**
```typescript
if (chatState.streaming || chatState.waitingForResponse) {
  cancelGeneration();
} else {
  focusManager.exitOneLevel();
}
```

### Case 4: ESC from Side Panel

**Scenario:** User is in side panel (context-panel, side-file-tree)  
**Behavior:** Same as any Level 3 content - switches to Chat + goes to input  
**Rationale:** Side panel is Level 3, follows same rules

## Testing Checklist

- [ ] ESC from syntax viewer in Files tab
- [ ] ESC from syntax viewer in Workspace panel
- [ ] ESC from Files tab content
- [ ] ESC from Workspace panel content
- [ ] ESC from Chat tab content
- [ ] ESC from Tools tab content
- [ ] ESC from navbar on Tools tab
- [ ] ESC from navbar on Chat tab
- [ ] ESC from user input (should do nothing)
- [ ] ESC during LLM streaming (should cancel)
- [ ] Rapid ESC presses
- [ ] ESC from search dialog
- [ ] ESC from help panel
- [ ] ESC from quick open
- [ ] ESC from quick actions menu

## User Benefits

1. **Fast Return to Input:** One ESC from any tab content
2. **Predictable:** Always leads to Chat + Input
3. **Efficient:** No unnecessary stops at navbar
4. **Flexible:** Navbar browsing still works as expected
5. **Consistent:** Same behavior across all tabs and panels

## Future Enhancements

1. **Visual Breadcrumbs:** Show current focus level in status bar
2. **Focus History:** Ctrl+Shift+ESC to go back to previous focus
3. **Custom ESC Behavior:** Settings to customize ESC navigation
4. **Focus Indicators:** Highlight current focus level with colors
5. **Keyboard Shortcuts:** Alt+1/2/3/4 to jump to specific levels

## Related Files

- `packages/cli/src/features/context/FocusContext.tsx` - Focus management
- `packages/cli/src/ui/App.tsx` - Global ESC handler
- `packages/cli/src/ui/components/file-explorer/FileTreeView.tsx` - Files tab
- `packages/cli/src/ui/components/layout/WorkspacePanel.tsx` - Workspace panel
- `.dev/HIERARCHICAL-FOCUS-IMPLEMENTATION.md` - Implementation details
- `.dev/FOCUS-HIERARCHY-AUDIT.md` - Initial audit
