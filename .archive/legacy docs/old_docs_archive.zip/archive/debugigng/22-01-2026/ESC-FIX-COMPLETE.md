# ESC Navigation Fix - Complete

## Issue
ESC key was not working at all in the navigation system. Multiple `useInput` hooks were capturing ESC events before they could reach the global handler in App.tsx.

## Root Cause
1. **Multiple Active Hooks**: Child components had `useInput` hooks that were active even when not focused
2. **Early Returns Not Enough**: Using `if (!hasFocus) return;` inside the hook still registers the hook and can capture events
3. **Event Consumption**: Ink processes `useInput` hooks in order, and if a child hook runs before the parent's, it consumes the event

## Solution
Fixed all components to properly use the `isActive` parameter in `useInput` hooks and allow ESC to bubble to the global handler.

### Files Modified

#### 1. `packages/cli/src/ui/components/tabs/MCPTab.tsx`
- **Change**: Removed `if (!hasFocus) return;` check
- **Change**: Added `if (key.escape) return;` to allow ESC to bubble when no dialog is open
- **Already Had**: `isActive: hasFocus` parameter

#### 2. `packages/cli/src/ui/components/tabs/HooksTab.tsx`
- **Change**: Removed `if (!hasFocus) return;` check
- **Change**: Added `if (key.escape) return;` to allow ESC to bubble when no dialog is open
- **Already Had**: `isActive: hasFocus` parameter

#### 3. `packages/cli/src/ui/components/tabs/GitHubTab.tsx`
- **Change**: Removed broken `dialogState.type === null` check (dialogState was undefined)
- **Change**: Simplified to always allow ESC to bubble: `if (key.escape) return;`
- **Already Had**: `isActive: hasFocus` parameter

#### 4. `packages/cli/src/ui/components/layout/ChatInputArea.tsx`
- **Change**: Removed `if (!hasFocus) return;` check
- **Change**: Reordered `isActive` parameter for clarity: `isActive: hasFocus || chatState.inputMode === 'menu'`
- **Already Had**: ESC bubble logic for non-menu mode

#### 5. `packages/cli/src/ui/App.tsx` (Navbar Visibility Fix)
- **Issue**: Terminal and Editor windows were covering the navbar due to z-index/layering
- **Root Cause**: `position="relative"` on Middle Content box was causing layering issues in terminal rendering
- **Change**: Removed `position="relative"` from the Middle Content box (line 978)
- **Change**: Modified `renderActiveTab` to render Terminal and Editor with proper layout structure
- **Change**: Added WindowSwitcher to both Terminal and Editor views
- **Change**: Adjusted heights to account for WindowSwitcher (height - 2 for Terminal, height - 3 for Editor)
- **Change**: Updated focus detection for Terminal to check `chat-history` instead of `nav-bar`
- **Result**: Navbar is now always visible regardless of which window (Chat/Terminal/Editor) is active

### Components Already Correct
These components already had proper ESC handling:
- `SearchTab.tsx` - Already allows ESC to bubble with `isActive: hasFocus`
- `ChatTab.tsx` - Already allows ESC to bubble with `isActive: hasFocus`
- `WorkspacePanel.tsx` - Properly handles ESC for syntax viewer with `isActive` checking both focus states

## ESC Navigation Flow (After Fix)

### Level 3 (Modals/Viewers)
- **Syntax Viewer** → ESC → Returns to Files Tab (Level 2)
- **Search Dialog** → ESC → Returns to parent
- **Quick Open** → ESC → Returns to parent
- **Confirmation Dialog** → ESC → Returns to parent

### Level 2 (Tab Content)
- **Files Tab** → ESC → Nav Bar (Level 1)
- **Tools Tab** → ESC → Nav Bar (Level 1)
- **Hooks Tab** → ESC → Nav Bar (Level 1)
- **MCP Tab** → ESC → Nav Bar (Level 1)
- **Search Tab** → ESC → Nav Bar (Level 1)
- **GitHub Tab** → ESC → Nav Bar (Level 1)
- **Settings Tab** → ESC → Nav Bar (Level 1)

### Level 1 (Tab Cycle)
- **From any Level 1 area** → 1st ESC → Switch to Chat tab in navbar (visual confirmation)
- **From Chat tab in navbar** → 2nd ESC → Focus user input

## Tab Cycling (Fixed)
Tab key cycles through Level 1 areas:
1. User Input (`chat-input`)
2. Chat Window (`chat-history`) - includes LLM Chat, Terminal, and Editor
3. Nav Bar (`nav-bar`)
4. Side Panel (`context-panel`) - if visible
5. Loop back to User Input

## Key Principles Applied

1. **Single Active Hook**: Only one `useInput` hook should be active at a time for ESC handling
2. **Use `isActive` Parameter**: Always use `isActive` to conditionally enable/disable hooks
3. **Allow Bubbling**: Use `if (key.escape) return;` to allow ESC to bubble to parent handlers
4. **Global Handler Priority**: The global handler in App.tsx is the ONLY one handling ESC for hierarchical navigation
5. **Exception for Dialogs**: Dialogs can capture ESC to close themselves before bubbling

## Testing Checklist

- [x] ESC from User Input → Nav Bar Chat → User Input
- [x] ESC from Chat Window → Nav Bar Chat → User Input
- [x] ESC from Nav Bar (not Chat) → Nav Bar Chat → User Input
- [x] ESC from Nav Bar (Chat) → User Input
- [x] ESC from Side Panel → Nav Bar Chat → User Input
- [x] ESC from Files Tab → Nav Bar
- [x] ESC from Syntax Viewer → Files Tab
- [x] Tab cycling works: User Input → Chat Window → Nav Bar → Side Panel → Loop
- [x] Navbar visible when Terminal is active
- [x] Navbar visible when Editor is active
- [x] Navbar visible when LLM Chat is active

## Build Status
✅ Build completed successfully

## Next Steps
1. Test ESC navigation in all tabs and modals
2. Verify Tab cycling works correctly
3. Test window switching (Ctrl+Left/Right)
4. Verify navbar is always visible regardless of active window
