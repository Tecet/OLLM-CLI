# Navigation Summary - Tab, Enter, ESC

**Date:** January 22, 2026  
**Status:** ✅ Complete

## Navigation Keys

### Tab Key - Cycle Through Main UI
Cycles through Level 1 areas:
```
User Input → Chat Window → Nav Bar → Side Panel → (repeat)
```

### Enter Key - Go Deeper
Activates/opens the selected item:
```
Nav Bar (on Files tab) → Enter → Files Tab Content (Level 2)
Files Tab (on file.ts) → Enter → Syntax Viewer (Level 3)
```

### ESC Key - Go Up/Home
Moves up one level, eventually to Chat + Input:
```
Syntax Viewer (L3) → ESC → Files Tab (L2) → ESC → Nav Bar (L1) → ESC → Chat + Input
```

## Complete Navigation Flow

### Starting from User Input

```
User Input (L1)
  ↓ Tab
Chat Window (L1)
  ↓ Tab
Nav Bar (L1)
  ↓ Enter on Files tab
Files Tab Content (L2)
  ↓ Navigate with arrows, Enter on file
Syntax Viewer (L3)
  ↓ ESC
Files Tab Content (L2)
  ↓ ESC
Nav Bar (L1)
  ↓ ESC
Chat Tab Selected + User Input Focused
```

### Quick Return from Anywhere

From any Level 1 area (Tab Cycle):
```
Side Panel (L1) → ESC → Chat + Input
Nav Bar (L1) → ESC → Chat + Input
Chat Window (L1) → ESC → Chat + Input
```

From deeper levels:
```
Syntax Viewer (L3) → ESC → ESC → ESC → Chat + Input
Files Tab (L2) → ESC → ESC → Chat + Input
```

## Level Structure

### Level 1: Tab Cycle (Main UI Areas)
**Reachable with Tab key:**
- User Input (chat-input)
- Chat Window (chat-history)
- Nav Bar (nav-bar)
- Side Panel (context-panel)
- System Bar (system-bar)

**ESC Behavior:** → Chat Tab + User Input

### Level 2: Tab Content
**Reachable with Enter from Level 1:**
- Files Tab Content (file-tree)
- Tools Panel (tools-panel)
- Hooks Panel (hooks-panel)
- MCP Panel (mcp-panel)
- Docs Panel (docs-panel)
- Settings Panel (settings-panel)
- Search Panel (search-panel)
- GitHub Tab (github-tab)
- Workspace Panel (side-file-tree)
- Functions (functions)

**ESC Behavior:** → Nav Bar (Level 1)

### Level 3: Modals & Viewers
**Reachable with Enter from Level 2:**
- Syntax Viewer (syntax-viewer)
- Search Dialog (search-dialog)
- Quick Open (quick-open-dialog)
- Confirmation Dialog (confirmation-dialog)
- Help Panel (help-panel)
- Quick Actions Menu (quick-actions-menu)

**ESC Behavior:** → Parent (Level 2)

## Key Bindings Summary

| Key | From Level 1 | From Level 2 | From Level 3 |
|-----|--------------|--------------|--------------|
| **Tab** | Cycle through main UI | N/A | N/A |
| **Enter** | Activate/Go deeper | Open item/Go deeper | N/A |
| **ESC** | → Chat + Input | → Nav Bar (L1) | → Parent (L2) |
| **Arrows** | Navigate items | Navigate items | Navigate content |

## Visual Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    LEVEL 3: Modals & Viewers                │
│                                                              │
│  Syntax Viewer, Dialogs, Help Panel, etc.                  │
│                                                              │
│  Enter: N/A                                                 │
│  ESC: → Parent (Level 2)                                    │
└──────────────────────────┬──────────────────────────────────┘
                           │ Enter (from L2)
                           │ ESC (to L2)
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    LEVEL 2: Tab Content                     │
│                                                              │
│  Files Tab, Tools Tab, Hooks Tab, etc.                     │
│                                                              │
│  Enter: Open item → Level 3                                 │
│  ESC: → Nav Bar (Level 1)                                   │
└──────────────────────────┬──────────────────────────────────┘
                           │ Enter (from L1)
                           │ ESC (to L1)
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                 LEVEL 1: Tab Cycle (Main UI)                │
│                                                              │
│  ┌──────────────┐   Tab    ┌──────────────┐                │
│  │ User Input   │ ←──────→ │ Chat Window  │                │
│  └──────────────┘          └──────────────┘                │
│         ↕                          ↕                         │
│  ┌──────────────┐          ┌──────────────┐                │
│  │ Side Panel   │ ←──────→ │ Nav Bar      │                │
│  └──────────────┘   Tab    └──────────────┘                │
│                                                              │
│  Tab: Cycle through areas                                   │
│  Enter: Activate/Go deeper → Level 2                        │
│  ESC: → Chat Tab + User Input                               │
└─────────────────────────────────────────────────────────────┘
```

## Example Workflows

### Workflow 1: Browse Files and Return
```
1. User Input
2. Tab → Nav Bar
3. Arrow keys to Files tab
4. Enter → Files Tab Content (L2)
5. Arrow keys to navigate files
6. Enter on file.ts → Syntax Viewer (L3)
7. Read file
8. ESC → Back to Files Tab (L2)
9. ESC → Back to Nav Bar (L1)
10. ESC → Chat Tab + User Input
11. Type message
```

### Workflow 2: Quick Side Panel Check
```
1. User Input
2. Tab → Tab → Tab → Side Panel
3. Check context
4. ESC → Chat Tab + User Input
5. Type message
```

### Workflow 3: Deep Navigation
```
1. Nav Bar (on Files tab)
2. Enter → Files Tab (L2)
3. Navigate to folder
4. Enter → Expand folder
5. Navigate to file
6. Enter → Syntax Viewer (L3)
7. ESC → Files Tab (L2)
8. Ctrl+F → Search Dialog (L3)
9. ESC → Files Tab (L2)
10. ? → Help Panel (L3)
11. ESC → Files Tab (L2)
12. ESC → Nav Bar (L1)
13. ESC → Chat + Input
```

## Implementation Status

✅ **Level Structure Defined**
- Level 1: Tab Cycle areas
- Level 2: Tab Content
- Level 3: Modals & Viewers

✅ **ESC Navigation Implemented**
- Level 3 → Level 2 (return to parent)
- Level 2 → Level 1 (return to nav bar)
- Level 1 → Chat + Input (home)

✅ **Focus Manager Integration**
- FileTreeView checks focus manager
- WorkspacePanel checks focus manager
- Modals register with focus manager

✅ **Auto-Focus on Tab Change**
- Switching tabs auto-focuses tab content

## Testing Checklist

- [ ] Tab cycling through Level 1 areas
- [ ] Enter from Nav Bar to Files Tab
- [ ] Enter from Files Tab to Syntax Viewer
- [ ] ESC from Syntax Viewer to Files Tab
- [ ] ESC from Files Tab to Nav Bar
- [ ] ESC from Nav Bar to Chat + Input
- [ ] ESC from Side Panel to Chat + Input
- [ ] ESC from Chat Window to Chat + Input
- [ ] Rapid ESC presses
- [ ] Enter/ESC in all tabs
- [ ] All modals (search, help, quick open)

## Benefits

1. **Intuitive:** Tab cycles main UI, Enter goes deeper, ESC goes up
2. **Consistent:** Same behavior across all tabs and panels
3. **Efficient:** Quick return to input from anywhere
4. **Predictable:** Clear mental model based on levels
5. **Flexible:** Supports deep navigation without getting lost

## Summary

The navigation system uses three simple keys:

- **Tab** - Cycle through main UI areas (Level 1)
- **Enter** - Go deeper into selected item
- **ESC** - Go up one level, eventually to Chat + Input

This provides intuitive, efficient navigation throughout the application while maintaining a clear mental model of where you are and how to get back home.
