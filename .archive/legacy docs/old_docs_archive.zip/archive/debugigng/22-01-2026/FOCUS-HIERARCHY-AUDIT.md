# Focus Hierarchy Audit & Implementation Plan

**Date:** January 22, 2026  
**Status:** 🔄 In Progress

## User Requirements

### Hierarchical ESC Navigation

The user wants a consistent ESC key behavior across the entire application:

```
Level 4: Modal/Viewer (deepest)
  ↓ ESC
Level 3: Tab Content (Files tab, Chat tab, etc.)
  ↓ ESC
Level 2: Navigation Bar (tab selector)
  ↓ ESC
Level 1: User Input (root/home)
```

**Key Principle:** ESC always moves "up" one level in the hierarchy, eventually returning to the user input area.

### Specific Scenarios

1. **Syntax Viewer in Files Tab:**
   - User presses Enter on file → Viewer opens (Level 4)
   - ESC → Viewer closes, Files tab gets focus (Level 3)
   - ESC → Navigation bar gets focus (Level 2)
   - ESC → User input gets focus (Level 1)

2. **Workspace Panel Syntax Viewer:**
   - User presses Enter on file → Viewer opens (Level 4)
   - ESC → Viewer closes, Workspace panel gets focus (Level 3)
   - ESC → Navigation bar gets focus (Level 2)
   - ESC → User input gets focus (Level 1)

3. **Any Dialog/Modal:**
   - Dialog opens (Level 4)
   - ESC → Dialog closes, parent component gets focus (Level 3)
   - ESC → Navigation bar gets focus (Level 2)
   - ESC → User input gets focus (Level 1)

## Current Architecture Analysis

### Focus Management System

**Location:** `packages/cli/src/features/context/FocusContext.tsx`

**Current FocusableId Types:**
```typescript
type FocusableId = 
  | 'chat-input'        // Level 1: User input
  | 'chat-history'      // Level 3: Chat tab content
  | 'nav-bar'           // Level 2: Navigation bar
  | 'context-panel'     // Level 3: Side panel
  | 'system-bar'        // Level 3: System bar
  | 'file-tree'         // Level 3: Files tab
  | 'side-file-tree'    // Level 3: Workspace panel
  | 'functions'         // Level 3: Functions panel
  | 'tools-panel'       // Level 3: Tools tab
  | 'hooks-panel'       // Level 3: Hooks tab
  | 'mcp-panel'         // Level 3: MCP tab
  | 'docs-panel'        // Level 3: Docs tab
  | 'settings-panel'    // Level 3: Settings tab
  | 'search-panel'      // Level 3: Search tab
  | 'github-tab'        // Level 3: GitHub tab
```

**Missing:** Level 4 (Modal/Viewer) focus IDs

### Current ESC Behavior

**In App.tsx (Global Handler):**
```typescript
else if (isKey(input, key, activeKeybinds.chat.cancel)) {
    if (chatState.streaming || chatState.waitingForResponse) {
      cancelGeneration();
    } else {
      focusManager.exitToNavBar();  // Goes directly to nav-bar
    }
}
```

**Problem:** `exitToNavBar()` always goes to nav-bar, skipping intermediate levels.

**In FocusContext.tsx:**
```typescript
const exitToNavBar = useCallback(() => {
  // When Esc is pressed from tab content, return to nav-bar in browse mode AND reset to chat
  setModeState('browse');
  setActiveTab('chat');  // ❌ Forces chat tab
  setActiveId('nav-bar');
}, [setActiveTab]);
```

**Problems:**
1. Forces chat tab instead of staying on current tab
2. No concept of hierarchical levels
3. No handling of modals/viewers

### Component-Level Input Handling

**FileTreeView.tsx:**
- Has `hasFocus` prop
- Uses `useInput(handleInput, { isActive: hasFocus })`
- Handles ESC for closing viewer internally
- ❌ Doesn't communicate focus changes to parent

**WorkspacePanel.tsx:**
- Has `hasFocus` prop
- Uses `useInput((input, key) => { if (!hasFocus) return; ... })`
- ❌ Doesn't handle ESC for viewer
- ❌ Doesn't communicate focus changes to parent

**ChatInputArea.tsx:**
- Likely has its own input handling
- Need to audit

## Problems Identified

### 1. No Modal/Viewer Focus Level

**Issue:** Modals and viewers are not tracked in the focus system.

**Impact:**
- ESC in viewer doesn't properly manage focus hierarchy
- No way to know if a modal is open from global handlers

**Solution:** Add Level 4 focus IDs:
```typescript
type FocusableId = 
  // ... existing ...
  | 'syntax-viewer'      // Level 4: Syntax viewer modal
  | 'search-dialog'      // Level 4: Search dialog
  | 'quick-open-dialog'  // Level 4: Quick open dialog
  | 'confirmation-dialog' // Level 4: Confirmation dialog
  | 'help-panel'         // Level 4: Help panel
```

### 2. No Hierarchical ESC Logic

**Issue:** `exitToNavBar()` jumps directly to nav-bar, skipping levels.

**Impact:**
- Can't implement "ESC moves up one level" behavior
- Inconsistent navigation experience

**Solution:** Implement `exitOneLevel()` function:
```typescript
const exitOneLevel = useCallback(() => {
  // Determine current level and move up one
  const level4Ids: FocusableId[] = ['syntax-viewer', 'search-dialog', ...];
  const level3Ids: FocusableId[] = ['file-tree', 'chat-history', ...];
  const level2Ids: FocusableId[] = ['nav-bar'];
  const level1Ids: FocusableId[] = ['chat-input'];
  
  if (level4Ids.includes(activeId)) {
    // From modal → parent tab content
    // Need to track which tab opened the modal
    setActiveId(modalParentId);
  } else if (level3Ids.includes(activeId)) {
    // From tab content → nav-bar
    setActiveId('nav-bar');
    setModeState('browse');
  } else if (level2Ids.includes(activeId)) {
    // From nav-bar → user input
    setActiveId('chat-input');
  }
  // Already at level 1, do nothing
}, [activeId, modalParentId]);
```

### 3. Modal Parent Tracking

**Issue:** When a modal opens, we don't track which component opened it.

**Impact:**
- Can't return to the correct parent when modal closes
- ESC from modal doesn't know where to go

**Solution:** Add modal parent tracking:
```typescript
const [modalParent, setModalParent] = useState<FocusableId | null>(null);

const openModal = useCallback((modalId: FocusableId, parentId: FocusableId) => {
  setModalParent(parentId);
  setActiveId(modalId);
}, []);

const closeModal = useCallback(() => {
  if (modalParent) {
    setActiveId(modalParent);
    setModalParent(null);
  }
}, [modalParent]);
```

### 4. Component-Level ESC Handling

**Issue:** Components handle ESC locally without coordinating with global focus system.

**Impact:**
- Inconsistent behavior
- ESC might be handled by multiple components
- Focus state gets out of sync

**Solution:** Components should:
1. Check if they have focus before handling ESC
2. Call focus manager methods instead of local state changes
3. Use `isActive` prop based on focus manager state

## Implementation Plan

### Phase 1: Extend Focus System (High Priority)

**File:** `packages/cli/src/features/context/FocusContext.tsx`

1. **Add Level 4 Focus IDs:**
   ```typescript
   type FocusableId = 
     // ... existing ...
     | 'syntax-viewer'
     | 'search-dialog'
     | 'quick-open-dialog'
     | 'confirmation-dialog'
     | 'help-panel'
     | 'quick-actions-menu'
   ```

2. **Add Modal Parent Tracking:**
   ```typescript
   const [modalParent, setModalParent] = useState<FocusableId | null>(null);
   ```

3. **Add Level Classification:**
   ```typescript
   const getFocusLevel = (id: FocusableId): number => {
     const level4 = ['syntax-viewer', 'search-dialog', ...];
     const level3 = ['file-tree', 'chat-history', ...];
     const level2 = ['nav-bar'];
     const level1 = ['chat-input'];
     
     if (level4.includes(id)) return 4;
     if (level3.includes(id)) return 3;
     if (level2.includes(id)) return 2;
     if (level1.includes(id)) return 1;
     return 1; // Default to input
   };
   ```

4. **Implement Hierarchical ESC:**
   ```typescript
   const exitOneLevel = useCallback(() => {
     const currentLevel = getFocusLevel(activeId);
     
     if (currentLevel === 4) {
       // Modal → Parent tab content
       if (modalParent) {
         setActiveId(modalParent);
         setModalParent(null);
       }
     } else if (currentLevel === 3) {
       // Tab content → Nav bar
       setActiveId('nav-bar');
       setModeState('browse');
     } else if (currentLevel === 2) {
       // Nav bar → User input
       setActiveId('chat-input');
     }
     // Level 1: Already at root, do nothing
   }, [activeId, modalParent]);
   ```

5. **Add Modal Management Methods:**
   ```typescript
   const openModal = useCallback((modalId: FocusableId) => {
     setModalParent(activeId);
     setActiveId(modalId);
   }, [activeId]);
   
   const closeModal = useCallback(() => {
     if (modalParent) {
       setActiveId(modalParent);
       setModalParent(null);
     }
   }, [modalParent]);
   ```

### Phase 2: Update Global ESC Handler (High Priority)

**File:** `packages/cli/src/ui/App.tsx`

Replace `exitToNavBar()` with `exitOneLevel()`:

```typescript
else if (isKey(input, key, activeKeybinds.chat.cancel)) {
    if (chatState.streaming || chatState.waitingForResponse) {
      cancelGeneration();
    } else {
      focusManager.exitOneLevel();  // ✅ Hierarchical navigation
    }
}
```

### Phase 3: Update FileTreeView (High Priority)

**File:** `packages/cli/src/ui/components/file-explorer/FileTreeView.tsx`

1. **Use Focus Manager for Viewer:**
   ```typescript
   const openViewer = useCallback(async () => {
     // ... existing file reading logic ...
     
     setViewerState({ isOpen: true, filePath, content });
     focusManager.openModal('syntax-viewer');  // ✅ Register with focus system
   }, [focusManager]);
   
   const closeViewer = useCallback(() => {
     setViewerState(null);
     focusManager.closeModal();  // ✅ Return to parent
   }, [focusManager]);
   ```

2. **Update ESC Handler:**
   ```typescript
   if (viewerState?.isOpen && isKey(input, key, activeKeybinds.chat.cancel)) {
     closeViewer();  // Will call focusManager.closeModal()
     return;
   }
   ```

3. **Update isActive Prop:**
   ```typescript
   useInput(handleInput, { 
     isActive: hasFocus && focusManager.isFocused('file-tree')
   });
   ```

### Phase 4: Update WorkspacePanel (High Priority)

**File:** `packages/cli/src/ui/components/layout/WorkspacePanel.tsx`

1. **Import Focus Manager:**
   ```typescript
   import { useFocusManager } from '../../../features/context/FocusContext.js';
   ```

2. **Use Focus Manager:**
   ```typescript
   const focusManager = useFocusManager();
   ```

3. **Update Viewer Handlers:**
   ```typescript
   // Open viewer
   readFile(selectedFile.path, 'utf-8').then(content => {
     setViewerState({ isOpen: true, filePath: selectedFile.path, content });
     focusManager.openModal('syntax-viewer');  // ✅ Register
   });
   
   // Close viewer (ESC handler)
   if (viewerState?.isOpen && key.escape) {
     setViewerState(null);
     focusManager.closeModal();  // ✅ Return to parent
     return;
   }
   ```

4. **Update isActive Check:**
   ```typescript
   useInput((input, key) => {
     if (!hasFocus || !focusManager.isFocused('side-file-tree')) return;
     // ... rest of handler ...
   }, { isActive: hasFocus });
   ```

### Phase 5: Update Other Modals (Medium Priority)

Apply same pattern to:
- FileSearchDialog
- QuickOpenDialog
- ConfirmationDialog
- HelpPanel
- QuickActionsMenu

### Phase 6: Update Tab Components (Medium Priority)

Ensure all tab components respect focus hierarchy:
- ChatTab
- ToolsTab
- HooksTab
- MCPTab
- DocsTab
- SearchTab
- SettingsTab
- GitHubTab

### Phase 7: Testing (High Priority)

**Test Scenarios:**

1. **Files Tab → Syntax Viewer:**
   - [ ] Enter opens viewer
   - [ ] ESC closes viewer, returns to Files tab
   - [ ] ESC moves to nav-bar
   - [ ] ESC moves to user input

2. **Workspace Panel → Syntax Viewer:**
   - [ ] Enter opens viewer
   - [ ] ESC closes viewer, returns to Workspace panel
   - [ ] ESC moves to nav-bar
   - [ ] ESC moves to user input

3. **Search Dialog:**
   - [ ] Ctrl+F opens dialog
   - [ ] ESC closes dialog, returns to Files tab
   - [ ] ESC moves to nav-bar
   - [ ] ESC moves to user input

4. **Quick Open:**
   - [ ] Ctrl+P opens dialog
   - [ ] ESC closes dialog, returns to Files tab
   - [ ] ESC moves to nav-bar
   - [ ] ESC moves to user input

5. **Help Panel:**
   - [ ] ? opens help
   - [ ] ESC closes help, returns to Files tab
   - [ ] ESC moves to nav-bar
   - [ ] ESC moves to user input

6. **Chat Tab:**
   - [ ] ESC from chat history moves to nav-bar
   - [ ] ESC from nav-bar moves to user input

7. **Navigation:**
   - [ ] Up/Down works in viewer
   - [ ] Up/Down works in file tree while viewer open
   - [ ] Tab switching works from any level

## Current Issues

### WorkspacePanel

**Problem:** ESC and navigation don't work in syntax viewer

**Root Cause:**
1. No ESC handler for viewer state
2. No focus manager integration
3. `hasFocus` prop not connected to focus system

**Fix:** Implement Phase 4 above

### FileTreeView

**Problem:** ESC closes viewer but doesn't manage focus hierarchy

**Root Cause:**
1. Local ESC handling without focus manager
2. No modal registration

**Fix:** Implement Phase 3 above

## Benefits of This Approach

1. **Consistency:** Same ESC behavior everywhere
2. **Predictability:** Users always know where ESC will take them
3. **Discoverability:** Clear mental model of navigation hierarchy
4. **Maintainability:** Centralized focus logic
5. **Extensibility:** Easy to add new modals/viewers

## Migration Strategy

1. ✅ Audit current focus system (this document)
2. 🔄 Implement Phase 1 (extend focus system)
3. 🔄 Implement Phase 2 (update global ESC)
4. 🔄 Implement Phase 3 (FileTreeView)
5. 🔄 Implement Phase 4 (WorkspacePanel)
6. ⏳ Implement Phase 5 (other modals)
7. ⏳ Implement Phase 6 (tab components)
8. ⏳ Implement Phase 7 (testing)

## Notes

- This is a breaking change to focus behavior
- Users will need to adjust to new ESC navigation
- Consider adding a setting to toggle between old/new behavior
- Document the new navigation in user guide
- Add visual indicators for current focus level

## Related Files

- `packages/cli/src/features/context/FocusContext.tsx` - Focus management
- `packages/cli/src/ui/App.tsx` - Global input handling
- `packages/cli/src/ui/components/file-explorer/FileTreeView.tsx` - Files tab
- `packages/cli/src/ui/components/layout/WorkspacePanel.tsx` - Workspace panel
- `packages/cli/src/ui/components/file-explorer/FileSearchDialog.tsx` - Search dialog
- `packages/cli/src/ui/components/file-explorer/QuickOpenDialog.tsx` - Quick open
- `packages/cli/src/ui/components/file-explorer/HelpPanel.tsx` - Help panel
- `packages/cli/src/ui/components/file-explorer/QuickActionsMenu.tsx` - Actions menu
