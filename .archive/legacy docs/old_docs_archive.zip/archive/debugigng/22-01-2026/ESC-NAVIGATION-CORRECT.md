# ESC Navigation - Correct Implementation

**Date:** January 22, 2026  
**Status:** ✅ Corrected

## The Correct Level Structure

### Level 1: Tab Cycle (Main UI Areas)
These are the areas you can reach with the **Tab key** cycling:
- **User Input** (chat-input)
- **Chat Window** (chat-history)
- **Nav Bar** (nav-bar)
- **Side Panel** (context-panel)
- **System Bar** (system-bar)

### Level 2: Tab Content (Deeper Navigation)
When you navigate INTO a tab (like Files tab):
- **Files Tab Content** (file-tree)
- **Workspace Panel** (side-file-tree)
- **Tools Panel** (tools-panel)
- **Hooks Panel** (hooks-panel)
- **MCP Panel** (mcp-panel)
- **Docs Panel** (docs-panel)
- **Settings Panel** (settings-panel)
- **Search Panel** (search-panel)
- **GitHub Tab** (github-tab)
- **Functions** (functions)

### Level 3+: Modals & Viewers (Deepest)
When you open something within tab content:
- **Syntax Viewer** (syntax-viewer)
- **Search Dialog** (search-dialog)
- **Quick Open** (quick-open-dialog)
- **Confirmation Dialog** (confirmation-dialog)
- **Help Panel** (help-panel)
- **Quick Actions Menu** (quick-actions-menu)

## ESC Behavior

### From Level 3 (Modals/Viewers):
```
Syntax Viewer
  ↓ ESC
Files Tab Content (Level 2)
```

### From Level 2 (Tab Content):
```
Files Tab Content
  ↓ ESC
Nav Bar (Level 1)
```

### From Level 1 (Tab Cycle):
```
Nav Bar (or any Tab Cycle area)
  ↓ ESC
Chat Tab Selected + User Input Focused
```

## Complete Flow Examples

### Example 1: Deep Navigation in Files Tab
```
1. Tab cycle: User Input → Chat Window → Nav Bar → Side Panel
2. User on Nav Bar, presses Enter on Files tab
3. Now in Files Tab Content (Level 2)
4. User navigates files, presses Enter on a file
5. Syntax Viewer opens (Level 3)
6. Press ESC → Back to Files Tab Content (Level 2)
7. Press ESC → Back to Nav Bar (Level 1)
8. Press ESC → Chat Tab Selected + User Input Focused
```

### Example 2: Tab Cycling
```
1. User Input (Level 1)
2. Press Tab → Chat Window (Level 1)
3. Press Tab → Nav Bar (Level 1)
4. Press Tab → Side Panel (Level 1)
5. Press ESC → Chat Tab Selected + User Input Focused
```

### Example 3: Side Panel Navigation
```
1. Tab to Side Panel (Level 1)
2. Navigate to Workspace Panel section
3. Press Enter on file
4. Syntax Viewer opens (Level 3)
5. Press ESC → Back to Side Panel (Level 1)
6. Press ESC → Chat Tab Selected + User Input Focused
```

## Visual Diagram

```
┌─────────────────────────────────────────────────────────────┐
│ Level 3: Modals & Viewers                                   │
│ (syntax-viewer, dialogs, help, etc.)                        │
│                                                              │
│  ESC → Return to Level 2 (Tab Content)                      │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Level 2: Tab Content                                        │
│ (file-tree, tools-panel, hooks-panel, etc.)                 │
│                                                              │
│  ESC → Return to Level 1 (Nav Bar)                          │
└──────────────────────────┬──────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│ Level 1: Tab Cycle (Main UI Areas)                         │
│                                                              │
│  ┌──────────────┐   Tab    ┌──────────────┐                │
│  │ User Input   │ ←──────→ │ Chat Window  │                │
│  └──────────────┘          └──────────────┘                │
│         ↕                          ↕                         │
│  ┌──────────────┐          ┌──────────────┐                │
│  │ Side Panel   │ ←──────→ │ Nav Bar      │                │
│  └──────────────┘   Tab    └──────────────┘                │
│                                                              │
│  ESC from ANY of these → Chat Tab + User Input              │
└─────────────────────────────────────────────────────────────┘
```

## Key Differences from Previous Implementation

### What Changed:

**Before (WRONG):**
- Level 1: User Input only
- Level 2: Nav Bar only
- Level 3: All tab content + side panel
- Level 4: Modals

**Now (CORRECT):**
- Level 1: User Input + Chat Window + Nav Bar + Side Panel (Tab Cycle)
- Level 2: Tab Content (Files, Tools, etc.)
- Level 3: Modals & Viewers

### Why This Is Correct:

1. **Respects Tab Cycling:** The Tab key cycles through Level 1 areas
2. **ESC from Tab Cycle:** Goes to Chat + Input (home position)
3. **ESC from Deeper:** Moves up one level until reaching Tab Cycle
4. **Consistent:** Same behavior regardless of which Tab Cycle area you're in

## Implementation

### exitOneLevel() Logic

```typescript
const exitOneLevel = useCallback(() => {
  const currentLevel = getFocusLevel(activeId);

  if (currentLevel === 3) {
    // Level 3 (Modals/Viewers) → Return to parent (Level 2)
    if (modalParent) {
      setActiveId(modalParent);
      setModalParent(null);
    } else {
      // Fallback: go to nav-bar
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    }
  } else if (currentLevel === 2) {
    // Level 2 (Tab Content) → Go to nav-bar (Level 1)
    setActiveId('nav-bar');
    setModeState('browse');
  } else if (currentLevel === 1) {
    // Level 1 (Tab Cycle) → Select Chat tab + Focus User Input
    setActiveTab('chat');
    setActiveId('chat-input');
  }
}, [activeId, modalParent, getFocusLevel, setActiveTab]);
```

### Level Classification

```typescript
const getFocusLevel = useCallback((id: FocusableId): number => {
  // Level 1: Tab Cycle - Main UI areas reachable with Tab key
  const level1: FocusableId[] = [
    'chat-input',
    'chat-history',
    'nav-bar',
    'context-panel',
    'system-bar',
  ];
  
  // Level 2: Tab Content - Deeper navigation within tabs
  const level2: FocusableId[] = [
    'file-tree',
    'side-file-tree',
    'functions',
    'tools-panel',
    'hooks-panel',
    'mcp-panel',
    'docs-panel',
    'settings-panel',
    'search-panel',
    'github-tab',
  ];
  
  // Level 3+: Modals & Viewers - Deepest level
  const level3: FocusableId[] = [
    'syntax-viewer',
    'search-dialog',
    'quick-open-dialog',
    'confirmation-dialog',
    'help-panel',
    'quick-actions-menu',
  ];

  if (level3.includes(id)) return 3;
  if (level2.includes(id)) return 2;
  if (level1.includes(id)) return 1;
  return 1; // Default to Level 1
}, []);
```

## Testing Scenarios

### Scenario 1: Tab Cycling + ESC
```
1. Start at User Input
2. Press Tab → Chat Window
3. Press Tab → Nav Bar
4. Press Tab → Side Panel
5. Press ESC → Back to Chat Tab + User Input ✅
```

### Scenario 2: Files Tab Deep Dive
```
1. Tab to Nav Bar
2. Select Files tab (Enter)
3. Now in file-tree (Level 2)
4. Navigate files
5. Press Enter on file → Syntax Viewer (Level 3)
6. Press ESC → Back to file-tree (Level 2)
7. Press ESC → Back to Nav Bar (Level 1)
8. Press ESC → Chat Tab + User Input ✅
```

### Scenario 3: Side Panel Quick ESC
```
1. Tab to Side Panel (Level 1)
2. Press ESC → Chat Tab + User Input ✅
```

### Scenario 4: Chat Window ESC
```
1. Tab to Chat Window (Level 1)
2. Press ESC → Chat Tab + User Input ✅
```

## Benefits

1. **Respects Tab Cycling:** ESC works with Tab navigation
2. **Consistent:** Same behavior from any Tab Cycle area
3. **Efficient:** Quick return to input from anywhere
4. **Predictable:** Clear mental model based on Tab cycling
5. **Flexible:** Supports deep navigation in tabs

## Summary

The corrected implementation recognizes that:
- **Level 1 = Tab Cycle areas** (User Input, Chat Window, Nav Bar, Side Panel)
- **Level 2 = Tab Content** (Files, Tools, etc.)
- **Level 3 = Modals** (Syntax Viewer, Dialogs, etc.)

ESC from Level 1 (Tab Cycle) always goes to Chat + Input.
ESC from deeper levels moves up one level until reaching Level 1, then goes to Chat + Input.

This matches the user's Tab cycling behavior and provides intuitive navigation.
