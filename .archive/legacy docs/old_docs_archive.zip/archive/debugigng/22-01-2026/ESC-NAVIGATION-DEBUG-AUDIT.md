# ESC Navigation - Deep Debug Audit

**Date:** January 22, 2026  
**Status:** 🔍 Debugging

## Problem Statement

ESC key is not working in the navigation cycle (Level 1 areas).

## Expected Behavior

When in Level 1 (Tab Cycle):
- User Input → ESC → Chat Tab + User Input
- Chat Window → ESC → Chat Tab + User Input  
- Nav Bar → ESC → Chat Tab + User Input
- Side Panel → ESC → Chat Tab + User Input

## Current Behavior

ESC is not responding when in Level 1 areas.

## Investigation Steps

### Step 1: Check Global ESC Handler

**File:** `packages/cli/src/ui/App.tsx`

**Handler:**
```typescript
else if (isKey(input, key, activeKeybinds.chat.cancel)) {
    if (chatState.streaming || chatState.waitingForResponse) {
      cancelGeneration();
    } else {
      focusManager.exitOneLevel();  // ✅ Calls exitOneLevel
    }
}
```

**Status:** ✅ Global handler exists and calls `exitOneLevel()`

### Step 2: Check exitOneLevel Implementation

**File:** `packages/cli/src/features/context/FocusContext.tsx`

**Implementation:**
```typescript
const exitOneLevel = useCallback(() => {
  const currentLevel = getFocusLevel(activeId);

  if (currentLevel === 3) {
    // Level 3 (Modals/Viewers) → Return to parent (Level 2)
    if (modalParent) {
      setActiveId(modalParent);
      setModalParent(null);
    } else {
      // Fallback: go to nav-bar
      setActiveTab('chat');
      setActiveId('nav-bar');
      setModeState('browse');
    }
  } else if (currentLevel === 2) {
    // Level 2 (Tab Content) → Go to nav-bar (Level 1)
    setActiveId('nav-bar');
    setModeState('browse');
  } else if (currentLevel === 1) {
    // Level 1 (Tab Cycle) → Select Chat tab + Focus User Input
    setActiveTab('chat');
    setActiveId('chat-input');
  }
}, [activeId, modalParent, getFocusLevel, setActiveTab]);
```

**Status:** ✅ Implementation looks correct for Level 1

### Step 3: Check Level Classification

**File:** `packages/cli/src/features/context/FocusContext.tsx`

**Implementation:**
```typescript
const getFocusLevel = useCallback((id: FocusableId): number => {
  // Level 1: Tab Cycle - Main UI areas reachable with Tab key
  const level1: FocusableId[] = [
    'chat-input',
    'chat-history',
    'nav-bar',
    'context-panel',
    'system-bar',
  ];
  
  // Level 2: Tab Content - Deeper navigation within tabs
  const level2: FocusableId[] = [
    'file-tree',
    'side-file-tree',
    'functions',
    'tools-panel',
    'hooks-panel',
    'mcp-panel',
    'docs-panel',
    'settings-panel',
    'search-panel',
    'github-tab',
  ];
  
  // Level 3+: Modals & Viewers - Deepest level
  const level3: FocusableId[] = [
    'syntax-viewer',
    'search-dialog',
    'quick-open-dialog',
    'confirmation-dialog',
    'help-panel',
    'quick-actions-menu',
  ];

  if (level3.includes(id)) return 3;
  if (level2.includes(id)) return 2;
  if (level1.includes(id)) return 1;
  return 1; // Default to Level 1
}, []);
```

**Status:** ✅ Level classification looks correct

### Step 4: Check if ESC is Being Captured

**Potential Issue:** Other components might be capturing ESC before it reaches the global handler.

**Components to Check:**
1. ChatInputArea
2. ChatTab
3. TabBar
4. SidePanel
5. WorkspacePanel

Let me check each...

### Step 5: ChatInputArea ESC Handling

**File:** `packages/cli/src/ui/components/layout/ChatInputArea.tsx`

**Code:**
```typescript
useInput(async (input, key) => {
    // Allow Tab to bubble up to global handler for focus cycling
    if (key.tab) return;
    
    // Input Logic only works if we have focus!
    if (!hasFocus) return;
    
    // ... other handlers ...
    
    } else if (isKey(input, key, activeKeybinds.chat.cancel)) {
        if (chatState.inputMode === 'menu') {
            setInputMode('text');
            setMenuState({ active: false });
        } else {
            exitToNavBar();  // ❌ PROBLEM: Calls exitToNavBar instead of letting global handler work
        }
    }
}, { isActive: chatState.inputMode === 'menu' || hasFocus });
```

**Status:** ❌ **FOUND ISSUE #1**: ChatInputArea is capturing ESC and calling `exitToNavBar()` instead of letting it bubble to global handler

### Step 6: Check Other Components

Need to check if other Level 1 components are also capturing ESC...

## Root Causes Found

### Issue #1: ChatInputArea Captures ESC
**Location:** `packages/cli/src/ui/components/layout/ChatInputArea.tsx`

**Problem:** When ChatInputArea has focus (which is most of the time in Level 1), it captures ESC and calls `exitToNavBar()` instead of letting the global handler call `exitOneLevel()`.

**Fix:** Remove the ESC handler from ChatInputArea or make it call `focusManager.exitOneLevel()` instead.

### Issue #2: Possible Other Components
Need to audit:
- ChatTab
- TabBar  
- SidePanel
- Any other Level 1 component

## Recommended Fixes

### Fix #1: Remove ESC Handler from ChatInputArea

**Option A:** Let ESC bubble to global handler
```typescript
useInput(async (input, key) => {
    // Allow Tab and ESC to bubble up to global handler
    if (key.tab || key.escape) return;
    
    // Input Logic only works if we have focus!
    if (!hasFocus) return;
    
    // ... rest of handlers (remove ESC handling) ...
}, { isActive: chatState.inputMode === 'menu' || hasFocus });
```

**Option B:** Call exitOneLevel from ChatInputArea
```typescript
} else if (isKey(input, key, activeKeybinds.chat.cancel)) {
    if (chatState.inputMode === 'menu') {
        setInputMode('text');
        setMenuState({ active: false });
    } else {
        focusManager.exitOneLevel();  // Use focus manager
    }
}
```

**Recommendation:** Option A is cleaner - let global handler manage all ESC behavior.

### Fix #2: Audit All Level 1 Components

Check these files for ESC handlers:
- [ ] `packages/cli/src/ui/components/tabs/ChatTab.tsx`
- [ ] `packages/cli/src/ui/components/layout/TabBar.tsx`
- [ ] `packages/cli/src/ui/components/layout/SidePanel.tsx`
- [ ] `packages/cli/src/ui/components/layout/SystemBar.tsx`

## Testing Plan

After fixes:
1. Start at User Input → Press ESC → Should go to Chat Tab + User Input
2. Tab to Chat Window → Press ESC → Should go to Chat Tab + User Input
3. Tab to Nav Bar → Press ESC → Should go to Chat Tab + User Input
4. Tab to Side Panel → Press ESC → Should go to Chat Tab + User Input
5. Navigate into Files Tab (Level 2) → Press ESC → Should go to Nav Bar
6. Open Syntax Viewer (Level 3) → Press ESC → Should go to Files Tab

## Next Steps

1. ✅ Identify root cause (ChatInputArea capturing ESC)
2. ⏳ Fix ChatInputArea
3. ⏳ Audit other Level 1 components
4. ⏳ Test all ESC scenarios
5. ⏳ Document final behavior
