# Bug Report Feature - Implementation Specification

**Date:** January 23, 2026  
**Status:** Ready for Implementation  
**Priority:** Medium

---

## Overview

Add a "Report Bug" feature to the Tools panel that allows users to easily report bugs via Discord or GitHub. The feature will be accessible via keyboard shortcut `B` and will be the last item in the navigation list.

---

## URLs

- **Discord:** `https://discord.gg/9GuCwdrB`
- **GitHub:** `https://github.com/Tecet/OLLM/issues`

---

## UI Design

### Navigation Structure

```
← Exit

🔍 File Discovery
📝 File Operations
💾 Memory
📦 Other
⚡ Shell
🌐 Web
🔄 Context

🐛 Report Bug          [B]
```

### Right Panel Content (When "Report Bug" is selected)

```
═══════════════════════════════════════════════════════════════════

                    🐛 Found a Bug? We're Here to Help!

═══════════════════════════════════════════════════════════════════

Hey there! 👋

Thanks for helping us make OLLM CLI better. Whether you've found a bug,
have a feature suggestion, or just need help - we'd love to hear from you!

───────────────────────────────────────────────────────────────────

📝 Before You Report:

  ✓ Check if the issue still happens after restarting OLLM CLI
  ✓ Make sure you're running the latest version (v0.1.0)
  ✓ Try to reproduce the issue to confirm it's consistent

📋 What Makes a Great Bug Report:

  • Clear description of what went wrong
  • Steps to reproduce (1, 2, 3...)
  • Expected vs actual behavior
  • Your OS and OLLM CLI version
  • Screenshots or error messages (if applicable)

───────────────────────────────────────────────────────────────────

🚀 Choose Your Platform:

  ▶ [D] Discord Community (Recommended for quick help)
    Chat with the community, get instant feedback, and report bugs
    https://discord.gg/9GuCwdrB

  ▶ [G] GitHub Issues (For detailed bug reports)
    Create a formal issue with full details and tracking
    https://github.com/Tecet/OLLM/issues

───────────────────────────────────────────────────────────────────

💡 Pro Tip: Discord is great for quick questions and discussions,
           while GitHub is better for detailed bug tracking.

Navigation: ↑↓ to select • Enter to open • Esc to go back
```

### Confirmation Dialog

**Discord:**
```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  Open Discord?                                                  │
│                                                                 │
│  This will open Discord in your default browser or app.        │
│                                                                 │
│  URL: https://discord.gg/9GuCwdrB                              │
│                                                                 │
│  ┌───────────┐  ┌───────────┐                                 │
│  │ [Y] Yes   │  │ [N] No    │                                 │
│  └───────────┘  └───────────┘                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**GitHub:**
```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│  Open GitHub Issues?                                            │
│                                                                 │
│  This will open GitHub in your default browser.                │
│                                                                 │
│  URL: https://github.com/Tecet/OLLM/issues                     │
│                                                                 │
│  ┌───────────┐  ┌───────────┐                                 │
│  │ [Y] Yes   │  │ [N] No    │                                 │
│  └───────────┘  └───────────┘                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Implementation Details

### File Structure

```
packages/cli/src/ui/components/tools/
├── ToolsPanel.tsx (modify - add Report Bug navigation)
├── BugReportPanel.tsx (new - main bug report UI)
└── ConfirmOpenURLDialog.tsx (new - confirmation dialog)
```

### State Management

```typescript
// In ToolsPanel.tsx
type NavigationItemType = 'exit' | 'category' | 'tool' | 'bug-report';

interface NavigationState {
  isOnExitItem: boolean;
  isOnBugReportItem: boolean;
  selectedCategoryIndex: number;
  selectedToolIndex: number;
}

// In BugReportPanel.tsx
type BugReportOption = 'discord' | 'github';

interface BugReportState {
  selectedOption: BugReportOption | null;
  showConfirmation: boolean;
}
```

### Keyboard Shortcuts

| Key | Action | Context |
|-----|--------|---------|
| `B` | Jump to Bug Report | Anywhere in Tools panel |
| `↑↓` | Navigate options | Bug Report panel |
| `D` | Select Discord | Bug Report panel |
| `G` | Select GitHub | Bug Report panel |
| `Enter` | Confirm selection | Bug Report panel / Dialog |
| `Y` | Confirm open URL | Confirmation dialog |
| `N` | Cancel | Confirmation dialog |
| `Esc` | Go back / Close | Bug Report panel / Dialog |

### URL Opening Logic

```typescript
import { exec } from 'child_process';

const openURL = (url: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const command = 
      process.platform === 'win32' ? `start "" "${url}"` :
      process.platform === 'darwin' ? `open "${url}"` :
      `xdg-open "${url}"`;
      
    exec(command, (error) => {
      if (error) {
        reject(error);
      } else {
        resolve();
      }
    });
  });
};
```

---

## Implementation Steps

### Phase 1: Add Navigation Item
1. ✅ Modify `ToolsPanel.tsx` to add 'bug-report' type
2. ✅ Add `isOnBugReportItem` state
3. ✅ Update `visibleItems` calculation to include bug report item
4. ✅ Update navigation handlers (up/down) to handle bug report item
5. ✅ Add `B` keyboard shortcut to jump to bug report
6. ✅ Render bug report item in left column

### Phase 2: Create Bug Report Panel
1. ✅ Create `BugReportPanel.tsx` component
2. ✅ Implement welcome message layout
3. ✅ Add Discord and GitHub options
4. ✅ Implement option selection state
5. ✅ Add `D` and `G` keyboard shortcuts
6. ✅ Handle Enter key to show confirmation

### Phase 3: Create Confirmation Dialog
1. ✅ Create `ConfirmOpenURLDialog.tsx` component
2. ✅ Implement dialog layout
3. ✅ Add Yes/No buttons
4. ✅ Handle `Y` and `N` keyboard shortcuts
5. ✅ Implement URL opening on confirmation
6. ✅ Add error handling for failed URL opens

### Phase 4: Integration
1. ✅ Wire up Bug Report panel in ToolsPanel right column
2. ✅ Connect confirmation dialog to Bug Report panel
3. ✅ Test navigation flow
4. ✅ Test keyboard shortcuts
5. ✅ Test URL opening on all platforms

### Phase 5: Testing
1. ✅ Test `B` shortcut from various positions
2. ✅ Test navigation to/from bug report item
3. ✅ Test Discord option selection and opening
4. ✅ Test GitHub option selection and opening
5. ✅ Test confirmation dialog Yes/No
6. ✅ Test Esc key at each level
7. ✅ Test on Windows
8. ✅ Test on macOS (if available)
9. ✅ Test on Linux (if available)
10. ✅ Test error handling for failed URL opens

---

## Edge Cases

1. **URL fails to open**
   - Show error message in status bar
   - Log error to console
   - Allow user to copy URL manually

2. **User spams B key**
   - Debounce or ignore if already on bug report item

3. **User navigates away during confirmation**
   - Close confirmation dialog
   - Return to bug report panel

4. **No default browser configured**
   - Show error with URL so user can copy it
   - Suggest configuring default browser

---

## Future Enhancements

1. **Copy URL to Clipboard**
   - Add `[C] Copy URL` option in confirmation dialog
   - Use clipboard package

2. **System Info Display**
   - Show OS, version, Node.js version
   - Make it easy to copy for bug reports

3. **Recent Errors**
   - If errors detected, show them
   - Suggest including in bug report

4. **Bug Report Template**
   - Pre-fill GitHub issue template
   - Include system info automatically

---

## Testing Checklist

- [ ] `B` shortcut opens Bug Report panel
- [ ] Navigation shows Bug Report as last item (after categories)
- [ ] Up/Down arrows navigate between Discord and GitHub
- [ ] `D` shortcut selects Discord
- [ ] `G` shortcut selects GitHub
- [ ] Enter on Discord shows confirmation dialog
- [ ] Enter on GitHub shows confirmation dialog
- [ ] `Y` in dialog opens URL in browser
- [ ] `N` in dialog closes dialog
- [ ] `Esc` closes dialog
- [ ] `Esc` from main panel returns to navigation
- [ ] URL opens correctly on Windows
- [ ] URL opens correctly on macOS
- [ ] URL opens correctly on Linux
- [ ] Error handling if URL fails to open
- [ ] All existing tests still pass

---

## Notes

- Bug Report item should be visually distinct (🐛 icon)
- Should be last item in navigation (after all categories)
- Should not interfere with existing tool navigation
- Should follow existing UI patterns and theme
- Should be accessible via keyboard only (no mouse required)

---

**Ready for Implementation:** Yes  
**Estimated Time:** 2-3 hours  
**Complexity:** Medium
