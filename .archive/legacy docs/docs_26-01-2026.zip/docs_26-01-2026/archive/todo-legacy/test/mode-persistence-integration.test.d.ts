/**
 * Mode Persistence Integration Test
 *
 * Tests the complete mode persistence flow including:
 * - Saving mode to settings
 * - Saving mode history to session metadata
 * - Restoring mode and history on session resume
 */
export {};
//# sourceMappingURL=mode-persistence-integration.test.d.ts.map