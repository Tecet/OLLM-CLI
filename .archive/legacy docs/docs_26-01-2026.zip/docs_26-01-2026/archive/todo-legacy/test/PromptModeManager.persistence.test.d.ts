/**
 * Tests for PromptModeManager mode persistence functionality
 */
export {};
//# sourceMappingURL=PromptModeManager.persistence.test.d.ts.map