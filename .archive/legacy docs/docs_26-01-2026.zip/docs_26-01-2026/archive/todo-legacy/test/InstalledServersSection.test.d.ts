/**
 * InstalledServersSection Component Tests
 *
 * Tests for the InstalledServersSection component including:
 * - Rendering server list with correct count
 * - Empty state display
 * - Focus state propagation to ServerItem components
 * - Expand/collapse functionality
 */
export {};
//# sourceMappingURL=InstalledServersSection.test.d.ts.map