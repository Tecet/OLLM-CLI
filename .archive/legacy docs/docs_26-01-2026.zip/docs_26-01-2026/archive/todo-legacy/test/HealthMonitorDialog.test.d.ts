/**
 * Tests for HealthMonitorDialog component
 *
 * Validates:
 * - Overall status summary display
 * - Server health list rendering
 * - Error/warning message display
 * - Restart button functionality
 * - View Logs button functionality
 * - Enable button for stopped servers
 * - Auto-restart configuration
 * - Refresh functionality
 * - Close functionality
 */
export {};
//# sourceMappingURL=HealthMonitorDialog.test.d.ts.map