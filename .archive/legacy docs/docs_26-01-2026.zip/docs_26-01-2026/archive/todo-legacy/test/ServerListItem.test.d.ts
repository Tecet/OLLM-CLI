/**
 * ServerListItem Component Tests
 *
 * Tests for the compact server list item component used in the left column
 * of the two-column MCP panel layout.
 *
 * Test Coverage:
 * - Rendering with different server states
 * - Focus highlighting
 * - Expand/collapse icon display
 * - Health status icon and color
 * - Minimal design validation
 */
export {};
//# sourceMappingURL=ServerListItem.test.d.ts.map