export {};
//# sourceMappingURL=localProvider.integration.edgecases.test.d.ts.map