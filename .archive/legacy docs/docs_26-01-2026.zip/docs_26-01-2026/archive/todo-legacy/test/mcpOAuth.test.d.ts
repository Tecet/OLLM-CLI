/**
 * Tests for MCPOAuthProvider UI methods
 */
export {};
//# sourceMappingURL=mcpOAuth.test.d.ts.map