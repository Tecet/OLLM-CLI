import { jsx as _jsx } from "react/jsx-runtime";
import { render } from 'ink-testing-library';
import { describe, it, expect } from 'vitest';
import { MarketplacePreview } from '../MarketplacePreview.js';
describe('MarketplacePreview', () => {
    const mockServers = [
        {
            id: 'filesystem',
            name: 'filesystem',
            description: 'Secure file system operations',
            rating: 5.0,
            installCount: 10000,
            requiresOAuth: false,
            requirements: ['Node.js 18+'],
            command: 'npx',
            args: ['-y', '@modelcontextprotocol/server-filesystem'],
            category: 'File System',
        },
        {
            id: 'github',
            name: 'github',
            description: 'GitHub API integration',
            rating: 4.8,
            installCount: 8500,
            requiresOAuth: true,
            requirements: ['Node.js 18+', 'GitHub Token'],
            command: 'npx',
            args: ['-y', '@modelcontextprotocol/server-github'],
            category: 'Development',
        },
        {
            id: 'postgres',
            name: 'postgres',
            description: 'PostgreSQL database integration',
            rating: 4.7,
            installCount: 7200,
            requiresOAuth: false,
            requirements: ['Node.js 18+'],
            command: 'npx',
            args: ['-y', '@modelcontextprotocol/server-postgres'],
            category: 'Database',
        },
        {
            id: 'slack',
            name: 'slack',
            description: 'Slack workspace integration',
            rating: 4.6,
            installCount: 6800,
            requiresOAuth: true,
            requirements: ['Node.js 18+'],
            command: 'npx',
            args: ['-y', '@modelcontextprotocol/server-slack'],
            category: 'Communication',
        },
    ];
    it('should render section header', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        expect(lastFrame() || '').toContain('Marketplace Preview');
    });
    it('should display only top 3 servers', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        // Should show first 3 servers
        expect(output).toContain('filesystem');
        expect(output).toContain('github');
        expect(output).toContain('postgres');
        // Should NOT show 4th server
        expect(output).not.toContain('slack');
    });
    it('should display server names', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        expect(output).toContain('filesystem');
        expect(output).toContain('github');
        expect(output).toContain('postgres');
    });
    it('should display server descriptions', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        expect(output).toContain('Secure file system operations');
        expect(output).toContain('GitHub API integration');
        expect(output).toContain('PostgreSQL database integration');
    });
    it('should display star ratings', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        // Should show stars for ratings
        expect(output).toContain('★★★★★'); // 5.0 rating
        expect(output).toContain('★★★★'); // 4.8 and 4.7 ratings
    });
    it('should display numeric ratings', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        expect(output).toContain('(5.0)');
        expect(output).toContain('(4.8)');
        expect(output).toContain('(4.7)');
    });
    it('should display formatted install counts', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        expect(output).toContain('10K installs');
        expect(output).toContain('8.5K installs');
        expect(output).toContain('7.2K installs');
    });
    it('should show OAuth requirement indicator for OAuth servers', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        // GitHub requires OAuth
        const lines = output.split('\n');
        const githubLine = lines.find(line => line.includes('github')) || '';
        expect(githubLine).toContain('[OAuth Required]');
    });
    it('should not show OAuth indicator for non-OAuth servers', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        // Filesystem does not require OAuth
        const lines = output.split('\n');
        const filesystemIndex = lines.findIndex(line => line.includes('filesystem'));
        const githubIndex = lines.findIndex(line => line.includes('github'));
        const filesystemSection = lines.slice(filesystemIndex === -1 ? 0 : filesystemIndex, githubIndex === -1 ? undefined : githubIndex).join('\n');
        expect(filesystemSection).not.toContain('[OAuth Required]');
    });
    it('should display marketplace hint', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers }));
        const output = lastFrame() || '';
        expect(output).toContain('Press');
        expect(output).toContain('M');
        expect(output).toContain('for full marketplace');
    });
    it('should handle empty server list', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: [] }));
        const output = lastFrame() || '';
        expect(output).toContain('No marketplace servers available');
        expect(output).toContain('Press');
        expect(output).toContain('M');
    });
    it('should handle less than 3 servers', () => {
        const twoServers = mockServers.slice(0, 2);
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: twoServers }));
        const output = lastFrame() || '';
        expect(output).toContain('filesystem');
        expect(output).toContain('github');
        expect(output).not.toContain('postgres');
    });
    it('should apply focus styling when focused', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers, focused: true }));
        const output = lastFrame() || '';
        // Header should be present (focus styling is applied via color which we can't easily test)
        expect(output).toContain('Marketplace Preview');
    });
    it('should format half-star ratings correctly', () => {
        const serversWithHalfStar = [
            {
                id: 'test',
                name: 'test-server',
                description: 'Test server',
                rating: 4.5,
                installCount: 1000,
                requiresOAuth: false,
                requirements: [],
                command: 'test',
            },
        ];
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: serversWithHalfStar }));
        const output = lastFrame() || '';
        expect(output).toContain('★★★★½');
    });
    it('should format install counts under 1000 without K suffix', () => {
        const serversWithLowInstalls = [
            {
                id: 'test',
                name: 'test-server',
                description: 'Test server',
                rating: 4.0,
                installCount: 500,
                requiresOAuth: false,
                requirements: [],
                command: 'test',
            },
        ];
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: serversWithLowInstalls }));
        const output = lastFrame() || '';
        expect(output).toContain('500 installs');
        expect(output).not.toContain('K');
    });
    it('should display all required information for each server', () => {
        const { lastFrame } = render(_jsx(MarketplacePreview, { servers: mockServers.slice(0, 1) }));
        const output = lastFrame() || '';
        // Check all required elements are present
        expect(output).toContain('filesystem'); // Name
        expect(output).toContain('Secure file system operations'); // Description
        expect(output).toContain('★'); // Rating stars
        expect(output).toContain('(5.0)'); // Numeric rating
        expect(output).toContain('10K installs'); // Install count
    });
});
//# sourceMappingURL=MarketplacePreview.test.js.map