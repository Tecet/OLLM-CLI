/**
 * Tests for Prompt Mode Manager
 *
 * Tests mode state tracking, transitions, tool filtering, prompt building,
 * hysteresis, cooldown, and event emission.
 */
export {};
//# sourceMappingURL=PromptModeManager.test.d.ts.map