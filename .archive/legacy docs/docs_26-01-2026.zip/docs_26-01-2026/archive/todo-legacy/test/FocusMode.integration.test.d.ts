/**
 * Integration tests for Focus Mode with Mode Switching
 */
export {};
//# sourceMappingURL=FocusMode.integration.test.d.ts.map