/**
 * Unit tests for LanceDB Setup
 *
 * Note: These tests mock the vectordb module since it's not installed yet.
 * This is Phase 19 (FUTURE) development.
 */
export {};
//# sourceMappingURL=LanceDBSetup.test.d.ts.map