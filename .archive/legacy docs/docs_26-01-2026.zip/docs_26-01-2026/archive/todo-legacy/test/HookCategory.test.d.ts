export {};
//# sourceMappingURL=HookCategory.test.d.ts.map