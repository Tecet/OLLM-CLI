/**
 * ServerSkeleton Component Tests
 *
 * Tests for the ServerSkeleton component that displays loading placeholders.
 */
export {};
//# sourceMappingURL=ServerSkeleton.test.d.ts.map