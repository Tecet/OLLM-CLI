/**
 * Tests for HooksContext
 */
export {};
//# sourceMappingURL=HooksContext.test.d.ts.map