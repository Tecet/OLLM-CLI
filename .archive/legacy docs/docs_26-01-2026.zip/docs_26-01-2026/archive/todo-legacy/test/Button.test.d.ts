/**
 * Button Component Tests
 *
 * Tests:
 * - Label rendering
 * - Disabled state
 * - Loading state
 * - Variant styles
 * - Shortcut display
 * - Icon display
 * - ButtonGroup functionality
 * - IconButton functionality
 */
export {};
//# sourceMappingURL=Button.test.d.ts.map