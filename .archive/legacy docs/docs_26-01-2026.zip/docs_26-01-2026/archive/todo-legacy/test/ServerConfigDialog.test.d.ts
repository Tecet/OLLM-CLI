/**
 * ServerConfigDialog Tests
 *
 * Tests for the server configuration dialog component
 */
export {};
//# sourceMappingURL=ServerConfigDialog.test.d.ts.map