/**
 * ServerLogsViewer - Tests
 *
 * Tests for the ServerLogsViewer dialog component
 */
export {};
//# sourceMappingURL=ServerLogsViewer.test.d.ts.map