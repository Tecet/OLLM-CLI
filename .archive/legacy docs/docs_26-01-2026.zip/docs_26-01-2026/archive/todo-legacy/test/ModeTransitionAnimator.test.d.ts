/**
 * Tests for Mode Transition Animator
 *
 * Tests animation creation, state management, message generation,
 * and lifecycle management for mode transitions.
 */
export {};
//# sourceMappingURL=ModeTransitionAnimator.test.d.ts.map