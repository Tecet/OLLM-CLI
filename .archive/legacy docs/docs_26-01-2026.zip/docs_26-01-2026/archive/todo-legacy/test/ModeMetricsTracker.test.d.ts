/**
 * Tests for ModeMetricsTracker
 */
export {};
//# sourceMappingURL=ModeMetricsTracker.test.d.ts.map