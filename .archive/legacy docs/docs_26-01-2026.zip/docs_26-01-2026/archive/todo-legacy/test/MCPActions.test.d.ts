/**
 * Tests for MCPActions Component
 *
 * Validates:
 * - Display of keyboard shortcuts in footer
 * - Context-sensitive action display based on focused item
 * - Proper styling and layout
 * - Different states (dialog open, marketplace, main panel)
 */
export {};
//# sourceMappingURL=MCPActions.test.d.ts.map