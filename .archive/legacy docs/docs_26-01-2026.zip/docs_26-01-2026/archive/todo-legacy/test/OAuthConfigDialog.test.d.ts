/**
 * OAuthConfigDialog Tests
 *
 * Tests for the OAuth configuration dialog component
 */
export {};
//# sourceMappingURL=OAuthConfigDialog.test.d.ts.map