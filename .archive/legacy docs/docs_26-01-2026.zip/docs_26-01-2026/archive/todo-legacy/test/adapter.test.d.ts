/**
 * Tests for hook adapter functions
 */
export {};
//# sourceMappingURL=adapter.test.d.ts.map