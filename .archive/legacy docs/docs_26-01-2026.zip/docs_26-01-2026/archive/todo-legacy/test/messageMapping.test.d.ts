/**
 * Tests for message part concatenation in LocalProvider
 * Verifies that message parts are properly separated with delimiters
 */
export {};
//# sourceMappingURL=messageMapping.test.d.ts.map