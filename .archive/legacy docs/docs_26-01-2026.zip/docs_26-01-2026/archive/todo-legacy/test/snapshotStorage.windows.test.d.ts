/**
 * Windows-Specific Snapshot Storage Tests
 *
 * Tests snapshot storage functionality on Windows, including:
 * - Path separators
 * - Long paths (260 character limit)
 * - Special characters
 * - File permissions
 */
export {};
//# sourceMappingURL=snapshotStorage.windows.test.d.ts.map