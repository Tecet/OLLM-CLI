/**
 * InstallServerDialog Tests
 *
 * Tests for the InstallServerDialog component covering:
 * - Server information display
 * - Requirements list display
 * - Dynamic configuration form
 * - Environment variables inputs
 * - Auto-approve checkbox
 * - Form validation
 * - Installation flow
 */
export {};
//# sourceMappingURL=InstallServerDialog.test.d.ts.map