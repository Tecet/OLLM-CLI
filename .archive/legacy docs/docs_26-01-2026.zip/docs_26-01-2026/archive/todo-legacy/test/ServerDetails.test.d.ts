/**
 * ServerDetails Component Tests
 *
 * Tests for the ServerDetails component that displays detailed information
 * about a selected MCP server in the right column of the two-column layout.
 *
 * Validates: Requirements 1.1-1.6, NFR-7
 */
export {};
//# sourceMappingURL=ServerDetails.test.d.ts.map