/**
 * Unit tests for FocusModeManager
 */
export {};
//# sourceMappingURL=FocusModeManager.test.d.ts.map