/**
 * Unit tests for LocalProvider adapter.
 * Tests message format conversion, stream event parsing, and error handling.
 *
 * Feature: stage-08-testing-qa
 */
export {};
//# sourceMappingURL=localProvider.test.d.ts.map