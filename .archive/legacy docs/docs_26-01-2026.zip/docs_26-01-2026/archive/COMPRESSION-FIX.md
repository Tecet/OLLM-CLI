# Compression Fix Required

## Issues Found

### 1. Tier 1 Compression Discards All Messages
**Location:** `packages/core/src/context/compressionCoordinator.ts` - `compressForTier1()`

**Problem:**
```typescript
context.messages = [
  ...systemMessages,
  summaryMessage
];
```

This discards:
- All user messages
- All assistant messages
- All recent conversation history

**Should be:**
```typescript
context.messages = [
  ...systemMessages,
  summaryMessage,
  ...recentMessages  // Need to preserve recent messages!
];
```

### 2. Summary is Too Simplistic
**Location:** `generateCompactSummary()`

**Current:**
```typescript
return `[Previous conversation summary - ${messages.length} messages]\n${keyPoints}`;
```

This just truncates messages to 100 chars, not a real summary.

**Should:**
- Use the CompressionService to generate proper LLM-based summary
- Or at least preserve more context in the placeholder

### 3. User Messages Not Preserved
The compression service has logic to preserve user messages, but Tier 1 ignores it.

## Fix Strategy

### Option 1: Use CompressionService Properly
Tier 1 should call `compressionService.compress()` and use its result:

```typescript
const compressed = await this.compressionService.compress(
  context.messages,
  {
    type: 'summarize',
    preserveRecent: 2048,  // Preserve recent 2K tokens
    summaryMaxTokens: 512
  }
);

context.messages = [
  ...systemMessages,
  compressed.summary,
  ...compressed.preserved  // This includes user messages + recent messages
];
```

### Option 2: Manual Preservation
If not using CompressionService, manually preserve:

```typescript
const userMessages = context.messages.filter(m => m.role === 'user');
const recentMessages = context.messages.slice(-10);  // Last 10 messages

context.messages = [
  ...systemMessages,
  summaryMessage,
  ...userMessages,  // All user messages
  ...recentMessages.filter(m => m.role !== 'user')  // Recent non-user messages
];
```

## Recommended Fix

Use Option 1 - leverage the existing CompressionService which already has:
- Proper user message preservation
- LLM-based summarization
- Token counting
- Fractional preservation logic

This ensures consistency across all tiers.
