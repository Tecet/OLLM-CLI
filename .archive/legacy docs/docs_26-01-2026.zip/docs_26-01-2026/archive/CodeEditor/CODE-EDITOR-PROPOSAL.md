# Code Editor Proposal for OLLM CLI

**Date**: January 22, 2026  
**Status**: 📋 Proposal  
**Related Specs**: `.kiro/specs/v0.3.0 File Explorer/`

## Executive Summary

This document proposes adding a built-in terminal-based code editor to OLLM CLI as a third window alongside Chat and Terminal. The editor will provide basic editing capabilities with syntax highlighting, line numbers, and file operations, while integrating with the existing File Explorer and Focus System.

## Current State Audit

### ✅ Already Implemented

1. **SyntaxViewer Component** (Read-only)
   - Location: `packages/cli/src/ui/components/file-explorer/SyntaxViewer.tsx`
   - Features:
     - Syntax highlighting using `shiki`
     - Support for 50+ programming languages
     - Read-only viewing with line numbers
     - Scrolling support
   - Status: ✅ Complete (Task 15 in File Explorer spec)

2. **EditorIntegration Service** (External editors)
   - Location: `packages/cli/src/ui/components/file-explorer/EditorIntegration.ts`
   - Features:
     - Spawns external editors ($EDITOR, nano, notepad)
     - Waits for editor exit
     - Reloads file after editing
   - Status: ✅ Complete (Task 16 in File Explorer spec)

3. **Window Management System**
   - Location: `packages/cli/src/ui/contexts/WindowContext.tsx`
   - Current windows: `'chat' | 'terminal' | 'editor'`
   - Status: ✅ Editor window type already defined but not implemented

4. **File Operations**
   - Location: `packages/cli/src/ui/components/file-explorer/FileOperations.ts`
   - Features: Create, rename, delete, copy path
   - Status: ✅ Complete (Task 19 in File Explorer spec)

### ❌ Not Implemented

1. **Built-in Code Editor** - No in-terminal editing capability
2. **Editor Window UI** - Placeholder shows "Editor - Coming Soon"
3. **Prettier Integration** - Mentioned in ContextAnalyzer but not integrated

## Problem Statement

Users currently have two options for editing files:
1. **External Editor** - Requires leaving the terminal, breaks workflow
2. **SyntaxViewer** - Read-only, cannot make changes

**Gap**: No way to quickly edit files without context switching.

## Proposed Solution

### Option A: Lightweight Terminal Editor (Recommended)

Build a minimal but functional terminal-based editor using Ink components.

**Features**:
- Line-based editing with cursor navigation
- Syntax highlighting (reuse SyntaxViewer's shiki integration)
- Line numbers
- Basic operations: insert, delete, save, undo
- File dirty state tracking
- Integration with File Explorer focus system

**Pros**:
- Stays within OLLM CLI context
- Seamless integration with existing UI
- Can leverage existing SyntaxViewer code
- Lightweight and fast

**Cons**:
- Limited editing features compared to full editors
- Complex to implement advanced features (multi-cursor, regex search)

### Option B: Embedded Terminal Editor (Alternative)

Embed an existing terminal editor (nano, micro, or helix) within the Ink UI.

**Features**:
- Full editor capabilities
- Familiar keybindings
- Mature and tested

**Pros**:
- Proven editor experience
- Less code to maintain
- Rich feature set

**Cons**:
- Requires external dependency
- May not integrate well with Ink rendering
- Harder to customize UI
- Platform compatibility issues

### Option C: Hybrid Approach (Balanced)

Use SyntaxViewer for quick viewing, lightweight editor for small edits, external editor for heavy editing.

**Features**:
- Quick Edit Mode: Simple line-based editing for small changes
- View Mode: Current SyntaxViewer (read-only)
- Full Edit Mode: External editor integration (already implemented)

**Pros**:
- Best of both worlds
- Progressive enhancement
- Leverages existing code

**Cons**:
- More complex UX
- Need to decide when to use which mode

## Recommended Approach: Option A (Lightweight Terminal Editor)

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Code Editor Window                      │
├─────────────────────────────────────────────────────────────┤
│ Header: filename.ts [Modified] | Line 42/150 | Col 12       │
├─────────────────────────────────────────────────────────────┤
│  1 │ import { useState } from 'react';                       │
│  2 │                                                          │
│  3 │ export function MyComponent() {                         │
│  4 │   const [count, setCount] = useState(0);                │
│  5 │   █                                                      │ ← Cursor
│  6 │   return <div>{count}</div>;                            │
│  7 │ }                                                        │
│    │                                                          │
├─────────────────────────────────────────────────────────────┤
│ Footer: Ctrl+S Save | Ctrl+Q Quit | Ctrl+Z Undo | Esc View  │
└─────────────────────────────────────────────────────────────┘
```

### Component Structure

```typescript
// New components to create
CodeEditor.tsx          // Main editor component
EditorBuffer.ts         // Text buffer management
EditorCursor.ts         // Cursor position and movement
EditorHistory.ts        // Undo/redo stack
EditorKeybindings.ts    // Keyboard shortcuts
EditorStatusBar.tsx     // Status bar with file info
```

### Core Features

#### Phase 1: Basic Editing (MVP)
- [x] File loading and display
- [ ] Cursor movement (arrow keys, Home, End, PgUp, PgDn)
- [ ] Text insertion and deletion
- [ ] Line numbers
- [ ] Save file (Ctrl+S)
- [ ] Quit editor (Ctrl+Q)
- [ ] Dirty state indicator

#### Phase 2: Enhanced Editing
- [ ] Undo/Redo (Ctrl+Z, Ctrl+Y)
- [ ] Copy/Cut/Paste (Ctrl+C, Ctrl+X, Ctrl+V)
- [ ] Find (Ctrl+F)
- [ ] Go to line (Ctrl+G)
- [ ] Select text (Shift+arrows)
- [ ] Tab/Shift+Tab for indentation

#### Phase 3: Advanced Features
- [ ] Syntax highlighting (reuse SyntaxViewer)
- [ ] Auto-indentation
- [ ] Bracket matching
- [ ] Multiple files (tabs)
- [ ] Split view
- [ ] Prettier integration (format on save)

### Data Structures

```typescript
// Editor state
interface EditorState {
  filePath: string;
  content: string[];  // Array of lines
  cursor: CursorPosition;
  selection: Selection | null;
  isDirty: boolean;
  history: EditorHistory;
  scrollOffset: number;
  viewportHeight: number;
}

interface CursorPosition {
  line: number;  // 0-based
  column: number;  // 0-based
}

interface Selection {
  start: CursorPosition;
  end: CursorPosition;
}

interface EditorHistory {
  undoStack: EditorAction[];
  redoStack: EditorAction[];
}

interface EditorAction {
  type: 'insert' | 'delete' | 'replace';
  position: CursorPosition;
  content: string;
  timestamp: number;
}
```

### Integration Points

#### 1. File Explorer Integration
```typescript
// In FileTreeView.tsx
// Add 'e' keybinding to open in built-in editor
if (input === 'e') {
  const selectedFile = getSelectedNode();
  if (selectedFile && selectedFile.type === 'file') {
    // Switch to editor window
    windowContext.setActiveWindow('editor');
    // Load file in editor
    editorContext.openFile(selectedFile.path);
  }
}
```

#### 2. Window Switching
```typescript
// In WindowContext.tsx
// Already supports 'editor' window type
export type WindowType = 'chat' | 'terminal' | 'editor';

// Add keybinding in App.tsx
// Ctrl+E to switch to editor
if (input === 'e' && key.ctrl) {
  setActiveWindow('editor');
}
```

#### 3. Focus System Integration
```typescript
// When saving a file in editor
// Automatically update focused file content
if (fileFocusContext.isFocused(filePath)) {
  const updatedContent = editorState.content.join('\n');
  fileFocusContext.updateFocusedFile(filePath, updatedContent);
}
```

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| **Navigation** |
| ↑↓←→ | Move cursor |
| Home | Start of line |
| End | End of line |
| Ctrl+Home | Start of file |
| Ctrl+End | End of file |
| PgUp/PgDn | Scroll page |
| **Editing** |
| Ctrl+S | Save file |
| Ctrl+Q | Quit editor |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Ctrl+C | Copy |
| Ctrl+X | Cut |
| Ctrl+V | Paste |
| Ctrl+F | Find |
| Ctrl+G | Go to line |
| Tab | Indent |
| Shift+Tab | Unindent |
| **Window** |
| Esc | Return to view mode |
| Ctrl+E | Switch to editor window |

### Prettier Integration

#### Option 1: Format on Save
```typescript
// In CodeEditor.tsx
async function saveFile() {
  let content = editorState.content.join('\n');
  
  // Check if file type supports Prettier
  if (shouldFormatFile(filePath)) {
    try {
      const prettier = await import('prettier');
      const formatted = await prettier.format(content, {
        filepath: filePath,
        // Load .prettierrc if exists
      });
      content = formatted;
    } catch (error) {
      // Prettier failed, save unformatted
      console.warn('Prettier formatting failed:', error);
    }
  }
  
  await fs.writeFile(filePath, content, 'utf-8');
  setIsDirty(false);
}
```

#### Option 2: Manual Format Command
```typescript
// Add Ctrl+Shift+F keybinding
if (input === 'f' && key.ctrl && key.shift) {
  await formatCurrentFile();
}
```

### Implementation Plan

#### Phase 1: MVP (3-4 days)
1. Create `CodeEditor.tsx` component
2. Implement `EditorBuffer.ts` for text management
3. Implement `EditorCursor.ts` for cursor movement
4. Add basic keyboard navigation
5. Implement save functionality
6. Add dirty state tracking
7. Wire up to Window system

#### Phase 2: Enhanced Editing (2-3 days)
8. Implement `EditorHistory.ts` for undo/redo
9. Add clipboard operations
10. Implement find functionality
11. Add go-to-line feature
12. Implement text selection

#### Phase 3: Polish (2-3 days)
13. Integrate syntax highlighting from SyntaxViewer
14. Add auto-indentation
15. Implement bracket matching
16. Add Prettier integration
17. Polish UI and error handling

### Testing Strategy

```typescript
// Unit tests
describe('EditorBuffer', () => {
  test('inserts text at cursor position', () => {
    const buffer = new EditorBuffer(['hello world']);
    buffer.insertAt({ line: 0, column: 5 }, ' beautiful');
    expect(buffer.getLine(0)).toBe('hello beautiful world');
  });
  
  test('deletes character at cursor', () => {
    const buffer = new EditorBuffer(['hello']);
    buffer.deleteAt({ line: 0, column: 4 });
    expect(buffer.getLine(0)).toBe('hell');
  });
});

// Property-based tests
describe('EditorHistory', () => {
  test('undo/redo round-trip preserves state', () => {
    fc.assert(
      fc.property(
        fc.array(fc.string()),
        (actions) => {
          const history = new EditorHistory();
          actions.forEach(action => history.push(action));
          
          // Undo all
          for (let i = 0; i < actions.length; i++) {
            history.undo();
          }
          
          // Redo all
          for (let i = 0; i < actions.length; i++) {
            history.redo();
          }
          
          // Should be back to original state
          expect(history.getCurrentState()).toEqual(actions);
        }
      )
    );
  });
});
```

### Performance Considerations

1. **Large Files**: Limit editor to files < 1MB
2. **Virtual Scrolling**: Render only visible lines
3. **Syntax Highlighting**: Debounce highlighting updates
4. **Undo Stack**: Limit to 100 actions
5. **Memory**: Monitor buffer size, warn if > 10MB

### Security Considerations

1. **Path Validation**: Use PathSanitizer for all file operations
2. **File Permissions**: Check write permissions before editing
3. **Backup**: Create `.bak` file before saving
4. **Confirmation**: Prompt before overwriting external changes

## Alternative: Enhance SyntaxViewer

Instead of building a full editor, we could enhance the existing SyntaxViewer to support basic editing:

```typescript
// Add edit mode to SyntaxViewer
interface SyntaxViewerProps {
  filePath: string;
  content: string;
  mode: 'view' | 'edit';  // New prop
  onSave?: (content: string) => void;
}
```

**Pros**:
- Reuses existing code
- Simpler implementation
- Familiar UI

**Cons**:
- Limited editing capabilities
- May complicate SyntaxViewer code
- Less flexible for future enhancements

## Recommendation

**Implement Option A: Lightweight Terminal Editor**

**Rationale**:
1. Provides immediate value for quick edits
2. Stays within OLLM CLI context
3. Can be enhanced incrementally
4. Leverages existing infrastructure
5. Complements external editor integration

**Timeline**: 7-10 days for full implementation
- Phase 1 (MVP): 3-4 days
- Phase 2 (Enhanced): 2-3 days
- Phase 3 (Polish): 2-3 days

**Dependencies**:
- Existing: `shiki` (syntax highlighting)
- New: `prettier` (optional, for formatting)
- New: `clipboardy` (for clipboard operations)

## Next Steps

1. **Create Spec**: Create `.kiro/specs/v0.4.0 Code Editor/` directory
2. **Requirements**: Define detailed requirements and acceptance criteria
3. **Design**: Create detailed design document with component specs
4. **Tasks**: Break down into implementable tasks
5. **Prototype**: Build MVP to validate approach
6. **Iterate**: Gather feedback and enhance

## Open Questions

1. **File Size Limit**: What's the maximum file size we should support?
   - Recommendation: 1MB (warn at 500KB)

2. **Syntax Highlighting**: Real-time or on-demand?
   - Recommendation: Debounced (500ms) for performance

3. **Multiple Files**: Support tabs or single file at a time?
   - Recommendation: Single file for MVP, tabs in Phase 3

4. **Prettier Config**: Auto-detect or require manual configuration?
   - Recommendation: Auto-detect `.prettierrc`, fallback to defaults

5. **Backup Strategy**: Auto-save or manual only?
   - Recommendation: Manual save with `.bak` backup on first save

## References

- File Explorer Spec: `.kiro/specs/v0.3.0 File Explorer/`
- SyntaxViewer: `packages/cli/src/ui/components/file-explorer/SyntaxViewer.tsx`
- EditorIntegration: `packages/cli/src/ui/components/file-explorer/EditorIntegration.ts`
- WindowContext: `packages/cli/src/ui/contexts/WindowContext.tsx`
- Shiki Documentation: https://shiki.matsu.io/
- Prettier Documentation: https://prettier.io/docs/en/api.html
