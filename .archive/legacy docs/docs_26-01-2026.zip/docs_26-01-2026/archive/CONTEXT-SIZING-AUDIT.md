# Context Sizing Logic Audit

## Overview
This document audits all code paths that handle context sizing to ensure we correctly use `ollama_context_size` from profiles without recalculating.

## Core Principle
**The app should read both `size` (user's selection) and `ollama_context_size` (Ollama's limit) from LLM_profiles.json and pass them through without calculation.**

## Files Audited

### ✅ CORRECT: packages/cli/src/features/context/contextSizing.ts
**Status:** Correct with acceptable fallback

```typescript
const ollamaContextSize = fallbackProfile?.ollama_context_size ?? Math.max(1, Math.floor(allowed * safeRatio));
```

- **Primary path:** Uses `ollama_context_size` from profile ✓
- **Fallback:** Calculates `allowed * 0.85` only if profile missing the field
- **Assessment:** Acceptable since all our profiles have `ollama_context_size`

### ✅ CORRECT: packages/cli/src/features/context/ModelContext.tsx
**Status:** Correct - uses profile value and updates context.maxTokens

```typescript
const contextSizing = calculateContextSizing(requestedContextSize, modelEntry, contextCapRatio);
const { allowed, ollamaContextSize } = contextSizing;

// Update context.maxTokens to match Ollama's limit
contextActions.updateConfig({ targetSize: ollamaContextSize });

// Send to Ollama
options: {
  num_ctx: ollamaContextSize,  // Direct pass-through from profile
  temperature: temperatureOverride ?? temperature,
}
```

- **Reads from profile:** ✓
- **Sends to Ollama:** ✓
- **Updates context.maxTokens:** ✓ (NEW FIX)
- **No recalculation:** ✓

### ✅ FIXED: packages/core/src/core/turn.ts
**Status:** Fallback is now only used when profile unavailable

```typescript
if (this.options.ollamaContextSize !== undefined) {
  opts.num_ctx = this.options.ollamaContextSize;  // Preferred path
} else if (this.options.contextSize !== undefined) {
  opts.num_ctx = Math.floor(this.options.contextSize * 0.85);  // Fallback
}
```

- **Primary path:** Uses `ollamaContextSize` if provided ✓
- **Fallback:** Calculates 85% only if `ollamaContextSize` not provided
- **Usage:** Used by ChatClient (non-interactive mode)
- **Fix:** Non-interactive mode now provides `ollamaContextSize` from profile ✓

### ✅ CORRECT: packages/ollm-bridge/src/provider/localProvider.ts
**Status:** Correct - passes through to Ollama

```typescript
options: optionsPayload,  // Includes num_ctx from request
```

- **No calculation:** ✓
- **Direct pass-through:** ✓

### ✅ FIXED: packages/cli/src/nonInteractive.ts
**Status:** Now loads profile and provides ollamaContextSize

```typescript
// Load model profile and calculate context sizing
const modelEntry = profileManager.getModelEntry(model);
if (modelEntry) {
  const contextSizing = calculateContextSizing(requestedContextSize, modelEntry, contextCapRatio);
  ollamaContextSize = contextSizing.ollamaContextSize;
  contextSize = contextSizing.allowed;
}

// Pass to ChatClient
for await (const event of chatClient.chat(options.prompt, {
  model,
  provider: providerName === 'ollama' ? 'local' : providerName,
  contextSize,  // User's selected context size
  ollamaContextSize,  // Actual size to send to Ollama (from profile)
})) {
```

- **Loads profile:** ✓
- **Calculates context sizing:** ✓
- **Provides ollamaContextSize:** ✓
- **No recalculation in Turn:** ✓ (uses provided value)
**Status:** Correct - uses profile value for /test prompt

```typescript
options: {
  num_ctx: contextSizing.ollamaContextSize,  // From profile
  temperature: temperature,
}
```

- **Uses profile value:** ✓
- **No recalculation:** ✓

### ✅ CORRECT: packages/core/src/context/contextDefaults.ts
**Status:** Correct - thresholds are percentages of ollama_context_size

```typescript
compression: {
  enabled: true,
  threshold: 0.75,  // 75% of ollama_context_size
  strategy: 'hybrid',
  preserveRecent: 4096,
  summaryMaxTokens: 1024
},
snapshots: {
  enabled: true,
  maxCount: 5,
  autoCreate: true,
  autoThreshold: 0.80  // 80% of ollama_context_size
}
```

- **Thresholds are percentages:** ✓
- **Applied to ollama_context_size:** ✓ (after context.maxTokens fix)

### ✅ CORRECT: packages/core/src/context/contextPool.ts
**Status:** Correct - tracks both values

```typescript
public currentSize: number;      // Ollama context size (from profile)
public userContextSize: number;  // User's selected size (for UI display)
```

- **Separate tracking:** ✓
- **No calculation:** ✓

### ✅ CORRECT: packages/core/src/context/messageStore.ts
**Status:** Correct - uses context.maxTokens for thresholds

```typescript
if (usageFraction >= this.config.compression.threshold) {
  console.log('[MessageStore] Compression threshold reached', {
    usageFraction: usageFraction.toFixed(3),
    threshold: this.config.compression.threshold,
    currentTokens: context.tokenCount,
    maxTokens: context.maxTokens  // Now set to ollama_context_size
  });
  await this.compress();
}
```

- **Uses context.maxTokens:** ✓
- **context.maxTokens now set to ollama_context_size:** ✓ (NEW FIX)

## Data Flow

### Interactive Mode (CLI)
```
LLM_profiles.json
  ↓ (read)
ProfileManager → user_models.json
  ↓ (read)
calculateContextSizing()
  ├─ size: 4096 (user's selection)
  └─ ollama_context_size: 3482 (from profile)
  ↓
ModelContext.sendToLLM()
  ├─ contextActions.updateConfig({ targetSize: 3482 })  ← NEW FIX
  │   └─ Sets context.maxTokens = 3482
  └─ provider.chatStream({ options: { num_ctx: 3482 } })
  ↓
LocalProvider → Ollama
  └─ Receives num_ctx: 3482
```

### Compression Triggers
```
context.maxTokens = 3482 (ollama_context_size)
  ↓
Compression threshold = 0.75
  ↓
Triggers at: 3482 * 0.75 = 2611 tokens
  ↓
Snapshot threshold = 0.80
  ↓
Triggers at: 3482 * 0.80 = 2785 tokens
  ↓
Ollama stops at: 3482 tokens
```

## Issues Found and Fixed

### ❌ FIXED: context.maxTokens not updated
**Problem:** `context.maxTokens` was set to user's selection (4096) instead of ollama_context_size (3482)

**Impact:** Compression thresholds calculated against wrong value
- Compression at 0.75 * 4096 = 3072 (should be 0.75 * 3482 = 2611)
- Snapshot at 0.80 * 4096 = 3277 (should be 0.80 * 3482 = 2785)

**Fix:** Added code in ModelContext.sendToLLM() to update context.maxTokens:
```typescript
contextActions.updateConfig({ targetSize: ollamaContextSize });
```

## Recommendations

### ✅ COMPLETED: Non-Interactive Mode
**Issue:** Non-interactive mode didn't provide `ollamaContextSize` to ChatClient

**Fix Applied:** Updated `packages/cli/src/nonInteractive.ts` to:
1. Load model profile using ProfileManager
2. Calculate context sizing using calculateContextSizing
3. Pass both `contextSize` and `ollamaContextSize` to ChatClient
4. Turn now receives the profile value and doesn't need to calculate

### 2. Remove Fallback Calculations
**Issue:** Non-interactive mode doesn't provide `ollamaContextSize` to ChatClient

**Recommendation:** Update `packages/cli/src/nonInteractive.ts` to:
1. Load model profile
2. Calculate context sizing
3. Pass `ollamaContextSize` to ChatClient

### 2. Remove Fallback Calculations
**Issue:** Multiple places have fallback calculations (e.g., `allowed * 0.85`)

**Recommendation:** 
- Keep fallbacks for safety but log warnings when used
- Ensure all profiles have `ollama_context_size` defined
- Consider making `ollama_context_size` required in profile schema

### 3. Documentation
**Issue:** Comments in code still reference "85% cap" which is misleading

**Recommendation:** Update comments to clarify:
- Profile values are pre-calculated
- App just passes through values
- Only fallback calculations use percentages

## Testing Checklist

- [x] Interactive mode uses profile `ollama_context_size`
- [x] `context.maxTokens` set to `ollama_context_size`
- [x] Compression triggers at 75% of `ollama_context_size`
- [x] Snapshot triggers at 80% of `ollama_context_size`
- [x] Ollama receives correct `num_ctx` value
- [x] Non-interactive mode uses profile values
- [ ] All profiles have `ollama_context_size` defined
- [ ] Fallback calculations log warnings

## Conclusion

Both interactive and non-interactive modes now correctly:
1. Read `ollama_context_size` from profiles
2. Send it to Ollama as `num_ctx`
3. Set `context.maxTokens` to match (interactive mode)
4. Calculate compression thresholds against the correct value

All code paths now follow the principle: **Read values from profiles and pass them through without recalculation.**
