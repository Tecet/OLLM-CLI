# Developer Hooks

This directory contains useful hooks for developer productivity, debugging, and security.

## Available Hooks

### 1. Debug Test Runner (`debug-test-runner.json`)

**Purpose:** Automatically runs relevant tests when code files are modified.

**Event:** `fileEdited` - Triggers when TypeScript, JavaScript, or JSX files are saved

**Action:** `askAgent` - Asks the agent to run relevant test files

**Benefits:**
- Catches bugs early by running tests immediately after code changes
- Provides immediate feedback on test failures
- Helps maintain code quality during development
- Focuses on relevant tests to keep execution fast

**Use Case:** Enable this hook during active development to get instant test feedback. Disable it when making many rapid changes to avoid test overhead.

**Example Workflow:**
1. Edit `packages/core/src/hooks/hookRegistry.ts`
2. Hook triggers automatically
3. Agent runs `packages/core/src/hooks/__tests__/hookRegistry.test.ts`
4. Test results appear immediately
5. If tests fail, agent suggests fixes

---

### 2. Security Check: Dangerous Commands (`security-check-dangerous-commands.json`)

**Purpose:** Validates shell commands before execution to prevent dangerous operations.

**Event:** `promptSubmit` - Triggers when any prompt is submitted

**Action:** `askAgent` - Asks the agent to validate commands before execution

**Protected Operations:**
- `rm -rf` - Recursive deletion
- `sudo rm` - Privileged deletion
- `format` - Disk formatting
- `dd if=` - Low-level disk operations
- `> /dev/` - Device file writes
- Modifications to system directories (`/etc`, `/sys`, `/boot`)

**Benefits:**
- Prevents accidental data loss
- Catches dangerous commands before execution
- Provides risk explanation for dangerous operations
- Requires explicit user confirmation for risky commands

**Use Case:** Keep this hook enabled at all times for safety. It adds minimal overhead and provides critical protection against destructive operations.

**Example Workflow:**
1. User asks: "Delete all log files with rm -rf logs/"
2. Hook triggers on prompt submit
3. Agent detects dangerous command: `rm -rf`
4. Agent warns: "Detected dangerous recursive deletion. This will permanently delete all files in logs/. Confirm?"
5. User can approve or modify the command

---

### 3. Auto Format on Save (`auto-format-on-save.json`)

**Purpose:** Automatically format code files using Prettier when saved.

**Event:** `fileEdited` - Triggers when code files are saved

**Action:** `runCommand` - Runs Prettier formatter directly

**Supported Files:**
- TypeScript (`.ts`, `.tsx`)
- JavaScript (`.js`, `.jsx`)
- JSON (`.json`)
- Markdown (`.md`)

**Benefits:**
- Maintains consistent code style automatically
- Eliminates manual formatting steps
- Ensures code follows project style guide
- Reduces code review friction

**Use Case:** Enable this hook to maintain consistent formatting across the codebase. Disable it if you prefer manual formatting control or if Prettier is not configured.

**Example Workflow:**
1. Edit `packages/cli/src/ui/components/tabs/HooksTab.tsx`
2. Save the file
3. Hook triggers automatically
4. Prettier formats the file
5. File is saved with consistent formatting

**Note:** Requires Prettier to be installed (`npm install -D prettier`)

---

## Hook Management

### Viewing Hooks

**Via Hooks Panel UI:**
1. Press **Tab** to navigate to Hooks tab
2. Press **Enter** to open Hooks Panel
3. Navigate with **↑** and **↓** keys
4. View hook details in the right panel

**Via Command Line:**
```bash
# List all hooks
ls -la .ollm/hooks/

# View hook details
cat .ollm/hooks/debug-test-runner.json
```

### Enabling/Disabling Hooks

**Via Hooks Panel UI:**
1. Open Hooks Panel (**Tab** → **Enter**)
2. Navigate to the hook
3. Press **Enter** to toggle enabled/disabled
4. Changes save automatically

**Via Settings File:**
Edit `~/.ollm/settings.json`:
```json
{
  "hooks": {
    "debug-test-runner": {
      "enabled": true
    },
    "security-check-dangerous-commands": {
      "enabled": true
    },
    "auto-format-on-save": {
      "enabled": false
    }
  }
}
```

### Testing Hooks

**Via Hooks Panel UI:**
1. Open Hooks Panel
2. Navigate to the hook
3. Press **T** to test
4. Review test results

**Manual Testing:**
```bash
# Test debug-test-runner
# 1. Edit a TypeScript file
# 2. Save it
# 3. Check if tests run automatically

# Test security-check-dangerous-commands
# 1. Submit a prompt with "rm -rf"
# 2. Check if agent warns about danger

# Test auto-format-on-save
# 1. Edit a file with bad formatting
# 2. Save it
# 3. Check if Prettier formats it
```

### Editing Hooks

**Via Hooks Panel UI:**
1. Open Hooks Panel
2. Navigate to the hook
3. Press **E** to edit
4. Modify name, command, or arguments
5. Press **S** to save

**Manual Editing:**
```bash
# Edit hook file directly
nano .ollm/hooks/debug-test-runner.json

# Validate JSON syntax
cat .ollm/hooks/debug-test-runner.json | jq .
```

### Deleting Hooks

**Via Hooks Panel UI:**
1. Open Hooks Panel
2. Navigate to the hook
3. Press **D** to delete
4. Confirm deletion

**Manual Deletion:**
```bash
# Delete hook file
rm .ollm/hooks/debug-test-runner.json
```

---

## Recommended Configuration

### For Active Development

Enable all three hooks for maximum productivity and safety:

```json
{
  "hooks": {
    "debug-test-runner": { "enabled": true },
    "security-check-dangerous-commands": { "enabled": true },
    "auto-format-on-save": { "enabled": true }
  }
}
```

**Benefits:**
- Immediate test feedback
- Protection against dangerous commands
- Consistent code formatting

**Trade-offs:**
- Slight overhead on file saves
- Tests run automatically (may slow down rapid changes)

### For Production/Deployment

Enable only security checks:

```json
{
  "hooks": {
    "debug-test-runner": { "enabled": false },
    "security-check-dangerous-commands": { "enabled": true },
    "auto-format-on-save": { "enabled": false }
  }
}
```

**Benefits:**
- Minimal overhead
- Critical safety protection
- No automatic formatting or testing

### For Code Review

Enable formatting and security:

```json
{
  "hooks": {
    "debug-test-runner": { "enabled": false },
    "security-check-dangerous-commands": { "enabled": true },
    "auto-format-on-save": { "enabled": true }
  }
}
```

**Benefits:**
- Consistent formatting for review
- Safety protection
- No automatic test runs

---

## Creating Custom Hooks

### Hook File Structure

```json
{
  "name": "Hook Name",
  "version": "1.0.0",
  "description": "What this hook does",
  "when": {
    "type": "eventType",
    "patterns": ["*.ext"]
  },
  "then": {
    "type": "actionType",
    "prompt": "Agent prompt",
    "command": "shell command"
  }
}
```

### Event Types

- `fileEdited` - When a file is saved
- `fileCreated` - When a file is created
- `fileDeleted` - When a file is deleted
- `userTriggered` - Manually triggered by user
- `promptSubmit` - When a prompt is submitted
- `agentStop` - When agent execution completes

### Action Types

- `askAgent` - Ask the agent to do something (requires `prompt`)
- `runCommand` - Run a shell command directly (requires `command`)

### Example: Lint on Save

```json
{
  "name": "Lint on Save",
  "version": "1.0.0",
  "description": "Run ESLint on TypeScript files when saved",
  "when": {
    "type": "fileEdited",
    "patterns": ["*.ts", "*.tsx"]
  },
  "then": {
    "type": "runCommand",
    "command": "npx eslint --fix"
  }
}
```

### Example: Commit Message Validation

```json
{
  "name": "Validate Commit Message",
  "version": "1.0.0",
  "description": "Ensure commit messages follow conventional commits format",
  "when": {
    "type": "agentStop"
  },
  "then": {
    "type": "askAgent",
    "prompt": "If the last operation involved git commit, verify the commit message follows conventional commits format (type(scope): description). If not, suggest a properly formatted message."
  }
}
```

---

## Troubleshooting

### Hook Not Triggering

**Check if hook is enabled:**
1. Open Hooks Panel
2. Look for ● (enabled) or ○ (disabled) indicator
3. Press **Enter** to toggle if needed

**Check file patterns:**
- Ensure file extension matches pattern
- Example: `*.ts` matches `file.ts` but not `file.js`

**Check event type:**
- `fileEdited` only triggers on save, not on every keystroke
- `promptSubmit` triggers on every prompt submission

### Hook Failing

**Test the hook:**
1. Open Hooks Panel
2. Navigate to the hook
3. Press **T** to test
4. Review error messages

**Check command availability:**
```bash
# For auto-format-on-save
which prettier
npx prettier --version

# For debug-test-runner
npm test --version
```

**Check JSON syntax:**
```bash
cat .ollm/hooks/hook-name.json | jq .
```

### Performance Issues

**Disable expensive hooks:**
- Disable `debug-test-runner` if tests are slow
- Disable `auto-format-on-save` if formatting is slow

**Optimize patterns:**
- Use specific patterns instead of wildcards
- Example: `src/**/*.ts` instead of `**/*.ts`

**Use `runCommand` instead of `askAgent`:**
- `runCommand` is faster (no LLM call)
- Use for simple operations like formatting

---

## Best Practices

### Hook Design

**Keep hooks focused:**
- One responsibility per hook
- Clear, descriptive names
- Detailed descriptions

**Use appropriate event types:**
- `fileEdited` for file-based automation
- `promptSubmit` for validation
- `agentStop` for post-processing

**Choose the right action type:**
- `askAgent` for complex logic requiring LLM
- `runCommand` for simple shell commands

### Hook Organization

**Group related hooks:**
- Keep hooks in the same directory
- Use consistent naming conventions
- Document hook dependencies

**Version control:**
- Commit hooks to repository
- Share with team
- Track changes

**Documentation:**
- Update README when adding hooks
- Document required dependencies
- Provide usage examples

### Security

**Review hook code:**
- Inspect hooks before enabling
- Understand what commands they run
- Check for sensitive data exposure

**Use workspace hooks for projects:**
- Keep project-specific hooks in `.ollm/hooks/`
- Keep personal hooks in `~/.ollm/hooks/`

**Test before trusting:**
- Always test hooks with **T** key
- Verify behavior before enabling
- Monitor hook execution

---

## Additional Resources

- [Hook System User Guide](../../docs/MCP/hooks/user-guide.md)
- [Hook Development Guide](../../docs/MCP/hooks/development-guide.md)
- [Hook Protocol](../../docs/MCP/hooks/protocol.md)
- [Keyboard Shortcuts](../../docs/MCP/hooks/keyboard-shortcuts.md)
- [Visual Guide](../../docs/MCP/hooks/visual-guide.md)

---

**Created:** January 18, 2026  
**Last Updated:** January 18, 2026  
**Version:** 1.0.0
