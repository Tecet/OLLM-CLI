# LLM Fixes Tracker

This file captures the intent, wiring, and references for the LLM context/VRAM fix work so future edits understand how the core guard, snapshot, and prompt flows stay in sync.

## Core goals
1. **Treat `packages/cli/src/config/LLM_profiles.json` as the immutable catalog.** The CLI should never invent a cap—`ollama_context_size` (plus any per-profile `max_context_window`, `vram_estimate`, and `quantization`) is the source of truth and is propagated to every consumer from the beginning of the request lifecycle.
2. **Mirror the read-only catalog with user overrides.** `ProfileManager` merges the shipped catalog with `~/.ollm/user_models.json`; once the merge completes, we persist that effective view to `~/.ollm/LLM_models.json` so the rest of the app (prompt builders, snapshot manager, CLI helpers) can read one file that already includes the resolved caps.
3. **Sync the guard/compression thresholds with the Ollama cap.** `contextSizing.calculateContextSizing` feeds `ollama_context_size` and the `ratio` directly into `ModelContext.syncAutoThreshold` (see `packages/cli/src/features/context/contextSizing.ts` and `ModelContext.tsx:660-720`), and `ContextManager`’s defaults (`packages/core/src/context/contextManager.ts:59-82`) use 0.68/`snapshots.autoThreshold` to ensure compression starts well before `num_ctx`.
4. **Keep session snapshots, rollovers, and history aligned.** The snapshot metadata and checkpoints stored in `ContextManager.snapshotStorage`/`snapshotManager` drive the compressed history that the CLI sends back to Ollama (see `packages/core/src/context/snapshotManager.ts` and `contextManager.ts:1240-1890`), which ensures rollovers happen just before we hit the Ollama cap.

 Here’s the current storage split:
                                                                                                                            
  - Chat history (persisted sessions): ~/.ollm/sessions via ChatRecordingService (packages/core/src/services/               
    chatRecordingService.ts:40).                                                                                            
  - Context compression snapshots: ~/.ollm/context-snapshots (packages/core/src/context/snapshotStorage.ts:95, packages/    
    core/src/utils/pathValidation.ts:158).                                                                                  
  - Mode transition snapshots: ~/.ollm/mode-transition-snapshots (packages/cli/src/features/context/                        
    ContextManagerContext.tsx:349).                                

## Recent actions
- Patched `.vitest.setup.ts` to ensure `console.Console` is preserved before `ink`/`patch-console` runs so the priority test suite no longer fails when the CLI loads keybinds.
- Added `/test prompt` in `packages/cli/src/commands/utilityCommands.ts` and documented it above so we can replay the assembled prompt/context/`num_ctx`/temperature payload as a system message for debugging without hitting Ollama (`llm_fixes.md:41`).
- Captured GPU telemetry inside `GPUContext` and `gpuHintStore` so `/test prompt` now re-derives the same `num_gpu`/`gpu_layers` guidance that `ModelContext` sends to Ollama, keeping the debug snapshot and in-flight request aligned with the cache (`packages/cli/src/features/context/GPUContext.tsx`, `gpuHintStore.ts`, `utilityCommands.ts`).
- Added `refreshModelDatabase` to core routing and call it from `ProfileManager.syncLLMModelsFile`, which reloads `~/.ollm/LLM_models.json` immediately after every store merge so the routing path always sees the same overrides as the UI.
- Wired `LocalProvider.chatStream` to poll the VRAM monitor, derive the same placement hints, and merge them into the `options` payload so both UI and non-UI paths send `num_gpu`/`gpu_layers` (`packages/ollm-bridge/src/provider/localProvider.ts:142-223`), and documented the new helper export in `packages/core/src/context/gpuHints.ts`.
- Expanded unit coverage (`contextManager.test.ts:303`, `contextSizing.test.tsx:46`, `utilityCommands.test.ts`) and ran the relevant spec trio plus the full `npm run test` suite to lock the thresholds and fallback logic.
- Implemented a mid-stream guard in `ContextManager.reportInflightTokens` that now triggers compression as usage (current + inflight) exceeds the configured threshold (`packages/core/src/context/contextManager.ts:2091-2122`), preventing runaway generations before the assistant message is complete.
- Normalized mode transition snapshot session paths so `sessionId` values that already include `session-` do not create `session-session-*` directories (`packages/core/src/prompts/modeSnapshotManager.ts`).
- Skipped auto snapshot/compression when the context has no user or assistant messages, preventing empty "no conversation" snapshots in `~/.ollm/context-snapshots` (`packages/core/src/context/contextManager.ts`).
- Changed auto-threshold snapshot/compression to require at least one user message, and emergency snapshots now skip when there is no user input (`packages/core/src/context/contextManager.ts`, `packages/core/src/context/memoryGuard.ts`).
- Mode transitions now persist snapshots from the UI handler (when user messages exist), so `~/.ollm/mode-transition-snapshots` is populated on normal mode switches (`packages/cli/src/features/context/ContextManagerContext.tsx`).
- Tier 1 rollover now retains only the base system prompt, summarizes only user/assistant messages, and skips snapshotting when there are no user/assistant messages, preventing repeated empty snapshots (`packages/core/src/context/contextManager.ts`).

## Current wiring reference
### Source-of-truth propagation
* `LLM_profiles.json` (CLI config; `packages/cli/src/config/LLM_profiles.json`) defines `context_profiles`, `ollama_context_size`, `max_context_window`, `vram_estimate`, and `quantization`. This file is read-only for the client and only updated via the core model DB generator (`node scripts/generate_model_db.js` → `packages/core/src/routing/generated_model_db.ts`).
* `ProfileManager` learns what models are installed and merges overrides from `~/.ollm/user_models.json` (`packages/cli/src/features/profiles/ProfileManager.ts`). The merged view is saved to `~/.ollm/LLM_models.json` for downstream consumers that do not want to recompute overrides each time they read config.

  - ~/.ollm/user_models.json is the editable runtime state—the CLI writes to it whenever the user confirms a tool-support override, sets a manual context, or installs a model. It’s intentionally  lightweight and only contains the delta relative to the shipped catalog.

  - ~/.ollm/LLM_models.json is the merged view we rebuild after every change so every part of the  app (prompt builders, context logic, snapshot manager) can read a single file that already  includes effective ollama_context_size, max_context_window, and quantization for each installed  model. This keeps the runtime logic simple—no need to recompute overrides on every read.

### Context sizing flow
* `calculateContextSizing` (`packages/cli/src/features/context/contextSizing.ts`) clamps user requests to the `getMaxContextWindow` result, selects the matching or fallback profile, and copies `ollama_context_size` from that profile (or defaults to 85% of the allowed size) into the result along with the `ratio`.
* `ModelContext.sendToLLM` (`packages/cli/src/features/context/ModelContext.tsx:600-820`) uses `contextSizing.ollamaContextSize` for `options.num_ctx` and calls `syncAutoThreshold` so the `ContextManager` snapshot threshold always mirrors `ollama_context_size / allowed`.
* The fallback for unknown models comes from the default profile entry we ship (`llama3.2:3b`) and is reflected in `ProfileManager`, ensuring even unsupported models have `ollama_context_size`, `vram_estimate`, and `max_context_window` before the CLI attempts to send a request.

### Guard and snapshot alignment
* `ContextManager` (`packages/core/src/context/contextManager.ts`) exposes `DEFAULT_CONFIG.compression.threshold = 0.68` and `snapshots.autoThreshold` that get copied whenever `contextActions.updateConfig({ snapshots })` is invoked.
* Snapshot and compression work (tiers, checkpoints, `snapshotManager.ts`) run before the usage fraction hits 1.0 so the CLI never races ahead of the Ollama cap. Inflight monitoring (`reportInflightTokens`) reports progress but uses the same thresholds, which are kept in sync via `ModelContext.syncAutoThreshold`.

### Session history and persistence
* `snapshotStorage.ts` plus `currentContext.checkpoints` keep the compressed history and rollover data. Checkpoints are saved with `compressionHistory` entries so we can reconstruct what was compressed/kept, and the CLI pushes the resulting history back as part of the prompts it sends to Ollama.
* Session/chat history (user + assistant turns) is stored in `currentContext.messages` and written into checkpoints for rollovers; the compressed history is what we reuse once a rollover triggers (see `contextManager.ts:1280-1895`, `snapshotManager.ts:40-230`).
* `~/.ollm/LLM_models.json` is the canonical merged view used by Scheduling/Context modules so every part of the system (sizing, prompts, guard) reads the same cap.

### GPU hint propagation
* `GPUContext` keeps the cached `GPUInfo` in sync with `gpuHintStore` every time the monitor polls (`packages/cli/src/features/context/GPUContext.tsx`), giving both the UI and CLI commands access to accurate VRAM/free counts.
* `ModelContext.sendToLLM` enriches the Ollama request with `num_gpu`/`gpu_layers` derived from `deriveGPUPlacementHints`, writing the hints back to `gpuHintStore` so downstream diagnostics can show the same guidance.
* `LocalProvider` now polls the VRAM monitor directly, derives placement hints via the shared helper, and merges them into every `provider.chatStream` call so non-UI flows also honor the GPU guidance (`packages/ollm-bridge/src/provider/localProvider.ts:142-223`).
* `/test prompt` now reads the cached GPU info, recalculates the placement hints for the current `contextSizing.ollamaContextSize`, and surfaces both the hint and the raw GPU metric lines in the system message (`packages/cli/src/commands/utilityCommands.ts`), ensuring debug output matches the live request.

## Tests
- Regression coverage now exists for the default compression/snapshot thresholds (`packages/core/src/context/__tests__/contextManager.test.ts:303`) and the fallback behavior when a profile omits `ollama_context_size` (`packages/cli/src/features/context/__tests__/contextSizing.test.tsx:46`).
- Added `packages/cli/src/commands/__tests__/utilityCommands.test.ts` to guard the `/test prompt` command; full suite run (`npm run test`) now succeeds thanks to the console patch, so the CLI keybind/Ink blocker is resolved.
- Added `packages/cli/src/features/context/__tests__/gpuHints.test.ts` and loosened the priority Vitest `include` list so `.test.ts` files under `packages/cli/src/features/context/__tests__` run as part of the guarded suite (`.dev/vitest.priority.config.ts:26-38`); the test suite now asserts the GPU hint heuristics and availability check.

## Pending restart
- User is about to reboot the workstation; pick up here after system startup so the metadata/ModelDatabase sync can be tackled with a clean environment (re-run the priority tests if the working tree changes).

## Remaining
- **Context metadata sync:** Complete; the core `ModelDatabase` now reloads `~/.ollm/LLM_models.json` whenever the CLI updates it, so the UI and routing paths share the same overrides. Next validation is a fresh context/VRAM regression suite run plus the manual `/test prompt` after the workstation restart to make sure the merged metadata behaves in a live session.

## Notes
- The CLI should never mutate `LLM_profiles.json`; it only writes deltas to `~/.ollm/user_models.json`, and `ProfileManager` mirrors that into `~/.ollm/LLM_models.json`. If the developer team updates the catalog (`node scripts/generate_model_db.js` → `packages/core/src/routing/generated_model_db.ts`), those new defaults flow through the same merge.
- When we update `contextManager.updateConfig`, always shallow-copy existing `snapshots` etc. before overwriting, so we keep compression/snapshot thresholds intact.
- The `/test prompt` helper (`packages/cli/src/commands/utilityCommands.ts:137-192`) mirrors the assembled system prompt, context snippet, and provider options into a chat system message so we can inspect the exact payload without calling Ollama.

## Recent work
- `refreshModelDatabase` is now exported from `@ollm/core` and invoked whenever `ProfileManager` rewrites `~/.ollm/LLM_models.json`, keeping the core routing database current with every override write (`packages/core/src/routing/modelDatabase.ts`, `packages/cli/src/features/profiles/ProfileManager.ts`).
- Added `packages/core/src/routing/__tests__/modelDatabase.test.ts` and surfaced routing tests in `.dev/vitest.priority.config.ts`, ensuring the priority suite verifies that the runtime store reload affects `getContextWindow`.
