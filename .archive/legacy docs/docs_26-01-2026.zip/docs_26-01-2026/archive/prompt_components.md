# Prompt Components (Current Payload)

This document describes the current Ollama payload schema and where each field is sourced.

## Payload Schema (Ollama /api/chat body)

```json
{
  "model": "string",
  "messages": [
    {
      "role": "system|user|assistant|tool",
      "content": "string",
      "name": "string (optional)",
      "tool_calls": [
        {
          "id": "string",
          "type": "function",
          "function": {
            "name": "string",
            "arguments": {}
          }
        }
      ],
      "tool_call_id": "string (optional)"
    }
  ],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "string",
        "description": "string",
        "parameters": {}
      }
    }
  ],
  "options": {
    "num_ctx": 0,
    "temperature": 0,
    "num_gpu": 0,
    "gpu_layers": 0
  },
  "stream": true,
  "think": false
}
```

Notes:
- `messages` is produced by `mapMessages` which *prepends* the system prompt as a system message if `systemPrompt` is provided. See mapping below.
- `tools` is omitted when empty/undefined.
- `options` is forwarded to Ollama from the provider request.
- `/test prompt` now renders two JSON blocks:
  - Structured (for compression debugging)
  - Actual Ollama payload (string content)

## Source Mapping (Field -> Origin)

### model
- Source: `currentModel` in the UI send path.
- Code: `provider.chatStream({ model: currentModel, ... })`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:788`

### messages
- Source: `currentContext` from ContextManager (system messages filtered out).
- Code: `const history = currentContext.filter(m => m.role !== 'system').map(...)`
- Reference: `packages/cli/src/features/context/ChatContext.tsx:767`

### system prompt injection (prepended message)
- Source: `systemPrompt` argument passed to provider.
- Code: `provider.chatStream({ systemPrompt: systemPrompt, ... })`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:792`
- Provider injection: `mapMessages(..., systemPrompt)` and `mapped.push({ role: 'system', content: systemPrompt })`
- Reference: `packages/ollm-bridge/src/provider/localProvider.ts:428`, `packages/ollm-bridge/src/provider/localProvider.ts:431`

### system prompt content (current build)
- Base prompt and tier prompt assembled in core context manager.
- Code: `basePrompt = systemPromptBuilder.build(...)`, `tierPrompt = getSystemPromptForTierAndMode()`, `newPrompt = [tierPrompt, basePrompt].join(...)`
- Reference: `packages/core/src/context/contextManager.ts:1058`
- Tier selection: `getSystemPromptForTierAndMode()`
- Reference: `packages/core/src/context/contextManager.ts:1026`
- UI-side augmentations:
  - Reorder to `tierPrompt + rules + tool note`: `systemPrompt = [tierPrompt, rulesOnly, toolNote].join(...)`
    - Reference: `packages/cli/src/features/context/ChatContext.tsx:704`
  - Focused files injection: `systemPrompt = injectFocusedFilesIntoPrompt(systemPrompt)`
    - Reference: `packages/cli/src/features/context/ChatContext.tsx:716`
  - Tool support note: appended when model lacks tools
    - Reference: `packages/cli/src/features/context/ChatContext.tsx:711`

### /test prompt structured payload (debug view)
- Built from the final system prompt + tier prompt + user messages.
- Fields: `rules`, `systemPrompt`, `userMessage`, `directives`, `tools` (arrays of strings).
- Reference: `packages/cli/src/commands/utilityCommands.ts:74`

### tools
- Source: tool registry filtered by mode.
- Code: `toolSchemas = toolRegistry.getFunctionSchemasForMode(currentMode, modeManager)`
- Reference: `packages/cli/src/features/context/ChatContext.tsx:686`
- Passed to provider: `provider.chatStream({ tools: toolSchemas, ... })`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:791`

### options.num_ctx
- Source: `calculateContextSizing(...)` -> `ollamaContextSize`
- Code: `options: { num_ctx: ollamaContextSize, ... }`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:762`, `packages/cli/src/features/context/ModelContext.tsx:797`

### options.temperature
- Source: `settings.llm.temperature` or override.
- Code: `options: { temperature: temperatureOverride ?? temperature, ... }`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:760`, `packages/cli/src/features/context/ModelContext.tsx:798`

### options.num_gpu / gpu_layers
- Source: `deriveGPUPlacementHints(...)` based on GPU info + context size.
- Code: `...(gpuHints ?? {})`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:765`, `packages/cli/src/features/context/ModelContext.tsx:799`

### stream
- Source: hardcoded in local provider body.
- Code: `stream: true`
- Reference: `packages/ollm-bridge/src/provider/localProvider.ts:223`

### think
- Source: `thinkingEnabled` from profile.
- Code: `provider.chatStream({ think: thinkingEnabled, ... })`
- Reference: `packages/cli/src/features/context/ModelContext.tsx:795`
- Sent to Ollama: `think: request.think`
- Reference: `packages/ollm-bridge/src/provider/localProvider.ts:224`
