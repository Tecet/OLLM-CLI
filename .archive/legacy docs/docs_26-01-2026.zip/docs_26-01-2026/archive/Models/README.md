# Model Management System - Development Documentation

**Last Updated:** January 17, 2026  
**Status:** ✅ Implementation Complete, Documentation Complete

This directory contains development documentation, tracking files, and reference materials for the Model Management System in OLLM CLI.

---

## 📁 Directory Structure

```
.dev/Models/
├── README.md                              # This file - navigation guide
├── Models_docs.md                         # Main documentation index
│
├── debugging/                             # Bug tracking and fixes
│   └── implementation-fixes.md           # Fixed bugs and solutions
│
├── development/                           # Development tracking
│   ├── documentation-tracking.md         # Documentation creation progress
│   ├── implementation-progress.md        # Implementation status tracking
│   └── draft-content-summary.md          # Draft content integration
│
└── reference/                             # Reference materials
    └── ollama-models.md                  # Ollama model reference


## 📚 User Documentation (docs/Models/)

The main user-facing documentation is located in `docs/Models/`:

### Core Documentation

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/README.md)** | Main entry point for users |
| **[getting-started.md](../../docs/Models/getting-started.md)** | Quick start guide |
| **[Models_index.md](../../docs/Models/Models_index.md)** | Complete documentation index |
| **[Models_architecture.md](../../docs/Models/Models_architecture.md)** | System architecture overview |
| **[Models_commands.md](../../docs/Models/Models_commands.md)** | CLI commands reference |
| **[Models_configuration.md](../../docs/Models/Models_configuration.md)** | Configuration guide |
| **[model-compatibility.md](../../docs/Models/model-compatibility.md)** | Model compatibility matrix |

### API Documentation (docs/Models/api/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/api/README.md)** | API overview |
| **[model-management-service.md](../../docs/Models/api/model-management-service.md)** | ModelManagementService API |
| **[model-router.md](../../docs/Models/api/model-router.md)** | ModelRouter API |
| **[memory-service.md](../../docs/Models/api/memory-service.md)** | MemoryService API |
| **[template-service.md](../../docs/Models/api/template-service.md)** | TemplateService API |
| **[project-profile-service.md](../../docs/Models/api/project-profile-service.md)** | ProjectProfileService API |

### Memory System (docs/Models/memory/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/memory/README.md)** | Memory system overview |
| **[user-guide.md](../../docs/Models/memory/user-guide.md)** | User guide for memory |
| **[api-reference.md](../../docs/Models/memory/api-reference.md)** | Memory API reference |

### Project Profiles (docs/Models/profiles/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/profiles/README.md)** | Profiles overview |
| **[user-guide.md](../../docs/Models/profiles/user-guide.md)** | User guide for profiles |
| **[built-in-profiles.md](../../docs/Models/profiles/built-in-profiles.md)** | Built-in profile reference |

### Templates (docs/Models/templates/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/templates/README.md)** | Templates overview |
| **[user-guide.md](../../docs/Models/templates/user-guide.md)** | User guide for templates |
| **[template-reference.md](../../docs/Models/templates/template-reference.md)** | Template syntax reference |

### Routing (docs/Models/routing/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/Models/routing/README.md)** | Routing overview |
| **[user-guide.md](../../docs/Models/routing/user-guide.md)** | User guide for routing |
| **[profiles.md](../../docs/Models/routing/profiles.md)** | Routing profiles reference |

---

## 🎯 What is Model Management?

The Model Management System handles everything related to AI models in OLLM CLI:

### Core Features

1. **Model Lifecycle**
   - List available models
   - Pull (download) new models
   - Remove models
   - Show model information
   - Model compatibility detection

2. **Model Routing**
   - Automatic model selection based on task
   - Routing profiles (fast, general, code, creative)
   - Fallback strategies
   - Cost optimization

3. **Memory System**
   - Persistent key-value storage
   - AI can remember important information
   - Search and retrieve memories
   - Memory management commands

4. **Templates**
   - Reusable prompt templates
   - Variable substitution
   - Template library
   - Custom template creation

5. **Project Profiles**
   - Project-specific model preferences
   - Tool configurations
   - Custom settings per project
   - Profile inheritance

---

## 🔧 Implementation Files

The Model Management System is implemented across multiple packages:

### Core Services (packages/core/src/services/)

| File | Purpose |
|------|---------|
| `modelManagementService.ts` | Model lifecycle management |
| `modelRouter.ts` | Model routing and selection |
| `memoryService.ts` | Persistent memory storage |
| `templateService.ts` | Template management |
| `projectProfileService.ts` | Project profile management |
| `costTracker.ts` | Token usage and cost tracking |

### Routing System (packages/core/src/routing/)

| File | Purpose |
|------|---------|
| `modelRouter.ts` | Main routing logic |
| `routingProfiles.ts` | Built-in routing profiles |

### CLI Commands (packages/cli/src/commands/)

| File | Purpose |
|------|---------|
| `modelCommands.ts` | Model management commands |
| `comparisonCommands.ts` | Model comparison commands |
| `memoryCommands.ts` | Memory management commands |
| `templateCommands.ts` | Template management commands |
| `projectCommands.ts` | Project profile commands |

### Test Files

Located in `packages/*/src/__tests__/`:
- Unit tests for each service
- Integration tests for workflows
- Property-based tests for edge cases

---

## 📊 Key Concepts

### Model Types

**By Size:**
- **Small (7B):** Fast, lower quality, 4-8GB VRAM
- **Medium (13B):** Balanced, 8-16GB VRAM
- **Large (70B+):** Best quality, 32GB+ VRAM

**By Capability:**
- **Code models:** Optimized for programming (CodeLlama, DeepSeek Coder)
- **Chat models:** General conversation (Llama, Mistral)
- **Vision models:** Image understanding (LLaVA)
- **Tool-calling models:** Function calling support

### Routing Profiles

**Built-in profiles:**
- `fast` - Prioritize speed (small models)
- `general` - Balanced performance
- `code` - Optimized for coding tasks
- `creative` - Best quality for creative work

**Custom profiles:**
```yaml
profiles:
  my-profile:
    primary: llama3.1:70b
    fallback: llama3.1:8b
    criteria:
      maxLatency: 5000
      minQuality: 0.8
```

### Memory System

**Storage:**
- Key-value pairs
- Persistent across sessions
- Searchable
- AI-accessible via `remember` tool

**Usage:**
```bash
# Store memory
/memory set project-goal "Build a CLI tool"

# Retrieve memory
/memory get project-goal

# Search memories
/memory search "CLI"

# List all memories
/memory list
```

### Templates

**Template syntax:**
```markdown
---
name: code-review
description: Review code for quality
variables:
  - code
  - language
---

Review this {{language}} code:

{{code}}

Check for:
- Code quality
- Best practices
- Potential bugs
```

**Usage:**
```bash
# List templates
/template list

# Use template
/template use code-review --code="function test() {}" --language="JavaScript"
```

---

## 🐛 Known Issues & Fixes

### Fixed Issues

See [implementation-fixes.md](debugging/implementation-fixes.md) for complete list of fixed bugs.

### Current Limitations

From audit findings (see `../.dev/audit/AUDIT-FINDINGS-EXPLAINED.md`):

1. **Model Comparison DI Issue** (HIGH PRIORITY)
   - ComparisonService created with `provider: undefined`
   - `/compare` command doesn't work
   - Status: Needs immediate fix

2. **Model Info Format Mismatch** (HIGH PRIORITY)
   - CLI expects different fields than provider returns
   - `/model info` displays incorrect data
   - Status: Needs immediate fix

3. **Remember Tool Not Registered** (HIGH PRIORITY)
   - RememberTool exists but not in tool registry
   - AI can't use remember feature
   - Status: Simple fix needed

4. **Environment Variable Name Mismatch** (HIGH PRIORITY)
   - Spec says `OLLM_MODEL`, code uses `OLLM_DEFAULT_MODEL`
   - Documentation doesn't match implementation
   - Status: Simple fix needed

5. **Project Profile Service DI** (MEDIUM PRIORITY)
   - Service instantiated via `Object as any` hack
   - Needs proper dependency injection
   - Status: Refactoring needed

6. **Template Create Command** (LOW PRIORITY)
   - Only returns manual instructions
   - Doesn't actually create template file
   - Status: Enhancement

7. **Memory Search Command** (LOW PRIORITY)
   - Documented but not implemented
   - `/memory search` doesn't exist
   - Status: Enhancement

---

## 🚀 Usage Examples

### Model Management

```bash
# List models
/model list

# Pull a model
/model pull llama3.1:8b

# Show model info
/model info llama3.1:8b

# Remove a model
/model remove old-model:7b

# Compare models
/compare "Explain recursion" llama3.1:8b mistral:7b
```

### Memory Management

```bash
# Store information
/memory set api-key "sk-..."
/memory set project-name "OLLM CLI"

# Retrieve information
/memory get api-key

# List all memories
/memory list

# Delete memory
/memory delete api-key
```

### Templates

```bash
# List templates
/template list

# Use a template
/template use code-review

# Create template (manual for now)
# See /template create for instructions
```

### Project Profiles

```bash
# List profiles
/project list

# Create profile
/project create my-project

# Switch profile
/project use my-project

# Show current profile
/project current
```

---

## 📈 Development Status

### ✅ Completed

- Model management service (list, pull, remove, info)
- Model router with routing profiles
- Memory service with persistent storage
- Template service with variable substitution
- Project profile service
- CLI commands for all features
- Comprehensive documentation (10,000+ lines)
- Unit tests (140 test files, 2,056 tests)
- Integration tests (54 tests)
- Property-based tests (47 properties)

### 🔧 Needs Fixing

- Model comparison DI issue (HIGH)
- Model info format mismatch (HIGH)
- Remember tool registration (HIGH)
- Environment variable name (HIGH)
- Project profile DI (MEDIUM)

### 📋 Enhancements

- Template create command implementation
- Memory search command implementation
- Advanced routing strategies
- Cost optimization features

---

## 🔗 Related Documentation

### Development Documentation

- **[Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md)** - Issues found in audit
- **[Fix Plan](../audit/fix_plan.md)** - Prioritized fix tasks (HP-1, HP-2, HP-3, HP-4)
- **[Bug Tracker](../bugtracker.md)** - Current bugs and fixes

### Specifications

- **Stage 07 Spec:** `.kiro/specs/stage-07-model-management/`
  - `requirements.md` - Feature requirements
  - `design.md` - System design
  - `tasks.md` - Implementation tasks

### Implementation Logs

- **[Stage 07 Log](../logs/stages/stage-07-model-management.md)** - Implementation history

### Reference Materials

- **[Ollama Models](reference/ollama-models.md)** - Available Ollama models
- **[Draft Content](development/draft-content-summary.md)** - Integrated draft content

---

## 🤝 Contributing

When working on model management:

1. **Read the architecture docs** - Understand the system design
2. **Check audit findings** - Know current limitations and bugs
3. **Run tests** - Ensure changes don't break existing functionality
4. **Update docs** - Keep documentation in sync with code
5. **Test with real models** - Verify functionality works

### Testing

```bash
# Run model management tests
npm test packages/core/src/services

# Run routing tests
npm test packages/core/src/routing

# Run CLI command tests
npm test packages/cli/src/commands

# Run specific test file
npx vitest run packages/core/src/services/__tests__/modelManagementService.test.ts

# Run with coverage
npm test -- --coverage packages/core/src/services
```

---

## 📞 Support

For questions or issues:

1. Check the [User Guide](../../docs/Models/getting-started.md)
2. Review [Troubleshooting](../../docs/troubleshooting.md)
3. Check [Bug Tracker](../bugtracker.md) for known issues
4. See [Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md) for limitations
5. Review [Fix Plan](../audit/fix_plan.md) for planned fixes

---

## 📝 Quick Reference

### Key Files to Know

| Purpose | File |
|---------|------|
| **User docs entry** | `docs/Models/README.md` |
| **Architecture** | `docs/Models/Models_architecture.md` |
| **Commands** | `docs/Models/Models_commands.md` |
| **Model management** | `packages/core/src/services/modelManagementService.ts` |
| **Model router** | `packages/core/src/routing/modelRouter.ts` |
| **Memory service** | `packages/core/src/services/memoryService.ts` |
| **Tests** | `packages/core/src/services/__tests__/` |
| **Bug fixes** | `.dev/Models/debugging/implementation-fixes.md` |

### Common Tasks

| Task | Command/File |
|------|--------------|
| List models | `/model list` |
| Pull model | `/model pull <model>` |
| Model info | `/model info <model>` |
| Compare models | `/compare "<prompt>" <model1> <model2>` |
| Store memory | `/memory set <key> <value>` |
| Use template | `/template use <name>` |
| Run tests | `npm test packages/core/src/services` |
| Read architecture | `docs/Models/Models_architecture.md` |
| Check bugs | `.dev/audit/fix_plan.md` |

### Priority Fixes Needed

See [Fix Plan](../audit/fix_plan.md) for details:

1. **HP-1:** Fix model comparison DI issue
2. **HP-2:** Fix model info format mismatch
3. **HP-3:** Register remember tool
4. **HP-4:** Fix environment variable name

---

**Last Updated:** January 17, 2026  
**Documentation Status:** Complete  
**Implementation Status:** Core complete, fixes needed (see audit)
