# Final Fix Summary - Compression Not Triggering

## Problem
After refactoring ChatContext, compression was not triggering during long conversations, causing the LLM to forget conversation history after context rollover.

## Root Cause
Mismatch between what we send to Ollama (`ollama_context_size` from profile) and what we use for compression thresholds (`context.maxTokens` set to user's selection).

## Solution
Ensure all code paths use `ollama_context_size` from profiles without recalculation.

## Files Modified

### 1. packages/cli/src/features/context/ModelContext.tsx
**Change:** Update `context.maxTokens` to match `ollama_context_size` before sending to Ollama

```typescript
// CRITICAL: Update contextPool to use Ollama's actual limit
// This ensures compression thresholds are calculated against the real limit
if (contextActions && contextActions.updateConfig) {
  try {
    contextActions.updateConfig({ 
      targetSize: ollamaContextSize  // Sets context.maxTokens to ollama_context_size
    });
    console.log(`[ModelContext] Updated context limits - Ollama: ${ollamaContextSize}, User display: ${allowed}`);
  } catch (error) {
    console.warn('[ModelContext] Failed to update context limits', error);
  }
}
```

**Impact:** Compression thresholds now calculated against actual Ollama limit

### 2. packages/core/src/context/contextDefaults.ts
**Change:** Adjusted compression thresholds and updated comments

```typescript
compression: {
  enabled: true,
  threshold: 0.75, // Trigger at 75% of ollama_context_size (before Ollama's hard stop)
  strategy: 'hybrid',
  preserveRecent: 4096,
  summaryMaxTokens: 1024
},
snapshots: {
  enabled: true,
  maxCount: 5,
  autoCreate: true,
  autoThreshold: 0.80 // Snapshot at 80% of ollama_context_size (after compression, before Ollama stop)
}
```

**Impact:** Clearer documentation of what thresholds mean

### 3. packages/core/src/context/messageStore.ts
**Change:** Added debug logging for compression triggers

```typescript
if (usageFraction >= this.config.compression.threshold) {
  console.log('[MessageStore] Compression threshold reached', {
    usageFraction: usageFraction.toFixed(3),
    threshold: this.config.compression.threshold,
    currentTokens: context.tokenCount,
    maxTokens: context.maxTokens
  });
  await this.compress();
}
```

**Impact:** Better visibility into when compression triggers

### 4. packages/cli/src/nonInteractive.ts
**Change:** Load model profile and provide `ollamaContextSize` to ChatClient

```typescript
// Load model profile and calculate context sizing
let ollamaContextSize: number | undefined;
let contextSize: number | undefined;

try {
  const { profileManager } = await import('./features/profiles/ProfileManager.js');
  const { calculateContextSizing } = await import('./features/context/contextSizing.js');
  const { SettingsService } = await import('./config/settingsService.js');
  
  const modelEntry = profileManager.getModelEntry(model);
  if (modelEntry) {
    const settingsService = SettingsService.getInstance();
    const settings = settingsService.getSettings();
    const requestedContextSize = settings.llm?.contextSize ?? modelEntry.default_context ?? 4096;
    const contextCapRatio = settings.llm?.contextCapRatio ?? 0.85;
    
    const contextSizing = calculateContextSizing(requestedContextSize, modelEntry, contextCapRatio);
    ollamaContextSize = contextSizing.ollamaContextSize;
    contextSize = contextSizing.allowed;
    
    console.error(`[NonInteractive] Context sizing: user=${contextSize}, ollama=${ollamaContextSize} (${Math.round(contextSizing.ratio * 100)}%)`);
  }
} catch (error) {
  console.error(`[NonInteractive] Warning: Could not load model profile for context sizing: ${error instanceof Error ? error.message : String(error)}`);
}

// Pass to ChatClient
for await (const event of chatClient.chat(options.prompt, {
  model,
  provider: providerName === 'ollama' ? 'local' : providerName,
  abortSignal: options.abortSignal || abortController.signal,
  contextSize,  // User's selected context size (for UI display)
  ollamaContextSize,  // Actual size to send to Ollama (from profile)
})) {
```

**Impact:** Non-interactive mode now uses profile values correctly

## How It Works Now

### For 4k Context Selection:

**Before (Broken):**
```
User selects: 4096
Profile has: ollama_context_size: 3482 (85% of 4096)
We send to Ollama: num_ctx: 3482 ✓
But context.maxTokens: 4096 ✗
Compression triggers at: 0.75 * 4096 = 3072 ✗
Ollama stops at: 3482
Result: Only 410 token buffer before Ollama stops
```

**After (Fixed):**
```
User selects: 4096
Profile has: ollama_context_size: 3482 (85% of 4096)
We send to Ollama: num_ctx: 3482 ✓
And context.maxTokens: 3482 ✓
Compression triggers at: 0.75 * 3482 = 2611 ✓
Snapshot triggers at: 0.80 * 3482 = 2785 ✓
Ollama stops at: 3482
Result: 871 token buffer for compression + snapshot
```

## Data Flow

### Interactive Mode (TUI)
```
LLM_profiles.json (source of truth)
  ↓
ProfileManager → user_models.json
  ↓
calculateContextSizing()
  ├─ size: 4096 (user's selection)
  └─ ollama_context_size: 3482 (from profile)
  ↓
ModelContext.sendToLLM()
  ├─ contextActions.updateConfig({ targetSize: 3482 })
  │   └─ Sets context.maxTokens = 3482
  └─ provider.chatStream({ options: { num_ctx: 3482 } })
  ↓
LocalProvider → Ollama (receives num_ctx: 3482)
```

### Non-Interactive Mode (--prompt flag)
```
LLM_profiles.json (source of truth)
  ↓
ProfileManager → user_models.json
  ↓
calculateContextSizing()
  ├─ size: 4096 (user's selection)
  └─ ollama_context_size: 3482 (from profile)
  ↓
ChatClient.chat({ contextSize: 4096, ollamaContextSize: 3482 })
  ↓
Turn.buildGenerationOptions()
  └─ Uses ollamaContextSize if provided (no calculation)
  ↓
LocalProvider → Ollama (receives num_ctx: 3482)
```

## When Non-Interactive Mode is Used

Non-interactive mode is triggered with the `--prompt` or `-p` flag:

```bash
# Examples:
ollm --prompt "What is 2+2?"
ollm -p "Explain quantum computing"
ollm --prompt - < input.txt  # Read from stdin
ollm -p "Hello" --output json  # JSON output
ollm -p "Test" --output stream-json  # Streaming JSON
```

**Use cases:**
- Scripting/Automation
- CI/CD Pipelines
- Piping with other tools
- Batch Processing
- API-like usage with structured output

## Core Principle

**The app reads both `size` (user's selection) and `ollama_context_size` (Ollama's limit) from LLM_profiles.json and passes them through without calculation.**

## Verification

To verify the fix works:

1. **Interactive Mode:**
   ```bash
   ollm  # Start TUI
   # Select 4k context
   # Send long prompt that fills context
   # Watch for compression message at ~2600 tokens
   # Verify snapshot at ~2800 tokens
   # Verify LLM remembers conversation after rollover
   ```

2. **Non-Interactive Mode:**
   ```bash
   ollm --prompt "Generate a very long response" --output json
   # Check that num_ctx is set correctly in logs
   # Verify response doesn't exceed context limit
   ```

3. **Check Logs:**
   ```
   [ModelContext] Updated context limits - Ollama: 3482, User display: 4096
   [MessageStore] Compression threshold reached { usageFraction: '0.750', threshold: 0.75, currentTokens: 2611, maxTokens: 3482 }
   ```

## Documentation Created

1. `.dev/COMPRESSION-FIX-SUMMARY.md` - Detailed explanation of the compression fix
2. `.dev/CONTEXT-SIZING-AUDIT.md` - Comprehensive audit of all context sizing code paths
3. `.dev/FINAL-FIX-SUMMARY.md` - This file

## Related Issues

- Original bug: `.dev/llm_bug.md`
- Previous fixes: `.dev/llm_fixes.md`, `.dev/llm_fixes2.md`
- Refactoring summary: `.dev/refactoring/REFACTORING-COMPLETE.md`
