# MCP Implementation Roadmap

**Model Context Protocol - Unfinished Work & Outstanding Issues**

**Created:** 2026-01-16  
**Status:** 🟡 Active Development  
**Overall Completion:** 45% (Weeks 1-4 complete, Week 5 pending)

---

## Executive Summary

This document tracks all unfinished work, pending implementations, and outstanding bugs related to the MCP (Model Context Protocol), Hooks, and Extensions systems in OLLM CLI.

### Implementation Status

**Completed (Weeks 1-4):**
- ✅ Hook approval UI
- ✅ MCP health monitoring
- ✅ Hook debugging mode
- ✅ MessageBus architecture
- ✅ Hook planning enhancements
- ✅ OAuth 2.0 support
- ✅ Resources and prompts discovery
- ✅ Extension marketplace
- ✅ Extension hot-reload
- ✅ Extension sandboxing

**Pending (Week 5+):**
- ⏳ Integration testing
- ⏳ CLI command integration
- ⏳ UI component integration
- ⏳ Comprehensive documentation
- ⏳ Official MCP SDK migration
- ⏳ Performance optimization

---

## Table of Contents

1. [Critical Issues](#critical-issues)
2. [High Priority Work](#high-priority-work)
3. [Medium Priority Work](#medium-priority-work)
4. [Testing Gaps](#testing-gaps)
5. [CLI Integration Gaps](#cli-integration-gaps)
6. [UI Integration Gaps](#ui-integration-gaps)
7. [Documentation Gaps](#documentation-gaps)
8. [Technical Debt](#technical-debt)
9. [Future Enhancements](#future-enhancements)

---

## Critical Issues

### 1. MCP Client Not Wired to Command Registry ❌

**Status:** Not Implemented  
**Priority:** 🔴 Critical  
**Impact:** MCP health commands exist but cannot function

**Issue:**
- MCP health commands created and registered
- Commands require MCP client instance to function
- No mechanism to provide MCP client to commands
- `commandRegistry.setMCPClient()` method exists but never called

**Required Work:**
1. Determine where MCP client is initialized in app
2. Call `commandRegistry.setMCPClient(mcpClient)` after initialization
3. Test that health commands work with real MCP client
4. Verify OAuth commands work with real MCP client

**Files Affected:**
- `packages/cli/src/cli.tsx` or app initialization
- `packages/cli/src/commands/commandRegistry.ts`
- `packages/cli/src/commands/mcpHealthCommands.ts`
- `packages/cli/src/commands/mcpOAuthCommands.ts`

**Estimated Effort:** 2-4 hours

---

### 2. Extension Registry Format Not Defined ❌

**Status:** Not Implemented  
**Priority:** 🔴 Critical  
**Impact:** Extension marketplace cannot function

**Issue:**
- `ExtensionRegistry` class implemented
- No standard registry JSON format defined
- No public registry available
- Installation from URLs works but search doesn't

**Required Work:**
1. Define registry JSON schema
2. Create sample registry file
3. Set up public registry (GitHub Pages or similar)
4. Implement registry fetching and caching
5. Test search and installation flow

**Registry Schema (Proposed):**
```json
{
  "version": "1.0",
  "extensions": [
    {
      "name": "github-integration",
      "version": "1.2.0",
      "description": "GitHub integration with MCP server",
      "author": "ollm-community",
      "keywords": ["github", "git", "mcp"],
      "downloadUrl": "https://github.com/ollm/ext-github/releases/download/v1.2.0/github-integration.tar.gz",
      "checksum": "sha256:abc123...",
      "homepage": "https://github.com/ollm/ext-github",
      "license": "MIT"
    }
  ]
}
```

**Files Affected:**
- `packages/core/src/extensions/extensionRegistry.ts`
- New: `schemas/extension-registry.schema.json`
- New: Public registry file

**Estimated Effort:** 4-8 hours

---

### 3. Archive Extraction Not Implemented ❌

**Status:** Placeholder Implementation  
**Priority:** 🔴 Critical  
**Impact:** Extension installation incomplete

**Issue:**
- `ExtensionRegistry.install()` downloads extensions
- Archive extraction is placeholder (throws error)
- Cannot extract .tar.gz or .zip files
- Installation cannot complete

**Required Work:**
1. Add dependency: `tar` or `adm-zip`
2. Implement tar.gz extraction
3. Implement zip extraction
4. Add extraction error handling
5. Test with real extension archives

**Files Affected:**
- `packages/core/src/extensions/extensionRegistry.ts`
- `packages/core/package.json` (add dependencies)

**Estimated Effort:** 2-4 hours

---

## High Priority Work

### 4. Integration Tests Missing ⏳

**Status:** Not Started  
**Priority:** 🟡 High  
**Impact:** No validation of system integration

**Missing Test Coverage:**
- Hook lifecycle integration
- Extension lifecycle integration
- MCP integration end-to-end
- OAuth flow integration
- Health monitoring integration
- Extension marketplace flow

**Required Work:**
1. Set up integration test infrastructure
2. Write hook lifecycle tests
3. Write extension lifecycle tests
4. Write MCP integration tests
5. Write OAuth flow tests
6. Write marketplace installation tests

**Test Files to Create:**
- `integration-tests/hooks-lifecycle.test.ts`
- `integration-tests/extension-lifecycle.test.ts`
- `integration-tests/mcp-integration.test.ts`
- `integration-tests/oauth-flow.test.ts`
- `integration-tests/health-monitoring.test.ts`
- `integration-tests/extension-marketplace.test.ts`

**Estimated Effort:** 16-24 hours

---

### 5. Deferred Unit Tests ⏳

**Status:** Tests Deferred  
**Priority:** 🟡 High  
**Impact:** Reduced code coverage

**Deferred Test Suites:**
- MCP health monitoring (3 tests failing, timing issues)
- Hook debugging mode (0 tests)
- MessageBus (80+ tests not run)
- Hook planning enhancements (0 tests)
- OAuth provider (0 tests)
- Extension registry (0 tests)
- Extension watcher (0 tests)
- Extension sandbox (0 tests)

**Required Work:**
1. Fix test environment issues (fake timers with async)
2. Run all deferred tests
3. Fix failing tests
4. Achieve 80%+ code coverage
5. Set up CI/CD integration

**Estimated Effort:** 12-16 hours

---

### 6. CLI Commands Not Fully Integrated ⏳

**Status:** Partially Implemented  
**Priority:** 🟡 High  
**Impact:** Commands exist but not all functional

**Commands Created But Not Tested:**
- `/mcp health` commands (need MCP client)
- `/mcp oauth` commands (need MCP client)
- `/extensions` commands (need testing)
- `/hooks debug` commands (need testing)

**Required Work:**
1. Wire MCP client to command registry
2. Test all MCP commands with real servers
3. Test all OAuth commands with real providers
4. Test all extension commands with real extensions
5. Test all hook debug commands with real hooks
6. Add command help text to `/help`

**Estimated Effort:** 8-12 hours

---

### 7. UI Components Not Integrated ⏳

**Status:** Not Started  
**Priority:** 🟡 High  
**Impact:** Poor user experience

**Missing UI Components:**
- OAuth authorization dialog
- Extension search dialog
- Extension installation progress
- Permission prompt dialog
- Extension management panel
- Health status indicators (partially done)

**Required Work:**
1. Create OAuth authorization dialog
2. Create extension search dialog
3. Create installation progress component
4. Create permission prompt dialog
5. Create extension management panel
6. Integrate all components into main UI

**Files to Create:**
- `packages/cli/src/ui/components/dialogs/OAuthDialog.tsx`
- `packages/cli/src/ui/components/dialogs/ExtensionSearchDialog.tsx`
- `packages/cli/src/ui/components/dialogs/InstallProgressDialog.tsx`
- `packages/cli/src/ui/components/dialogs/PermissionPromptDialog.tsx`
- `packages/cli/src/ui/components/panels/ExtensionPanel.tsx`

**Estimated Effort:** 16-24 hours

---

## Medium Priority Work

### 8. Official MCP SDK Migration ⏸️

**Status:** Deferred  
**Priority:** 🟢 Medium  
**Impact:** Missing some SDK features

**Issue:**
- Custom MCP client implementation working
- Official SDK installed but not integrated
- Missing some SDK features (notifications, etc.)
- Can migrate later without breaking changes

**Required Work:**
1. Study official SDK API
2. Create adapter layer for compatibility
3. Migrate transport implementations
4. Test all existing functionality
5. Add SDK-specific features

**Files Affected:**
- `packages/core/src/mcp/mcpClient.ts`
- `packages/core/src/mcp/mcpTransport.ts`
- All MCP-related files

**Estimated Effort:** 16-24 hours

---

### 9. Performance Optimization ⏳

**Status:** Not Started  
**Priority:** 🟢 Medium  
**Impact:** Potential performance issues

**Areas Needing Optimization:**
- MessageBus event emission overhead
- Hook execution parallelization
- Extension hot-reload debouncing
- Registry caching strategy
- Health check frequency

**Required Work:**
1. Benchmark current performance
2. Identify bottlenecks
3. Optimize hot paths
4. Add performance monitoring
5. Document performance characteristics

**Estimated Effort:** 8-12 hours

---

### 10. Error Messages and Logging ⏳

**Status:** Partially Implemented  
**Priority:** 🟢 Medium  
**Impact:** Harder to debug issues

**Issues:**
- Some error messages too generic
- Logging not consistent across modules
- No structured logging
- Debug output not always helpful

**Required Work:**
1. Audit all error messages
2. Add context to error messages
3. Implement structured logging
4. Add debug logging throughout
5. Create logging guidelines

**Estimated Effort:** 8-12 hours

---

## Testing Gaps

### Unit Test Coverage

**Current Coverage:** ~60% (estimated)  
**Target Coverage:** 80%+

**Modules Needing Tests:**
- `mcpHealthMonitor.ts` - 90% (3 tests failing)
- `hookDebugger.ts` - 0%
- `messageBus.ts` - Tests exist but not run
- `hookEventHandler.ts` - Tests exist but not run
- `mcpOAuth.ts` - 0%
- `extensionRegistry.ts` - 0%
- `extensionWatcher.ts` - 0%
- `extensionSandbox.ts` - 0%

**Estimated Effort:** 16-24 hours

---

### Integration Test Coverage

**Current Coverage:** 0%  
**Target Coverage:** All major workflows

**Missing Integration Tests:**
1. Hook execution flow (event → hook → output)
2. Extension loading flow (discover → parse → register)
3. MCP server flow (start → discover → call tool)
4. OAuth flow (authorize → token → refresh)
5. Health monitoring flow (check → fail → restart)
6. Extension installation flow (search → download → install)

**Estimated Effort:** 16-24 hours

---

### Property-Based Test Coverage

**Current Coverage:** Good for core modules  
**Target Coverage:** All critical paths

**Missing Property Tests:**
- Extension manifest parsing edge cases
- OAuth token refresh timing
- Health check retry logic
- Permission checking logic
- Registry search relevance

**Estimated Effort:** 8-12 hours

---

## CLI Integration Gaps

### Commands Not Registered

**Status:** Commands exist but not all registered

**Missing Registrations:**
- MCP health commands (registered but need client)
- Some hook debug commands may need registration check

**Estimated Effort:** 2-4 hours

---

### Command Help Text

**Status:** Partially Complete

**Missing Help Text:**
- Detailed help for each command
- Examples in help output
- Error message improvements
- Command aliases documentation

**Estimated Effort:** 4-8 hours

---

### Command Validation

**Status:** Basic validation only

**Missing Validation:**
- Argument type checking
- Argument count validation
- Better error messages for invalid input
- Suggestions for similar commands

**Estimated Effort:** 4-8 hours

---

## UI Integration Gaps

### Dialog Components

**Status:** Hook approval dialog complete, others missing

**Missing Dialogs:**
- OAuth authorization dialog
- Extension search dialog
- Installation progress dialog
- Permission prompt dialog
- Error dialogs for MCP/extension failures

**Estimated Effort:** 12-16 hours

---

### Status Indicators

**Status:** MCP status component exists, others missing

**Missing Indicators:**
- Extension status in status bar
- Hook execution status
- OAuth token expiration warnings
- Health check status (partially done)

**Estimated Effort:** 8-12 hours

---

### Management Panels

**Status:** Not Started

**Missing Panels:**
- Extension management panel
- Hook management panel
- MCP server management panel
- OAuth token management panel

**Estimated Effort:** 16-24 hours

---

## Documentation Gaps

### User Documentation

**Status:** Architecture and integration guides complete

**Missing Documentation:**
- ✅ MCP Architecture (complete)
- ✅ MCP Integration Guide (complete)
- ✅ MCP Commands Reference (complete)
- ❌ Getting Started Guide
- ❌ Hook System User Guide
- ❌ Extension Development Guide
- ❌ OAuth Setup Guide
- ❌ Troubleshooting Guide

**Estimated Effort:** 16-24 hours

---

### Developer Documentation

**Status:** Minimal

**Missing Documentation:**
- API reference for all modules
- Extension manifest reference
- Hook protocol specification
- Testing guide
- Contributing guide

**Estimated Effort:** 16-24 hours

---

### Code Documentation

**Status:** Partial

**Missing Documentation:**
- JSDoc comments for all public APIs
- Inline comments for complex logic
- Architecture decision records
- Migration guides

**Estimated Effort:** 8-12 hours

---

## Technical Debt

### 1. Test Environment Issues

**Issue:** Fake timers with async operations cause hangs  
**Impact:** Cannot run some tests  
**Priority:** High  
**Estimated Effort:** 4-8 hours

---

### 2. Custom MCP Implementation

**Issue:** Not using official SDK  
**Impact:** Missing features, maintenance burden  
**Priority:** Medium  
**Estimated Effort:** 16-24 hours (SDK migration)

---

### 3. Error Handling Inconsistency

**Issue:** Error handling patterns vary across modules  
**Impact:** Harder to debug, inconsistent UX  
**Priority:** Medium  
**Estimated Effort:** 8-12 hours

---

### 4. Logging Inconsistency

**Issue:** No structured logging, inconsistent log levels  
**Impact:** Harder to debug production issues  
**Priority:** Medium  
**Estimated Effort:** 8-12 hours

---

### 5. Configuration Validation

**Issue:** Limited validation of configuration values  
**Impact:** Runtime errors instead of startup errors  
**Priority:** Medium  
**Estimated Effort:** 4-8 hours

---

## Future Enhancements

### 1. Advanced Health Monitoring

**Features:**
- Metrics collection
- Performance tracking
- Alerting system
- Dashboard view
- Historical data

**Estimated Effort:** 16-24 hours

---

### 2. Extension Dependencies

**Features:**
- Declare dependencies in manifest
- Automatic dependency resolution
- Version compatibility checking
- Dependency installation

**Estimated Effort:** 12-16 hours

---

### 3. Extension Permissions UI

**Features:**
- Visual permission editor
- Permission audit log
- Permission templates
- Bulk permission management

**Estimated Effort:** 12-16 hours

---

### 4. Hook Telemetry

**Features:**
- Hook execution metrics
- Performance profiling
- Error tracking
- Usage analytics

**Estimated Effort:** 8-12 hours

---

### 5. MCP Server Discovery

**Features:**
- Automatic server discovery
- Server recommendations
- Server ratings/reviews
- Server compatibility checking

**Estimated Effort:** 12-16 hours

---

### 6. Extension Marketplace Features

**Features:**
- User ratings and reviews
- Extension screenshots
- Extension categories
- Featured extensions
- Update notifications

**Estimated Effort:** 16-24 hours

---

### 7. Advanced OAuth Features

**Features:**
- Multiple OAuth providers per server
- OAuth scope management
- Token sharing between extensions
- OAuth token encryption at rest

**Estimated Effort:** 12-16 hours

---

### 8. Hook Composition

**Features:**
- Hook pipelines
- Hook dependencies
- Conditional hook execution
- Hook templates

**Estimated Effort:** 12-16 hours

---

## Priority Matrix

### Immediate (This Week)

1. **Wire MCP client to command registry** (4 hours)
2. **Define extension registry format** (8 hours)
3. **Implement archive extraction** (4 hours)
4. **Fix test environment issues** (8 hours)

**Total:** 24 hours

---

### Short-term (Next 2 Weeks)

1. **Write integration tests** (24 hours)
2. **Run and fix deferred unit tests** (16 hours)
3. **Test all CLI commands** (12 hours)
4. **Create missing UI components** (24 hours)

**Total:** 76 hours

---

### Medium-term (Next Month)

1. **Complete user documentation** (24 hours)
2. **Complete developer documentation** (24 hours)
3. **Performance optimization** (12 hours)
4. **Error handling improvements** (12 hours)

**Total:** 72 hours

---

### Long-term (Next Quarter)

1. **Official MCP SDK migration** (24 hours)
2. **Advanced health monitoring** (24 hours)
3. **Extension dependencies** (16 hours)
4. **Extension marketplace features** (24 hours)

**Total:** 88 hours

---

## Risk Assessment

### High Risk Items

1. **MCP Client Integration**
   - Risk: Commands may not work with real MCP client
   - Mitigation: Test thoroughly with multiple servers

2. **Extension Registry**
   - Risk: Registry format may need changes
   - Mitigation: Version the schema, plan for migrations

3. **Test Environment**
   - Risk: Cannot validate code without working tests
   - Mitigation: Fix test environment as top priority

---

### Medium Risk Items

1. **Performance**
   - Risk: MessageBus overhead may be significant
   - Mitigation: Benchmark and optimize if needed

2. **OAuth Security**
   - Risk: Token storage vulnerabilities
   - Mitigation: Security audit, use platform keychain

3. **Extension Security**
   - Risk: Malicious extensions
   - Mitigation: Sandboxing, permissions, code review

---

### Low Risk Items

1. **SDK Migration**
   - Risk: Breaking changes
   - Mitigation: Adapter layer, gradual migration

2. **Documentation**
   - Risk: Outdated docs
   - Mitigation: Keep docs in sync with code

---

## Success Criteria

### Week 5 (Testing & Documentation)

- [ ] All integration tests passing
- [ ] Unit test coverage > 80%
- [ ] All CLI commands functional
- [ ] All UI components integrated
- [ ] User documentation complete
- [ ] Developer documentation complete

### Post-Week 5

- [ ] MCP client wired to commands
- [ ] Extension registry operational
- [ ] Archive extraction working
- [ ] Test environment fixed
- [ ] Performance acceptable
- [ ] No critical bugs

---

## Tracking

### Overall Progress

**Completed:** 45% (Weeks 1-4)  
**Remaining:** 55% (Week 5 + post-work)

**Estimated Total Effort:** 260 hours  
**Completed Effort:** ~120 hours  
**Remaining Effort:** ~140 hours

---

### Weekly Breakdown

| Week | Focus | Status | Effort |
|------|-------|--------|--------|
| 1 | Critical Fixes | ✅ Complete | 40h |
| 2 | Architecture | ✅ Complete | 32h |
| 3 | MCP Enhancements | ✅ Complete | 32h |
| 4 | Extension Ecosystem | ✅ Complete | 40h |
| 5 | Testing & Docs | ⏳ Pending | 40h |
| Post | Integration & Polish | ⏳ Pending | 76h |

---

## Next Actions

### This Week

1. ✅ Complete MCP documentation organization
2. ✅ Create MCP roadmap (this document)
3. ⏳ Wire MCP client to command registry
4. ⏳ Define extension registry format
5. ⏳ Implement archive extraction

### Next Week

1. Fix test environment issues
2. Run all deferred tests
3. Write integration tests
4. Test all CLI commands
5. Start UI component integration

---

## References

- Upgrade Plan (.dev/MCP/development/upgrade-plan.md)
- Implementation Progress (.dev/MCP/development/implementation-progress.md)
- Bug Tracker (.dev/bugtracker.md)
- [MCP Architecture](../docs/MCP/MCP_architecture.md)
- [MCP Integration Guide](../docs/MCP/MCP_integration.md)
- [MCP Commands Reference](../docs/MCP/MCP_commands.md)

---

**Document Version:** 1.0  
**Created:** 2026-01-16  
**Last Updated:** 2026-01-16  
**Next Review:** Weekly during active development
