# MCP API Key Management - Implementation Plan

**Date:** January 19, 2026  
**Status:** 📋 Planning

## Overview

Many MCP servers require API keys or authentication tokens. We need a user-friendly way to:
1. Detect when a server needs API keys
2. Prompt users to enter them during installation
3. Provide links to get API keys from provider websites
4. Securely store and manage API keys
5. Allow editing API keys after installation

## Current State

### What Works
- Environment variables are stored in `mcp.json` config
- Metadata includes `requirements` field (e.g., "API Key required")
- Servers can be installed with empty env vars

### What's Missing
- No UI for entering API keys during installation
- No links to provider websites to get API keys
- No validation that required keys are present
- No secure storage (keys are in plain text in config)
- No way to edit keys after installation without manual config editing

## Proposed Solution

### Phase 1: Installation Flow Enhancement

#### 1.1 Detect Required API Keys

When installing a server, check metadata for required environment variables:

```typescript
interface MCPServerMetadata {
  requirements?: string[];  // e.g., ["Node.js 18+", "API Key (BRAVE_API_KEY)"]
  requiresOAuth?: boolean;
  // NEW:
  envVars?: Array<{
    name: string;
    description: string;
    required: boolean;
    getKeyUrl?: string;  // Link to get the API key
    isSecret: boolean;
  }>;
}
```

#### 1.2 API Key Input Dialog

Create a new dialog component: `APIKeyInputDialog.tsx`

**Features:**
- Shows list of required environment variables
- Input fields for each key (masked for secrets)
- "Get API Key" button that opens browser to provider website
- Validation that required keys are filled
- Option to skip (install without keys, server will be disabled)

**UI Mockup:**
```
┌─────────────────────────────────────────────────┐
│ Configure API Keys - brave-search              │
├─────────────────────────────────────────────────┤
│                                                 │
│ This server requires the following API keys:   │
│                                                 │
│ BRAVE_API_KEY (Required)                       │
│ ┌─────────────────────────────────────────┐   │
│ │ ••••••••••••••••••••                    │   │
│ └─────────────────────────────────────────┘   │
│ [Get API Key] https://brave.com/search/api     │
│                                                 │
│ SMITHERY_API_KEY (Optional)                    │
│ ┌─────────────────────────────────────────┐   │
│ │                                         │   │
│ └─────────────────────────────────────────┘   │
│ [Get API Key] https://smithery.ai/             │
│                                                 │
│ ⚠️  Keys are stored in plain text in:          │
│    ~/.ollm/settings/mcp.json                   │
│                                                 │
│ [Skip] [Cancel] [Install]                      │
└─────────────────────────────────────────────────┘
```

#### 1.3 Installation Flow Update

```typescript
// In MarketplaceContent component
async function handleInstall(server: MCPMarketplaceServer) {
  // Check if server requires API keys
  const requiredEnvVars = server.env ? Object.keys(server.env) : [];
  
  if (requiredEnvVars.length > 0) {
    // Show API key input dialog
    const envVars = await showAPIKeyDialog(server);
    
    if (!envVars) {
      // User cancelled
      return;
    }
    
    // Install with provided keys
    await installServer(server.id, { env: envVars });
  } else {
    // Install without keys
    await installServer(server.id, {});
  }
}
```

### Phase 2: Post-Installation Management

#### 2.1 Edit API Keys Action

Add a new action in server details view:

```
← Exit

Status: ● Enabled

[Server Details...]

[E] Edit API Keys  ← NEW
[D] Delete Server
```

#### 2.2 API Key Editor Dialog

Similar to installation dialog, but pre-filled with existing values:
- Shows current keys (masked)
- Allows editing
- Validates required keys
- Updates config and restarts server

### Phase 3: Security Enhancements (Future)

#### 3.1 Encrypted Storage

Instead of plain text in `mcp.json`, store encrypted:

```json
{
  "mcpServers": {
    "brave-search": {
      "command": "npx",
      "args": ["-y", "@smithery/brave-search-mcp"],
      "env": {
        "BRAVE_API_KEY": "encrypted:AES256:base64encodeddata"
      }
    }
  }
}
```

**Implementation:**
- Use Node.js `crypto` module
- Derive encryption key from machine ID + user password (optional)
- Decrypt on-the-fly when starting servers

#### 3.2 System Keychain Integration

For better security, integrate with OS keychains:
- **Windows:** Windows Credential Manager
- **macOS:** Keychain Access
- **Linux:** Secret Service API (gnome-keyring, kwallet)

**Library:** `keytar` or `node-keytar`

```typescript
import keytar from 'keytar';

// Store
await keytar.setPassword('ollm-mcp', 'brave-search:BRAVE_API_KEY', apiKey);

// Retrieve
const apiKey = await keytar.getPassword('ollm-mcp', 'brave-search:BRAVE_API_KEY');
```

### Phase 4: Provider Integration

#### 4.1 Provider Registry

Maintain a registry of known MCP server providers with metadata:

```typescript
const PROVIDER_REGISTRY = {
  'brave-search': {
    name: 'Brave Search',
    apiKeyUrl: 'https://brave.com/search/api/',
    apiKeyInstructions: 'Sign up for Brave Search API and copy your API key',
    envVars: [
      {
        name: 'BRAVE_API_KEY',
        description: 'Brave Search API Key',
        required: true,
        isSecret: true,
      }
    ]
  },
  'context7': {
    name: 'Context7',
    apiKeyUrl: 'https://console.upstash.com/context7',
    apiKeyInstructions: 'Create a Context7 account and generate an API key',
    envVars: [
      {
        name: 'CONTEXT7_API_KEY',
        description: 'Context7 API Key',
        required: true,
        isSecret: true,
      }
    ]
  },
  // ... more providers
};
```

#### 4.2 Auto-Detection

When installing from marketplace, automatically detect provider and show relevant info:

```typescript
function getProviderInfo(serverId: string): ProviderInfo | null {
  // Try exact match
  if (PROVIDER_REGISTRY[serverId]) {
    return PROVIDER_REGISTRY[serverId];
  }
  
  // Try fuzzy match
  for (const [key, info] of Object.entries(PROVIDER_REGISTRY)) {
    if (serverId.includes(key) || key.includes(serverId)) {
      return info;
    }
  }
  
  return null;
}
```

## Implementation Priority

### High Priority (Do First)
1. ✅ Metadata storage (DONE)
2. 🔄 API Key Input Dialog during installation
3. 🔄 "Get API Key" button with provider links
4. 🔄 Edit API Keys action in server details

### Medium Priority
5. Provider registry with known servers
6. Validation that required keys are present
7. Better error messages when keys are missing

### Low Priority (Future)
8. Encrypted storage
9. System keychain integration
10. OAuth flow improvements

## Files to Create/Modify

### New Files
- `packages/cli/src/ui/components/dialogs/APIKeyInputDialog.tsx`
- `packages/cli/src/services/providerRegistry.ts`
- `packages/cli/src/services/keyStorage.ts` (for encryption)

### Modified Files
- `packages/cli/src/ui/components/tabs/MCPTab.tsx` - Add "Edit API Keys" action
- `packages/cli/src/services/mcpMarketplace.ts` - Enhanced metadata
- `packages/core/src/mcp/types.ts` - Extended metadata interface

## User Experience Flow

### Installation with API Keys

```
1. User selects "brave-search" from marketplace
2. Presses Enter on "Install"
3. System detects required API keys
4. Shows API Key Input Dialog:
   - "This server requires: BRAVE_API_KEY"
   - Input field (masked)
   - [Get API Key] button → opens https://brave.com/search/api/
5. User gets API key from website
6. Pastes into input field
7. Presses Install
8. Server installs with API key configured
9. Server starts and connects (healthy)
```

### Editing API Keys

```
1. User selects server in left menu
2. Navigates to "Edit API Keys" in right panel
3. Presses Enter
4. Shows API Key Editor Dialog with current values (masked)
5. User updates keys
6. Presses Save
7. Config updates
8. Server restarts with new keys
9. Status updates to healthy/unhealthy based on key validity
```

## Security Considerations

### Current (Plain Text)
- ⚠️ Keys stored in `~/.ollm/settings/mcp.json` as plain text
- ⚠️ Readable by any process with user permissions
- ⚠️ Backed up in plain text
- ✅ Simple, no dependencies
- ✅ Works cross-platform

### With Encryption
- ✅ Keys encrypted at rest
- ✅ Requires decryption key to read
- ⚠️ Decryption key must be stored somewhere
- ⚠️ More complex implementation

### With System Keychain
- ✅ OS-level security
- ✅ Encrypted by OS
- ✅ Requires user authentication (on some systems)
- ⚠️ Platform-specific code
- ⚠️ Additional dependencies

## Recommendation

**Start with Phase 1** (API Key Input Dialog) using plain text storage. This provides immediate value with minimal complexity. Add encryption/keychain in Phase 3 once the basic flow is proven.

## Next Steps

1. Create `APIKeyInputDialog.tsx` component
2. Update marketplace installation flow
3. Add "Edit API Keys" action to server details
4. Test with real MCP servers (brave-search, context7)
5. Gather user feedback
6. Iterate on UX
7. Add encryption in future release

## Related Issues

- Health monitor refresh rate: 30 seconds (configurable)
- Server unhealthy state: Often due to missing/invalid API keys
- OAuth servers: Separate flow, already partially implemented
