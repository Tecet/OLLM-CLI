# MCP Implementation - Required Packages & Imports

**Created:** January 15, 2026  
**Purpose:** Quick reference for MCP-related packages and imports  
**Related:** Gemini MCP Patterns (.dev/reference/gemini-mcp-patterns.md)

---

## Core MCP SDK

### Installation

```bash
npm install @modelcontextprotocol/sdk
```

### Key Imports

```typescript
// Server-side (for building MCP servers)
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';

// Client-side (for connecting to MCP servers)
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';

// Types
import type {
  CallToolRequest,
  CallToolResult,
  ListToolsResult,
  Tool,
  ContentBlock,
  TextContent,
  ImageContent,
  ResourceContent
} from '@modelcontextprotocol/sdk/types.js';
```

---

## Transport Dependencies

### HTTP/SSE Support

```bash
npm install eventsource node-fetch
```

```typescript
import EventSource from 'eventsource';
import fetch from 'node-fetch';
```

### WebSocket Support (Optional)

```bash
npm install ws
```

```typescript
import WebSocket from 'ws';
```

---

## OAuth & Authentication

### Secure Token Storage

```bash
npm install keytar  # Platform-specific keychain integration
```

```typescript
import * as keytar from 'keytar';

// Store token
await keytar.setPassword('ollm-cli', 'mcp-server-name', accessToken);

// Retrieve token
const token = await keytar.getPassword('ollm-cli', 'mcp-server-name');

// Delete token
await keytar.deletePassword('ollm-cli', 'mcp-server-name');
```

### OAuth Flow

```bash
npm install oauth4webapi  # Modern OAuth 2.0 library
```

```typescript
import * as oauth from 'oauth4webapi';

// Authorization URL
const authUrl = new URL(authorizationEndpoint);
authUrl.searchParams.set('client_id', clientId);
authUrl.searchParams.set('redirect_uri', redirectUri);
authUrl.searchParams.set('response_type', 'code');
authUrl.searchParams.set('scope', scopes.join(' '));

// Token exchange
const tokenResponse = await oauth.authorizationCodeGrantRequest(
  authorizationServer,
  client,
  authorizationCode,
  redirectUri
);
```

---

## Schema Validation

### Zod (Recommended)

```bash
npm install zod
```

```typescript
import { z } from 'zod';

// Define schema
const toolArgsSchema = z.object({
  query: z.string().min(1),
  limit: z.number().optional().default(10)
});

// Validate
const args = toolArgsSchema.parse(input);
```

### AJV (Already installed in OLLM CLI)

```typescript
import Ajv from 'ajv';
import addFormats from 'ajv-formats';

const ajv = new Ajv();
addFormats(ajv);

const validate = ajv.compile(schema);
const valid = validate(data);
```

---

## Process Management (Stdio Transport)

### Child Process Utilities

```typescript
import { spawn } from 'child_process';
import { Readable, Writable } from 'stream';

// Spawn MCP server
const serverProcess = spawn(command, args, {
  cwd: workingDirectory,
  env: { ...process.env, ...customEnv },
  stdio: ['pipe', 'pipe', 'pipe']
});

// Create transport
const transport = new StdioClientTransport({
  stdin: serverProcess.stdin as Writable,
  stdout: serverProcess.stdout as Readable,
  stderr: serverProcess.stderr as Readable
});
```

---

## Content Type Handling

### Image Processing

```bash
npm install sharp  # Already in OLLM CLI dependencies
```

```typescript
import sharp from 'sharp';

// Resize and convert image
const buffer = await sharp(imageData)
  .resize(800, 600, { fit: 'inside' })
  .png()
  .toBuffer();

// Convert to base64
const base64 = buffer.toString('base64');
```

### MIME Type Detection

```bash
npm install mime-types
```

```typescript
import mime from 'mime-types';

const mimeType = mime.lookup('image.png'); // 'image/png'
const extension = mime.extension('image/png'); // 'png'
```

---

## Logging & Debugging

### Debug Module

```bash
npm install debug
```

```typescript
import debug from 'debug';

const log = debug('ollm:mcp');
const logError = debug('ollm:mcp:error');

log('Connecting to MCP server: %s', serverName);
logError('Connection failed: %O', error);
```

### Structured Logging (Optional)

```bash
npm install pino
```

```typescript
import pino from 'pino';

const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: { colorize: true }
  }
});

logger.info({ serverName, status }, 'MCP server connected');
```

---

## Testing Utilities

### MCP Server Testing

```typescript
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { InMemoryTransport } from '@modelcontextprotocol/sdk/inMemory.js';

// Create test server
const server = new McpServer({ name: 'test-server', version: '1.0.0' });

// Register test tool
server.registerTool('test-tool', {
  description: 'A test tool',
  inputSchema: {
    type: 'object',
    properties: {
      input: { type: 'string' }
    }
  }
}, async (args) => ({
  content: [{ type: 'text', text: `Received: ${args.input}` }]
}));

// Create in-memory transport for testing
const transport = new InMemoryTransport();
await server.connect(transport);
```

### Mock OAuth Provider

```typescript
import { MockOAuthProvider } from '@ollm/test-utils';

const mockProvider = new MockOAuthProvider({
  accessToken: 'mock-token',
  refreshToken: 'mock-refresh',
  expiresIn: 3600
});
```

---

## Type Definitions

### MCP Protocol Types

```typescript
// Tool definition
interface Tool {
  name: string;
  description: string;
  inputSchema: JSONSchema;
}

// Tool call request
interface CallToolRequest {
  method: 'tools/call';
  params: {
    name: string;
    arguments?: Record<string, unknown>;
  };
}

// Tool call result
interface CallToolResult {
  content: ContentBlock[];
  isError?: boolean;
}

// Content blocks
type ContentBlock = 
  | TextContent 
  | ImageContent 
  | ResourceContent;

interface TextContent {
  type: 'text';
  text: string;
}

interface ImageContent {
  type: 'image';
  data: string;  // base64
  mimeType: string;
}

interface ResourceContent {
  type: 'resource';
  resource: {
    uri: string;
    mimeType?: string;
    text?: string;
  };
}
```

### OAuth Types

```typescript
interface OAuthConfig {
  enabled: boolean;
  authorizationUrl?: string;
  tokenUrl?: string;
  clientId: string;
  clientSecret?: string;
  scopes?: string[];
  redirectPort?: number;
  usePKCE?: boolean;
}

interface OAuthTokens {
  accessToken: string;
  refreshToken?: string;
  expiresAt: number;
  tokenType: string;
  scope?: string;
}
```

---

## Environment Variables

### MCP Configuration

```bash
# MCP server endpoints
export MCP_SERVER_URL="https://api.example.com/mcp"

# OAuth credentials
export OAUTH_CLIENT_ID="your-client-id"
export OAUTH_CLIENT_SECRET="your-client-secret"

# API keys for MCP servers
export GITHUB_TOKEN="ghp_..."
export GOOGLE_API_KEY="AIza..."

# Debug logging
export DEBUG="ollm:mcp*"
export LOG_LEVEL="debug"
```

---

## Package.json Updates

### Add to OLLM CLI Core

```json
{
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.0",
    "eventsource": "^2.0.2",
    "node-fetch": "^3.3.0",
    "oauth4webapi": "^2.0.0",
    "zod": "^3.22.0",
    "mime-types": "^2.1.35"
  },
  "optionalDependencies": {
    "keytar": "^7.9.0"
  },
  "devDependencies": {
    "@types/eventsource": "^1.1.15",
    "@types/node-fetch": "^2.6.11",
    "@types/mime-types": "^2.1.4"
  }
}
```

---

## Import Organization

### Recommended Structure

```typescript
// packages/core/src/mcp/index.ts

// External dependencies
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';
import type { Tool, CallToolResult } from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import * as keytar from 'keytar';

// Internal dependencies
import { MCPConfig, MCPServerConfig } from './config.js';
import { MCPOAuthProvider } from './mcpOAuth.js';
import { MCPHealthMonitor } from './mcpHealthMonitor.js';
import { MCPToolWrapper } from './mcpToolWrapper.js';

// Types
import type { 
  MCPServerStatus, 
  MCPDiscoveryState,
  OAuthTokens 
} from './types.js';

// Re-exports
export { Client, Tool, CallToolResult };
export type { MCPConfig, MCPServerConfig, MCPServerStatus };
```

---

## Migration Path

### Phase 1: Install Core SDK

```bash
cd packages/core
npm install @modelcontextprotocol/sdk eventsource node-fetch
```

### Phase 2: Update Imports

Replace custom MCP client imports:

```typescript
// Before
import { DefaultMCPClient } from './mcpClient.js';

// After
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
```

### Phase 3: Add OAuth Support

```bash
npm install oauth4webapi keytar
```

### Phase 4: Add Schema Validation

```bash
npm install zod
```

---

## Quick Start Example

### Complete MCP Client Setup

```typescript
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { spawn } from 'child_process';

// Spawn MCP server
const serverProcess = spawn('node', ['mcp-server.js'], {
  stdio: ['pipe', 'pipe', 'pipe']
});

// Create transport
const transport = new StdioClientTransport({
  stdin: serverProcess.stdin,
  stdout: serverProcess.stdout,
  stderr: serverProcess.stderr
});

// Create client
const client = new Client({
  name: 'ollm-cli',
  version: '0.1.0'
});

// Connect
await client.connect(transport);

// List tools
const { tools } = await client.listTools();
console.log('Available tools:', tools);

// Call tool
const result = await client.callTool({
  name: 'search',
  arguments: { query: 'hello world' }
});
console.log('Result:', result);

// Cleanup
await client.close();
serverProcess.kill();
```

---

## References

- **MCP SDK**: github.com/modelcontextprotocol/sdk (https://github.com/modelcontextprotocol/sdk)
- **MCP Specification**: spec.modelcontextprotocol.io (https://spec.modelcontextprotocol.io/)
- **OAuth 4 WebAPI**: github.com/panva/oauth4webapi (https://github.com/panva/oauth4webapi)
- **Keytar**: github.com/atom/node-keytar (https://github.com/atom/node-keytar)
- **Zod**: zod.dev (https://zod.dev/)

---

**Document Status:** ✅ Complete  
**Last Updated:** January 15, 2026  
**Next Steps:** Install packages and begin Week 3 implementation
