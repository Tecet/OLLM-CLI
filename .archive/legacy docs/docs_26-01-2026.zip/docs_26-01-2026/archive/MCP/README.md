# MCP (Model Context Protocol) System - Development Documentation

**Last Updated:** January 17, 2026  
**Status:** ✅ Core Implementation Complete, Documentation Complete

This directory contains development documentation, tracking files, and reference materials for the MCP (Model Context Protocol) integration in OLLM CLI.

---

## 📁 Directory Structure

```
.dev/MCP/
├── README.md                              # This file - navigation guide
├── MCP_docs.md                            # Main documentation index
├── MCP_roadmap.md                         # Feature roadmap and enhancements
│
├── debugging/                             # Bug tracking and fixes
│   ├── critical-bugs-fixed.md            # Fixed critical bugs
│   ├── critical-bugs-summary.md          # Bug summary
│   └── mcp-health-integration.md         # Health monitoring integration
│
├── development/                           # Development tracking
│   ├── documentation-tracking.md         # Documentation creation progress
│   ├── extension-ecosystem.md            # Extension system design
│   ├── hook-planning-integration.md      # Hook system integration
│   ├── implementation-progress.md        # Implementation status
│   ├── messageBus-integration.md         # MessageBus integration
│   ├── oauth-integration.md              # OAuth implementation
│   └── upgrade-plan.md                   # System upgrade planning
│
└── reference/                             # Reference materials
    ├── cli-commands.md                   # CLI command reference
    ├── gemini-mcp-patterns.md            # Gemini MCP patterns
    ├── gemini-patterns.md                # Gemini integration patterns
    ├── mcp-packages-guide.md             # MCP package guide
    └── mcp-packages.md                   # Available MCP packages


## 📚 User Documentation (docs/MCP/)

The main user-facing documentation is located in `docs/MCP/`:

### Core Documentation

| File | Description |
|------|-------------|
| **[README.md](../../docs/MCP/README.md)** | Main entry point for users |
| **[getting-started.md](../../docs/MCP/getting-started.md)** | Quick start guide |
| **[MCP_index.md](../../docs/MCP/MCP_index.md)** | Complete documentation index |
| **[MCP_architecture.md](../../docs/MCP/MCP_architecture.md)** | System architecture overview |
| **[MCP_commands.md](../../docs/MCP/MCP_commands.md)** | CLI commands reference |
| **[MCP_integration.md](../../docs/MCP/MCP_integration.md)** | Integration guide |

### API Documentation (docs/MCP/api/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/MCP/api/README.md)** | API overview |
| **[mcp-client.md](../../docs/MCP/api/mcp-client.md)** | MCPClient API reference |
| **[extension-manager.md](../../docs/MCP/api/extension-manager.md)** | ExtensionManager API reference |
| **[hook-system.md](../../docs/MCP/api/hook-system.md)** | Hook system API reference |

### Extensions Documentation (docs/MCP/extensions/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/MCP/extensions/README.md)** | Extensions overview |
| **[user-guide.md](../../docs/MCP/extensions/user-guide.md)** | User guide for extensions |
| **[development-guide.md](../../docs/MCP/extensions/development-guide.md)** | Creating extensions |
| **[manifest-reference.md](../../docs/MCP/extensions/manifest-reference.md)** | Manifest file reference |
| **[marketplace.md](../../docs/MCP/extensions/marketplace.md)** | Extension marketplace |

### Hooks Documentation (docs/MCP/hooks/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/MCP/hooks/README.md)** | Hooks overview |
| **[user-guide.md](../../docs/MCP/hooks/user-guide.md)** | User guide for hooks |
| **[development-guide.md](../../docs/MCP/hooks/development-guide.md)** | Creating hooks |
| **[protocol.md](../../docs/MCP/hooks/protocol.md)** | Hook protocol specification |

### MCP Servers Documentation (docs/MCP/servers/)

| File | Description |
|------|-------------|
| **[README.md](../../docs/MCP/servers/README.md)** | MCP servers overview |
| **[development-guide.md](../../docs/MCP/servers/development-guide.md)** | Creating MCP servers |
| **[health-monitoring.md](../../docs/MCP/servers/health-monitoring.md)** | Health monitoring guide |
| **[oauth-setup.md](../../docs/MCP/servers/oauth-setup.md)** | OAuth configuration |

---

## 🎯 What is MCP?

**Model Context Protocol (MCP)** is an open protocol that standardizes how applications provide context to LLMs. OLLM CLI implements MCP to enable:

### Core Capabilities

1. **MCP Servers**
   - External tools and services (web search, databases, APIs)
   - Automatic tool registration and schema conversion
   - Health monitoring and auto-restart
   - OAuth authentication support

2. **Extensions**
   - Package MCP servers, hooks, skills, and settings
   - Manifest-based configuration
   - Enable/disable/reload functionality
   - Marketplace support (planned)

3. **Hooks**
   - Event-driven automation
   - Safety gates and validation
   - Custom workflows
   - Trusted hook system

4. **Skills**
   - Reusable prompt templates
   - Task-specific instructions
   - Context injection

---

## 🔧 Implementation Files

The MCP system is implemented across multiple packages:

### Core MCP Implementation (packages/core/src/mcp/)

| File | Purpose |
|------|---------|
| `mcpClient.ts` | MCP client for server communication |
| `mcpTransport.ts` | Transport layer (stdio, HTTP) |
| `mcpSchemaConverter.ts` | Convert MCP schemas to internal format |
| `mcpToolWrapper.ts` | Wrap MCP tools as internal tools |
| `mcpHealthMonitor.ts` | Health monitoring and auto-restart |
| `mcpOAuth.ts` | OAuth authentication flow |
| `types.ts` | TypeScript type definitions |

### Extensions System (packages/core/src/extensions/)

| File | Purpose |
|------|---------|
| `extensionManager.ts` | Extension lifecycle management |
| `extensionRegistry.ts` | Extension registration and discovery |
| `manifestParser.ts` | Parse extension manifests |
| `settingsIntegration.ts` | Extension settings management |
| `skillRegistry.ts` | Skill registration and loading |

### Hooks System (packages/core/src/hooks/)

| File | Purpose |
|------|---------|
| `hookRegistry.ts` | Hook registration and discovery |
| `hookRunner.ts` | Hook execution engine |
| `hookPlanner.ts` | Hook planning and scheduling |
| `trustedHooks.ts` | Trusted hook management |
| `messageBus.ts` | Event bus for hook communication |

### CLI Integration (packages/cli/src/commands/)

| File | Purpose |
|------|---------|
| `mcpCommands.ts` | MCP server commands |
| `mcpHealthCommands.ts` | Health monitoring commands |
| `mcpOAuthCommands.ts` | OAuth authentication commands |
| `extensionCommands.ts` | Extension management commands |
| `hookCommands.ts` | Hook management commands |

---

## 📊 Key Concepts

### MCP Servers

External processes that provide tools to LLMs:

**Official MCP Servers:**
- `@modelcontextprotocol/server-brave-search` - Web search
- `@modelcontextprotocol/server-puppeteer` - Web scraping
- `@modelcontextprotocol/server-github` - GitHub API
- `@modelcontextprotocol/server-postgres` - PostgreSQL
- `@modelcontextprotocol/server-gdrive` - Google Drive
- `@modelcontextprotocol/server-slack` - Slack integration

**Configuration:**
```yaml
mcp:
  servers:
    brave-search:
      command: "npx"
      args: ["-y", "@modelcontextprotocol/server-brave-search"]
      env:
        BRAVE_API_KEY: "${BRAVE_API_KEY}"
```

### Extensions

Packages that bundle MCP servers, hooks, skills, and settings:

**Manifest Structure:**
```json
{
  "name": "my-extension",
  "version": "1.0.0",
  "description": "My custom extension",
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["server.js"]
    }
  },
  "hooks": [...],
  "skills": [...],
  "settings": [...]
}
```

### Hooks

Event-driven automation:

**Hook Types:**
- `fileEdited` - When a file is saved
- `fileCreated` - When a file is created
- `fileDeleted` - When a file is deleted
- `promptSubmit` - When a message is sent
- `agentStop` - When agent execution completes
- `userTriggered` - Manual trigger

**Hook Actions:**
- `askAgent` - Send message to agent
- `runCommand` - Execute shell command

### Skills

Reusable prompt templates:

```markdown
---
name: code-review
description: Review code for best practices
---

Review the following code for:
- Code quality
- Best practices
- Potential bugs
- Performance issues

{code}
```

---

## 🐛 Known Issues & Fixes

### Fixed Issues

1. **MCPHealthMonitor Auto-Restart Timing** (Fixed 2026-01-17)
   - Issue: Auto-restart tests timed out due to immediate restarts
   - Fix: Start backoff on first failure instead of immediate restart
   - Details: [critical-bugs-fixed.md](debugging/critical-bugs-fixed.md)

2. **MessageBus emitSync Behavior** (Fixed 2026-01-16)
   - Issue: `emitSync` triggered listeners immediately
   - Fix: Defer emission to microtask
   - Details: [critical-bugs-fixed.md](debugging/critical-bugs-fixed.md)

### Current Limitations

From audit findings (see `../.dev/audit/AUDIT-FINDINGS-EXPLAINED.md`):

1. **Extension Archive Extraction**
   - Not implemented (throws error)
   - Can only install from directories
   - Status: Low priority enhancement

2. **OAuth Token Refresh**
   - Not implemented
   - Tokens expire without refresh
   - Status: Low priority enhancement

3. **MCP Auth Commands**
   - `/mcp auth status`, `/mcp auth revoke`, `/mcp auth refresh` are stubs
   - Return "not yet implemented"
   - Status: Low priority enhancement

---

## 🚀 Usage Examples

### MCP Server Management

```bash
# List MCP servers
/mcp list

# Start a server
/mcp start brave-search

# Stop a server
/mcp stop brave-search

# Check server health
/mcp health check brave-search

# View server logs
/mcp logs brave-search
```

### Extension Management

```bash
# Search extensions
/extensions search github

# Install extension
/extensions install my-extension

# List installed extensions
/extensions list

# Enable/disable extension
/extensions enable my-extension
/extensions disable my-extension

# View extension info
/extensions info my-extension

# Reload extension
/extensions reload my-extension
```

### Hook Management

```bash
# List hooks
/hooks list

# Enable/disable hook
/hooks enable my-hook
/hooks disable my-hook

# Trigger hook manually
/hooks trigger my-hook
```

---

## 📈 Development Status

### ✅ Completed

- MCP client implementation
- MCP server management (start/stop/restart)
- Health monitoring with auto-restart
- Extension system (load/enable/disable)
- Hook system (register/execute)
- Skill system (load/use)
- CLI commands (MCP, extensions, hooks)
- OAuth scaffolding
- Comprehensive documentation (4,500+ lines)

### 🔧 In Progress

- OAuth token refresh implementation
- Extension marketplace integration
- Archive extraction support

### 📋 Planned (See MCP_roadmap.md)

- Enhanced hook debugging
- Extension hot-reload
- More hook event types
- Extension dependency management
- Extension versioning and updates

---

## 🔗 Related Documentation

### Development Documentation

- **[MCP Roadmap](MCP_roadmap.md)** - Future enhancements
- **[Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md)** - Issues found in audit
- **[Fix Plan](../audit/fix_plan.md)** - Prioritized fix tasks
- **[Bug Tracker](../bugtracker.md)** - Current bugs and fixes

### Specifications

- **Stage 05 Spec:** `.kiro/specs/stage-05-hooks-extensions-mcp/`
  - `requirements.md` - Feature requirements
  - `design.md` - System design
  - `tasks.md` - Implementation tasks

### Implementation Logs

- **[Stage 05 Log](../logs/stages/stage-05-hooks-extensions-mcp.md)** - Implementation history

### Reference Materials

- **[CLI Commands](reference/cli-commands.md)** - Command reference
- **[MCP Packages](reference/mcp-packages.md)** - Available packages
- **[Gemini Patterns](reference/gemini-patterns.md)** - Integration patterns

---

## 🤝 Contributing

When working on MCP system:

1. **Read the architecture docs** - Understand the system design
2. **Check audit findings** - Know current limitations
3. **Run tests** - Ensure changes don't break existing functionality
4. **Update docs** - Keep documentation in sync with code
5. **Test with real MCP servers** - Verify integration works

### Testing

```bash
# Run MCP tests
npm test packages/core/src/mcp

# Run extension tests
npm test packages/core/src/extensions

# Run hook tests
npm test packages/core/src/hooks

# Run specific test file
npx vitest run packages/core/src/mcp/__tests__/mcpClient.test.ts

# Run with coverage
npm test -- --coverage packages/core/src/mcp
```

---

## 📞 Support

For questions or issues:

1. Check the [User Guide](../../docs/MCP/getting-started.md)
2. Review [Troubleshooting](../../docs/troubleshooting.md)
3. Check [Bug Tracker](../bugtracker.md) for known issues
4. See [Audit Findings](../audit/AUDIT-FINDINGS-EXPLAINED.md) for limitations
5. Review [MCP Roadmap](MCP_roadmap.md) for planned features

---

## 📝 Quick Reference

### Key Files to Know

| Purpose | File |
|---------|------|
| **User docs entry** | `docs/MCP/README.md` |
| **Architecture** | `docs/MCP/MCP_architecture.md` |
| **Commands** | `docs/MCP/MCP_commands.md` |
| **Integration** | `docs/MCP/MCP_integration.md` |
| **MCP client** | `packages/core/src/mcp/mcpClient.ts` |
| **Extension manager** | `packages/core/src/extensions/extensionManager.ts` |
| **Hook system** | `packages/core/src/hooks/hookRegistry.ts` |
| **Tests** | `packages/core/src/mcp/__tests__/` |
| **Roadmap** | `.dev/MCP/MCP_roadmap.md` |

### Common Tasks

| Task | Command/File |
|------|--------------|
| List MCP servers | `/mcp list` |
| Start server | `/mcp start <server>` |
| Check health | `/mcp health check <server>` |
| Install extension | `/extensions install <name>` |
| List hooks | `/hooks list` |
| Run tests | `npm test packages/core/src/mcp` |
| Read architecture | `docs/MCP/MCP_architecture.md` |
| Check roadmap | `.dev/MCP/MCP_roadmap.md` |

### Available MCP Servers

See [docs/MCP/servers/README.md](../../docs/MCP/servers/README.md) for a complete list of official MCP servers and how to configure them.

**Popular servers:**
- Brave Search - Web search with API
- Puppeteer - Web scraping and automation
- GitHub - GitHub API integration
- PostgreSQL - Database access
- Google Drive - File storage
- Slack - Team communication

---

**Last Updated:** January 17, 2026  
**Documentation Status:** Complete  
**Implementation Status:** Core complete, enhancements in roadmap
