**MCP Config Audit**

Summary
- **What:** Audit of MCP configuration handling and storage used by the CLI.
- **Why:** Remove legacy/local registry entries safely and understand runtime effects (e.g., `context7`).

Locations
- **User config:** ~/.ollm/settings/mcp.json (user home directory)
- **Workspace config:** .ollm/settings/mcp.json (current working directory)

How config is read
- **Entry point:** `mcpConfigService.loadMCPConfig()` merges two files.
- **Precedence:** Workspace config overrides user config when merging.
- **Return shape:** { mcpServers: Record<string, MCPServerConfig> }
- **Recovery:** If JSON parsing fails, the service attempts recovery via `mcpConfigBackup.recoverFromCorruption()`.

How config is written
- **Writes:** `mcpConfigService.saveMCPConfig()` writes to the **user** config path only.
- **Updates:** `updateServerConfig(serverName, config)` loads user config, mutates the single server entry, validates, then atomically writes back.
- **Atomic write:** Writes to `mcp.json.tmp` then renames to `mcp.json` (temp cleanup on failure).
- **Backups:** Before save/update, `mcpConfigBackup.createBackup()` is invoked when `mcp.json` exists.

File watching and notifications
- **Start/stop:** `startWatching()` / `stopWatching()` watch both user and workspace locations.
- **Behavior:** If file missing, watches the parent directory to detect creation, otherwise watches file and debounces 'change' events before notifying listeners.
- **Listeners:** External code can `addChangeListener()` and will receive `{ type: 'user'|'workspace', path, timestamp }` events.

Validation
- **validateConfig()** enforces required fields per-server (e.g., `command` string, `args` array, valid `transport`, positive `timeout`, `env` object).

Runtime integration notes
- `MCPMarketplace.installServer()` calls `mcpConfigService.updateServerConfig()` to persist installed servers into the user `mcp.json`.
- UI code (MCP context) calls `mcpConfigService.loadMCPConfig()` on init and uses `startWatching()` to react to external edits.

Implications for removing local registry entries (e.g., `io.github.upstash/context7`)
- The marketplace has a local fallback registry used when remote fetch fails and to ensure canonical IDs (see `getLocalRegistry()` in `mcpMarketplace`).
- Removing `context7` from the local registry will not change persisted `mcp.json` entries already written by installs, but may affect tests and UI code that expect the fallback to include that ID when the registry is unavailable.

Recommendations / Next steps
- Run the CLI integration tests that cover `MCPConfigService` and `MCPMarketplace` after any registry change (tests exist and cover file save/recovery/watching).
- If removing `context7` from `getLocalRegistry()`: update related tests and any `.kiro/settings/mcp.json` fixtures that include it.
- Consider adding a migration or cleanup step that removes legacy local-registry-only server entries from user `mcp.json` if desired.
- For prompt-driven metadata: keep UI display decoupled from `mcp.json` server authoring; populate runtime view from marketplace/registry metadata instead of local-registry defaults.

Files inspected (primary)
- packages/cli/src/services/mcpConfigService.ts
- packages/cli/src/services/mcpMarketplace.ts (dist copy inspected)
- packages/cli/src/ui/contexts/MCPContext.tsx (uses load/startWatching)

Prepared by: CLI audit (saved on DATE)
