# RAG (Retrieval-Augmented Generation) Development Roadmap

**Feature:** RAG Integration with Codebase Indexing and Mode-Specific Knowledge Bases  
**Status:** 🚀 FUTURE - Not Started  
**Priority:** Enhancement (Post-MVP)  
**Estimated Effort:** 12-15 hours  
**Stage:** To be determined (separate from Stage 04c)

---

## Executive Summary

RAG (Retrieval-Augmented Generation) integration will provide the Dynamic Prompt System with semantic search capabilities over the codebase and mode-specific knowledge bases. This enables specialized modes (debugger, security, performance, planning) to automatically access relevant context from indexed code and accumulated knowledge.

**Key Benefits:**
- Automatic context retrieval for specialized modes
- Semantic code search across workspace
- Knowledge accumulation from mode findings
- Offline operation with local embeddings
- Incremental indexing with file watching

---

## Overview

The RAG system integrates with the Dynamic Prompt System to provide mode-specific context from codebase indexing and knowledge bases. This enables specialized modes to access relevant information automatically.

### Core Capabilities

1. **Codebase Indexing** - Semantic search across workspace files
2. **Mode-Specific Knowledge** - Accumulated findings from specialized modes
3. **Local Embeddings** - Offline operation using local models
4. **Incremental Updates** - File watching and automatic re-indexing
5. **Context Injection** - Automatic RAG context on mode entry

---

## Architecture

### System Components

```typescript
interface RAGSystem {
  // Core indexing
  codebaseIndex: CodebaseIndex;
  embeddingService: EmbeddingService;
  vectorStore: LanceDBVectorStore;
  
  // Mode-specific knowledge bases
  modeKnowledge: {
    debugger: LanceDBIndex;     // Common bugs, solutions
    security: LanceDBIndex;     // Vulnerabilities, fixes
    performance: LanceDBIndex;  // Optimization patterns
    planning: LanceDBIndex;     // Design patterns
  };
}
```

### Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                       RAG System                             │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Codebase   │    │  Embedding   │    │   LanceDB    │  │
│  │    Index     │───▶│   Service    │───▶│ Vector Store │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│         │                                         │          │
│         │                                         │          │
│         ▼                                         ▼          │
│  ┌──────────────────────────────────────────────────────┐  │
│  │          Mode-Specific Knowledge Bases               │  │
│  ├──────────────────────────────────────────────────────┤  │
│  │  Debugger  │  Security  │  Performance  │  Planning  │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## Detailed Component Specifications

### 1. Codebase Index

Indexes workspace files for semantic search.

```typescript
interface CodebaseIndex {
  // Lifecycle
  initialize(rootPath: string, options: IndexOptions): Promise<void>;
  shutdown(): Promise<void>;
  
  // Indexing operations
  indexWorkspace(): Promise<IndexStats>;
  updateFile(filePath: string): Promise<void>;
  removeFile(filePath: string): Promise<void>;
  
  // Search operations
  search(query: string, options?: SearchOptions): Promise<SearchResult[]>;
  
  // Status
  getStats(): IndexStats;
  clear(): Promise<void>;
}

interface IndexOptions {
  extensions: string[];           // ['.ts', '.js', '.py']
  excludePatterns: string[];      // ['node_modules', 'dist']
  maxFileSize: number;            // Skip larger files
  chunkSize: number;              // Tokens per chunk
  chunkOverlap: number;           // Overlap between chunks
  autoIndex: boolean;             // Index on startup
}

interface SearchResult {
  filePath: string;
  content: string;
  score: number;                  // Similarity score (0-1)
  startLine: number;
  endLine: number;
  metadata: {
    language: string;
    lastModified: Date;
  };
}
```

**Features:**
- Workspace indexing with file watching (chokidar)
- File chunking (512 tokens, 50 token overlap)
- Incremental updates on file changes
- Semantic search with topK and threshold parameters
- Respect .gitignore and exclude patterns
- Skip large files (configurable threshold, default 1MB)
- Index statistics and monitoring

---

### 2. Embedding Service

Provides local embeddings for offline operation.

```typescript
interface EmbeddingService {
  embed(text: string): Promise<number[]>;
  embedBatch(texts: string[]): Promise<number[][]>;
  cosineSimilarity(a: number[], b: number[]): number;
  getDimensions(): number;
  getModel(): string;
}

// Local implementation using @xenova/transformers
class LocalEmbeddingService implements EmbeddingService {
  private model = 'Xenova/all-MiniLM-L6-v2';  // 384-dim
  
  async embed(text: string): Promise<number[]> {
    const output = await this.pipeline(text, {
      pooling: 'mean',
      normalize: true,
    });
    return Array.from(output.data);
  }
  
  getDimensions(): number {
    return 384;
  }
}
```

**Features:**
- Local embeddings using `@xenova/transformers`
- Model: Xenova/all-MiniLM-L6-v2 (384 dimensions)
- Single text embedding with error handling
- Batch embedding for efficient processing
- Cosine similarity calculation for search
- Embedding caching for performance (LRU cache)

---

### 3. LanceDB Vector Store

LanceDB is chosen for its embedded nature, TypeScript support, and local-first design.

```typescript
interface LanceDBVectorStore {
  // Storage operations
  upsert(id: string, vector: number[], metadata: VectorMetadata): Promise<void>;
  upsertBatch(items: VectorItem[]): Promise<void>;
  
  // Search operations
  searchByVector(vector: number[], topK: number, threshold?: number): Promise<VectorResult[]>;
  
  // Management
  delete(id: string): Promise<void>;
  clear(): Promise<void>;
  count(): Promise<number>;
}

interface VectorMetadata {
  filePath: string;
  startLine: number;
  endLine: number;
  language: string;
  lastModified: number;
}
```

**Features:**
- Upsert operations (single and batch)
- Vector search with similarity scoring
- Delete operations for cleanup
- Clear and count operations
- Vector metadata storage (file path, line numbers, language)

---

## Storage Structure

```
~/.ollm/rag/
├── codebase.lance/          # Codebase index
├── knowledge/
│   ├── debugger.lance/      # Debugger knowledge
│   ├── security.lance/      # Security knowledge
│   ├── performance.lance/   # Performance knowledge
│   └── planning.lance/      # Planning knowledge
```

---

## Integration with Mode System

### On Mode Entry

Automatically retrieve relevant context when entering a specialized mode.

```typescript
async onModeEnter(mode: ModeType, context: string): Promise<void> {
  if (this.ragSystem) {
    // Search codebase for relevant context
    const codebaseResults = await this.ragSystem.codebaseIndex.search(
      context,
      { topK: 5, threshold: 0.7 }
    );
    
    // Search mode-specific knowledge
    const knowledgeResults = await this.ragSystem.modeKnowledge[mode]?.search(
      context,
      { topK: 3, threshold: 0.75 }
    );
    
    // Inject RAG context into system prompt
    const ragContext = this.formatRAGContext(codebaseResults, knowledgeResults);
    this.modeManager.addContextToPrompt(ragContext);
  }
}
```

### On Mode Exit

Store findings from specialized modes into knowledge bases.

```typescript
async onModeExit(mode: ModeType, findings: any): Promise<void> {
  if (this.ragSystem && this.isSpecializedMode(mode)) {
    const knowledge = this.convertFindingsToDocuments(mode, findings);
    await this.ragSystem.modeKnowledge[mode].upsertBatch(knowledge);
  }
}
```

### Mode-Specific RAG Integration

```typescript
interface ModeRAGIntegration {
  // Context retrieval for each specialized mode
  retrieveDebuggerContext(query: string): Promise<SearchResult[]>;
  retrieveSecurityContext(query: string): Promise<SearchResult[]>;
  retrievePerformanceContext(query: string): Promise<SearchResult[]>;
  retrievePlanningContext(query: string): Promise<SearchResult[]>;
  
  // Knowledge indexing on mode exit
  indexFindings(mode: ModeType, findings: any): Promise<void>;
  
  // RAG context formatting for prompts
  formatRAGContext(codebaseResults: SearchResult[], knowledgeResults: SearchResult[]): string;
  
  // Add RAG context injection to PromptModeManager.buildPrompt()
  injectRAGContext(prompt: string, ragContext: string): string;
}
```

---

## Automatic Indexing

- **Startup Indexing** - Index workspace on startup (if enabled)
- **File Watching** - Watch for file changes and update incrementally
- **Gitignore Respect** - Respect .gitignore and exclude patterns
- **Large File Handling** - Skip large files (configurable threshold)
- **Incremental Updates** - Only re-index changed files

---

## Configuration

```yaml
rag:
  enabled: true
  codebase:
    autoIndex: true
    extensions: ['.ts', '.js', '.py', '.md']
    excludePatterns: ['node_modules', 'dist', '.git']
    maxFileSize: 1048576  # 1MB
    chunkSize: 512        # tokens
    chunkOverlap: 50      # tokens
  embedding:
    provider: 'local'     # local | ollama
    model: 'all-MiniLM-L6-v2'
  search:
    topK: 5
    threshold: 0.7
```

---

## Implementation Tasks

### Phase 1: LanceDB Infrastructure (3-4 hours)

- [ ] **Task 1: Setup Dependencies**
  - [ ] 1.1 Add `vectordb` or `lancedb` dependency to package.json
  - [ ] 1.2 Add `@xenova/transformers` dependency for local embeddings
  - [ ] 1.3 Create `packages/core/src/rag/` directory
  - [ ] 1.4 Create `RAGSystem.ts` interface defining the RAG architecture

- [ ] **Task 2: LanceDB Setup**
  - [ ] 2.1 Create `LanceDBSetup.ts` class for database initialization
  - [ ] 2.2 Implement database initialization with proper error handling
  - [ ] 2.3 Create table schema for codebase index (file paths, chunks, embeddings)
  - [ ] 2.4 Create tables for mode-specific knowledge (debugger, security, performance, planning)
  - [ ] 2.5 Write unit tests for LanceDB setup and initialization

### Phase 2: Embedding Service (2-3 hours)

- [ ] **Task 3: Implement Embedding Service**
  - [ ] 3.1 Create `EmbeddingService.ts` interface
  - [ ] 3.2 Implement `LocalEmbeddingService` using @xenova/transformers
  - [ ] 3.3 Initialize embedding model (Xenova/all-MiniLM-L6-v2, 384-dim)
  - [ ] 3.4 Implement single text embedding with proper error handling
  - [ ] 3.5 Implement batch embedding for efficient processing
  - [ ] 3.6 Implement cosine similarity calculation for search
  - [ ] 3.7 Add embedding caching for performance (LRU cache)
  - [ ] 3.8 Write unit tests for embedding service

### Phase 3: Codebase Index (3-4 hours)

- [ ] **Task 4: Implement Codebase Index**
  - [ ] 4.1 Create `CodebaseIndex.ts` class
  - [ ] 4.2 Implement workspace indexing with file watching (chokidar)
  - [ ] 4.3 Implement file chunking (512 tokens, 50 token overlap)
  - [ ] 4.4 Implement incremental updates on file changes
  - [ ] 4.5 Implement semantic search with topK and threshold parameters
  - [ ] 4.6 Respect .gitignore and exclude patterns (node_modules, dist, etc.)
  - [ ] 4.7 Skip large files (configurable threshold, default 1MB)
  - [ ] 4.8 Implement index statistics and monitoring (file count, chunk count, etc.)
  - [ ] 4.9 Write unit tests for codebase index

### Phase 4: LanceDB Vector Store (2-3 hours)

- [ ] **Task 5: Implement Vector Store**
  - [ ] 5.1 Create `LanceDBVectorStore.ts` class
  - [ ] 5.2 Implement upsert operations (single and batch)
  - [ ] 5.3 Implement vector search with similarity scoring
  - [ ] 5.4 Implement delete operations for cleanup
  - [ ] 5.5 Implement clear and count operations
  - [ ] 5.6 Add vector metadata storage (file path, line numbers, language)
  - [ ] 5.7 Write unit tests for vector store operations

### Phase 5: Mode-Specific RAG Integration (2-3 hours)

- [ ] **Task 6: Implement Mode RAG Integration**
  - [ ] 6.1 Create `ModeRAGIntegration.ts` class
  - [ ] 6.2 Implement context retrieval for debugger mode (error patterns, solutions)
  - [ ] 6.3 Implement context retrieval for security mode (vulnerabilities, fixes)
  - [ ] 6.4 Implement context retrieval for performance mode (optimization patterns)
  - [ ] 6.5 Implement context retrieval for planning mode (design patterns, architectures)
  - [ ] 6.6 Implement knowledge indexing on mode exit (store findings)
  - [ ] 6.7 Implement RAG context formatter for prompts
  - [ ] 6.8 Add RAG context injection to PromptModeManager.buildPrompt()
  - [ ] 6.9 Write unit tests for mode RAG integration

### Phase 6: Storage and Configuration (1-2 hours)

- [ ] **Task 7: RAG Storage and Configuration**
  - [ ] 7.1 Create storage directory structure (~/.ollm/rag/)
  - [ ] 7.2 Implement index persistence to disk
  - [ ] 7.3 Implement index cleanup/pruning (remove old entries)
  - [ ] 7.4 Add RAG configuration to settings schema (enabled, topK, threshold)
  - [ ] 7.5 Implement RAG enable/disable toggle in settings
  - [ ] 7.6 Add RAG statistics to `/mode status` command output
  - [ ] 7.7 Write unit tests for storage and configuration

---

## Success Criteria

### Functional Requirements

- [ ] Codebase is automatically indexed on startup
- [ ] File changes trigger incremental re-indexing
- [ ] Semantic search returns relevant code snippets
- [ ] Mode entry retrieves relevant RAG context
- [ ] Mode exit stores findings in knowledge base
- [ ] RAG context is injected into system prompts
- [ ] Configuration allows enabling/disabling RAG
- [ ] Statistics show index size and search performance

### Performance Requirements

- [ ] Indexing completes within 30 seconds for typical workspace (< 1000 files)
- [ ] Search returns results within 500ms
- [ ] Incremental updates complete within 1 second
- [ ] Memory usage stays under 500MB for index
- [ ] Embedding generation completes within 100ms per text

### Quality Requirements

- [ ] All unit tests pass
- [ ] Integration tests verify end-to-end RAG flow
- [ ] Documentation covers configuration and usage
- [ ] Error handling prevents crashes on invalid input
- [ ] Logging provides visibility into RAG operations

---

## Testing Strategy

### Unit Tests

- Embedding service (single, batch, similarity)
- Vector store operations (upsert, search, delete)
- Codebase index (chunking, search, updates)
- Mode RAG integration (context retrieval, formatting)

### Integration Tests

- End-to-end indexing and search
- Mode entry/exit with RAG context
- File watching and incremental updates
- Knowledge base accumulation

### Manual Testing

1. Start app with RAG enabled
2. Verify workspace is indexed
3. Enter debugger mode with error
4. Verify RAG context is retrieved
5. Exit debugger mode
6. Verify findings are stored
7. Re-enter debugger mode
8. Verify previous findings are available

---

## Dependencies

### Required Packages

- `lancedb` or `vectordb` - Vector database
- `@xenova/transformers` - Local embeddings
- `chokidar` - File watching
- `ajv` - JSON schema validation (for structured output)

### Existing Systems

- Dynamic Prompt System (Mode Manager)
- Context Manager
- Settings Service
- File System utilities

---

## Future Enhancements

### Phase 2 Enhancements

- **Multi-workspace support** - Index multiple projects
- **Cloud sync** - Sync knowledge bases across devices
- **Custom embeddings** - Support for different embedding models
- **Advanced search** - Hybrid search (semantic + keyword)
- **Knowledge graphs** - Relationship extraction between code entities

### Phase 3 Enhancements

- **Collaborative knowledge** - Share knowledge bases with team
- **Version control integration** - Track knowledge with git history
- **Smart suggestions** - Proactive context suggestions
- **Performance optimization** - GPU acceleration for embeddings
- **Advanced analytics** - Usage patterns and effectiveness metrics

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Large workspace indexing slow | Medium | Medium | Incremental indexing, background processing |
| Embedding model download fails | Low | High | Bundle model with app, fallback to simpler model |
| Vector search accuracy poor | Medium | Medium | Tune threshold, use hybrid search |
| Memory usage too high | Low | Medium | Implement pruning, limit cache size |
| File watching performance impact | Low | Low | Debounce updates, batch processing |

---

## Timeline Estimate

| Phase | Tasks | Estimated Time |
|-------|-------|----------------|
| Phase 1: LanceDB Infrastructure | 1-2 | 3-4 hours |
| Phase 2: Embedding Service | 3 | 2-3 hours |
| Phase 3: Codebase Index | 4 | 3-4 hours |
| Phase 4: Vector Store | 5 | 2-3 hours |
| Phase 5: Mode RAG Integration | 6 | 2-3 hours |
| Phase 6: Storage and Configuration | 7 | 1-2 hours |
| **Total** | **7 tasks** | **13-19 hours** |

**Recommended Approach:** Implement in phases, test each phase thoroughly before proceeding.

---

## Related Documentation

- Dynamic Prompt System Design (stage-04c)
- Mode System Architecture
- Context Management
- Structured Output Integration

---

## Notes

- RAG is a major enhancement that adds semantic search capabilities
- The mode system is fully functional without RAG
- RAG should be implemented as a separate stage after core mode system is stable
- Consider starting with a minimal viable RAG (codebase index only) before adding mode-specific knowledge bases

---

**Status:** 🚀 FUTURE - Not Started  
**Priority:** Enhancement (Post-MVP)  
**Blockers:** None (can start after mode system is complete)  
**Next Step:** Create new stage specification for RAG implementation

---

## Cross-Reference: Intelligence Layer

This RAG roadmap covers the **Codebase Indexing and Semantic Search** features from the Intelligence Layer (stage-10c-intelligence-layer-future-dev), including:

- ✅ Embedding Service (local embeddings with @xenova/transformers)
- ✅ Vector Store (LanceDB for persistence)
- ✅ File Watcher for incremental updates
- ✅ Semantic search with similarity ranking
- ✅ Automatic workspace indexing
- ✅ .gitignore pattern respect
- ✅ Configurable file extensions and exclusions

Other Intelligence Layer features are documented separately:
- **Structured Output**: See `structured-output-roadmap.md`
- **Code Execution Sandbox**: See `code-execution-roadmap.md`
- **Vision Support**: See File Explorer roadmap (upload integration) + `vision-support-roadmap.md`
- **Productivity Tools**: See `productivity-tools-roadmap.md`
