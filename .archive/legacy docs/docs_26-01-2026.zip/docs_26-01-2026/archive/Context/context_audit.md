# Context System Audit - Implementation vs Design

**Date:** January 21, 2026  
**Purpose:** Verify actual implementation matches designed architecture  
**Status:** In Progress

---

## AUDIT FINDINGS SUMMARY

### ✅ What's Working

1. **85% Context Cap Strategy** - Core implementation is correct
   - User selects size (4K) → UI shows 4096
   - App sends 85% to Ollama (3482) via `num_ctx`
   - Ollama stops at 85% with `done_reason: 'length'`
   - Snapshot created automatically
   - UI percentage calculated against user's size

2. **Progressive Checkpoints** - Fully implemented
   - Checkpoints created during compression
   - Hierarchical aging: DETAILED → MODERATE (3 compressions) → COMPACT (6 compressions)
   - Additive history (never delete, only compress)
   - Checkpoint merging when limit exceeded
   - Per-tier limits enforced (Tier 2: 5, Tier 3: 5, Tier 4: 10, Tier 5: 15)

### ⚠️ Issues Found

1. **Snapshots Not Saved to Disk** - CRITICAL
   - **Status**: Snapshots created in memory but not persisted
   - **Impact**: User loses all context on app restart
   - **Location**: `packages/core/src/context/snapshotStorage.ts`
   - **Needs**: Investigation of save() method

2. **No Checkpoint on Context Overflow** - MINOR
   - **Status**: When hitting 85% limit, only snapshot created (no checkpoint)
   - **Impact**: User loses context after overflow (can't resume from checkpoint)
   - **Location**: `packages/cli/src/features/context/ModelContext.tsx` lines 180-200
   - **Fix**: Create checkpoint in addition to snapshot when `finishReason === 'length'`

3. **Emergency Clearing** - NEEDS VERIFICATION
   - **Status**: Unknown if emergency clearing (95% threshold) interferes with snapshot
   - **Impact**: Could wipe context before snapshot is saved
   - **Location**: `packages/core/src/context/memoryGuard.ts`
   - **Needs**: Verification that emergency actions don't trigger before snapshot

---

## CORE MECHANICS CHECKLIST

### 1. **85% Context Cap Strategy** ⭐ CRITICAL

**Design:**
- User selects context size (e.g., 4K) - UI shows 4096
- App sends 85% to Ollama via `num_ctx` (e.g., 3482)
- Ollama stops naturally at 85% with `done_reason: 'length'`
- Snapshot created when finish reason is 'length'
- UI percentage calculated against user's size (not 85%)
- No emergency clearing before snapshot

**Implementation Status:**
- [x] User selects context size (e.g., 4K) - UI shows 4096 ✅
- [x] App sends 85% to Ollama via `num_ctx` (e.g., 3482) ✅
- [x] Ollama stops naturally at 85% with `done_reason: 'length'` ✅
- [x] Snapshot created when finish reason is 'length' ✅
- [x] UI percentage calculated against user's size (not 85%) ✅
- [ ] No emergency clearing before snapshot ⚠️ NEEDS CHECK

**Files Checked:**
- ✅ `packages/cli/src/features/context/ModelContext.tsx` - Lines 720-755
  - Gets `userContextSize` from settings (e.g., 4096)
  - Calculates `ollamaContextSize` from profile or 85% fallback (e.g., 3482)
  - Sends `num_ctx: ollamaContextSize` to provider
  
- ✅ `packages/cli/src/features/context/ChatContext.tsx` - Lines 669-686
  - `onComplete` receives `finishReason` parameter
  - Checks `if (finishReason === 'length')`
  - Creates snapshot via `contextActions?.createSnapshot()`
  - Logs success/failure
  
- ✅ `packages/core/src/context/contextPool.ts` - Lines 213-227
  - `getUsage()` calculates percentage against `userContextSize`
  - Returns `maxTokens: this.userContextSize` (not 85% size)
  - UI shows correct user-selected size
  
- ⚠️ `packages/core/src/context/memoryGuard.ts` - NEEDS CHECK
  - Need to verify emergency actions don't trigger before snapshot

---

### 2. **Progressive Checkpoints** (Tier 3: 8-32K) ✅ WORKING

**Design:**
- Creates checkpoints when compressing (not just snapshots)
- Maintains 5 checkpoints with hierarchical aging
- Recent = DETAILED (800 tokens)
- Old = MODERATE (300 tokens)  
- Ancient = COMPACT (80 tokens)
- Checkpoints ADDITIVE (never delete, only compress)
- Max 10 checkpoints (merge oldest when exceeded)

**Implementation Status:**
- [x] Creates checkpoints when compressing (not just snapshots) ✅
- [x] Maintains 5 checkpoints with hierarchical aging ✅
- [x] Recent = DETAILED (level 3) ✅
- [x] Old = MODERATE (level 2) after 3 compressions ✅
- [x] Ancient = COMPACT (level 1) after 6 compressions ✅
- [x] Checkpoints ADDITIVE (never delete, only compress) ✅
- [x] Max checkpoints per tier (Tier 2: 5, Tier 3: 5, Tier 4: 10, Tier 5: 15) ✅
- [x] Merge oldest when exceeded ✅

**Files Checked:**
- ✅ `packages/core/src/context/contextManager.ts` - Lines 360-390, 1280-1340, 1450-1500
  - Checkpoints created during compression with unique IDs
  - Structure includes summary, range, tokens, keyDecisions, filesModified
  - `compressionNumber` field tracks when checkpoint was created
  - Checkpoints pushed to array (ADDITIVE)
  
- ✅ `packages/core/src/context/contextManager.ts` - Lines 1806-1890
  - `compressOldCheckpoints()` implements hierarchical aging
  - Age = totalCompressions - checkpoint.compressionNumber
  - DETAILED (level 3) → MODERATE (level 2) after 3 compressions
  - Any level → COMPACT (level 1) after 6 compressions
  - Token counts updated after compression
  
- ✅ `packages/core/src/context/contextManager.ts` - Lines 1050-1100
  - `mergeCheckpoints()` combines multiple checkpoints
  - Preserves all summaries, decisions, and files
  - Updates token counts correctly
  - Triggered when checkpoint count exceeds tier limit

**Hierarchical Compression Logic:**
```typescript
const MODERATE_AGE = 3; // Compress to moderate after 3 more compressions
const COMPACT_AGE = 6;  // Compress to compact after 6 more compressions

age = totalCompressions - checkpoint.compressionNumber;

if (age >= COMPACT_AGE && checkpoint.level !== 1) {
  checkpoint.level = 1; // COMPACT
  checkpoint.summary.content = createCompactSummary(...);
}
else if (age >= MODERATE_AGE && checkpoint.level === 3) {
  checkpoint.level = 2; // MODERATE
  checkpoint.summary.content = createModerateSummary(...);
}
```

**Minor Issue Found:**
- ⚠️ When `finishReason === 'length'`, only snapshot is created (no checkpoint)
- This means user loses context after hitting limit
- **Fix needed:** Create checkpoint in addition to snapshot when hitting 85% limit
- **Location:** `packages/cli/src/features/context/ModelContext.tsx` lines 180-200

---

### 3. **Never-Compressed Sections**

**Design:**
- Task definition preserved
- Architecture decisions preserved (6 for Tier 3)
- Active goals preserved
- Reasoning traces preserved
- System prompt adaptive to tier

**Implementation Status:**
- [ ] Task definition preserved
- [ ] Architecture decisions preserved (6 for Tier 3)
- [ ] Active goals preserved
- [ ] Reasoning traces preserved
- [ ] System prompt adaptive to tier

**Files to Check:**
- `packages/core/src/context/compressionService.ts` - Never-compressed logic
- `packages/core/src/context/contextManager.ts` - Preservation rules
- `packages/core/src/prompts/` - Adaptive prompt templates

---

### 4. **Tier Detection & Adaptive Prompts**

**Design:**
- Tier 1 (2-4K): 200 token prompt, rollover strategy
- Tier 2 (4-8K): 500 token prompt, 1 checkpoint
- Tier 3 (8-32K): 1000 token prompt, 5 checkpoints ⭐
- Tier 4 (32-64K): 1500 token prompt, 10 checkpoints
- Hardware-aware: Locks prompt tier when auto-sizing enabled

**Implementation Status:**
- [ ] Tier 1 (2-4K): 200 token prompt, rollover strategy
- [ ] Tier 2 (4-8K): 500 token prompt, 1 checkpoint
- [ ] Tier 3 (8-32K): 1000 token prompt, 5 checkpoints ⭐
- [ ] Tier 4 (32-64K): 1500 token prompt, 10 checkpoints
- [ ] Hardware-aware: Locks prompt tier when auto-sizing enabled

**Files to Check:**
- `packages/core/src/context/contextManager.ts` - Tier detection
- `packages/core/src/prompts/` - Prompt templates by tier
- `packages/core/src/context/contextPool.ts` - Hardware capability detection

---

### 5. **Compression Flow**

**Design:**
- Triggers at 80% of 85% cap (~2786 for 4K)
- Creates snapshot FIRST (for recovery)
- Compresses messages → creates checkpoint
- Adds checkpoint to history (ADDITIVE)
- Compresses older checkpoints hierarchically
- Merges if > MAX_CHECKPOINTS
- Reconstructs context with all checkpoints

**Implementation Status:**
- [ ] Triggers at 80% of 85% cap (~2786 for 4K)
- [ ] Creates snapshot FIRST (for recovery)
- [ ] Compresses messages → creates checkpoint
- [ ] Adds checkpoint to history (ADDITIVE)
- [ ] Compresses older checkpoints hierarchically
- [ ] Merges if > MAX_CHECKPOINTS
- [ ] Reconstructs context with all checkpoints

**Files to Check:**
- `packages/core/src/context/contextManager.ts` - Compression trigger
- `packages/core/src/context/compressionService.ts` - Compression logic
- `packages/core/src/context/snapshotManager.ts` - Snapshot creation

---

### 6. **Mode-Specific Preservation**

**Design:**
- Developer: Architecture, API contracts, code changes
- Planning: Goals, requirements, task breakdown
- Assistant: User preferences, conversation context
- Debugger: Error traces, reproduction steps

**Implementation Status:**
- [ ] Developer: Architecture, API contracts, code changes
- [ ] Planning: Goals, requirements, task breakdown
- [ ] Assistant: User preferences, conversation context
- [ ] Debugger: Error traces, reproduction steps

**Files to Check:**
- `packages/core/src/context/modeProfiles.ts` - Mode-specific rules
- `packages/core/src/context/compressionService.ts` - Mode-aware compression

---

### 7. **Goal Management** (v2.2)

**Design:**
- Goal tracking with checkpoints
- Decision recording with rationale
- Artifact tracking (files created/modified)
- Reasoning trace capture (for reasoning models)
- Goal context NEVER compressed

**Implementation Status:**
- [ ] Goal tracking with checkpoints
- [ ] Decision recording with rationale
- [ ] Artifact tracking (files created/modified)
- [ ] Reasoning trace capture (for reasoning models)
- [ ] Goal context NEVER compressed

**Files to Check:**
- `packages/core/src/context/goalManager.ts` - Goal tracking
- `packages/core/src/context/reasoningManager.ts` - Reasoning traces
- `packages/core/src/context/compressionService.ts` - Goal preservation

---

## AUDIT FINDINGS

### Critical Issues Found

1. **[ISSUE]** Description
   - **Expected:** What the design says
   - **Actual:** What the code does
   - **Impact:** How this affects users
   - **Fix:** What needs to change

### Non-Critical Issues Found

1. **[ISSUE]** Description
   - **Expected:** What the design says
   - **Actual:** What the code does
   - **Impact:** How this affects users
   - **Fix:** What needs to change

### Working Correctly

1. **[OK]** Feature name
   - **Verified:** What was checked
   - **Status:** Working as designed

---

## AUDIT PROGRESS

- [x] Section 1: 85% Context Cap Strategy - **MOSTLY WORKING** ✅
  - All core functionality implemented correctly
  - Need to verify emergency clearing doesn't interfere
- [x] Section 2: Progressive Checkpoints - **WORKING** ✅
  - Checkpoint creation, hierarchical aging, and merging all implemented
  - Minor issue: No checkpoint created on `finishReason: 'length'` (only snapshot)
- [ ] Section 3: Never-Compressed Sections
- [ ] Section 4: Tier Detection & Adaptive Prompts
- [ ] Section 5: Compression Flow
- [ ] Section 6: Mode-Specific Preservation
- [ ] Section 7: Goal Management

---

## NEXT STEPS

1. Complete audit of each section
2. Document all findings
3. Prioritize fixes by impact
4. Create implementation plan
5. Fix critical issues first
6. Verify fixes with tests


---

## NEXT STEPS

### Immediate Actions (Priority Order)

1. **Investigate Snapshot Save Failure** - CRITICAL
   - Check console logs for path diagnostics from `logPathDiagnostics`
   - Verify `~/.ollm/context-snapshots/` directory exists and is writable
   - Check for errors in snapshot save flow (should be logged to console)
   - Verify `snapshotStorage.save()` is completing successfully
   - **Files**: `packages/core/src/context/snapshotStorage.ts` lines 100-150

2. **Add Checkpoint on Context Overflow** - HIGH
   - When `finishReason === 'length'`, create checkpoint in addition to snapshot
   - This allows user to resume from checkpoint after hitting limit
   - **Location**: `packages/cli/src/features/context/ModelContext.tsx` lines 180-200
   - **Implementation**: Call `contextManager.compress()` before creating snapshot

3. **Verify Emergency Clearing Timing** - MEDIUM
   - Ensure emergency clearing (95% threshold) doesn't trigger before snapshot
   - Check that snapshot creation completes before any emergency actions
   - **Files**: `packages/core/src/context/memoryGuard.ts`

4. **Continue Audit** - ONGOING
   - Section 3: Never-Compressed Sections
   - Section 4: Tier Detection & Adaptive Prompts
   - Section 5: Compression Flow
   - Section 6: Mode-Specific Preservation
   - Section 7: Goal Management

### Testing Recommendations

1. **Test Snapshot Creation**
   ```bash
   # Check if snapshots are being created
   ls -la ~/.ollm/context-snapshots/
   
   # Check console logs for errors
   # Look for: "[SnapshotStorage] Failed to save snapshot"
   ```

2. **Test Context Overflow**
   - Fill context to 85% limit
   - Verify snapshot is created
   - Verify checkpoint is created
   - Verify context can be resumed

3. **Test Hierarchical Compression**
   - Trigger multiple compressions
   - Verify checkpoints age correctly (DETAILED → MODERATE → COMPACT)
   - Verify checkpoint merging when limit exceeded

### Key Findings Summary

**What's Working:**
- ✅ 85% context cap strategy correctly implemented
- ✅ Progressive checkpoints with hierarchical aging
- ✅ Additive checkpoint history (never delete, only compress)
- ✅ Checkpoint merging when limits exceeded
- ✅ Per-tier checkpoint limits enforced

**What Needs Attention:**
- ⚠️ Snapshots not being saved to disk (CRITICAL)
- ⚠️ No checkpoint created on context overflow (only snapshot)
- ⚠️ Emergency clearing timing needs verification

**Next Audit Sections:**
- Never-compressed sections preservation
- Tier detection and adaptive prompts
- Compression flow and triggers
- Mode-specific preservation rules
- Goal management integration
