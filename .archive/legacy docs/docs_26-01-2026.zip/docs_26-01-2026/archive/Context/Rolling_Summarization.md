# Rolling (Recursive) Summarization Strategy

**Implemented:** January 2026  
**Component:** `CompressionService.ts`

## Concept
The Rolling Summarization strategy addresses the problem of context loss in long-running LLM sessions. Instead of creating isolated summaries of conversation chunks, it maintains a single, evolving narrative that "rolls" forward.

## Key Features

### 1. Recursive Logic
When compressing context:
1.  **Look Back**: The system checks for an existing `[Recursive Context Summary]` message.
2.  **Merge**: If found, the *content* of the old summary is extracted and passed to the LLM along with the new conversation messages.
3.  **Update**: The LLM generates a *new* summary that integrates the `PREVIOUS SUMMARY` + `NEW CONVERSATION`.
4.  **Replace**: The old summary message is removed, and the new one takes its place.

This ensures that the summary evolves rather than fragmenting.

### 2. Dual-Section Structure
To prevent the summary from becoming a generic blob of text, the prompt enforces a strict two-part structure:

*   **🎯 Active Goals**:
    *   high-priority context.
    *   Tracks what we are doing *right now*.
    *   Examples: "Fix Python code in file X", "Refactor module Y".
*   **📜 History Archive**:
    *   High-compression chronological log.
    *   Tracks decisions made, steps completed, and established facts.
    *   Example: "User requested feature A. Implemented via class B. Tests passed."

### 3. Strict User Preservation
**Critical Rule**: User messages are **NEVER** compressed, summarized, or truncated.
*   They are explicitly filtered out before providing the context to the summarizer.
*   They are re-injected into the context *after* the summarization of Assistant/Tool outputs is complete.
*   **Result**: The user's exact instructions and intent are preserved 100% of the time, no matter how long the session lasts.

## The Prompt Template

```markdown
You are a specialized Context Compressor. Your goal is to maintain a coherent "Long-Term Memory" for an AI session.

INPUTS:
1. PREVIOUS SUMMARY: A summary of the conversation up to this point.
2. NEW CONVERSATION: Recent messages that need to be compressed.

INSTRUCTIONS:
- Combine the PREVIOUS SUMMARY and NEW CONVERSATION into a single, updated summary.
- You MUST structure the output into two distinct sections:
  1. "🎯 Active Goals": The current high-level objectives and immediate next steps. Keep this precise.
  2. "📜 History Archive": A highly compressed chronological history of key decisions, actions taken, and established facts.
- Drop irrelevant details from the archives but preserve technical specifics (file paths, variable names) if they are still relevant to the Active Goals.
- Keep the total output under {maxTokens} tokens.

PREVIOUS SUMMARY:
{previousSummary}

NEW CONVERSATION:
{conversationText}

Updated Summary:
```

## Benefits
- **Continuity**: No context fragmentation.
- **Goal Permanence**: The "Active Goals" section prevents the LLM from "forgetting what it was doing" after long outputs.
- **Data Safety**: User input is strictly immutable.
