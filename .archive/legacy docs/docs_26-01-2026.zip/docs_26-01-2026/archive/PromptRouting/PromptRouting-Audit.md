## Prompt routing: new logic (source of truth)

### Owner
- `packages/core/src/context/contextManager.ts` is the single owner of the system prompt.
- UI layers must never call `setSystemPrompt` or compose prompts.

### Prompt composition
1. `SystemPromptBuilder` builds the base rules prompt (sanity, skills, guardrails).
2. `TieredPromptStore` loads a tiered prompt file from disk.
3. `ContextManager.updateSystemPrompt()` concatenates `tiered prompt` + `rules`.
4. The send path reorders to `tiered prompt` → `rules` → `tool note` before sending.

### Prompt templates
- Location: `packages/core/src/prompts/templates/<mode>/tierN.txt`
- Modes: `assistant`, `developer`, `planning`, `debugger`
- Tiers: `tier1`, `tier2`, `tier3`, `tier4`
- Tier 5 maps to tier 4 content.

### Tier mapping
Based on actual context window (`maxTokens`) for both auto and manual sizing:
- `<= 4096` -> Tier 1
- `<= 8192` -> Tier 2
- `<= 16384` -> Tier 3
- `<= 32768` -> Tier 4
- `>= 65536` -> Tier 5 (64K+ tier label)
- `32769..65535` rounds down to Tier 4 for prompt selection.

Auto-size only sets the context size; prompt tier always follows actual context size.

### Auto-size rule
- Compute max possible context from VRAM.
- Determine the highest supported tier for that max.
- Choose **one tier lower** as the recommended size:
  - Tier 1 -> 4K
  - Tier 2 -> 4K
  - Tier 3 -> 8K
  - Tier 4 -> 16K
  - Tier 5 -> 32K
- Clamp recommended size to the max possible context (if hardware is below 4K).

### Mode flow
- `PromptModeManager` decides transitions (auto/manual) but does not build prompts.
- `ContextManagerContext` listens for mode changes and calls `ContextManager.setMode(...)`.
- `ContextManager.setMode(...)` triggers prompt rebuild with the correct tier file.

### CLI behavior
- `/mode` and shortcuts only support: `assistant`, `planning`, `developer`, `debugger`.
- Hybrid or legacy modes are disabled to avoid prompt mixing.

### What to verify
- `/test prompt` returns different prompt bodies per mode and tier.
- No prompt accumulation across turns (prompt content stays stable).
- Context size and prompt tier stay aligned in both auto-size and manual size modes.
- Ollama payload includes a single system prompt string, with tiered prompt first.
