## Prompt bug: hardcoded Active Prompt author

- Location: `packages/cli/src/ui/components/layout/ActivePromptInfo.tsx`
- Issue: The UI included a hardcoded "Author: github.upstash" line in the Active Prompt area. This was static and not driven by active/dynamic MCP metadata.
- Cause: Legacy/local registry entries (e.g., `io.github.upstash/context7`) exist in `packages/cli/src/services/mcpMarketplace.ts` and tests/settings reference `context7`. The `ActivePromptInfo` component contained a literal author string.
- Action taken: Removed the hardcoded author line from the UI.
- Rationale: Active Prompt should reflect active MCP metadata only; prompts will later carry MCP info and be used to populate this area dynamically.
- Next steps:
  - When ready, implement dynamic author display using the active MCP context metadata.
  - Consider removing `io.github.upstash/context7` from `getLocalRegistry()` and cleaning test/.kiro references if deprecated.

---

## Prompt routing audit (2026-01-25)

### Design drift vs. implementation
- **Design docs expect** tiered prompt files under `packages/core/src/context/prompts/tier*/{mode}.txt`.
- **Repo reality**: Tiered templates live inline in `packages/core/src/context/types.ts` as `SYSTEM_PROMPT_TEMPLATES`. Mode templates also exist in `packages/core/src/prompts/templates/modes/`, but they are **not** used by the routing path that reaches the LLM.

### Current prompt routing path (what is actually sent)
1. `ConversationContextManager` in `packages/core/src/context/contextManager.ts` selects a tiered prompt via `SYSTEM_PROMPT_TEMPLATES` based on:
   - `autoSize` + hardware capability tier (locked) **or**
   - manual `targetSize` tier.
2. `ContextManagerContext` in `packages/cli/src/features/context/ContextManagerContext.tsx` **overwrites** that prompt:
   - It creates a `PromptModeManager` with a fake `SystemPromptBuilder` that simply returns `manager.getSystemPrompt()`.
   - It calls `modeManager.buildPrompt(...)` and then `manager.setSystemPrompt(newPrompt)` on:
     - initial startup,
     - every mode change,
     - every send in `ChatContext`.
3. `PromptModeManager.buildPrompt(...)` **appends a mode template** (inline strings in `PromptModeManager.getModeTemplate`) on top of the existing prompt.
   - Because the "core prompt" is just the current system prompt, repeated rebuilds **stack** mode templates over time and **stop** reflecting tier selection changes.

### Why /test prompt shows a single prompt
- `/test prompt` dumps `manager.getSystemPrompt()` (global context manager).
- That prompt is repeatedly overwritten by `ContextManagerContext` using `PromptModeManager.buildPrompt`, so it no longer tracks tiered templates or context size changes.

### Auto-size and context size mismatch
- Core `ConversationContextManager` uses VRAM-based auto-sizing and locks prompt tier to hardware capability (`autoSize=true`).
- `ModelContext.sendToLLM` uses **settings-based** context size (`settings.llm.contextSize`) to compute `num_ctx`, independent of core auto-sizing.
- This means prompt tier selection and `num_ctx` sent to Ollama can diverge.

### Immediate risks
- Tiered prompts are effectively bypassed in the UI path.
- Mode prompts are duplicated over time (prompt growth).
- Context size + prompt tier selection are inconsistent between core and provider request.

---

## Prompt routing cleanup log (2026-01-25)

### Changes applied
- Moved tiered prompts to file-based templates under `packages/core/src/prompts/templates/<mode>/tier*.txt` and added `TieredPromptStore`.
- Core `ContextManager` now owns prompt composition: `SystemPromptBuilder` + tiered prompt file based on mode + tier.
- Removed legacy mode templates and old modes from core prompt pipeline and CLI mode commands/shortcuts.
- UI no longer rebuilds/overwrites system prompts on mode change, send, or compression.
- HotSwap now updates mode via `ContextManager.setMode` instead of building prompts.
- Mode metrics, workflows, and snapshot findings trimmed to the four supported modes.

### Remaining checks
- Validate provider request parameters (`num_ctx`, model) against auto-size logic.
- Ensure `/test prompt` reflects tier/mode changes after this refactor.

---

## Prompt templates not loaded in built CLI (2026-01-25)

### Symptom
- `/test prompt` always returns only the base `SystemPromptBuilder` output.

### Cause
- Tiered prompt files were not copied into `packages/core/dist/prompts/templates`, so runtime file reads returned empty.

### Fix
- Added build-time copy of `src/prompts/templates` into `dist/prompts/templates`.
- Build script now runs `tsc -b && node ./scripts/copy-prompts.cjs`.

---

## Core build missing dist outputs (2026-01-25)

### Symptom
- `packages/core/dist` only contained prompt templates after build.
- CLI build failed with TS6305 “output file has not been built from source file”.

### Cause
- `tsconfig.tsbuildinfo` reported “up to date” even though `dist` was deleted, so `tsc -b` emitted nothing.

### Fix
- Rebuild core with `npx tsc -b --force` (then run the normal core build to copy prompt templates).
  - Commands:
    - `npx tsc -b --force` (in `packages/core`)
    - `npm run build -w packages/core`

---

## Auto context forces developer prompt (2026-01-25)

### Symptom
- With auto context enabled, `/test prompt` shows the same prompt across modes.
- In manual context mode, prompts switch correctly by mode.

### Suspected cause
- Auto context locks prompt tier to hardware capability and may build the initial prompt before the UI forces the mode to `assistant`.
- Prompt tier selection should track the actual context size, not the hardware tier.

### Desired behavior
- Auto context only sets context size (recommended tier below max hardware).
- Prompt selection uses the current mode + actual context size tier (auto or manual).

### Fix applied
- Prompt tier now follows the actual context size for both auto and manual sizing.
- Auto size uses VRAM max → tier → one-tier-lower recommended size (clamped).
- Auto context resize updates the system prompt when the tier changes.

---

## /test prompt duplicated output (2026-01-25)

### Symptom
- `/test prompt` showed repeated system prompt content (full prompt plus tail and system message snippet).

### Fix applied
- `/test prompt` now prints the system prompt once and excludes system messages from the context snippet.

---

## /test prompt full payload (2026-01-25)

### Change
- `/test prompt` now prints the full system prompt and the full message payload (no truncation), matching what is sent to Ollama.
- Added expected tier prompt dump and inclusion flag to spot missing tier templates.

---

## Tier prompt missing in Ollama payload (2026-01-25)

### Symptom
- Ollama payload `system` field contains only core identity/mandates (no tier prompt).

### Fix applied
- CLI send path appends the tier prompt when it is missing from the system prompt, using the current mode and actual context size.

---

## Duplicate system content in payload (2026-01-25)

### Symptom
- Ollama payload included both the combined system prompt and a second system message containing the rules.

### Fix applied
- Messages sent to Ollama now exclude all `role: system` entries; system prompt is passed separately.
- System prompt is reordered to `tier prompt` → `rules` → `tool note` at send time.

---

## /test prompt JSON formatting (2026-01-25)

### Change
- `/test prompt` now outputs two JSON blocks:
  - Structured payload (arrays for rules/systemPrompt/userMessage/directives/tools)
  - Actual Ollama payload
