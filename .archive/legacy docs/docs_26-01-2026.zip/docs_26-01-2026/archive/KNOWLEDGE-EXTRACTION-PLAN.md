# Knowledge Extraction Plan

## Purpose
Track which reference/audit documents need dev_ knowledge files created.

## Status
- ✅ Sorted: All documents organized
- 🔄 Extraction: In progress
- ⏳ Pending: Awaiting extraction

## Reference Documents by Topic

### Context Management
**Location:** `.dev/docs/devs/reference/Context/`
**Files:** 8 documents
**Status:** ✅ Already have `dev_ContextCompression.md`
**Additional Topics:**
- Adaptive System Prompts (tier-based)
- Checkpoint Flow & Progressive Compression
- Session Snapshots
- Prompt Routing Logic

**Recommendation:** Update existing `dev_ContextCompression.md` or create `dev_PromptSystem.md`

---

### MCP Integration
**Location:** `.dev/docs/devs/reference/MCP/`
**Files:** 7 documents
**Status:** ⏳ Needs `dev_MCPIntegration.md`
**Key Logic:**
- MCP client lifecycle (initialization → connection → tool discovery)
- OAuth flow for MCP servers
- Health monitoring and reconnection
- Tool schema conversion (MCP → internal format)

**Priority:** HIGH - Core feature

---

### Models & Profiles
**Location:** `.dev/docs/devs/reference/Models/`
**Files:** 3 documents + subdirectories
**Status:** ⏳ Needs `dev_ModelManagement.md`
**Key Logic:**
- LLM_profiles.json structure
- Model database generation
- Profile merging (catalog → user overrides)
- Context window detection

**Priority:** HIGH - Already partially covered in dev_ContextCompression.md

---

### Hook System
**Location:** `.dev/docs/devs/reference/HookSystem/` (empty folder, needs files moved)
**Files:** Scattered in audits-bugtracker
**Status:** ⏳ Needs `dev_HookSystem.md`
**Key Logic:**
- Hook event flow (trigger → planner → runner → execution)
- Hook types (askAgent, runCommand)
- Trusted hooks vs user hooks
- Hook debugging and approval

**Priority:** MEDIUM

---

### File Explorer
**Location:** `.dev/docs/devs/reference/FileExplorer/`
**Files:** 6 documents + implementation folder
**Status:** ⏳ Needs `dev_FileExplorer.md`
**Key Logic:**
- Tree state management
- Expansion/collapse logic
- File watching and updates
- Integration with context

**Priority:** LOW - UI feature

---

### UI Components
**Location:** `.dev/docs/devs/reference/UI/`
**Files:** 8 documents
**Status:** ⏳ Needs `dev_UIArchitecture.md`
**Key Logic:**
- Panel system (tools, hooks, MCP, GitHub)
- Navigation menu structure
- Scroll management
- Terminal integration

**Priority:** LOW - UI implementation details

---

### Tools System
**Location:** `.dev/docs/devs/reference/Tools/`
**Files:** 6 documents
**Status:** ⏳ Needs `dev_ToolExecution.md`
**Key Logic:**
- Tool registry and discovery
- Tool execution flow
- Permission checking (policy engine)
- Tool result handling

**Priority:** MEDIUM

---

### Window System
**Location:** `.dev/docs/devs/reference/WindowSystem/`
**Files:** 4 documents
**Status:** ⏳ Needs `dev_WindowSystem.md`
**Key Logic:**
- Window container architecture
- Focus management
- Window rendering optimization

**Priority:** LOW - UI implementation

---

### Extensions
**Location:** `.dev/docs/devs/reference/Extensions/` (empty folder)
**Files:** Scattered
**Status:** ⏳ Needs `dev_ExtensionSystem.md`
**Key Logic:**
- Extension loading and sandboxing
- Extension manifest format
- Extension marketplace
- Hot-reload mechanism

**Priority:** MEDIUM

---

## Audit Documents by Topic

### Context Management Audits
**Location:** `.dev/docs/devs/audits-bugtracker/ContextManagement/`
**Files:** Multiple weeks of audits (W2, W3, W4)
**Status:** Already processed into BugsFixes and Audit docs
**Action:** Review for any missing logic chains

---

### MCP Integration Audits
**Location:** `.dev/docs/devs/audits-bugtracker/MCPIntegration/`
**Files:** W3 audit + connection flow docs
**Status:** Needs review
**Action:** Extract connection flow logic

---

### Hook System Audits
**Location:** `.dev/docs/devs/audits-bugtracker/HookSystem/`
**Files:** Multiple audit and fix documents
**Status:** Needs review
**Action:** Extract hook execution flow

---

### Other Audits
- FileExplorer: Performance optimizations
- FocusManagement: Focus tracking logic
- Navigation: Menu system
- ProviderSystem: Provider abstraction
- TestSuite: Test patterns
- ToolsAndHooks: Tool execution
- UIComponents: Component patterns
- WindowSystem: Window management

---

## Recommended Priority Order

1. **HIGH PRIORITY** (Core logic, frequently referenced):
   - `dev_MCPIntegration.md` - MCP client lifecycle and tool discovery
   - `dev_ModelManagement.md` - Profile system and model database
   - `dev_PromptSystem.md` - Adaptive prompts and tier selection

2. **MEDIUM PRIORITY** (Important features):
   - `dev_HookSystem.md` - Hook event flow and execution
   - `dev_ToolExecution.md` - Tool registry and permission checking
   - `dev_ExtensionSystem.md` - Extension loading and sandboxing

3. **LOW PRIORITY** (UI/implementation details):
   - `dev_FileExplorer.md`
   - `dev_UIArchitecture.md`
   - `dev_WindowSystem.md`

---

## Next Steps

**Option A:** Create all HIGH priority dev_ files now (3 files)
**Option B:** Create one dev_ file at a time, starting with MCP
**Option C:** User selects which topic to prioritize

**Recommendation:** Start with `dev_MCPIntegration.md` since it's a core feature with clear logic chains.
