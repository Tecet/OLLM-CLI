# Core Services Deep Dive

## Overview

The `packages/core/src/services/` directory contains essential business logic services that power Gemini CLI's core functionality.

## Services Directory Structure

```
packages/core/src/services/
├── chatCompressionService.ts      # History compression
├── chatRecordingService.ts        # Session recording
├── contextManager.ts              # JIT context management
├── environmentSanitization.ts     # Secret redaction
├── fileDiscoveryService.ts        # File system scanning
├── fileSystemService.ts           # FS abstraction
├── gitService.ts                  # Git operations
├── loopDetectionService.ts        # Infinite loop detection
├── modelConfigService.ts          # Model configuration
├── sessionSummaryService.ts       # Session summarization
├── sessionSummaryUtils.ts         # Summary utilities
└── shellExecutionService.ts       # Shell command execution
```

## 1. Chat Compression Service

**File**: `chatCompressionService.ts` (~7KB)

Compresses long conversation histories to fit within context limits.

### Purpose
- Prevent context window overflow
- Maintain conversation continuity
- Preserve critical information

### Implementation

```typescript
class ChatCompressionService {
  async compressChat(
    chat: GeminiChat,
    config: Config,
  ): Promise<ChatCompressionResult>
}

interface ChatCompressionResult {
  compressionStatus: CompressionStatus;
  compressionInfo?: ChatCompressionInfo;
}

enum CompressionStatus {
  NOT_NEEDED = 'not_needed',
  COMPRESSED = 'compressed',
  FAILED = 'failed',
}
```

### Compression Process
1. Estimate current token count
2. Check against threshold (~70% of limit)
3. Generate compressed summary using model
4. Replace history with compressed state
5. Maintain recent messages for context

## 2. Chat Recording Service

**File**: `chatRecordingService.ts` (~16KB)

Records and persists conversation sessions.

### Features
- Session persistence
- Resume capability
- History export

### Implementation

```typescript
class ChatRecordingService {
  constructor(config: Config)
  
  initialize(resumedSessionData?: ResumedSessionData): void
  
  recordMessage(message: {
    model: string;
    type: 'user' | 'model' | 'tool';
    content: string;
  }): void
  
  recordToolCall(toolCall: {
    name: string;
    args: Record<string, unknown>;
    result: unknown;
    duration: number;
  }): void
  
  save(): Promise<void>
  getSessionData(): SessionData
}
```

### Session File Format

```json
{
  "sessionId": "abc123",
  "startTime": "2024-01-09T10:00:00Z",
  "model": "gemini-2.5-pro",
  "messages": [
    {
      "type": "user",
      "content": "...",
      "timestamp": "..."
    }
  ],
  "toolCalls": [
    {
      "name": "edit_file",
      "args": {...},
      "result": {...},
      "duration": 1234
    }
  ]
}
```

## 3. Context Manager

**File**: `contextManager.ts` (~3KB)

Manages Just-In-Time (JIT) context loading.

### Purpose
- Dynamic context loading
- Memory management
- On-demand resource fetching

### Implementation

```typescript
class ContextManager {
  constructor(config: Config)
  
  async refresh(): Promise<void>
  getContext(): string
  addContext(key: string, value: string): void
  removeContext(key: string): void
}
```

## 4. Environment Sanitization Service

**File**: `environmentSanitization.ts` (~4KB)

Protects against accidental secret exposure.

### Features
- Environment variable redaction
- Pattern-based detection
- Configurable allow/block lists

### Implementation

```typescript
interface EnvironmentSanitizationConfig {
  allowedEnvironmentVariables?: string[];
  blockedEnvironmentVariables?: string[];
  enableRedaction?: boolean;
}

function sanitizeEnvironment(
  env: Record<string, string | undefined>,
  config: EnvironmentSanitizationConfig,
): Record<string, string | undefined>

function redactSecrets(
  text: string,
  config: EnvironmentSanitizationConfig,
): string
```

### Redaction Patterns
- API keys (patterns like `sk-...`, `gsk_...`)
- Tokens (JWT patterns)
- Passwords (common env var names)
- Connection strings

## 5. File Discovery Service

**File**: `fileDiscoveryService.ts` (~3KB)

Scans and indexes project files.

### Features
- Fast directory traversal (fdir)
- Gitignore/geminiignore support
- File type filtering
- Size limits

### Implementation

```typescript
class FileDiscoveryService {
  constructor(config: Config)
  
  async discoverFiles(
    directory: string,
    options?: FileDiscoveryOptions,
  ): Promise<DiscoveredFile[]>
  
  async getProjectTree(
    maxDirs?: number,
  ): Promise<ProjectTree>
}

interface DiscoveredFile {
  path: string;
  relativePath: string;
  size: number;
  modifiedTime: Date;
  isDirectory: boolean;
}
```

## 6. File System Service

**File**: `fileSystemService.ts` (~1KB)

Abstraction layer for file system operations.

### Implementation

```typescript
interface FileSystemService {
  readFile(path: string): Promise<string>
  writeFile(path: string, content: string): Promise<void>
  exists(path: string): Promise<boolean>
  isDirectory(path: string): Promise<boolean>
  mkdir(path: string, options?: { recursive?: boolean }): Promise<void>
}

class StandardFileSystemService implements FileSystemService {
  // Uses Node.js fs/promises
}
```

### Purpose
- Testability (easy mocking)
- Abstraction for potential sandbox support
- Consistent error handling

## 7. Git Service

**File**: `gitService.ts` (~5KB)

Git operations wrapper using simple-git.

### Features
- Repository detection
- Status checking
- Diff generation
- Commit operations

### Implementation

```typescript
class GitService {
  constructor(projectRoot: string)
  
  async isGitRepository(): Promise<boolean>
  async getStatus(): Promise<GitStatus>
  async getDiff(options?: DiffOptions): Promise<string>
  async getLog(n?: number): Promise<GitLogEntry[]>
  async getCurrentBranch(): Promise<string>
  async stageFiles(files: string[]): Promise<void>
  async commit(message: string): Promise<void>
}
```

## 8. Loop Detection Service

**File**: `loopDetectionService.ts` (~19KB)

Detects and prevents infinite agent loops.

### Purpose
- Prevent token waste
- Detect stuck states
- Provide recovery options

### Implementation

```typescript
class LoopDetectionService {
  constructor(config: Config)
  
  async turnStarted(signal: AbortSignal): Promise<boolean>
  
  addAndCheck(event: ServerGeminiStreamEvent): boolean
  
  reset(promptId: string): void
}
```

### Detection Strategies
1. **Repeated content detection** - Same text appearing multiple times
2. **Pattern matching** - Common loop indicators
3. **Turn count limits** - Maximum turns per prompt
4. **Time-based limits** - Maximum time per task

### Configuration

```typescript
{
  maxTurns: 100,
  repeatThreshold: 3,
  timeoutMinutes: 30,
}
```

## 9. Model Config Service

**File**: `modelConfigService.ts` (~11KB)

Manages model-specific configurations.

### Features
- Model aliases
- Generation config overrides
- Model availability checking

### Implementation

```typescript
class ModelConfigService {
  constructor(config: ModelConfigServiceConfig)
  
  getResolvedConfig(key: ModelConfigKey): {
    model: string;
    generateContentConfig: GenerateContentConfig;
  }
  
  resolveAlias(alias: string): string
  
  getModelOverrides(model: string): GenerateContentConfig
}

interface ModelConfigKey {
  model: string;
  isRetry?: boolean;
}
```

## 10. Session Summary Service

**File**: `sessionSummaryService.ts` (~5KB)

Generates human-readable session summaries.

### Features
- AI-powered summarization
- Multi-format output
- History analysis

### Implementation

```typescript
class SessionSummaryService {
  async summarize(
    history: Content[],
    config: Config,
  ): Promise<SessionSummary>
}

interface SessionSummary {
  title: string;
  description: string;
  keyActions: string[];
  filesModified: string[];
}
```

## 11. Shell Execution Service

**File**: `shellExecutionService.ts` (~27KB - large)

Executes shell commands with advanced features.

### Features
- PTY support (interactive shells)
- Output streaming
- Terminal emulation (xterm-headless)
- Environment management
- Timeout handling

### Implementation

```typescript
class ShellExecutionService {
  constructor(config: ShellExecutionConfig)
  
  async execute(
    command: string,
    options: ShellExecutionOptions,
  ): Promise<ShellExecutionResult>
  
  async executeInteractive(
    command: string,
    onOutput: (data: string) => void,
    signal: AbortSignal,
  ): Promise<void>
}

interface ShellExecutionConfig {
  terminalWidth: number;
  terminalHeight: number;
  showColor: boolean;
  pager: string;
  sanitizationConfig: EnvironmentSanitizationConfig;
}

interface ShellExecutionResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  duration: number;
  timedOut: boolean;
}
```

### PTY Support

```typescript
// Uses @lydell/node-pty for interactive shells
const pty = spawn('bash', [], {
  name: 'xterm-256color',
  cols: 80,
  rows: 24,
  cwd: process.cwd(),
  env: sanitizedEnv,
});
```

## OLLM CLI Adaptation Notes

### Fully Reusable Services
| Service | Status | Notes |
|---------|--------|-------|
| chatCompressionService | ✅ | May need prompt adjustment |
| chatRecordingService | ✅ | Fully reusable |
| contextManager | ✅ | Fully reusable |
| environmentSanitization | ✅ | Fully reusable |
| fileDiscoveryService | ✅ | Fully reusable |
| fileSystemService | ✅ | Fully reusable |
| gitService | ✅ | Fully reusable |
| loopDetectionService | ✅ | Fully reusable |
| shellExecutionService | ✅ | Fully reusable |

### Services Needing Adaptation

#### modelConfigService
- Remove Gemini-specific model aliases
- Add Ollama model names
- Adapt config format for Ollama parameters

```typescript
// OLLM version
interface OllamaModelConfig {
  model: string;
  options: {
    temperature?: number;
    num_ctx?: number;
    num_predict?: number;
    num_gpu?: number;
  };
}
```

#### sessionSummaryService
- Keep the interface
- Adapt summarization prompt for different model capabilities
- May need smaller summary for context-limited models

### New Services for OLLM CLI

```typescript
// Model Management Service
class OllamaModelService {
  async listModels(): Promise<OllamaModel[]>
  async pullModel(name: string, onProgress: ProgressCallback): Promise<void>
  async deleteModel(name: string): Promise<void>
  async showModel(name: string): Promise<ModelInfo>
}

// Local Embedding Service (optional)
class LocalEmbeddingService {
  async embed(text: string): Promise<number[]>
  async similarity(a: string, b: string): Promise<number>
}
```
