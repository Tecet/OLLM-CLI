# Agent System Deep Dive

## Overview

Gemini CLI includes a sophisticated agent delegation system that allows the main agent to spawn specialized sub-agents for complex tasks.

## Architecture

**Location**: `packages/core/src/agents/`

```
agents/
├── agentRegistry.ts            # Agent registration
├── codebaseInvestigatorAgent.ts  # Deep codebase analysis
├── agentTypes.ts               # Type definitions
└── index.ts                    # Exports
```

## Agent Registry

**File**: `agentRegistry.ts`

Manages available agents and their invocation:

```typescript
class AgentRegistry {
  constructor(config: Config)
  
  registerAgent(agent: AgentDefinition): void
  
  getAgent(name: string): AgentDefinition | undefined
  
  getAllAgents(): AgentDefinition[]
  
  async invokeAgent(
    name: string,
    task: string,
    context: AgentContext,
    signal: AbortSignal,
  ): Promise<AgentResult>
}
```

### Agent Definition

```typescript
interface AgentDefinition {
  name: string;
  displayName: string;
  description: string;
  
  // The tool that invokes this agent
  toolDefinition: FunctionDeclaration;
  
  // Agent execution
  execute(
    params: Record<string, unknown>,
    context: AgentContext,
    signal: AbortSignal,
  ): AsyncGenerator<AgentEvent, AgentResult>;
}

interface AgentContext {
  config: Config;
  toolRegistry: ToolRegistry;
  messageBus: MessageBus;
  parentHistory: Content[];
}

type AgentEvent =
  | { type: 'thinking'; content: string }
  | { type: 'tool_call'; tool: string; args: Record<string, unknown> }
  | { type: 'tool_result'; result: unknown }
  | { type: 'response'; content: string }
  | { type: 'error'; error: Error };

interface AgentResult {
  success: boolean;
  response: string;
  artifacts?: AgentArtifact[];
}
```

## Codebase Investigator Agent

**File**: `codebaseInvestigatorAgent.ts` (~21KB)

A specialized agent for deep codebase exploration and analysis.

### Purpose
- Complex refactoring analysis
- Multi-file dependency tracking
- Architecture understanding
- System-wide searches

### Tool Definition

```typescript
{
  name: 'codebase_investigator',
  description: `Delegate complex analysis to a specialized investigator agent.
    Use for: architectural exploration, multi-file dependency analysis,
    systematic code searches, and complex refactoring planning.`,
  parameters: {
    type: 'object',
    properties: {
      task: {
        type: 'string',
        description: 'The investigation task to perform'
      },
      scope: {
        type: 'string',
        enum: ['file', 'directory', 'project'],
        description: 'Scope of investigation'
      },
      focusAreas: {
        type: 'array',
        items: { type: 'string' },
        description: 'Specific areas to focus on'
      }
    },
    required: ['task']
  }
}
```

### Investigator Workflow

1. **Task Analysis**
   - Parse the investigation request
   - Identify required search strategies
   - Plan tool usage

2. **Discovery Phase**
   - Use `glob_tool` for file discovery
   - Use `grep_search` for content search
   - Build dependency graph

3. **Analysis Phase**
   - Deep read of relevant files
   - Pattern identification
   - Cross-reference analysis

4. **Synthesis Phase**
   - Compile findings
   - Generate recommendations
   - Return structured report

### Investigator System Prompt

```markdown
You are a codebase investigator agent. Your role is to thoroughly 
analyze code and provide detailed, accurate reports.

## Your Capabilities
- File system exploration (glob, grep, read)
- Pattern recognition
- Dependency analysis
- Architecture mapping

## Guidelines
1. Be thorough but efficient
2. Report findings with file locations
3. Provide actionable insights
4. Cite specific line numbers when relevant
```

### Sub-agent Communication

The investigator runs as a separate conversation with its own context:

```typescript
async function* execute(
  params: InvestigatorParams,
  context: AgentContext,
  signal: AbortSignal,
): AsyncGenerator<AgentEvent, AgentResult> {
  // Create sub-chat with investigator system prompt
  const investigatorChat = await context.config.startChat(
    investigatorSystemPrompt,
  );
  
  // Run investigation loop
  for await (const event of investigatorChat.run(params.task, signal)) {
    yield event;
  }
  
  // Return synthesized results
  return {
    success: true,
    response: investigatorChat.getLastResponse(),
  };
}
```

## Agent Invocation Flow

```
User Request
     │
     ▼
┌──────────────────────────┐
│     Main Agent           │
│  (GeminiClient/Turn)     │
└──────────────────────────┘
     │
     │  Complex analysis detected
     ▼
┌──────────────────────────┐
│  Tool: codebase_invest.  │
│                          │
└──────────────────────────┘
     │
     ▼
┌──────────────────────────┐
│   AgentRegistry          │
│   .invokeAgent()         │
└──────────────────────────┘
     │
     ▼
┌──────────────────────────┐
│  CodebaseInvestigator    │
│  Agent                   │
│  ┌────────────────────┐  │
│  │ Sub-conversation   │  │
│  │ with tools access  │  │
│  └────────────────────┘  │
└──────────────────────────┘
     │
     ▼
     Result returned to main agent
```

## Agent Configuration

In system prompt, agents are referenced:

```markdown
## Codebase Investigator Integration

When the task involves complex refactoring, codebase exploration 
or system-wide analysis, your first and primary action must be 
to delegate to the 'codebase_investigator' agent.

The investigator will:
- Perform thorough codebase analysis
- Return a detailed report
- Provide actionable recommendations
```

### Enable/Disable

```typescript
// In Config
getCodebaseInvestigatorEnabled(): boolean {
  return this.params.enableCodebaseInvestigator ?? true;
}
```

## Agent Tool Execution

Agents have access to the same tools as the main agent:

```typescript
const agentTools = context.toolRegistry.getAllTools().filter(
  tool => !tool.name.startsWith('agent_')  // Prevent agent recursion
);
```

### Tool Call Propagation

```typescript
for await (const event of agentStream) {
  if (event.type === 'tool_call') {
    // Execute tool
    const result = await executeToolCall(
      event.tool,
      event.args,
      context,
      signal,
    );
    
    yield { type: 'tool_result', result };
  }
  
  yield event;  // Propagate to parent
}
```

## Agent Artifacts

Agents can return structured artifacts:

```typescript
interface AgentArtifact {
  type: 'file_list' | 'dependency_graph' | 'action_plan' | 'report';
  name: string;
  content: unknown;
}

// Example
{
  type: 'file_list',
  name: 'affected_files',
  content: [
    'src/components/Button.tsx',
    'src/styles/button.css',
    'tests/Button.test.tsx'
  ]
}
```

## OLLM CLI Adaptation Notes

### Agent System Reusability
**Status**: ✅ Fully Reusable with Adaptation

The agent architecture is model-agnostic:

1. **AgentRegistry** - Fully reusable
2. **Tool access** - Fully reusable
3. **Event streaming** - Fully reusable
4. **Artifact system** - Fully reusable

### Required Adaptations

1. **Sub-agent Chat Creation**
   - Replace `GeminiChat` with Ollama client
   - Adapt streaming format
   - Adjust context window management

2. **System Prompts**
   - May need shorter prompts for smaller models
   - Adjust complexity expectations

3. **Tool Calling**
   - Adapt tool call format for Ollama
   - Some models may not support function calling

### Model Selection for Agents

Consider using capable models for agent tasks:

```typescript
// For OLLM
const RECOMMENDED_AGENT_MODELS = [
  'llama3:70b',      // Best for complex reasoning
  'codellama:34b',   // Good for code analysis
  'mistral:7b-instruct', // Lighter option
];
```

### Alternative: ReAct Pattern

For models without native tool support, implement ReAct:

```typescript
interface ReActStep {
  thought: string;
  action: string;
  actionInput: Record<string, unknown>;
  observation: string;
}

async function* reactAgent(
  task: string,
  tools: Tool[],
  model: OllamaModel,
): AsyncGenerator<ReActStep> {
  // Parse LLM output for Thought/Action/Action Input
  // Execute action
  // Feed observation back
  // Repeat until Final Answer
}
```
