# Packages and Dependencies Analysis

## Monorepo Structure

Gemini CLI uses npm workspaces for monorepo management:

```json
{
  "workspaces": ["packages/*"]
}
```

## Package Overview

| Package | Size | Purpose |
|---------|------|---------|
| `@google/gemini-cli` | Main | CLI entry point |
| `@google/gemini-cli-core` | ~489 files | Backend logic |
| `@google/gemini-cli-a2a-server` | ~34 files | Agent-to-Agent server |
| `@google/gemini-cli-test-utils` | ~6 files | Test helpers |
| `vscode-ide-companion` | ~21 files | VS Code extension |

## Core Package Dependencies

### AI/ML Integration
```json
{
  "@google/genai": "1.30.0",           // Gemini API client
  "@modelcontextprotocol/sdk": "^1.23.0"  // MCP integration
}
```

### Code Analysis
```json
{
  "web-tree-sitter": "^0.25.10",       // AST parsing
  "tree-sitter-bash": "^0.25.0"        // Bash syntax parsing
}
```

### File System & Search
```json
{
  "fdir": "^6.4.6",                    // Fast directory traversal
  "glob": "^12.0.0",                   // Glob pattern matching
  "ignore": "^7.0.0",                  // .gitignore parsing
  "picomatch": "^4.0.1",               // Pattern matching
  "@joshua.litt/get-ripgrep": "^0.0.3" // Ripgrep binary
}
```

### Text Processing
```json
{
  "diff": "^7.0.0",                    // Text diffing
  "fast-levenshtein": "^2.0.6",        // String similarity
  "marked": "^15.0.12",                // Markdown parsing
  "html-to-text": "^9.0.5",            // HTML conversion
  "chardet": "^2.1.0",                 // Encoding detection
  "js-yaml": "^4.1.1"                  // YAML parsing
}
```

### Networking & HTTP
```json
{
  "undici": "^7.10.0",                 // HTTP client
  "https-proxy-agent": "^7.0.6",       // Proxy support
  "open": "^10.1.2"                    // Open URLs in browser
}
```

### Google Cloud
```json
{
  "@google-cloud/logging": "^11.2.1",
  "@google-cloud/opentelemetry-cloud-monitoring-exporter": "^0.21.0",
  "@google-cloud/opentelemetry-cloud-trace-exporter": "^3.0.0",
  "google-auth-library": "^9.11.0"
}
```

### Telemetry (OpenTelemetry)
```json
{
  "@opentelemetry/api": "^1.9.0",
  "@opentelemetry/exporter-logs-otlp-grpc": "^0.203.0",
  "@opentelemetry/exporter-logs-otlp-http": "^0.203.0",
  "@opentelemetry/exporter-metrics-otlp-grpc": "^0.203.0",
  "@opentelemetry/exporter-metrics-otlp-http": "^0.203.0",
  "@opentelemetry/exporter-trace-otlp-grpc": "^0.203.0",
  "@opentelemetry/exporter-trace-otlp-http": "^0.203.0",
  "@opentelemetry/instrumentation-http": "^0.203.0",
  "@opentelemetry/resource-detector-gcp": "^0.40.0",
  "@opentelemetry/sdk-node": "^0.203.0"
}
```

### Validation
```json
{
  "ajv": "^8.17.1",                    // JSON Schema validation
  "ajv-formats": "^3.0.0",             // Format validators
  "zod": "^3.25.76"                    // TypeScript-first validation
}
```

### Terminal & Shell
```json
{
  "@xterm/headless": "5.5.0",          // Terminal emulation
  "shell-quote": "^1.8.3"              // Shell command parsing
}
```

### Git
```json
{
  "simple-git": "^3.28.0"              // Git operations
}
```

### Miscellaneous
```json
{
  "@iarna/toml": "^2.2.5",             // TOML parsing
  "fzf": "^0.5.2",                     // Fuzzy finder
  "mnemonist": "^0.40.3",              // Data structures
  "uuid": "^13.0.0",                   // UUID generation
  "mime": "4.0.7",                     // MIME type detection
  "strip-ansi": "^7.1.0"               // ANSI code removal
}
```

### Optional/Platform-specific
```json
{
  "@lydell/node-pty": "1.1.0",         // PTY for interactive shells
  "@lydell/node-pty-darwin-arm64": "1.1.0",
  "@lydell/node-pty-darwin-x64": "1.1.0",
  "@lydell/node-pty-linux-x64": "1.1.0",
  "@lydell/node-pty-win32-arm64": "1.1.0",
  "@lydell/node-pty-win32-x64": "1.1.0",
  "keytar": "^7.9.0",                  // Credential storage
  "node-pty": "^1.0.0"                 // Alternative PTY
}
```

## CLI Package Dependencies

### UI Framework
```json
{
  "react": "^19.2.0",                  // React framework
  "ink": "npm:@jrichman/ink@6.4.6",    // Terminal React renderer
  "ink-gradient": "^3.0.0",            // Gradient text
  "ink-spinner": "^5.0.0",             // Loading spinners
  "tinygradient": "^1.1.5"             // Gradient generation
}
```

### Syntax Highlighting
```json
{
  "highlight.js": "^11.11.1",          // Syntax highlighting
  "lowlight": "^3.3.0"                 // Lowlight adapter
}
```

### CLI Utilities
```json
{
  "yargs": "^17.7.2",                  // Argument parsing
  "prompts": "^2.4.2",                 // Interactive prompts
  "clipboardy": "^5.0.0",              // Clipboard access
  "command-exists": "^1.2.9",          // Check command availability
  "dotenv": "^17.1.0",                 // Environment variables
  "strip-json-comments": "^3.1.1"      // JSON5 parsing
}
```

### Additional CLI Dependencies
```json
{
  "@agentclientprotocol/sdk": "^0.11.0",  // ACP support
  "ansi-regex": "^6.2.2",                 // ANSI detection
  "comment-json": "^4.2.5",               // JSON with comments
  "extract-zip": "^2.0.1",                // ZIP extraction
  "latest-version": "^9.0.0",             // Update checking
  "string-width": "^8.1.0",               // Unicode string width
  "tar": "^7.5.2",                        // TAR handling
  "wrap-ansi": "9.0.2"                    // ANSI word wrapping
}
```

## Development Dependencies

### Build Tools
```json
{
  "esbuild": "^0.25.0",                // Fast bundler
  "esbuild-plugin-wasm": "^1.1.0",     // WASM support
  "tsx": "^4.20.3",                    // TypeScript execution
  "typescript": "^5.3.3"               // TypeScript compiler
}
```

### Testing
```json
{
  "vitest": "^3.2.4",                  // Test framework
  "@vitest/coverage-v8": "^3.1.1",     // Coverage
  "ink-testing-library": "^4.0.0",     // Ink component testing
  "msw": "^2.10.4",                    // Mock Service Worker
  "mock-fs": "^5.5.0",                 // File system mocking
  "memfs": "^4.42.0"                   // In-memory file system
}
```

### Linting & Formatting
```json
{
  "eslint": "^9.24.0",
  "eslint-config-prettier": "^10.1.2",
  "eslint-plugin-headers": "^1.3.3",
  "eslint-plugin-import": "^2.31.0",
  "eslint-plugin-react": "^7.37.5",
  "eslint-plugin-react-hooks": "^5.2.0",
  "@vitest/eslint-plugin": "^1.3.4",
  "prettier": "^3.5.3",
  "typescript-eslint": "^8.30.1"
}
```

## Dependency Analysis for OLLM CLI

### Required (Keep or Replace)

| Category | Gemini CLI | OLLM CLI Alternative |
|----------|------------|---------------------|
| **AI Client** | `@google/genai` | `ollama-ai-provider` or custom HTTP client |
| **MCP** | `@modelcontextprotocol/sdk` | Keep as-is (model agnostic) |
| **UI** | React + Ink | Keep as-is |
| **File System** | fdir, glob, ignore | Keep as-is |
| **Telemetry** | OpenTelemetry + GCP | Optional/configurable |
| **Auth** | google-auth-library | Remove (local models) |

### Fully Reusable
- All file system tools (fdir, glob, ignore)
- Terminal handling (xterm/headless, node-pty)
- Text processing (diff, marked, html-to-text)
- UI components (React, Ink, highlight.js)
- CLI utilities (yargs, prompts)
- Git integration (simple-git)

### Removable for OLLM CLI
- Google Cloud dependencies
- OpenTelemetry (or make optional)
- Keytar (no cloud auth needed)
- Some telemetry packages

### New Dependencies for OLLM CLI
```json
{
  "ollama": "^0.5.0",                  // Ollama SDK
  // or
  "ollama-ai-provider": "^0.x.x"       // Vercel AI SDK provider
}
```

## Bundle Size Analysis

The bundled CLI (`bundle/gemini.js`) includes:
- All core dependencies
- Compiled TypeScript
- Tree-shaken unused code

For OLLM CLI:
- Smaller bundle possible without GCP dependencies
- Consider lazy loading for optional features
- WASM dependencies (tree-sitter) add ~5MB

## Security Considerations

### Sensitive Dependencies
- `keytar` - Stores credentials securely
- `google-auth-library` - Handles OAuth tokens
- Environment variable handling

### For OLLM CLI
- No cloud auth needed = simpler security model
- Still need to handle API keys if using remote Ollama
- Consider secure storage for custom model configs
