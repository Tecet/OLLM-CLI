# Configuration System Deep Dive

## Overview

Gemini CLI uses a hierarchical configuration system with multiple sources:
1. Default values (hardcoded)
2. User settings (`~/.gemini/settings.json`)
3. Workspace settings (`.gemini/settings.json`)
4. Environment variables
5. Command-line arguments

## Configuration Files

### Directory Structure

```
~/.gemini/                    # User-level config
├── settings.json             # User settings
├── memory.json               # Saved memories
├── trusted-folders.json      # Folder trust settings
├── extensions/               # User extensions
└── session-data/             # Session history

.gemini/                      # Workspace-level config
├── settings.json             # Project settings
├── GEMINI.md                 # Project context
├── .geminiignore             # File exclusions
├── system.md                 # Custom system prompt
├── skills/                   # Project skills
└── extensions/               # Project extensions
```

### Settings Schema

**Location**: `schemas/settings.schema.json`

Complete settings structure:

```typescript
interface GeminiSettings {
  // Model Configuration
  model?: string;
  previewFeatures?: boolean;
  generation?: {
    aliases?: Record<string, string>;
    overrides?: Record<string, GenerateContentConfig>;
  };

  // Authentication
  security?: {
    auth?: {
      selectedType?: AuthType;
      useExternal?: boolean;
    };
  };

  // Tool Configuration
  tools?: {
    allowedTools?: string[];
    excludeTools?: string[];
    coreTools?: string[];
  };

  // MCP Servers
  mcpServers?: Record<string, MCPServerConfig>;

  // Hooks
  hooks?: {
    [event: HookEventName]?: HookDefinition[];
    disabled?: string[];
  };

  // UI Settings
  ui?: {
    theme?: string;
    incrementalRendering?: boolean;
    hideWindowTitle?: boolean;
  };

  // Accessibility
  accessibility?: {
    disableLoadingPhrases?: boolean;
    screenReader?: boolean;
  };

  // File Filtering
  fileFiltering?: {
    respectGitIgnore?: boolean;
    respectGeminiIgnore?: boolean;
    enableRecursiveFileSearch?: boolean;
    disableFuzzySearch?: boolean;
  };

  // Advanced
  advanced?: {
    dnsResolutionOrder?: 'ipv4first' | 'verbatim';
    autoConfigureMemory?: boolean;
  };

  // Telemetry
  telemetry?: {
    enabled?: boolean;
    target?: TelemetryTarget;
    otlpEndpoint?: string;
    logPrompts?: boolean;
  };

  // Session
  session?: {
    checkpointing?: boolean;
    maxTurns?: number;
    compressionThreshold?: number;
  };

  // Extensions
  extensions?: {
    enabled?: string[];
    management?: boolean;
  };

  // Sandbox
  sandbox?: {
    type?: 'docker' | 'podman' | 'sandbox-exec' | false;
    image?: string;
  };

  // Bug Reporting
  bugCommand?: {
    urlTemplate?: string;
  };
}
```

## Config Class

**Location**: `packages/core/src/config/config.ts`

The `Config` class (~1865 lines) is the central configuration object:

```typescript
class Config {
  // Core getters
  getSessionId(): string
  getModel(): string
  getActiveModel(): string
  getDebugMode(): boolean
  getProjectRoot(): string
  
  // Feature flags
  isInteractive(): boolean
  getCheckpointingEnabled(): boolean
  getIdeMode(): boolean
  getEnableHooks(): boolean
  
  // Service accessors
  getToolRegistry(): ToolRegistry
  getPromptRegistry(): PromptRegistry
  getResourceRegistry(): ResourceRegistry
  getAgentRegistry(): AgentRegistry
  getSkillManager(): SkillManager
  getHookSystem(): HookSystem | undefined
  
  // API client
  getContentGenerator(): ContentGenerator
  getGeminiClient(): GeminiClient
  getBaseLlmClient(): BaseLlmClient
  
  // Policy
  getPolicyEngine(): PolicyEngine
  getMessageBus(): MessageBus
  getApprovalMode(): ApprovalMode
  
  // Authentication
  refreshAuth(authMethod: AuthType): Promise<void>
  
  // Lifecycle
  async initialize(): Promise<void>
}
```

## Authentication Types

```typescript
enum AuthType {
  LOGIN_WITH_GOOGLE = 'login_with_google',
  API_KEY = 'api_key',
  GOOGLE_CLOUD_ADC = 'google_cloud_adc',
  COMPUTE_ADC = 'compute_adc',
  VERTEX_AI = 'vertex_ai',
  SERVICE_ACCOUNT = 'service_account',
  LEGACY_CLOUD_SHELL = 'legacy_cloud_shell',
}
```

## Approval Modes

```typescript
enum ApprovalMode {
  ASK = 'ask',           // Always ask for confirmation
  AUTO = 'auto',         // Auto-approve safe operations
  YOLO = 'yolo',         // Auto-approve everything
}
```

## Environment Variables

### Authentication
```bash
GEMINI_API_KEY          # API key for Gemini
GOOGLE_API_KEY          # Google Cloud API key
GOOGLE_CLOUD_PROJECT    # GCP project ID
GOOGLE_GENAI_USE_VERTEXAI  # Use Vertex AI
```

### Configuration
```bash
GEMINI_SANDBOX          # Sandbox mode (docker/podman/false)
GEMINI_SYSTEM_MD        # Custom system prompt path
GEMINI_WRITE_SYSTEM_MD  # Export system prompt
GEMINI_PROMPT_*         # Individual prompt toggles
```

### Debug
```bash
DEBUG                   # Enable debug mode
GEMINI_CLI_NO_RELAUNCH  # Disable child process relaunch
```

### Telemetry
```bash
GEMINI_TELEMETRY_ENABLED
GEMINI_TELEMETRY_TARGET
GEMINI_OTLP_ENDPOINT
```

## Command-Line Arguments

**Location**: `packages/cli/src/config/config.ts`

```typescript
const parseArguments = async (settings: Settings) => {
  return yargs(hideBin(process.argv))
    .options({
      // Model
      model: { alias: 'm', type: 'string', describe: 'Model to use' },
      
      // Input
      prompt: { alias: 'p', type: 'string', describe: 'Prompt text' },
      promptInteractive: { type: 'boolean', describe: 'Start with prompt but continue interacting' },
      
      // Directories
      includeDirectories: { type: 'array', describe: 'Additional directories' },
      
      // Debug
      debug: { type: 'boolean', describe: 'Enable debug mode' },
      
      // Output
      outputFormat: { type: 'string', choices: ['text', 'json', 'stream-json'] },
      
      // Session
      resume: { alias: 'r', type: 'string', describe: 'Resume session' },
      listSessions: { type: 'boolean', describe: 'List sessions' },
      deleteSession: { type: 'string', describe: 'Delete session' },
      
      // Extensions
      listExtensions: { type: 'boolean', describe: 'List extensions' },
      
      // Sandbox
      sandbox: { type: 'string', describe: 'Sandbox mode' },
      
      // Approval
      yolo: { type: 'boolean', describe: 'Auto-approve all' },
    })
    .parse();
};
```

## Model Configuration

### Model Aliases

```json
{
  "generation": {
    "aliases": {
      "flash": "gemini-2.5-flash",
      "pro": "gemini-2.5-pro",
      "auto": "gemini-2.5-auto"
    }
  }
}
```

### Model Overrides

```json
{
  "generation": {
    "overrides": {
      "gemini-2.5-pro": {
        "temperature": 0.7,
        "topP": 0.9,
        "maxOutputTokens": 8192
      }
    }
  }
}
```

### Default Model Configs

**Location**: `packages/core/src/config/defaultModelConfigs.ts`

```typescript
const DEFAULT_MODEL_CONFIGS = {
  aliases: {
    'auto': 'gemini-2.5-auto',
    'flash': 'gemini-2.5-flash',
    'pro': 'gemini-2.5-pro',
  },
  overrides: {
    'gemini-2.5-flash': {
      httpOptions: { timeout: 300_000 },
    },
  },
};
```

## Settings Loader

**Location**: `packages/cli/src/config/settings.ts`

```typescript
interface LoadedSettings {
  user: Settings;
  workspace: Settings;
  merged: Settings;
  errors: SettingsError[];
  
  setValue(scope: SettingScope, key: string, value: unknown): void
  save(scope: SettingScope): void
}

function loadSettings(): LoadedSettings {
  // 1. Load user settings from ~/.gemini/settings.json
  // 2. Load workspace settings from .gemini/settings.json
  // 3. Merge with defaults
  // 4. Validate with JSON schema
  // 5. Return merged settings
}
```

## Trusted Folders

**Location**: `packages/cli/src/config/trustedFolders.ts`

```json
// ~/.gemini/trusted-folders.json
{
  "folders": {
    "/path/to/project": {
      "trusted": true,
      "approvalMode": "auto"
    }
  }
}
```

## OLLM CLI Adaptation Notes

### Settings Structure
**Status**: ✅ Mostly Reusable

Keep the hierarchical settings system, remove/replace:
- Authentication settings → Ollama connection settings
- Gemini model aliases → Ollama model names
- Telemetry (optional) → Local logging

### New Settings for OLLM CLI

```typescript
interface OllmSettings {
  // Ollama Connection
  ollama?: {
    host?: string;           // http://localhost:11434
    timeout?: number;
    keepAlive?: number;
  };
  
  // Model Settings
  model?: string;
  modelOptions?: {
    temperature?: number;
    numCtx?: number;         // Context window
    numPredict?: number;     // Max tokens
    numGpu?: number;         // GPU layers
  };
  
  // Local Model Management
  models?: {
    autoDownload?: boolean;
    preferredQuantization?: 'q4_0' | 'q4_1' | 'q5_0' | 'q5_1' | 'q8_0';
  };
}
```

### Environment Variables for OLLM

```bash
OLLAMA_HOST          # Ollama server address
OLLAMA_MODEL         # Default model
OLLAMA_TIMEOUT       # Request timeout
```

### Config Class Changes

1. **Remove**: Google auth, Vertex AI, GCP integration
2. **Add**: Ollama client initialization
3. **Keep**: Tool registry, hooks, MCP, extensions
4. **Adapt**: Model routing for local models

### Migration Path

1. Fork `Config` class
2. Replace `ContentGenerator` with Ollama adapter
3. Remove auth-related methods
4. Add Ollama-specific configuration
5. Keep all tool and extension infrastructure
