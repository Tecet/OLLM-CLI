# CLI User Interface Deep Dive

## Overview

Gemini CLI uses **React** with **Ink** to render a rich terminal user interface. Ink is a library that brings React's component model to the terminal, allowing for a reactive, component-based UI architecture.

## UI Technology Stack

| Component | Technology | Version |
|-----------|------------|---------|
| UI Framework | React | ^19.2.0 |
| Terminal Renderer | Ink (fork) | @jrichman/ink@6.4.6 |
| Syntax Highlighting | highlight.js + lowlight | ^11.11.1 |
| Gradient Text | ink-gradient | ^3.0.0 |
| Spinners | ink-spinner | ^5.0.0 |
| Clipboard | clipboardy | ^5.0.0 |

## Main Entry Points

### Interactive Mode
**File**: `packages/cli/src/gemini.tsx`

```typescript
async function startInteractiveUI(
  config: Config,
  settings: LoadedSettings,
  startupWarnings: string[],
  workspaceRoot: string,
  resumedSessionData: ResumedSessionData | undefined,
  initializationResult: InitializationResult,
)
```

The main render uses React with Ink:

```tsx
const instance = render(
  <React.StrictMode>
    <AppWrapper />
  </React.StrictMode>,
  {
    stdout: inkStdout,
    stderr: inkStderr,
    stdin: process.stdin,
    exitOnCtrlC: false,
    isScreenReaderEnabled: config.getScreenReader(),
    onRender: ({ renderTime }) => {
      // Performance monitoring
    },
    alternateBuffer: useAlternateBuffer,
    incrementalRendering: true,
  },
);
```

### Non-Interactive Mode
**File**: `packages/cli/src/nonInteractiveCli.ts`

Runs without UI, outputs to stdout/stderr.

## Component Hierarchy

```
AppWrapper
├── SettingsContext.Provider
│   └── KeypressProvider
│       └── MouseProvider
│           └── ScrollProvider
│               └── SessionStatsProvider
│                   └── VimModeProvider
│                       └── AppContainer
```

## AppContainer (`AppContainer.tsx`)

The main application container (~52KB) orchestrates:

- Authentication flow
- Chat interface
- Tool execution display
- Debug console
- Command palette

### Key State Management

```typescript
// Conversation state
const [history, setHistory] = useState<Content[]>([]);
const [isProcessing, setIsProcessing] = useState(false);
const [pendingToolCalls, setPendingToolCalls] = useState<ToolCall[]>([]);

// UI state
const [showDebugConsole, setShowDebugConsole] = useState(false);
const [showCommandPalette, setShowCommandPalette] = useState(false);
const [inputMode, setInputMode] = useState<'normal' | 'insert'>('insert');
```

## UI Directory Structure

```
packages/cli/src/ui/
├── App.tsx                    # Root app component
├── AppContainer.tsx           # Main container (~52KB)
├── auth/                      # Authentication UI
├── commands/                  # Slash command UIs
├── components/               
│   ├── chat/                  # Chat message components
│   ├── debug/                 # Debug console
│   ├── input/                 # Input field components
│   ├── shared/                # Shared components (Box, Text)
│   ├── tools/                 # Tool execution UI
│   └── ...
├── contexts/                   # React contexts
├── hooks/                      # Custom React hooks
├── themes/                     # Theme definitions
└── utils/                      # UI utilities
```

## Key Components

### 1. Input Components

#### InputPrompt
**File**: `InputPrompt.tsx`

Main input field for user prompts.

```tsx
<InputPrompt
  placeholder="Type a message..."
  onSubmit={handleSubmit}
  multiline={true}
  historyEnabled={true}
/>
```

#### ShellInputPrompt
For interactive shell tool input.

### 2. Chat Components

#### Message Display
- `UserMessage` - User input display
- `ModelMessage` - AI response display
- `ToolCallDisplay` - Tool execution results
- `ErrorMessage` - Error display

#### Streaming
Messages stream in real-time:
```tsx
<StreamingText content={partialResponse} />
```

### 3. Tool UI Components

#### ToolConfirmation
Displays confirmation dialogs:
```tsx
<ToolConfirmation
  toolName="edit_file"
  description="Edit src/main.ts"
  diff={changes}
  onConfirm={handleConfirm}
  onCancel={handleCancel}
/>
```

#### ToolOutput
Shows tool execution results:
```tsx
<ToolOutput
  toolName="run_shell_command"
  output={commandOutput}
  isStreaming={isRunning}
/>
```

### 4. Debug Console

**File**: `DebugConsole.tsx`

Accessible via F12, shows:
- Console logs
- API calls
- Tool invocations
- Performance metrics

## Custom Hooks

### Core Hooks

#### `useGeminiChat`
Manages chat interaction with the Gemini API.

```typescript
const {
  sendMessage,
  history,
  isProcessing,
  abort,
} = useGeminiChat(config);
```

#### `useKeypress`
Handles keyboard input.

```typescript
useKeypress((key) => {
  if (key.ctrl && key.name === 'c') {
    abort();
  }
});
```

#### `usePromptCompletion`
Tab completion for commands and file paths.

#### `useAlternateBuffer`
Manages terminal alternate screen buffer.

### UI State Hooks

#### `useScrollPosition`
Manages scroll state in long outputs.

#### `useTheme`
Theme context provider.

```typescript
const { colors, styles } = useTheme();
```

## Context Providers

### SettingsContext
Global settings access:
```typescript
const settings = useContext(SettingsContext);
```

### VimModeContext
Vi key bindings:
```typescript
const { mode, setMode } = useVimMode();
// mode: 'normal' | 'insert' | 'visual'
```

### MouseContext
Mouse event handling (for alternate buffer mode).

### KeypressContext
Centralized keypress handling.

### SessionStatsContext
Token usage and session statistics.

## Themes

**Directory**: `packages/cli/src/ui/themes/`

Built-in themes:
- Default (dark)
- Light
- Custom themes via settings

Theme structure:
```typescript
interface Theme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    success: string;
    error: string;
    warning: string;
    info: string;
    background: string;
    foreground: string;
    // ...
  };
  styles: {
    // Component-specific styles
  };
}
```

## Keyboard Shortcuts

From `docs/cli/keyboard-shortcuts.md`:

| Key | Action |
|-----|--------|
| `Ctrl+C` | Cancel current operation |
| `Ctrl+D` | Exit |
| `Ctrl+L` | Clear screen |
| `Ctrl+R` | Search history |
| `F12` | Toggle debug console |
| `Tab` | Autocomplete |
| `Esc` | Cancel/exit |

## Screen Reader Support

**Files**: `ConsentPrompt.tsx`, `InputPrompt.tsx`

When `accessibility.screenReader` is enabled:
- Disables loading phrases
- Uses plain text output
- Enables ARIA labels
- Avoids animations

```tsx
const { screenReader } = useContext(SettingsContext);

if (screenReader) {
  return <Text>{plainTextOutput}</Text>;
}
```

## Performance Optimizations

### Incremental Rendering
Only re-renders changed portions:
```typescript
{
  incrementalRendering: true,
}
```

### Slow Render Detection
```typescript
onRender: ({ renderTime }) => {
  if (renderTime > 200) {
    recordSlowRender(config, renderTime);
  }
}
```

### Buffer Management
Uses alternate screen buffer for better scrolling:
```typescript
enterAlternateScreen();
disableLineWrapping();
```

## OLLM CLI Adaptation Notes

For creating an Ollama-based CLI:

1. **Component Reuse**
   - All Ink components are model-agnostic
   - Themes, inputs, and displays fully reusable
   - Only need to adapt streaming format

2. **Streaming Adaptation**
   - Gemini uses `AsyncGenerator<ServerGeminiStreamEvent>`
   - Ollama uses different streaming format
   - Create adapter for `useGeminiChat` → `useOllamaChat`

3. **Tool UI**
   - Tool confirmation UI is fully reusable
   - May need to adapt tool call format display

4. **Settings**
   - Can reuse settings structure
   - Remove Gemini-specific auth settings

5. **Performance**
   - Local models may have different latency patterns
   - Consider progress indicators for model loading

6. **Model Selection**
   - Replace Gemini model dropdown with Ollama model list
   - Add model download/management UI
