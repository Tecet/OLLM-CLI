# Gemini CLI Architecture Overview

## Executive Summary

Gemini CLI is a comprehensive AI-powered command-line interface that brings Google's Gemini model directly to the terminal. It's built as a **TypeScript monorepo** with a modular architecture separating concerns between the CLI frontend and the core backend.

## Technology Stack

| Component | Technology |
|-----------|------------|
| Language | TypeScript (ES Modules) |
| Runtime | Node.js (≥20.0.0) |
| Package Manager | npm with workspaces |
| Build System | esbuild |
| UI Framework | React + Ink (terminal UI) |
| Testing | Vitest |
| Linting | ESLint + Prettier |

## Monorepo Structure

```
gemini-cli/
├── packages/
│   ├── cli/              # Frontend CLI package
│   ├── core/             # Backend core logic
│   ├── a2a-server/       # Agent-to-Agent server
│   ├── test-utils/       # Shared test utilities
│   └── vscode-ide-companion/  # VS Code extension
├── docs/                 # Documentation
├── integration-tests/    # E2E tests
├── scripts/              # Build & automation scripts
└── schemas/              # JSON schemas
```

## Core Packages

### 1. CLI Package (`packages/cli`)

**Purpose**: User-facing terminal interface

**Key Responsibilities**:
- Command-line argument parsing (yargs)
- Terminal UI rendering (React + Ink)
- User input handling
- Display formatting and theming
- Session management
- Authentication flow UI

**Main Entry Point**: `gemini.tsx`

**Key Components**:
- `AppContainer.tsx` - Main application container (~52KB)
- `nonInteractiveCli.ts` - Headless mode execution
- `ui/` - React components for terminal UI
- `config/` - CLI-specific configuration
- `commands/` - Slash command implementations

### 2. Core Package (`packages/core`)

**Purpose**: Backend business logic and AI interaction

**Key Responsibilities**:
- Gemini API communication
- System prompt management
- Tool registration and execution
- MCP (Model Context Protocol) integration
- Chat history management
- Authentication handling
- Telemetry

**Key Modules**:
```
packages/core/src/
├── agents/          # Agent system (delegation, codebase investigator)
├── config/          # Configuration management
├── core/            # Core Gemini client & chat
├── hooks/           # Hook system for customization
├── mcp/             # MCP OAuth & authentication
├── policy/          # Approval policies
├── prompts/         # Prompt registry
├── routing/         # Model routing
├── services/        # Business logic services
├── telemetry/       # Telemetry and logging
├── tools/           # Built-in tools
└── utils/           # Utility functions
```

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Terminal                             │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CLI Package (packages/cli)                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │   Input     │  │   React     │  │   Config    │             │
│  │  Handler    │→ │   + Ink     │  │   Loader    │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Core Package (packages/core)                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  GeminiChat │→ │  ToolReg.   │→ │   MCP       │             │
│  │   (Turn)    │  │  (Execute)  │  │   Client    │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│         │                                                       │
│         ▼                                                       │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │              ContentGenerator (API Client)                  ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Gemini API (Google Cloud)                     │
└─────────────────────────────────────────────────────────────────┘
```

## Key Design Patterns

### 1. Event-Driven Architecture
The system uses an event emitter pattern (`coreEvents`) for loose coupling between components:
- `CoreEvent.Output` - Stream output
- `CoreEvent.ConsoleLog` - Console messages
- `CoreEvent.UserFeedback` - User-facing messages

### 2. Message Bus Pattern
A `MessageBus` class handles tool confirmation requests and policy decisions, enabling decoupled communication between the policy engine and tool execution.

### 3. Registry Pattern
Tools, prompts, and resources use registry patterns:
- `ToolRegistry` - Manages available tools
- `PromptRegistry` - Manages prompt templates
- `ResourceRegistry` - Manages MCP resources
- `AgentRegistry` - Manages sub-agents

### 4. Hook System
Extensible hooks for customization:
- `beforeAgent` / `afterAgent`
- `beforeModel` / `afterModel`
- `beforeToolSelection`
- `sessionStart` / `sessionEnd`

## Configuration Hierarchy

1. **User Settings** (`~/.gemini/settings.json`)
2. **Workspace Settings** (`.gemini/settings.json`)
3. **Context Files** (`GEMINI.md`)
4. **Environment Variables**
5. **Command-line Arguments**

## Key Dependencies

| Package | Purpose |
|---------|---------|
| `@google/genai` | Gemini API client |
| `@modelcontextprotocol/sdk` | MCP integration |
| `ink` | Terminal React UI |
| `yargs` | CLI argument parsing |
| `zod` | Schema validation |
| `simple-git` | Git operations |
| `web-tree-sitter` | Code parsing |

## Security Architecture

- **Policy Engine**: Controls tool execution permissions
- **Approval Modes**: ASK, AUTO, YOLO
- **Sandbox Support**: Docker, Podman, macOS Sandbox-exec
- **OAuth Integration**: For MCP servers and authentication
- **Environment Sanitization**: Prevents secret exposure

## OLLM CLI Adaptation Notes

For converting to Ollama-based CLI:

1. **Replace `@google/genai`** with Ollama client
2. **Adapt `ContentGenerator`** interface for local models
3. **Simplify authentication** (local models don't need OAuth)
4. **Maintain tool system** (fully reusable)
5. **Keep MCP integration** (model-agnostic)
6. **Reuse UI components** (Ink-based rendering)
