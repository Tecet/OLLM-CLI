# Tools System Deep Dive

## Overview

Gemini CLI features a comprehensive tools system that enables the AI to interact with the file system, execute commands, search the web, and integrate with external services via MCP.

## Tool Architecture

### Core Interfaces

```typescript
// Base tool invocation interface
interface ToolInvocation<TParams, TResult> {
  params: TParams;
  getDescription(): string;
  toolLocations(): ToolLocation[];
  shouldConfirmExecute(abortSignal: AbortSignal): Promise<ToolCallConfirmationDetails | false>;
  execute(
    signal: AbortSignal,
    updateOutput?: (output: string | AnsiOutput) => void,
    shellExecutionConfig?: ShellExecutionConfig,
  ): Promise<TResult>;
}

// Tool builder interface
interface DeclarativeTool<TParams, TResult> {
  name: string;
  displayName: string;
  serverName?: string;  // For MCP tools
  schema: FunctionDeclaration;
  parameterSchema?: Record<string, unknown>;
  createInvocation(
    params: TParams,
    messageBus: MessageBus,
    toolName?: string,
    displayName?: string,
  ): ToolInvocation<TParams, TResult>;
}
```

### Tool Registry

The `ToolRegistry` class manages all available tools:

```typescript
class ToolRegistry {
  registerTool(tool: AnyDeclarativeTool): void
  unregisterTool(name: string): void
  getTool(name: string): AnyDeclarativeTool | undefined
  getAllTools(): AnyDeclarativeTool[]
  getAllToolNames(): string[]
  getFunctionDeclarations(): FunctionDeclaration[]
  getToolsByServer(serverName: string): AnyDeclarativeTool[]
  discoverAllTools(): Promise<void>
}
```

## Built-in Tools

### 1. File System Tools

#### `read_file`
**File**: `read-file.ts`

Reads file contents from the file system.

**Parameters**:
```typescript
{
  path: string;        // Absolute path to the file
  startLine?: number;  // Optional start line (1-indexed)
  endLine?: number;    // Optional end line (1-indexed)
}
```

**Features**:
- Line range support
- Binary file handling (images, videos)
- File size limits
- Encoding detection (chardet)

#### `read_many_files`
**File**: `read-many-files.ts`

Reads multiple files in parallel.

**Parameters**:
```typescript
{
  paths: string[];  // Array of absolute file paths
}
```

#### `write_new_file` / `create_file`
**File**: `write-file.ts`

Creates new files or overwrites existing ones.

**Parameters**:
```typescript
{
  path: string;
  content: string;
  overwrite?: boolean;
}
```

**Features**:
- Directory creation (recursive)
- Overwrite protection
- Content validation

#### `edit_file`
**File**: `edit.ts` (~35KB - most complex tool)

Edits existing files with target/replacement patterns.

**Parameters**:
```typescript
{
  path: string;
  edits: Array<{
    target: string;
    replacement: string;
    startLine?: number;
    endLine?: number;
  }>;
}
```

**Features**:
- Multi-edit support
- Line range targeting
- Diff generation (for confirmation)
- Fuzzy matching
- Change detection

### 2. Search Tools

#### `glob_tool`
**File**: `glob.ts`

Searches for files by name pattern using fdir.

**Parameters**:
```typescript
{
  pattern: string;      // Glob pattern
  directory?: string;   // Search directory
  maxResults?: number;  // Limit results
  includeHidden?: boolean;
}
```

#### `grep_search`
**File**: `grep.ts`

Searches file contents for patterns.

**Parameters**:
```typescript
{
  pattern: string;
  directory?: string;
  filePattern?: string;
  caseSensitive?: boolean;
  maxResults?: number;
}
```

#### `ripgrep` (Optional)
**File**: `ripGrep.ts`

High-performance search using ripgrep binary.

**Features**:
- Automatic binary detection
- Fallback to grep_search
- Respects .gitignore
- Parallel execution

### 3. Shell Tool

**File**: `shell.ts` (~16KB)

Executes shell commands.

**Parameters**:
```typescript
{
  command: string;
  cwd?: string;
  timeout?: number;
  background?: boolean;
}
```

**Features**:
- Interactive shell support (via node-pty)
- Background process management
- Output streaming
- Timeout handling
- Environment sanitization
- Inactivity timeout (5 min default)

**Shell Execution Service** (`shellExecutionService.ts`):
- Terminal emulation via xterm-headless
- Color output support
- Width/height configuration
- PAGER=cat enforcement

### 4. Web Tools

#### `web_fetch`
**File**: `web-fetch.ts`

Fetches and converts web pages to markdown.

**Parameters**:
```typescript
{
  url: string;
  selector?: string;   // CSS selector to extract
  maxLength?: number;
}
```

**Features**:
- HTML to text conversion (html-to-text library)
- CSS selector support
- Content length limits
- Proxy support

#### `web_search`
**File**: `web-search.ts`

Performs web searches via Google Search grounding.

**Parameters**:
```typescript
{
  query: string;
  numResults?: number;
}
```

### 5. Memory Tool
**File**: `memoryTool.ts`

Persists user preferences and facts.

**Parameters**:
```typescript
{
  action: 'save' | 'get' | 'list' | 'delete';
  key?: string;
  value?: string;
}
```

**Storage**:
- User-level: `~/.gemini/memory.json`
- Project-level: `.gemini/memory.json`

### 6. List Directory Tool
**File**: `ls.ts`

Lists directory contents with metadata.

**Parameters**:
```typescript
{
  path: string;
  recursive?: boolean;
  includeHidden?: boolean;
  maxDepth?: number;
}
```

### 7. TODO/Task Tool
**File**: `write-todos.ts`

Manages task lists and to-do items.

**Parameters**:
```typescript
{
  action: 'add' | 'complete' | 'list' | 'clear';
  task?: string;
  id?: number;
}
```

### 8. Activate Skill Tool
**File**: `activate-skill.ts`

Activates predefined skill modules.

**Parameters**:
```typescript
{
  skillName: string;
}
```

## MCP (Model Context Protocol) Integration

### MCP Client
**File**: `mcp-client.ts` (~57KB - largest single file)

Full implementation of MCP SDK client.

**Features**:
- STDIO, SSE, and HTTP transports
- OAuth authentication
- Service account impersonation
- Tool discovery and registration
- Resource and prompt discovery
- Dynamic tool updates (listChanged)

### MCP Tool Wrapper
**File**: `mcp-tool.ts`

Wraps MCP tools as native tools.

```typescript
class DiscoveredMCPTool implements DeclarativeTool {
  constructor(
    serverName: string,
    mcpTool: McpTool,
    client: Client,
    config: Config,
  );
}
```

## Tool Confirmation System

### Policy Engine
All tools integrate with the policy engine for confirmation:

```typescript
enum ToolConfirmationOutcome {
  PROCEED = 'proceed',
  PROCEED_ALWAYS = 'proceed_always',
  PROCEED_ALWAYS_SAVE = 'proceed_always_save',
  CANCEL = 'cancel',
}
```

### Confirmation Flow
1. Tool invocation created
2. `shouldConfirmExecute()` called
3. Policy engine consulted
4. If `ASK_USER` → UI displays confirmation
5. User responds → Policy updated
6. Tool executes or cancels

## Tool Output Handling

### Truncation
Long outputs are automatically truncated:
- Default threshold: 4,000,000 characters
- Default line limit: 1,000 lines

### Streaming
Tools can stream output via callback:
```typescript
execute(
  signal: AbortSignal,
  updateOutput?: (output: string | AnsiOutput) => void
)
```

## OLLM CLI Adaptation Notes

For adapting to Ollama:

1. **Tool Calling Format**
   - Gemini uses `functionCall` / `functionResponse`
   - Ollama uses different format depending on model
   - Create adapter layer for tool call translation

2. **Tool Registration**
   - Keep `ToolRegistry` pattern
   - Adapt `FunctionDeclaration` to Ollama format
   - Map JSON Schema to tool definitions

3. **MCP Integration**
   - MCP is model-agnostic, can reuse entirely
   - OAuth may need simplification for local use

4. **Shell Tool**
   - Fully reusable, no model dependencies
   - Consider safety for local execution

5. **Web Tools**
   - Fully reusable
   - Consider local web search alternatives

6. **File Tools**
   - Fully reusable
   - May need to adjust path handling

7. **Confirmation System**
   - Fully reusable
   - Policy engine is model-agnostic
