# Hooks and Extensions System

## Overview

Gemini CLI provides a powerful extensibility layer through:
1. **Hook System** - Event-driven customization points
2. **Extension System** - Package-based plugins
3. **MCP (Model Context Protocol)** - External tool integration
4. **Skills** - Task-specific instruction modules

## Hook System

### Architecture

**Location**: `packages/core/src/hooks/`

```
hooks/
├── hookAggregator.ts      # Combines multiple hook outputs
├── hookEventHandler.ts    # Main event processing
├── hookPlanner.ts         # Determines which hooks to run
├── hookRegistry.ts        # Hook registration & storage
├── hookRunner.ts          # Executes hook scripts
├── hookSystem.ts          # Main orchestration
├── hookTranslator.ts      # Input/output translation
├── trustedHooks.ts        # Trust verification
├── types.ts               # Type definitions
└── index.ts               # Exports
```

### Hook Events

```typescript
type HookEventName =
  | 'session_start'
  | 'session_end'
  | 'before_agent'
  | 'after_agent'
  | 'before_model'
  | 'after_model'
  | 'before_tool_selection'
  | 'after_tool_context';
```

### Hook Definition

```typescript
interface HookDefinition {
  name: string;
  description?: string;
  event: HookEventName;
  command: string | string[];  // Shell command(s)
  cwd?: string;
  env?: Record<string, string>;
  timeout?: number;  // milliseconds
  enabled?: boolean;
}
```

### Hook Configuration

In `settings.json`:
```json
{
  "hooks": {
    "session_start": [
      {
        "name": "load-context",
        "command": "cat .context/summary.md",
        "timeout": 5000
      }
    ],
    "before_agent": [
      {
        "name": "input-validator",
        "command": ["node", "scripts/validate.js"]
      }
    ],
    "disabled": ["hook-name-to-skip"]
  }
}
```

### Hook Input/Output Protocol

**Input** (via stdin as JSON):
```json
{
  "event": "before_agent",
  "data": {
    "request": "User's message...",
    "history": [...]
  }
}
```

**Output** (via stdout as JSON):
```json
{
  "decision": "proceed",  // or "stop", "block"
  "reason": "Optional explanation",
  "additionalContext": "Extra context to add",
  "systemMessage": "Message to show user"
}
```

### Hook Triggers

**Session Lifecycle**:
```typescript
// On session start
await hookSystem.fireSessionStartEvent(SessionStartSource.Startup);

// On session end
await hookSystem.fireSessionEndEvent(SessionEndReason.Exit);
```

**Agent Events**:
```typescript
// Before agent processes request
const result = await fireBeforeAgentHook(messageBus, request);
if (result?.shouldStopExecution()) {
  return; // Stop processing
}

// After agent completes
await fireAfterAgentHook(messageBus, request, response);
```

**Model Events**:
```typescript
// Before calling the model
const beforeResult = await fireBeforeModelHook(messageBus, {
  model: modelToUse,
  config,
  contents: contentsToUse,
});

// After model responds
await fireAfterModelHook(messageBus, originalRequest, response);
```

### Hook Trust Model

Hooks from untrusted sources require explicit approval:

```typescript
interface TrustedHookInfo {
  hash: string;
  approvedAt: number;
  source: 'user' | 'workspace' | 'extension';
}
```

## Extension System

### Architecture

**Location**: `packages/cli/src/config/extension-manager.ts`

Extensions are directories containing:
```
my-extension/
├── manifest.json          # Extension metadata
├── GEMINI.md              # Context for AI
├── settings.json          # Extension settings
└── tools/                 # Custom tools (optional)
```

### Manifest Format

```json
{
  "name": "my-extension",
  "version": "1.0.0",
  "description": "Extension description",
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["server.js"]
    }
  },
  "hooks": {
    "session_start": [{
      "name": "init",
      "command": "echo 'Extension loaded'"
    }]
  },
  "settings": [{
    "name": "apiKey",
    "description": "API key for service",
    "envVar": "MY_API_KEY",
    "sensitive": true
  }],
  "skills": [{
    "name": "code-review",
    "description": "Perform code review"
  }]
}
```

### Extension Locations

1. **User Extensions**: `~/.gemini/extensions/`
2. **Workspace Extensions**: `.gemini/extensions/`

### Extension Manager

```typescript
class ExtensionManager {
  constructor(options: {
    workspaceDir: string;
    settings: Settings;
    enabledExtensionOverrides: string[];
    requestConsent: (ext: Extension) => Promise<boolean>;
    requestSetting: (setting: ExtensionSetting) => Promise<string>;
  });
  
  async start(config: Config): Promise<void>
  getExtensions(): GeminiCLIExtension[]
  getExtension(name: string): GeminiCLIExtension | undefined
}
```

### Extension Installation

From GitHub:
```bash
gemini /extension install github:owner/repo
```

From local directory:
```bash
gemini /extension link /path/to/extension
```

## MCP Integration

### MCP Server Configuration

In `settings.json`:
```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}"
      }
    },
    "remote-server": {
      "url": "https://mcp.example.com",
      "type": "http",
      "headers": {
        "Authorization": "Bearer ${API_KEY}"
      }
    }
  }
}
```

### MCP Server Types

1. **STDIO Transport**
   ```json
   {
     "command": "python",
     "args": ["mcp_server.py"],
     "cwd": "/path/to/server"
   }
   ```

2. **SSE Transport**
   ```json
   {
     "url": "https://server.example.com/sse",
     "type": "sse"
   }
   ```

3. **HTTP Streamable Transport**
   ```json
   {
     "url": "https://server.example.com/api",
     "type": "http"
   }
   ```

### MCP OAuth Support

```json
{
  "mcpServers": {
    "oauth-server": {
      "url": "https://mcp.example.com",
      "oauth": {
        "enabled": true,
        "authorizationUrl": "https://auth.example.com/authorize",
        "tokenUrl": "https://auth.example.com/token",
        "scopes": ["read", "write"]
      }
    }
  }
}
```

### MCP Features Used

- **tools/list** - Discover available tools
- **tools/call** - Execute tools
- **prompts/list** - Discover prompts
- **prompts/get** - Get prompt content
- **resources/list** - List available resources
- **resources/read** - Read resource content
- **notifications** - Dynamic updates

## Skills System

### Architecture

**Location**: `packages/core/src/skills/`

Skills are task-specific instruction modules that can be activated on-demand.

### Skill Definition

```typescript
interface SkillDefinition {
  name: string;
  description: string;
  location: string;  // Path to skill file
}
```

### Skill File Format

`.gemini/skills/code-review.md`:
```markdown
# Code Review Skill

## Instructions

When performing code reviews, follow these steps:

1. Check for security vulnerabilities
2. Verify coding standards compliance
3. Review test coverage
4. Assess performance implications

## Resources

- Company style guide: /docs/style-guide.md
- Security checklist: /docs/security.md
```

### Skill Activation

Via the `activate_skill` tool:
```typescript
{
  skillName: "code-review"
}
```

The AI receives:
```xml
<activated_skill>
  <instructions>
    When performing code reviews...
  </instructions>
  <available_resources>
    /docs/style-guide.md
    /docs/security.md
  </available_resources>
</activated_skill>
```

### Skill Discovery

Skills are discovered from:
1. `.gemini/skills/` directory
2. Extension manifests
3. Settings configuration

## OLLM CLI Adaptation Notes

### Hook System
**Status**: ✅ Fully Reusable

The hook system is completely model-agnostic:
- Shell command execution
- JSON input/output protocol
- Event-driven architecture

### Extension System
**Status**: ✅ Fully Reusable

Extensions work independently of the AI model:
- Manifest-based configuration
- MCP server management
- Context file loading

### MCP Integration
**Status**: ✅ Fully Reusable

MCP is designed to be model-agnostic:
- Standard protocol
- OAuth handling
- Transport abstraction

**Considerations**:
- Tool call format translation needed
- May need to adapt MCP tool schemas for Ollama

### Skills System
**Status**: ✅ Fully Reusable

Skills are just markdown instructions:
- Model-agnostic content
- Path resolution
- Activation mechanism

### Recommended Changes for OLLM CLI

1. **Hook Input Format**
   - May need to adapt data structure for Ollama's format
   - Keep same JSON protocol

2. **Extension Settings**
   - Remove Gemini-specific settings
   - Add Ollama model selection

3. **MCP Tool Translation**
   - Create adapter for Ollama tool call format
   - Handle different response structures

4. **New Extension Capabilities**
   - Model download/management
   - Quantization options
   - Hardware detection (GPU/CPU)
